export const environment = {
	production: false,
	apiAvailable: true,
	baseUrl: 'https://qdeloittecertifiedapi.deloitte.com/api',
	baseUrlNotification: 'https://localhost:7153/notification',
	clientId: '73577ef6-d898-4cb6-a192-7b4267980c75',
	authority: 'https://login.microsoftonline.com/36da45f1-dd2c-4d1f-af13-5abe46b99921',
	graphUrl: 'https://graph.microsoft.com/v1.0/me',
	apiScope: 'https://qdeloittecertifiedapi.deloitte.com/user_impersonation',
	credlyRoute: 'https://sandbox.credly.com/users/sign_in'
};
