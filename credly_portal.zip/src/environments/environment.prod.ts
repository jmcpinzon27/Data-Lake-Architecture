export const environment = {
	production: true,
	apiAvailable: true,
	credlyRoute: 'https://www.credly.com/signin/deloitte-us',
	baseUrl: 'https://deloittecertifiedapi.deloitte.com/api'
};
