export const environment = {
	production: false,
	apiAvailable: true,
	baseUrl: 'https://dintdeloittecertifiedapi.deloitte.com/api',
	baseUrlNotification: 'https://dintdeloittecertifiedapi.deloitte.com/notification',
	clientId: '3268052c-3758-4ad9-9ea7-65919ed471c0',
	authority: 'https://login.microsoftonline.com/36da45f1-dd2c-4d1f-af13-5abe46b99921',
	graphUrl: 'https://graph.microsoft.com/v1.0/me',
	apiScope: 'https://dintdeloittecertifiedapi.deloitte.com/user_impersonation',
	credlyRoute: 'https://sandbox.credly.com/users/sign_in'
};