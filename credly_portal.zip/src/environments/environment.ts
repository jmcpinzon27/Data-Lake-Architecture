export const environment = {
	production: false,
	apiAvailable: true,
	baseUrl: 'https://ddeloittecertifiedapi.deloitte.com/api',
	//baseUrl: 'https://ddigitalcredentialingapi.deloitte.com:7153/api',
	baseUrlNotification: 'https://ddeloittecertifiedapi.deloitte.com/notification',
	clientId: '490d1385-2be8-44b1-a371-692b03407345',
	authority: 'https://login.microsoftonline.com/36da45f1-dd2c-4d1f-af13-5abe46b99921',
	graphUrl: 'https://graph.microsoft.com/v1.0/me',
	apiScope: 'https://ddeloittecertifiedapi.deloitte.com/user_impersonation',
	credlyRoute: 'https://sandbox.credly.com/users/sign_in'
};
