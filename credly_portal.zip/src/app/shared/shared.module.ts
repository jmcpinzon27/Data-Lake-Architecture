import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { CommonModule } from '@angular/common';
import { LibModule } from '@usitsdasdesign/dds-ng';
import { ExpandableRowModule } from '@usitsdasdesign/dds-ng/shared/expandable-row';
import { FilterModule } from '@usitsdasdesign/dds-ng/filter';
import { SortByModule } from '@usitsdasdesign/dds-ng/shared/sort-by';
import { HighlightModule } from '@usitsdasdesign/dds-ng/shared/highlight';
import { FocusHandlerModule } from '@usitsdasdesign/dds-ng/core/focus-handler';
import { CheckboxModule } from '@usitsdasdesign/dds-ng/checkbox';
import { StickerModule } from '@usitsdasdesign/dds-ng/sticker';
import { ToastModule } from '@usitsdasdesign/dds-ng/toast';
import { ButtonModule } from '@usitsdasdesign/dds-ng/button';
import { SpinnerModule } from '@usitsdasdesign/dds-ng/spinner';
import { PaginationModule } from '@usitsdasdesign/dds-ng/pagination';
import { SelectModule } from '@usitsdasdesign/dds-ng/select';
import { WizardModule } from '@usitsdasdesign/dds-ng/wizard';
import { TextareaModule } from '@usitsdasdesign/dds-ng/textarea';
import { TabsModule } from '@usitsdasdesign/dds-ng/tabs';
import { AccordionModule } from '@usitsdasdesign/dds-ng/accordion';
import { InputModule } from '@usitsdasdesign/dds-ng/input';
import { DatepickerModule } from '@usitsdasdesign/dds-ng/datepicker';
import { ChartsModule } from '@progress/kendo-angular-charts';
import { DataGridComponent } from './components/data-grid/data-grid.component';
import { NotFoundComponent } from './features/not-found/not-found.component';
import { DrawerComponent } from './layout/default/drawer/drawer.component';
import { HeaderComponent } from './layout/default/header/header.component';
import { FooterComponent } from './layout/default/footer/footer.component';
import { DefaultLayoutComponent } from './layout/default/default-layout/default-layout.component';
import { BreadcrumbsComponent } from './layout/default/breadcrumbs/breadcrumbs.component';
import { LoadingComponent } from './components/loading/loading.component';
import { ModalComponent } from './components/modal/modal.component';
import { NotificationComponent } from './components/notification/notification.component';
import { NotificationMenuComponent } from './layout/default/notification-menu/notification-menu.component';
import { BadgeFilterComponent } from './components/badge-filter/badge-filter.component';
import { CustomTreeComponent } from './components/custom-tree/custom-tree.component';
import { BadgeWizardComponent } from './components/badge-wizard/badge-wizard.component';
import { SplitByUpperPipe, StatusTransformPipe, StatusBulkAwardedPipe, OrdinalPipe } from './pipes';
import { ActionListComponent } from './components/action-list/action-list.component';
import { BadgeApprovalComponent } from './features/badge-approval/badge-approval.component';
import { BadgePreviewComponent } from './components/badge-preview/badge-preview.component';
import { StatusBarComponent } from './components/status-bar/status-bar.component';
import { GenericModalComponent } from './generic-modal/generic-modal.component';
import { ColorByStatusDirective } from './directives/color-by-status.directive';
import { NgxDropzoneModule } from 'ngx-dropzone';
import { BadgeFilterHeaderComponent } from './components/badge-filter/badge-filter-header/badge-filter-header.component';
import { BadgeFilterGridComponent } from './components/badge-filter/badge-filter-grid/badge-filter-grid.component';
import { ReactiveFormsModule } from '@angular/forms';
import { ConnectCredlyComponent } from './components/connect-credly/connect-credly.component';
import { ProficiencySkillComponent } from './components/proficiency-skill/proficiency-skill.component';
import { DeepLinksComponent } from './components/deep-links/deep-links.component';
import { SearchMobileComponent } from './components/badge-filter/search-mobile/search-mobile.component';
import { SkillsLevelsFilterComponent } from './components/badge-filter/search-mobile/skills-levels-filter/skills-levels-filter.component';


@NgModule({
	declarations: [
		DataGridComponent,
		NotFoundComponent,
		HeaderComponent,
		FooterComponent,
		DrawerComponent,
		DefaultLayoutComponent,
		BreadcrumbsComponent,
		LoadingComponent,
		ModalComponent,
		NotificationMenuComponent,
		NotificationComponent,
		BadgeFilterComponent,
		BadgeWizardComponent,
		CustomTreeComponent,
		SplitByUpperPipe,
		ActionListComponent,
		BadgeApprovalComponent,
		BadgePreviewComponent,
		BadgeApprovalComponent,
		StatusBarComponent,
		GenericModalComponent,
		ColorByStatusDirective,
		StatusTransformPipe,
		BadgeFilterHeaderComponent,
		BadgeFilterGridComponent,
		StatusBulkAwardedPipe,
		OrdinalPipe,
		ProficiencySkillComponent,
  		DeepLinksComponent,
		ConnectCredlyComponent,
  SearchMobileComponent,
  SkillsLevelsFilterComponent
	],
	imports: [
		CommonModule,
		ReactiveFormsModule,
		SpinnerModule,
		LibModule,
		CheckboxModule,
		PaginationModule,
		ExpandableRowModule,
		FilterModule,
		SortByModule,
		HighlightModule,
		FocusHandlerModule,
		StickerModule,
		ToastModule,
		ButtonModule,
		SelectModule,
		WizardModule,
		ChartsModule,
		RouterModule,
		TextareaModule,
		TabsModule,
		AccordionModule,
		InputModule,
		DatepickerModule,
		NgxDropzoneModule
	],
	exports: [
		DataGridComponent,
		NotFoundComponent,
		DefaultLayoutComponent,
		LoadingComponent,
		BadgeFilterComponent,
		ButtonModule,
		BadgeWizardComponent,
		CustomTreeComponent,
		SplitByUpperPipe,
		BreadcrumbsComponent,
		ActionListComponent,
		TextareaModule,
		TabsModule,
		AccordionModule,
		InputModule,
		SelectModule,
		StickerModule,
		BadgePreviewComponent,
		DatepickerModule,
		StatusTransformPipe,
		StatusBulkAwardedPipe,
		BadgeApprovalComponent,
		GenericModalComponent,
		StatusBarComponent,
		OrdinalPipe,
		ProficiencySkillComponent,
		NgxDropzoneModule,
		ReactiveFormsModule,
		LibModule,
		DeepLinksComponent,
		ConnectCredlyComponent
	]
})
export class SharedModule {}
