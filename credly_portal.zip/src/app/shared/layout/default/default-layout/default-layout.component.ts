import { BreadCrumbService } from '@/core/services/store';
import { Component } from '@angular/core';

@Component({
	selector: 'app-default-layout',
	templateUrl: './default-layout.component.html',
	styleUrls: ['./default-layout.component.scss']
})
export class DefaultLayoutComponent {
	hideBreadCrumb = false;
	constructor(private breadCrumbService: BreadCrumbService) {
		this.breadCrumbService.getHideBreadcrumbs.subscribe({
			next: (hide) => {
				this.hideBreadCrumb = hide;
			}
		});
	}


}
