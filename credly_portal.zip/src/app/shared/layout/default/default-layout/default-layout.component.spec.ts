import { ComponentFixture, TestBed } from '@angular/core/testing';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { DefaultLayoutComponent } from './default-layout.component';
import { BreadCrumbService } from '@/core/services/store';
import { ToastService } from '@usitsdasdesign/dds-ng/toast';

describe('DefaultLayoutComponent', () => {
  let component: DefaultLayoutComponent;
  let fixture: ComponentFixture<DefaultLayoutComponent>;
  let service : BreadCrumbService;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DefaultLayoutComponent ],
      imports : [ HttpClientTestingModule ],
      providers: [BreadCrumbService, ToastService]
    })
    .compileComponents();

    fixture = TestBed.createComponent(DefaultLayoutComponent);
    component = fixture.componentInstance;
    service = TestBed.inject(BreadCrumbService);
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
