import { ComponentFixture, TestBed } from '@angular/core/testing';

import { NotificationMenuComponent } from './notification-menu.component';

describe('NotificationMenuComponent', () => {
  let component: NotificationMenuComponent;
  let fixture: ComponentFixture<NotificationMenuComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ NotificationMenuComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(NotificationMenuComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should emit event closeNotification', () => {
    spyOn(component.closeNotification, 'emit');  
    component.close({});
    component.closeNotification.emit({}); 
    fixture.detectChanges(); 

    expect(component.closeNotification.emit).toHaveBeenCalledWith({});
  });

  it('should emit event openNotification', () => {
    spyOn(component.openNotification, 'emit');  
    component.goToNotification({});
    component.openNotification.emit({}); 
    fixture.detectChanges(); 

    expect(component.openNotification.emit).toHaveBeenCalledWith({});
  });

});
