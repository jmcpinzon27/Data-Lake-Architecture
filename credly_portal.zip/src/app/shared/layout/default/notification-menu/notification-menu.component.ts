import { Component, Input, Output, EventEmitter } from '@angular/core';
@Component({
	selector: 'app-notification-menu',
	templateUrl: './notification-menu.component.html',
	styleUrls: ['./notification-menu.component.scss']
})
export class NotificationMenuComponent {
	@Output() closeNotification = new EventEmitter<any>();

	@Output() openNotification = new EventEmitter<any>();

	@Input()
	listNotifications: Array<any> = [];

	isOpenNotification: boolean = true;
	constructor() {}



	goToNotification(dataNotification: any) {
		this.openNotification.emit(dataNotification);
	}

	close(dataNotification: any) {
		this.closeNotification.emit(dataNotification);
	}
}
