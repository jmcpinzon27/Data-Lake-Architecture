import { NavigationItem } from '@/core/services/store/breadCrumbService';
import { BreadCrumbService } from '@/core/services/store';
import { Component, Input } from '@angular/core';
import { NavigationEnd, Router } from '@angular/router';
import { BreadcrumbsOptions } from '@usitsdasdesign/dds-ng/breadcrumbs';
import { LinkOptions, Kind } from '@usitsdasdesign/dds-ng/shared';
import { filter, switchMap } from 'rxjs';

@Component({
	selector: 'app-breadcrumbs',
	templateUrl: './breadcrumbs.component.html',
	styleUrls: ['./breadcrumbs.component.scss']
})
export class BreadcrumbsComponent {
	@Input() hideBreadcrumb = false;

	navBreadCrumbs: NavigationItemContainer;

	breadcrumbsOptions: BreadcrumbsOptions = {
		kind: Kind.secondary
	};

	breadcrumbsList: any[] = [{ title: '', path: '' }];

	constructor(private router: Router, private breadCrumbService: BreadCrumbService) {
		this.breadCrumbService.getNavigation
			.pipe(
				switchMap((navigation) => {
					this.navBreadCrumbs = new NavigationItemContainer(navigation);
					return router.events;
				}),
				filter((event) => event instanceof NavigationEnd)
			)
			.subscribe((event) => {
				const activeRoute = (event as NavigationEnd).urlAfterRedirects;

				this.breadcrumbsList = this.navBreadCrumbs
					.getNavigation(activeRoute)
					.reverse()
					.map((item: NavigationItem) => ({
						title: item.title,
						path: item.path
					}));

				let tempData: any = this.breadcrumbsList.map((item: any) => {
					return [JSON.stringify(item), item];
				});

				let tempDataMap: any = new Map(tempData);

				this.breadcrumbsList = [...tempDataMap.values()];
			});
	}
}

class NavigationItemContainer {
	parent: NavigationItemContainer | null = null;
	items: NavigationItemContainer[] = [];
	item: Array<NavigationItem> | null = null;

	constructor(item: Array<NavigationItem>) {
		this.item = item;
	}

	add(item: NavigationItemContainer) {
		this.items.push(item);
	}

	setParent(parent: NavigationItemContainer): void {
		this.parent = parent;
	}

	getNavigation(ruta: string, items: (NavigationItem | null)[] = []) {
		for (let itemNav of this.item) {
			if (itemNav.path === ruta) {
				items.push(itemNav);
			}

			if (itemNav?.items !== undefined) {
				for (let itemNavItems of itemNav?.items) {
					if (itemNavItems.path === ruta) {
						items.push(itemNavItems);
						items.push(itemNav);
					}

					if (itemNavItems?.items !== undefined) {
						for (let itemNavItemsSub of itemNavItems?.items) {
							if (itemNavItemsSub.path === ruta) {
								items.push(itemNavItemsSub);
								items.push(itemNavItems);
							}
						}
					}
				}
			}
		}

		return items;
	}

	private compare(configuredUrl: string, activeUrl: string): boolean {
		let matched = true;
		const configuredUrlSplited = configuredUrl.split('/');
		const activeUrlSplited = activeUrl.split('/');
		activeUrlSplited.forEach((item, idx) => {
			if (configuredUrlSplited.length === activeUrlSplited.length) {
				matched &&= item === configuredUrlSplited[idx] || configuredUrlSplited[idx].startsWith(':');
			} else {
				matched = false;
			}
		});
		return matched;
	}
}
