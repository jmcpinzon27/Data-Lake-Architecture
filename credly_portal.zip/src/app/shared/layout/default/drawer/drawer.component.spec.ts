import { ComponentFixture, TestBed } from '@angular/core/testing';
import { DrawerComponent } from './drawer.component';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { ToastService } from '@usitsdasdesign/dds-ng/toast';
import { SessionStoreService } from '@/core/services/store';
import { of } from 'rxjs';
import AdminFolder from '@/data/menu/admin.json';
import { Session } from '@/core/model/entities';
describe('HeaderComponent', () => {
  let component: DrawerComponent;
  let fixture: ComponentFixture<DrawerComponent>;
  let sessionStoreService : SessionStoreService;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DrawerComponent ],
      imports : [ HttpClientTestingModule ],
      providers : [ ToastService, SessionStoreService ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(DrawerComponent);
    component = fixture.componentInstance;
    sessionStoreService = TestBed.inject(SessionStoreService);
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

});
