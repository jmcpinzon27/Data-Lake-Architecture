import { Component, OnInit, AfterContentInit } from '@angular/core';
import { TreeNodeOptions } from '@usitsdasdesign/dds-ng/tree';
import { BehaviorSubject } from 'rxjs';
import { take } from 'rxjs/operators';
import SessionStoreService from '@/core/services/store/sessionStoreService';
import AdminFolder from '@/data/menu/admin.json';
import RepFolder from '@/data/menu/businessRep.json';
import PractitionerFolder from '@/data/menu/practitioner.json';
import Role from '@/core/model/entities/role';
import { Session } from '@/core/model/entities';

@Component({
	selector: 'app-drawer',
	templateUrl: './drawer.component.html',
	styleUrls: ['./drawer.component.scss']
})
export class DrawerComponent implements OnInit, AfterContentInit {
	rolesList: Role[] = [];
	userRole: string;
	hasAdminRole = new BehaviorSubject<boolean>(false);
	hasReportRole = new BehaviorSubject<boolean>(false);
	hasPractitionerRole = new BehaviorSubject<boolean>(false);
	showConnectCredly: boolean = false;

	items: TreeNodeOptions[] = [];

	constructor(private sessionService: SessionStoreService) {}

	ngOnInit(): void {
		this.sessionService.UserSession.pipe(take(2)).subscribe((session : Session) => {
			if (session) {
				if (session.isAdmin) {
					this.items = AdminFolder;
				} else if (session.isBusinessRep) {
					this.items = RepFolder;
				} else {
					this.items = PractitionerFolder;
				}
			}
		});
	}

	ngAfterContentInit() {
		this.sessionService.credlyOptInObs$.subscribe(
			(isConectedWithCredly: boolean) => (this.showConnectCredly = !isConectedWithCredly)
		);
	}
}
