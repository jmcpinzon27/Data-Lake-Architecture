import { Component, OnInit, ViewChild } from '@angular/core';
import { WidthState, Themes, Size, ButtonKind } from '@usitsdasdesign/dds-ng/shared';
import { HeaderOptions, HeaderElmnts } from '@usitsdasdesign/dds-ng/header';
import { ButtonOptions } from '@usitsdasdesign/dds-ng/button';
import { ProfileOptions } from '@usitsdasdesign/dds-ng/profile';
import { StickerDirective } from '@usitsdasdesign/dds-ng/sticker';
import { MsalService } from '@azure/msal-angular';
import { RoleType, Session } from '@/core/model/entities';
import SessionStoreService from '@/core/services/store/sessionStoreService';
import { SystemParamsService } from '@/core/services/apis';
import { Router } from '@angular/router';
import { ModalService } from '@usitsdasdesign/dds-ng/modal';
import { ModalComponent } from '@/shared/components/modal/modal.component';
import { BehaviorSubject } from 'rxjs';
import { getSettings } from '@/core/infrastructure/settingsLoader';
import { Settings } from '../../../../core/model/common';
import { showExternalUrl } from '@/modules/shared/helpers';

@Component({
	selector: 'app-header',
	templateUrl: './header.component.html',
	styleUrls: ['./header.component.scss']
})
export class HeaderComponent implements OnInit {
	session?: Session = null;
	private session$: BehaviorSubject<Session | null> = new BehaviorSubject<Session>(null);
	listNotifications: Array<any> = [];
	currentRole: string;
	optionalRole: string;
	isPractitionerActive = false;
	settings: Settings;

	constructor(
		private authService: MsalService,
		private sessionService: SessionStoreService,
		private router: Router,
		private modal: ModalService,
		private sysParam: SystemParamsService
	) {
		this.settings = getSettings();
	}

	ngOnInit() {
		this.sessionService.UserSession.subscribe((session) => {
			this.session = session;

			if (session) {
				this.isPractitionerActive = session.isAdmin ? false : session.isBusinessRep ? false : true;
			}
		});

		this.sessionService.NotificationSession.subscribe((data: any) => {
			if (data !== null) {
				let notifications: any = data.map((e: any) => {
					return {
						id: e.id,
						title: e.title,
						message: e.description
					};
				});
				this.listNotifications = notifications;
			}
		});
	}

	@ViewChild('stickerDir') stickerDir: StickerDirective;
	headerOptions: HeaderOptions = {
		name: 'Deloitte Certified',
		width: WidthState.full,
		theme: Themes.green,
		isResponsive: false,
		isInverse: false,
		customClass: ''
	};

	responsivePriority: HeaderElmnts[] = [
		HeaderElmnts.logo,
		HeaderElmnts.projectName,
		HeaderElmnts.profile,
		HeaderElmnts.nav,
		HeaderElmnts.icons,
		HeaderElmnts.search
	];

	buttonNavOptions: ButtonOptions = {
		theme: Themes.dark,
		kind: ButtonKind.primaryLoud,
		size: Size.lg
	};

	buttonOptionsNotification: ButtonOptions = {
		theme: Themes.dark,
		icon: 'dds-icon_sm',
		customClass: 'dds-icon_notification'
	};

	button1Options: ButtonOptions = {
		theme: Themes.dark,
		icon: 'dds-icon_sm dds-icon_external-link'
	};

	button2Options: ButtonOptions = {
		theme: Themes.dark,
		icon: 'dds-icon_sm dds-icon_chat'
	};

	button3Options: ButtonOptions = {
		theme: Themes.dark,
		icon: 'dds-icon_sm dds-icon_bookmark'
	};

	profileOptions: ProfileOptions = {
		username: 'Keanu Reeves',
		nameLetter: 'KR',
		userInfo: 'Actor, musician'
	};

	activeNotifications: boolean = false;

	openNofiticationMenu(event: any) {
		this.closeNofiticationMenu(event);
		this.stickerDir.hide();
		this.router.navigate(['notifications']);
	}

	closeNofiticationMenu(event: any) {
		this.listNotifications = this.listNotifications.filter((data) => data.id != event.id);
		if (this.listNotifications.length == 0) this.activeNotifications = false;
	}

	openSticker(): void {
		if (this.listNotifications.length == 0) return;
		this.activeNotifications = true;
		this.stickerDir.show();
	}

	closeSticker() {
		this.activeNotifications = false;
	}

	switchRole() {
		if (this.session.isAdmin) {
			this.session.isAdmin = false;
		} else if (!this.session.isAdmin && this.session.roles.includes(RoleType.Admin)) {
			this.session.isAdmin = true;
		} else if (this.session.isBusinessRep) {
			this.session.isBusinessRep = false;
		} else if (!this.session.isBusinessRep && this.session.roles.includes(RoleType.BusinessRep)) {
			this.session.isBusinessRep = true;
		}
		this.session$.next(this.session);
		localStorage.setItem(
			'userRoles',
			JSON.stringify({
				isAdmin: this.session.isAdmin,
				isBusinessRep: this.session.isBusinessRep,
				isPractitioner: this.session.isPractitioner
			})
		);
		this.reloadPage();
	}

	reloadPage() {
		setTimeout(() => {
			window.location.reload();
		}, 300);
		this.router.navigate(['']);
	}

	openModal() {
		if (this.session.isAdmin) {
			this.currentRole = 'Administrator';
			this.optionalRole = 'Practitioner';
		} else if (!this.session.isAdmin && this.session.roles.includes(RoleType.Admin)) {
			this.optionalRole = 'Administrator';
			this.currentRole = 'Practitioner';
		} else if (this.session.isBusinessRep) {
			this.currentRole = 'Business Representative';
			this.optionalRole = 'Practitioner';
		} else if (!this.session.isBusinessRep && this.session.roles.includes(RoleType.BusinessRep)) {
			this.optionalRole = 'Business Representative';
			this.currentRole = 'Practitioner';
		}

		const approveModal = {
			title: 'Switch Role',
			hasFooter: true,
			contentTitle: `Are you sure you want to switch to ${this.optionalRole}?`,
			contentText: [`You can switch again to come back to ${this.currentRole} role.`],
			aceptButtonText: 'Yes, switch',
			cancelButtonText: 'Cancel',
			actionForAceptButton: this.switchRole.bind(this)
		};
		this.modal.open(ModalComponent, { modal: approveModal });
	}

	closeModal() {
		this.modal.close();
	}

	logout() {
		sessionStorage.removeItem('showInitBadgeToast');
		this.authService.logoutRedirect();
	}

	redirectToCredly() {
		showExternalUrl(this.sysParam.backendParams[0].value);
	}
}
