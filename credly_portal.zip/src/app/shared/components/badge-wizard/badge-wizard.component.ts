import { Component, Input } from '@angular/core';
import { Size } from '@usitsdasdesign/dds-ng/shared';
import { AccordionOptions } from '@usitsdasdesign/dds-ng/accordion';
import { WizardOptions, WizardItemOptions, WizardThemes } from '@usitsdasdesign/dds-ng/wizard';
import { AccordionItemsCustom } from './model';

@Component({
	selector: 'app-badge-wizard',
	templateUrl: './badge-wizard.component.html',
	styleUrls: ['./badge-wizard.component.scss']
})
export class BadgeWizardComponent {
	@Input()
	itemsWizard: AccordionItemsCustom[] = [];

	@Input()
	showPathTitle: boolean = false;

	@Input()
	pathTitle!: string;

	selectedItem: number = 0;

	wizardOptions: WizardOptions = {
		theme: WizardThemes.dark,
		startNumbering: 1,
		isNumeric: false,
		isVertical: true,
		isCompact: true,
		isInverse: false,
		customClass: '',
		activeIndex: 0
	};

	wizardItemOptions: WizardItemOptions = {
		label: 'Option',
		icon: '',
		progress: 100,
		isDisabled: false,
		customClass: ''
	};

	accordionOptions: AccordionOptions = {
		size: Size.md,
		isDisabled: false,
		isOpen: false,
		isMulti: true,
		customClass: ''
	};

	constructor() {}

	openItem(item: number) {
		item != this.selectedItem ? (this.selectedItem = item) : (this.selectedItem = 0);
	}
}
