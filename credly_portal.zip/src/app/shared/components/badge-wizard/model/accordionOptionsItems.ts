export default interface AccordionOptionsItems {
	name: string;
	isCompleted: boolean;
}
