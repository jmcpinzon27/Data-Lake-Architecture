import { AccordionOptionsItems } from '.';

export default interface AccordionItemsCustom {
	heading: string;
	isItemCompleted: boolean;
	isOpen?: boolean;
	options: Array<AccordionOptionsItems>;
}
