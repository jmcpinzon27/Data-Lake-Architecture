import { ComponentFixture, TestBed } from '@angular/core/testing';

import { BadgeWizardComponent } from './badge-wizard.component';

describe('BadgeWizardComponent', () => {
  let component: BadgeWizardComponent;
  let fixture: ComponentFixture<BadgeWizardComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ BadgeWizardComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(BadgeWizardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should selectedItem equal 1 ', () => {
    component.openItem(1);
    fixture.detectChanges();
    
    expect(component.selectedItem).toEqual(1);
  });

  it('should selectedItem equal 0 ', () => {
    component.openItem(0);
    fixture.detectChanges();
    
    expect(component.selectedItem).toEqual(0);
  });
});
