import { Themes } from '@usitsdasdesign/dds-ng/shared';
import { ToastOptions, ToastService } from '@usitsdasdesign/dds-ng/toast';

export class DeepLinksClass {
	readonly copyDeepLinkToast: ToastOptions = {
		title: `Link copied to clipboard`,
		message: ``,
		lifeTime: 10000,
		position: 'bottom-left',
		closeBtnIcon: 'dds-icon_close',
		isCloseIcon: true,
		customClass: 'simple-toast',
		limit: 5,
		theme: Themes.white
	};

	readonly errorCopyDeepLinkToast: ToastOptions = {
		title: 'Error copy to Clipboard!',
		message: ``,
		lifeTime: 5000,
		position: 'bottom-left',
		closeBtnIcon: 'dds-icon_close',
		isCloseIcon: true,
		customClass: 'simple-toast',
		limit: 5,
		theme: Themes.danger
	};

	constructor(private toastService: ToastService) {}

	clipCopy(url: string): void {
		navigator.clipboard.writeText(url);
		this.toastService.createToast(this.copyDeepLinkToast);
	}
}
