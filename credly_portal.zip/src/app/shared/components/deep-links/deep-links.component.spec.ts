import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DeepLinksComponent } from './deep-links.component';

describe('DeepLinksComponent', () => {
  let component: DeepLinksComponent;
  let fixture: ComponentFixture<DeepLinksComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DeepLinksComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(DeepLinksComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});