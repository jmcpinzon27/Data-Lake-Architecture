import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { ButtonOptions } from '@usitsdasdesign/dds-ng/button';
import { ToastService } from '@usitsdasdesign/dds-ng/toast';
import { DeepLinksClass } from '@/shared/components/deep-links/class/deep-links.class';

@Component({
  selector: 'app-deep-links',
  templateUrl: './deep-links.component.html',
  styleUrls: ['./deep-links.component.scss']
})
export class DeepLinksComponent implements OnInit {

  @Input() templateId : string = '';
  @Input() isDisabled : boolean = false;
  @Input() isVisible : boolean = true;
  @Input() urlExternal : boolean = false;
  @Input() isCopyUrl : boolean = false;  
  @Input() urlSub : string = '';

  @Output() index = new EventEmitter<boolean>();

  readonly optionsDeepLink: ButtonOptions = {
		theme: 'white',
		kind: 'secondaryLoud',
		size: 'md',
		width: 'fixed',
		isLoading: false,
		icon: 'deep-link-icon',
		isInverse: false,
		isDisabled: this.isDisabled,
		ariaLabel: '',
		customClass: 'deep-link',
		role: 'button'
	}  
  
  deepLinksClass = new DeepLinksClass(this.toastService);
  setUrlSub : string = 'badges-list';

  constructor(private toastService: ToastService) { }

  ngOnInit(): void {
    this.optionsDeepLink.isDisabled = this.isDisabled;
  }

  deepLink() : void { 
		try {
			const url = window.location.href;

			if (this.urlExternal) {
				this.index.emit(true);
				return;
			}	

			if(this.urlSub.length > 0 && !url.includes(this.setUrlSub) ) {
				const path = `${url}/${this.urlSub}`
				this.deepLinksClass.clipCopy(path);
				return;
			}

			const getNewUrl = url.split('/');
			const setUrl = `${getNewUrl[0]}//${getNewUrl[2]}/catalog/preview/${this.templateId}`

			this.deepLinksClass.clipCopy(this.isCopyUrl ? url : setUrl);

		} catch (error) {
			this.toastService.createToast(this.deepLinksClass.errorCopyDeepLinkToast);
		}
	}

}
