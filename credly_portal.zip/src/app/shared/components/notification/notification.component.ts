import { Component, Input, Output, EventEmitter } from '@angular/core';
import { ModalService } from '@usitsdasdesign/dds-ng/modal';

@Component({
	selector: 'app-notification',
	templateUrl: './notification.component.html',
	styleUrls: ['./notification.component.scss']
})
export class NotificationComponent {
	@Output() closeNotification = new EventEmitter<any>();

	@Input()
	listNotifications: Array<any> = [];

	@Input()
	showOverlay: boolean = true;

	isOpenNotification: boolean = true;
	constructor(public modalService: ModalService) {}



	close() {
		this.isOpenNotification = false;
		this.modalService.close();
	}
}
