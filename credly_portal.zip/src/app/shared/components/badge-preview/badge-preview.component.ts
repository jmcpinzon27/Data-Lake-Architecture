import { Component, OnInit, Input, ElementRef, ViewChild, OnDestroy } from '@angular/core';
import { Size, ButtonKind, Themes, WidthState } from '@usitsdasdesign/dds-ng/shared';
import { InputOptions } from '@usitsdasdesign/dds-ng/input';
import { DatepickerOptions } from '@usitsdasdesign/dds-ng/datepicker';
import { ButtonOptions } from '@usitsdasdesign/dds-ng/button';
import { ActivatedRoute, Params, Router } from '@angular/router';
import { catchError, of, switchMap, tap } from 'rxjs';
import {
	BadgeStatus,
	BadgeTemplate,
	BadgeTemplateCriteria,
	BadgeTemplateStatus,
	CriteriaType,
	ExpirationRange,
	RoleType,
	Session
} from '@/core/model/entities';
import { ModalService } from '@usitsdasdesign/dds-ng/modal';
import { ModalComponent } from '../modal/modal.component';
import { BadgeTemplateApiService, BadgeApiService, SystemParamsService } from '@/core/services/apis';
import { BadgeTemplateStoreService, SessionStoreService, PageStoreService } from '@/core/services/store';
import { ToastOptions, ToastService } from '@usitsdasdesign/dds-ng/toast';
import { ModalValues } from '@/core/model/common/actions';
import { getSettings } from '@/core/infrastructure/settingsLoader';
import { Settings } from '@/core/model/common';
import { showExternalUrl } from '@/modules/shared/helpers';
import { AccordionOptions } from '@usitsdasdesign/dds-ng/accordion';
import SkillType from '@/core/model/entities/skillType';

@Component({
	selector: 'app-badge-preview',
	templateUrl: './badge-preview.component.html',
	styleUrls: ['./badge-preview.component.scss']
})
export class BadgePreviewComponent implements OnInit, OnDestroy {
	@ViewChild('badgeName') badgeTemplateName!: ElementRef<HTMLElement>;

	@Input() showButton: boolean = true;
	@Input() showStatusBar: boolean = false;
	@Input() badgeActionButtonText: string = '';
	@Input() templateInfo: BadgeTemplate = {};
	@Input() isVisibleDeepLinks: boolean = true;

	private readonly toastToClaim: ToastOptions = {
		title: 'Your Badge has been Approved! Go and claim it!',
		message: `Your requested Badge was successfully approved by an Approver. Now you need to <strong>'claim it'</strong> in Credly to finish the process and fully earn it!`,
		lifeTime: 10000,
		position: 'bottom-left',
		closeBtnIcon: 'dds-icon_close',
		customClass: 'simple-toast',
		limit: 5,
		theme: Themes.dark
	};

	private readonly archivedToast: ToastOptions = {
		title: 'This badge has been archived',
		message: `This badge is no longer available to be awarded in the Deloitte Badge Catalog.`,
		lifeTime: 10000,
		position: 'bottom-left',
		closeBtnIcon: 'dds-icon_close',
		customClass: 'simple-toast',
		limit: 5,
		theme: Themes.dark
	};

	private readonly noExternalIdToast: ToastOptions = {
		title: 'Badge Notification',
		message: `The badge is not in sync with Credly. Please try again later.`,
		lifeTime: 10000,
		position: 'bottom-left',
		closeBtnIcon: 'dds-icon_close',
		customClass: 'simple-toast',
		limit: 5,
		theme: Themes.dark
	};

	private readonly claimText: string = 'Claim it in Credly';
	private readonly backToCatalogText: string = 'Go to Deloitte Badges Catalog';
	readonly skillTypes = SkillType;

	// Type could change
	private newRegistry!: any;
	templateId: string;

	expirationRange: any = ExpirationRange;
	badgeStatus!: BadgeStatus;
	isDisableDeep: boolean = false;

	initiateModalConfirmation: ModalValues = {
		title: '',
		hasFooter: true,
		contentTitle: `Are you sure you want to initiate this badge?`,
		contentText: [
			`This action indicates your intention to pursue this badge.
			<br/>Selecting "Yes" will add this badge to your My Badges & Certifications dashboard.`
		],
		aceptButtonText: 'Yes, initiate',
		cancelButtonText: 'Cancel',
		actionForAceptButton: this.modalConfirmation.bind(this)
	};

	CriteriaTypes = CriteriaType;

	options: ButtonOptions = {
		theme: Themes.dark,
		kind: ButtonKind.primaryLoud,
		size: Size.md,
		width: WidthState.fixed,
		isLoading: false,
		icon: '',
		isInverse: false,
		isDisabled: false,
		ariaLabel: 'Button',
		customClass: '',
		role: 'button'
	};

	inputOptions: InputOptions = {
		isRequired: true
	};

	datepickerOptions: DatepickerOptions = {
		label: 'Completion Date',
		placeholder: 'Add date of completion',
		format: 'MM/dd/yyyy',
		isManualInput: true,
		isRequired: true
	};

	accordionOptions: AccordionOptions = {
		size: Size.lg,
		isDisabled: false,
		isOpen: false,
		isMulti: true
	};

	settings: Settings;

	role: 'admin' | 'practitioner' | 'businessrep' = 'practitioner';
	entity: BadgeTemplate;
	standardCriteriaItems: any[] = [];
	alternateCriteriaItems: any[] = [];
	skillsTemp: BadgeTemplate = {};
	isAlternativeCriterias: boolean = false;
	isShowLoading: boolean = false;
	isVisiblePreview: boolean = false;

	constructor(
		private badgeTemplateStoreService: BadgeTemplateStoreService,
		private service: BadgeTemplateApiService,
		private badgeService: BadgeApiService,
		private activatedRouter: ActivatedRoute,
		private modalService: ModalService,
		private toastService: ToastService,
		private sessionService: SessionStoreService,
		private pageStoreService: PageStoreService,
		private router: Router,
		private modal: ModalService,
		private sysParam: SystemParamsService
	) {
		this.settings = getSettings();
	}

	ngOnInit(): void {
		this.isShowLoading = true;
		this.isDisableDeep = this.badgeStatus == BadgeStatus.PrivateBadge;
		this.role = this.sessionService.getActiveRole();
		if (this.templateInfo !== undefined) {
			this.isValidAlternativeCriteria();
			this.badgeTemplateStoreService.updateForm(this.templateInfo);
		}
		this.getBadgeInformation();
	}

	isValidAlternativeCriteria(): void {
		if (this.templateInfo.criterias) {
			const getAlternative = this.templateInfo.criterias.find((x) => x.isAlternative);
			if (getAlternative) this.isAlternativeCriterias = Object.entries(getAlternative)?.length !== 0;
		}
	}

	private filterSkills(): void {
		if (this.templateInfo.skills !== undefined) {
			const getCoreSkills = this.templateInfo.skills
				.slice()
				.sort((a, b) => -(a.proficiency - b.proficiency || b.skillName.localeCompare(a.skillName)));

			this.skillsTemp.skills = getCoreSkills.filter((x) => x.skillType == SkillType.Core);
		}
	}

	private getBadgeInformation() {
		this.badgeStatus = (this.badgeService.badge?.status as BadgeStatus) ?? null;
		const storeHasValue = Object.keys(this.badgeTemplateStoreService.entityStateLastValue)?.length;
		storeHasValue ? this.getFromStore() : this.getFromParam();
	}

	private groupCriteriaItems(criteriaItems: any[]) {
		criteriaItems.forEach((item) => {
			if (item.isAlternative) {
				this.alternateCriteriaItems.push(item);
			} else {
				this.standardCriteriaItems.push(item);
			}
		});
	}

	getStatusBadge(): void {
		const { badgeIdForCurrentUser } = this.templateInfo;
		this.badgeService
			.getBadgeById(badgeIdForCurrentUser)
			.pipe(catchError(() => of(false)))
			.subscribe((response: any) => {
				if (!response) {
					this.isShowLoading = false;
					this.isVisiblePreview = true;
					return;
				}
				this.redirectionByDeepLink(response?.status);
			});
	}

	redirectionByDeepLink(status: string): void {
		const { badgeIdForCurrentUser, badgeStatusForCurrentUser } = this.templateInfo;

		if (badgeIdForCurrentUser?.length > 0 && badgeStatusForCurrentUser?.length > 0) {
			if (
				status === BadgeStatus.Initiated ||
				status === BadgeStatus.SubmittedForApproval ||
				status === BadgeStatus.InProgress ||
				status === BadgeStatus.AwaitingApproval ||
				status === BadgeStatus.AttentionRequired ||
				status === BadgeStatus.SubmittedForApproval
			) {
				this.router.navigateByUrl(`/badges/validation/${badgeIdForCurrentUser}`);
			} else {
				this.badgeStatus = status as BadgeStatus;
			}
		}
		this.setFinalStatus();
		this.isShowLoading = false;
		this.isVisiblePreview = true;
	}

	private getFromParam() {
		this.activatedRouter.params
			.pipe(
				tap((resp: Params) => this.setValues(resp)),
				switchMap(() => this.service.getBadgeTemplateInfo(this.templateId))
			)
			.subscribe({
				next: (resp) => {
					this.templateInfo = { ...resp };
					const { badgeIdForCurrentUser, badgeStatusForCurrentUser } = this.templateInfo;
					this.isValidAlternativeCriteria();

					if (this.templateInfo.applyReleaseNotesOnlyInitiated === true) {
						this.templateInfo.applyReleaseNotesOnlyInitiated = null;
					}
					this.filterSkills();
					if (this.templateInfo.criterias) {
						this.groupCriteriaItems(this.templateInfo.criterias);
					}
					this.badgeTemplateStoreService.updateForm(this.templateInfo);
					this.getInfoToCreateNew();

					if (badgeIdForCurrentUser !== null && badgeStatusForCurrentUser !== null) {
						this.getStatusBadge();
					} else {
						this.setFinalStatus();
						this.isShowLoading = false;
						this.isVisiblePreview = true;
					}
				},
				error: (err) => (this.isShowLoading = false)
			});

		if (this.templateInfo !== undefined) {
			this.filterSkills();
			this.badgeTemplateStoreService.updateForm(this.templateInfo);
		}
	}

	private setFinalStatus() {
		const isTemplateArchived = this.templateInfo.status === BadgeTemplateStatus.Archived;
		if (this.badgeStatus === BadgeStatus.Awarded && !isTemplateArchived) {
			this.showStatusBar = true;
			this.badgeActionButtonText = this.backToCatalogText;
			this.getInfoToCreateNew('Awarded');
		}
		if (this.badgeStatus === BadgeStatus.Approved && !isTemplateArchived) {
			this.showStatusBar = true;
			this.toastService.createToast(this.toastToClaim);
			this.badgeActionButtonText = this.claimText;
		}
		if (isTemplateArchived) {
			this.setArchivedStatus();
		}
	}

	private setArchivedStatus() {
		this.showStatusBar = true;
		this.toastService.createToast(this.archivedToast);
		this.badgeActionButtonText = this.backToCatalogText;
		this.badgeStatus = this.templateInfo.status as unknown as BadgeStatus;
	}

	private getFromStore() {
		this.showButton = false;
		this.badgeTemplateStoreService.entity$.subscribe((template: BadgeTemplate) => {
			this.templateInfo = template;
			this.filterSkills();
			if (this.templateInfo.criterias) {
				this.groupCriteriaItems(this.templateInfo.criterias);
			}
			this.isVisiblePreview = true;
		});
		this.isShowLoading = false;
	}

	private getInfoToCreateNew(status = 'Initiated') {
		const { name, level, id, issuer, expiresAt } = this.templateInfo;
		const baseObj = { badgeTemplateId: id, badgeTemplateName: name, status };
		if (status !== 'Initiated') {
			this.newRegistry = {
				...baseObj,
				badgeTemplateIssuer: issuer,
				awardedAt: new Date(),
				expiresAt
			};
		} else {
			this.newRegistry = {
				...baseObj,
				badgeTemplateLevel: level
			};
		}
	}

	private setValues(resp: Params) {
		const { id } = resp;
		this.templateId = id;
		const firstRoute = this.activatedRouter.snapshot.url[0].path;
		if (firstRoute === 'preview') this.badgeActionButtonText = 'Initiate Badge';
	}

	buttonAction() {
		const isInitiateAction = this.badgeActionButtonText.toLocaleLowerCase().includes('initiate');
		const isClaimAction = this.badgeStatus === BadgeStatus.Approved;
		const isAwardedAction = this.badgeStatus === BadgeStatus.Awarded;
		const isArchivedAction = this.badgeStatus === BadgeStatus.Archived;

		if (isInitiateAction) this.initiateModal();
		if (isClaimAction) this.credlyRedirect();
		if (isAwardedAction) this.goToAwarded();
		if (isArchivedAction) this.redirectToCatalog();
	}

	private initiateModal() {
		const modal = { ...this.initiateModalConfirmation };
		modal.actionForCancelButton = this.modalClose.bind(this);
		this.modalService.open(ModalComponent, { modal });
	}

	private credlyRedirect() {
		const credlyBadgeId = this.badgeService.badge?.externalId;
		credlyBadgeId
			? showExternalUrl(this.sysParam.backendParams[0].value)
			: this.toastService.createToast(this.noExternalIdToast);
	}

	private goToAwarded() {
		this.badgeService.newRegistry = this.newRegistry;
		this.pageStoreService.setBadgesActiveTabIndex(1);
		this.router.navigate(['/catalog']);
	}

	private redirectToCatalog() {
		this.router.navigate(['badges']);
	}

	private modalConfirmation() {
		this.sessionService.UserSession.pipe(
			switchMap((resp: Session) => {
				const body = { employeePersonID: resp.personID, badgeTemplateId: this.templateId };
				return this.badgeService.updateBadge(body);
			})
		).subscribe((resp) => {
			this.newRegistry.submittedAt = resp.submittedAt;
			this.badgeService.newRegistry = { ...this.newRegistry, id: resp.id };
			this.modalClose();
			this.router.navigate(['badges']);
		});
	}

	hasCriteriaByType(criterias: Array<BadgeTemplateCriteria>, type: CriteriaType): boolean {
		return criterias.some((item) => item.type === type);
	}

	modalClose() {
		this.modalService.close();
	}

	showUrl(url: string) {
		showExternalUrl(url);
	}

	ngOnDestroy(): void {
		this.badgeService.badge = null;
		const practitioner = RoleType.Practitioner.toString().toLowerCase();
		if (this.role == practitioner) this.badgeTemplateStoreService.updateForm({});
	}

	showUpdates() {
		const modal: ModalValues = {
			title: 'This badge has been updated!',
			hasFooter: true,
			contentTitle: '',
			contentText: [],
			hideCancelBtn: true,
			aceptButtonText: 'Got it',
			actionForAceptButton: () => this.modal.close(),
			actionForCancelButton: () => {}
		};

		this.modal.open(ModalComponent, {
			defaultValueFeedback: this.templateInfo?.releaseNotes,
			showUpdates: true,
			modal
		});
	}

	getSkillLevel(event: any): void {
		if (event.skillType == SkillType.Core) {
			this.entity.skills[event.index].proficiency = event?.proficiency;
			this.entity.skills[event.index].skillType = event?.skillType;
		}
		this.badgeTemplateStoreService.updateForm(this.entity);
	}

	// This chould be added in the helper file and prepared to filter by type
	educationFiltered(path: 'standard' | 'alternate') {
		const paths = {
			standard: this.standardCriteriaItems,
			alternate: this.alternateCriteriaItems
		};
		return paths[path].filter((item) => item.type === this.CriteriaTypes.Education);
	}
}
