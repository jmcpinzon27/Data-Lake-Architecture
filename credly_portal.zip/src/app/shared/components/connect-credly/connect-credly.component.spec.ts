import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ConnectCredlyComponent } from './connect-credly.component';

describe('ConnectCredlyComponent', () => {
  let component: ConnectCredlyComponent;
  let fixture: ComponentFixture<ConnectCredlyComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ConnectCredlyComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ConnectCredlyComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
