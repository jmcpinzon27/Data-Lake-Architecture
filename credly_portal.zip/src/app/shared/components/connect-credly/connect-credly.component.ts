import { Component, Input, OnInit } from '@angular/core';
import { SessionStoreService } from '@/core/services/store';
import { ButtonOptions } from '@usitsdasdesign/dds-ng/button';
import { RoleType } from '@/core/model/entities';
import { SystemParamsService } from '@/core/services/apis';
import { showExternalUrl } from '@/modules/shared/helpers';

@Component({
	selector: 'app-connect-credly',
	templateUrl: './connect-credly.component.html',
	styleUrls: ['./connect-credly.component.scss']
})
export class ConnectCredlyComponent implements OnInit {
	@Input() showSidebarText: boolean = true;
	@Input() showDatagridText: boolean = false;
	@Input() btnColor: 'green' | 'dark' = 'green';

	showButton: boolean = false;

	connectButton: ButtonOptions = {
		isLoading: false,
		ariaLabel: 'Connect with Credly'
	};

	constructor(private sysParam: SystemParamsService, private sessionService: SessionStoreService) {}

	ngOnInit() {
		this.getCredlyStatus();
	}

	private getCredlyStatus() {
		this.sessionService.credlyOptInObs$.subscribe((isConectedWithCredly: boolean) => {
			const logedRole = this.sessionService.getActiveRole();
			const practitioner = (RoleType.Practitioner as string).toLowerCase();
			if (logedRole === practitioner) this.showButton = !isConectedWithCredly;
			else this.showButton = false;
		});
	}

	connect(): void {
		showExternalUrl(this.sysParam.backendParams[0].value);
	}
}
