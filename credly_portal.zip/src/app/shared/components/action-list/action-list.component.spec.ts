import { ComponentFixture, TestBed } from '@angular/core/testing';
import { ActionListComponent } from './action-list.component';
import { Action } from '@/core/model/common/actions';

describe('ActionListComponent', () => {
  let component: ActionListComponent;
  let fixture: ComponentFixture<ActionListComponent>;
  const action : Action = {	
    label: 'string',
    disabled: false,
    icon: 'string'
  };

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ActionListComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ActionListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should emit event action', () => {
    spyOn(component.actionEvent, 'emit');  
    component.actionSelected(action);  
    fixture.detectChanges();  

    expect(component.actionEvent.emit).toHaveBeenCalledWith(action);
  });
});









