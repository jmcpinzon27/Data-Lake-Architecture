import { Component, Input, Output, EventEmitter } from '@angular/core';
import { Action } from '@/core/model/common/actions';

@Component({
	selector: 'app-action-list',
	templateUrl: './action-list.component.html',
	styleUrls: ['./action-list.component.scss']
})
export class ActionListComponent {
	@Output() actionEvent = new EventEmitter<Action>();
	@Input() actions: Action[] = [];

	constructor() {}

	actionSelected(action: Action) {
		this.actionEvent.emit(action);
	}
}
