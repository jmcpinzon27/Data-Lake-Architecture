import { BadgeTemplateStatus } from '@/core/model/entities';

export interface DataFilterBadgeTemplate {
	filterSkill: any[];
	filterLevel: any[];
	searchTextFilter: string | string[];
}

export interface FilterBadgeTemplate {
	filter: DataFilterBadgeTemplate;
	requestData: boolean;
	origin: string;
}

export interface FiltersBadgeTemplate {
	Levels: any[];
	Skills: any[];
	SearchText: any;
	ShowExternals: boolean;
	status?: BadgeTemplateStatus[];
}
