export { DataFilterBadgeTemplate } from './dataFilterBadge';
export { FilterBadgeTemplate } from './dataFilterBadge';
