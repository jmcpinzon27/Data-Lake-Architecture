import { Component, OnInit } from '@angular/core';

import { LabelPosition, Size, ErrorState, Themes, ButtonKind, WidthState } from '@usitsdasdesign/dds-ng/shared';
import {
	MultiSelectOptions,
	MultiSelectItem,
	SelectType,
	SelectControlTypes
} from '@usitsdasdesign/dds-ng/multi-select';

@Component({
	selector: 'app-skills-levels-filter',
	templateUrl: './skills-levels-filter.component.html',
	styleUrls: ['./skills-levels-filter.component.scss']
})
export class SkillsLevelsFilterComponent implements OnInit {
	controlType: SelectControlTypes = SelectControlTypes.icon;

	multiSelectOptions: MultiSelectOptions = {
		label: 'Label',
		size: Size.md,
		description: '',
		placeholder: 'Placeholder',
		type: SelectType.tags,
		controlType: SelectControlTypes.icon,
		isDisabled: false,
		isResponsive: true,
		isError: false,
		isRequired: false,
		displayTickAllBtn: true,
		errorMessage: '',
		errorState: ErrorState.default,
		customClass: 'dds-multi-select-custom',
		stickerWidth: 0,
		stickerShift: 0,
		stickerMaxHeight: '300px',
		stickerIsDisabled: false,
		stickerPosition: 'bottom-left',
		stickerIndent: 0,
		stickerCustomClass: 'dds-multi-select-custom'
	};

	constructor() {}

	ngOnInit(): void {}
}
