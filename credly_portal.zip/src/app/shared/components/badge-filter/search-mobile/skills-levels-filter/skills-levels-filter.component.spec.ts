import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SkillsLevelsFilterComponent } from './skills-levels-filter.component';

describe('SkillsLevelsFilterComponent', () => {
  let component: SkillsLevelsFilterComponent;
  let fixture: ComponentFixture<SkillsLevelsFilterComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SkillsLevelsFilterComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(SkillsLevelsFilterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
