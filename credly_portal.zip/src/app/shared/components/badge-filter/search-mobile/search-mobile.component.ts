import { Component, OnInit, TemplateRef, ViewChild, Renderer2 } from '@angular/core';
import { SuggestionsTagsInputOptions } from '@usitsdasdesign/dds-ng/suggestions-tags-input';
import { LabelPosition, Size, ErrorState, Themes, ButtonKind, WidthState } from '@usitsdasdesign/dds-ng/shared';
import { DescriptionType } from '@usitsdasdesign/dds-ng/input';
import { ModalComponent } from '@/shared/components/modal/modal.component';
import { ModalService } from '@usitsdasdesign/dds-ng/modal';
import { GenericModalComponent } from '@/shared/generic-modal/generic-modal.component';

import { TagOptions } from '@usitsdasdesign/dds-ng/tags';

@Component({
	selector: 'app-search-mobile',
	templateUrl: './search-mobile.component.html',
	styleUrls: ['./search-mobile.component.scss']
})
export class SearchMobileComponent implements OnInit {
	@ViewChild('contentTemplate', { read: TemplateRef }) contentTemplate: TemplateRef<any>;

	optionsSuggest: SuggestionsTagsInputOptions = {
		label: 'Keyword search',
		debounceTime: 1500,
		ariaLabel: '',
		placeholder: 'Search',
		isDisabled: false,
		isRequired: false,
		isError: false,
		errorMessage: '',
		errorState: ErrorState.default,
		customClass: 'dds-suggestions-custom',
		size: Size.md,
		stickerWidth: 0,
		stickerShift: 0,
		stickerMaxHeight: '300px',
		stickerPosition: 'bottom',
		stickerIndent: 8,
		stickerCustomClass: '',
		tooltipIcon: 'dds-icon_search',
		tooltipPosition: 'left',
		tooltipIndent: 8,
		tooltipWidth: 0,
		tooltipShift: 0,
		tooltipHasBeak: false,
		tooltipIsDisabled: true,
		tooltipCustomClass: '',
		description: '.',
		descriptionType: DescriptionType.tooltip,
		labelPosition: 'external',
		maxHeight: '100px',
		minSearchSymbols: 1
	};

	tags = ['1', '2', '3'];

	optionsTerm: TagOptions = {
		isRemovable: true,
		isError: false,
		size: Size.md,
		customClass: ''
	};

	optionsSkillsLevels: TagOptions = {
		isRemovable: true,
		isError: false,
		size: Size.md,
		customClass: ''
	};

	constructor(private modal: ModalService) {}

	ngOnInit(): void {}

	openSkillsAndLevels() {
		let modalRef = this.modal.open(GenericModalComponent, {
			title: 'Create New Bulk Award Request',
			size: 'lg',
			contentTemplate: this.contentTemplate
		});
	}

	removeSkillsLevels(item: any) {
		console.log(item);
	}

	removeTerm() {
		console.log('removeTerm');
	}
}
