import { Component, OnInit, ViewChild, TemplateRef, Input, AfterContentInit } from '@angular/core';

import { ModalService } from '@usitsdasdesign/dds-ng/modal';
import { GenericModalComponent } from '@/shared/generic-modal/generic-modal.component';
import { MultiSelectItem } from '@usitsdasdesign/dds-ng/multi-select';
import { FilterBadgeTemplateService, SessionStoreService } from '@/core/services/store';
import { SkillApiService } from '@/core/services/apis';
import { BadgeLevel, BadgeTemplate, BadgeTemplateStatus, RoleType } from '@/core/model/entities';
import { BadgeTemplateApiService } from '@/core/services/apis';
import { BadgeFilterGridComponent } from './badge-filter-grid/badge-filter-grid.component';
import { FiltersBadgeTemplate } from './model/dataFilterBadge';
import { ButtonOptions } from '@usitsdasdesign/dds-ng/button';
import { Themes, Size, ButtonKind } from '@usitsdasdesign/dds-ng/shared';
import { Router } from '@angular/router';

@Component({
	selector: 'app-badge-filter',
	templateUrl: './badge-filter.component.html',
	styleUrls: ['./badge-filter.component.scss']
})
export class BadgeFilterComponent implements OnInit, AfterContentInit {
	@ViewChild('contentTemplate', { read: TemplateRef }) contentTemplate: TemplateRef<any>;
	@ViewChild('badgeTemplateGrid') badgeTemplateGridRef!: BadgeFilterGridComponent;

	@Input() titleFilter: string = '';
	role: RoleType = RoleType.BusinessRep;

	selectItemsLevels: MultiSelectItem[] = [];

	selectedSkills: any[] = [];

	selectedLevels: any[] = [];

	keyWordTyped: string = '';

	searchSuggestionsList: string[] = [];

	dataSendFilter: FiltersBadgeTemplate = {
		Skills: [],
		Levels: [],
		SearchText: '',
		ShowExternals: false,
		status: [BadgeTemplateStatus.Accepted]
	};

	totalRecords = 0;

	options: ButtonOptions = {
		theme: Themes.dark,
		size: Size.md,
		isLoading: false,
		icon: '',
		kind: ButtonKind.secondary,
		isInverse: false,
		isDisabled: false,
		ariaLabel: 'Button',
		customClass: '',
		role: 'button'
	};

	serviceMethod = '';

	constructor(
		private modal: ModalService,
		private sessionService: SessionStoreService,
		private skillApiService: SkillApiService,
		public badgeTemplateApiService: BadgeTemplateApiService,
		private filterBadgeTemplateService: FilterBadgeTemplateService,
		private router: Router
	) {}

	ngOnInit(): void {
		this.sessionService.UserSession.subscribe({
			next: (userData) => {
				this.role = userData.isBusinessRep
					? RoleType.BusinessRep
					: userData.isAdmin
					? RoleType.Admin
					: RoleType.Practitioner;
				switch (this.role) {
					case RoleType.Admin:
						this.serviceMethod = 'getBadgesTemplatesAdmin';
						break;
					case RoleType.BusinessRep:
						this.serviceMethod = 'getBadgeTemplatesBusinessRep';
						break;
					default:
						this.serviceMethod = 'getBadgeTemplatesPractitioner';
						break;
				}
			}
		});
	}

	ngAfterContentInit() {
		this.filterBadgeTemplateService.selectedSkills.subscribe({
			next: (selectedSkills) => {
				this.dataSendFilter = { ...this.dataSendFilter, Skills: selectedSkills.map((e: any) => e.label) };
			}
		});

		this.filterBadgeTemplateService.selectedLevels.subscribe({
			next: (selectedLevels) => {
				this.dataSendFilter = { ...this.dataSendFilter, Levels: selectedLevels.map((e: any) => e.label) };
			}
		});

		this.filterBadgeTemplateService.keyword.subscribe({
			next: (keyWordTyped) => {
				this.dataSendFilter = { ...this.dataSendFilter, SearchText: keyWordTyped };
			}
		});

		this.filterBadgeTemplateService.refreshResults.subscribe({
			next: () => {
				this.badgeTemplateGridRef.filterResultsGridRef.getInformationToFillTable();
			}
		});

		this.skillApiService.getSkillsDistinctByName().subscribe({
			next: (response) => {
				this.filterBadgeTemplateService.setSkills(
					response.map((skill) => {
						return {
							label: skill,
							icon: 'dds-icon_close'
						};
					})
				);
			},
			error: (err) => console.error(err) // TODO: How to handle the errors
		});

		const selectItemsLevels = [];
		for (const levelName in BadgeLevel) {
			selectItemsLevels.push({
				label: levelName,
				icon: 'dds-icon_close'
			});
		}
		this.filterBadgeTemplateService.setLevels(selectItemsLevels);
	}

	openModalForResults() {
		let modalRef = this.modal.open(GenericModalComponent, {
			title: 'Find a badge',
			width: '80vw',
			minWidth: '800px',
			contentTemplate: this.contentTemplate
		});
	}

	close() {
		this.modal.close();
	}

	resetFilters() {
		this.filterBadgeTemplateService.setKeyword('');
		this.filterBadgeTemplateService.setSelectedLevels([]);
		this.filterBadgeTemplateService.setSelectedSkills([]);
		sessionStorage.removeItem('keyword');
		sessionStorage.removeItem('selectedSkills');
		sessionStorage.removeItem('selectedLevels');
		this.dataSendFilter = {
			Skills: [],
			Levels: [],
			SearchText: '',
			ShowExternals: false,
			status: [BadgeTemplateStatus.Accepted]
		};
		setTimeout(() => {
			this.badgeTemplateGridRef.filterResultsGridRef.getInformationToFillTable();
		});
	}

	handleTotalRows(event: number) {
		this.totalRecords = event;
	}

	handleSelectedRow(selectedRow: BadgeTemplate) {
		const badgeTemplateStatus = selectedRow.status;
		let action: string = 'review';
		let endpoint: string = '';
		if (this.role === RoleType.Admin) {
			endpoint = 'badges/templates';
			if (badgeTemplateStatus === BadgeTemplateStatus.Draft) {
				action = 'edit';
			}
			this.router.navigate([`${endpoint}/${action}/`, selectedRow.id]);
		} else if (this.role === RoleType.BusinessRep) {
			endpoint = 'templates';
			if (
				badgeTemplateStatus === BadgeTemplateStatus.Draft ||
				badgeTemplateStatus === BadgeTemplateStatus.AttentionRequired
			) {
				action = 'edit';
			}
			this.router.navigate([`${endpoint}/${action}/`, selectedRow.id]);
		} else {
			endpoint = 'catalog/preview';
			this.router.navigate([`${endpoint}`, selectedRow.id]);
		}
		this.modal.close();
	}
}
