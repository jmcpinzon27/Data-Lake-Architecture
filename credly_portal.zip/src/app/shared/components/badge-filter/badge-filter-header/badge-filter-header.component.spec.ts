import { ComponentFixture, TestBed } from '@angular/core/testing';

import { BadgeFilterHeaderComponent } from './badge-filter-header.component';

xdescribe('BadgeFilterHeaderComponent', () => {
  let component: BadgeFilterHeaderComponent;
  let fixture: ComponentFixture<BadgeFilterHeaderComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ BadgeFilterHeaderComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(BadgeFilterHeaderComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
