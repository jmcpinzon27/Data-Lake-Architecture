import {
	Component,
	OnInit,
	Input,
	Output,
	EventEmitter,
	ViewChild,
	AfterContentInit,
	ChangeDetectorRef,
	OnDestroy
} from '@angular/core';
import { debounceTime, switchMap, distinctUntilChanged, filter } from 'rxjs';

import { LabelPosition, Size, ErrorState, Themes, ButtonKind, WidthState } from '@usitsdasdesign/dds-ng/shared';

import { SelectOptions } from '@usitsdasdesign/dds-ng/select';
import { ButtonOptions } from '@usitsdasdesign/dds-ng/button';
import { DescriptionType } from '@usitsdasdesign/dds-ng/input';
import { BadgeTemplateApiService } from '@/core/services/apis';

import {
	MultiSelectOptions,
	MultiSelectItem,
	SelectType,
	SelectControlTypes
} from '@usitsdasdesign/dds-ng/multi-select';
import {
	SuggestionsTagsInputComponent,
	SuggestionsTagsInputOptions
} from '@usitsdasdesign/dds-ng/suggestions-tags-input';
import { FilterBadgeTemplateService, SessionStoreService } from '@/core/services/store';
import { FilterBadgeTemplate } from '../model';
import { BadgeTemplateQuery, BadgeTemplateStatus } from '@/core/model/entities';
import { ListResponse } from '@/core/model/common';

@Component({
	selector: 'app-badge-filter-header',
	templateUrl: './badge-filter-header.component.html',
	styleUrls: ['./badge-filter-header.component.scss']
})
export class BadgeFilterHeaderComponent implements OnInit, AfterContentInit, OnDestroy  {
	@Input()
	origin: string = 'page';

	@Input()
	listSuggestionSearch: string[] = [];

	@Input()
	urlRedirect: string = '/';

	@Output() openModal = new EventEmitter<void>();

	@Output() changeLevels = new EventEmitter<MultiSelectItem[]>();
	@Output() changeKeyword = new EventEmitter<FilterBadgeTemplate>();

	@ViewChild(SuggestionsTagsInputComponent) searchBox: SuggestionsTagsInputComponent;

	keyWordTyped: string | string[] = '';

	optionsSkills: MultiSelectItem[] | string[] = [];
	optionsLevels: MultiSelectItem[] | string[] = [];

	selectedSkills: MultiSelectItem[] | string[] = [];
	selectedLevels: MultiSelectItem[] | string[] = [];

	options: ButtonOptions = {
		theme: Themes.dark,
		kind: ButtonKind.primaryLoud,
		size: Size.md,
		width: WidthState.fixed,
		isLoading: false,
		icon: '',
		isInverse: false,
		isDisabled: false,
		ariaLabel: 'Button',
		customClass: '',
		role: 'button'
	};
	selectOptions: SelectOptions = {};

	selectedItem: string;

	controlType: SelectControlTypes = SelectControlTypes.icon;

	multiSelectOptions: MultiSelectOptions = {
		label: 'Label',
		size: Size.md,
		description: '',
		placeholder: 'Placeholder',
		type: SelectType.tags,
		controlType: SelectControlTypes.icon,
		isDisabled: false,
		isResponsive: true,
		isError: false,
		isRequired: false,
		displayTickAllBtn: true,
		errorMessage: '',
		errorState: ErrorState.default,
		customClass: 'dds-multi-select-custom',
		stickerWidth: 0,
		stickerShift: 0,
		stickerMaxHeight: '300px',
		stickerIsDisabled: false,
		stickerPosition: 'bottom-left',
		stickerIndent: 0,
		stickerCustomClass: 'dds-multi-select-custom'
	};

	optionsSuggest: SuggestionsTagsInputOptions = {
		label: 'Keyword search',
		debounceTime: 1500,
		ariaLabel: '',
		placeholder: 'Search',
		isDisabled: false,
		isRequired: false,
		isError: false,
		errorMessage: '',
		errorState: ErrorState.default,
		customClass: 'dds-suggestions-custom',
		size: Size.md,
		stickerWidth: 0,
		stickerShift: 0,
		stickerMaxHeight: '300px',
		stickerPosition: 'bottom',
		stickerIndent: 8,
		stickerCustomClass: '',
		tooltipIcon: 'dds-icon_search',
		tooltipPosition: 'left',
		tooltipIndent: 8,
		tooltipWidth: 0,
		tooltipShift: 0,
		tooltipHasBeak: false,
		tooltipIsDisabled: true,
		tooltipCustomClass: '',
		description: '.',
		descriptionType: DescriptionType.tooltip,
		labelPosition: 'external',
		maxHeight: '100px',
		minSearchSymbols: 1
	};

	constructor(
		public badgeTemplateApiService: BadgeTemplateApiService,
		private filterBadgeTemplateService: FilterBadgeTemplateService,
		private sessionStoreService: SessionStoreService,
		private cdr: ChangeDetectorRef
	) {}

	ngOnInit(): void {
		this.selectOptions = {
			label: '',
			labelPosition: LabelPosition.internal,
			description: 'Label',
			placeholder: 'Placeholder',
			size: Size.md,
			isDisabled: false,
			isResponsive: false,
			isRequired: false,
			isError: false,
			errorMessage: '',
			errorState: ErrorState.default,
			customClass: '',
			stickerWidth: 0,
			stickerShift: 0,
			stickerMaxHeight: '',
			stickerIsDisabled: false,
			stickerPosition: 'bottom-left',
			stickerIndent: 0,
			stickerCustomClass: ''
		};
	}

	ngAfterContentInit() {
		this.cdr.detectChanges();

		this.filterBadgeTemplateService.skills.subscribe({
			next: (skills) => {
				this.optionsSkills = skills;
			}
		});

		this.filterBadgeTemplateService.selectedSkills.subscribe({
			next: (selectedSkills) => {
				setTimeout(() => {
					this.selectedSkills = selectedSkills;
				}, 500);
			}
		});

		this.filterBadgeTemplateService.levels.subscribe({
			next: (levels) => {
				this.optionsLevels = levels;
			}
		});

		this.filterBadgeTemplateService.selectedLevels.subscribe({
			next: (selectedLevels) => {
				this.selectedLevels = selectedLevels;
			}
		});

		this.filterBadgeTemplateService.keyword.subscribe({
			next: (keyWordTyped) => {
				this.keyWordTyped = keyWordTyped;
			}
		});

		const role = this.sessionStoreService.getActiveRole() as any;

		this.searchBox.valueChanged
			.pipe(
				filter((term) => term !== ''),
				debounceTime(750),
				distinctUntilChanged(),
				switchMap((keyword) => {
					this.keyWordTyped = keyword;
					this.filterBadgeTemplateService.setKeyword(keyword);

					if (role === 'businessrep') {
						return this.badgeTemplateApiService.getBadgeTemplatesBusinessRep({
							SearchText: keyword,
							status: [BadgeTemplateStatus.Accepted],
							showExternals: false
						});
					}

					if (role === 'practitioner') {
						return this.badgeTemplateApiService.getBadgeTemplatesPractitioner({
							SearchText: keyword,
							status: [BadgeTemplateStatus.Accepted],
							showExternals: false
						});
					}

					return this.badgeTemplateApiService.getBadgesTemplatesAdmin({
						SearchText: keyword,
						status: [BadgeTemplateStatus.Accepted],
						showExternals: false
					});
				})
			)
			.subscribe((response: ListResponse<BadgeTemplateQuery>) => {
				this.listSuggestionSearch = response.data.map(
					(badgeTemplate: BadgeTemplateQuery) => badgeTemplate.name
				);
			});
	}

	search(): void {
		if (this.origin === 'page') {
			this.openModal.emit();
		} else {
			this.filterBadgeTemplateService.setRefreshResults();
		}
	}

	valueChangedMultiSelect(value: MultiSelectItem[] | string[], filter: string) {
		if (filter == 'skill') {
			this.filterBadgeTemplateService.setSelectedSkills(value);
		}

		if (filter == 'level') {
			this.filterBadgeTemplateService.setSelectedLevels(value);
		}
	}

	changeSearch(event : any) : void {
		if (event.length == 0) this.filterBadgeTemplateService.setKeyword('');
	}

	ngOnDestroy(): void {
		this.filterBadgeTemplateService.setKeyword('');
	}
}
