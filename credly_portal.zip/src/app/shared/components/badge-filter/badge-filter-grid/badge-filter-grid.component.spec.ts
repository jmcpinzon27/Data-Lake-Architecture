import { ComponentFixture, TestBed } from '@angular/core/testing';

import { BadgeFilterGridComponent } from './badge-filter-grid.component';
import { HttpClientTestingModule } from '@angular/common/http/testing';


describe('BadgeFilterGridComponent', () => {
  let component: BadgeFilterGridComponent;
  let fixture: ComponentFixture<BadgeFilterGridComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ BadgeFilterGridComponent ],
      imports : [ HttpClientTestingModule ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(BadgeFilterGridComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should emit selectedRow', () => {
    spyOn(component.selectedRow, 'emit');  
    component.handleSelectedRow({});    
    fixture.detectChanges();  

    expect(component.selectedRow.emit).toHaveBeenCalledWith({});
  });

  it('should emit totalRows', () => {
    spyOn(component.totalRows, 'emit');  
    component.handleTotalRows(2);    
    fixture.detectChanges();  

    expect(component.totalRows.emit).toHaveBeenCalledWith(2);
  });
});
