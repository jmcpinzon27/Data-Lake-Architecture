import { Component, Input, Output, ViewChild, EventEmitter } from '@angular/core';
import { DataGridColumn } from '@/shared/components/data-grid/model';
import { BadgeTemplateApiService } from '@/core/services/apis';
import { DataGridComponent } from '@/shared/components/data-grid/data-grid.component';
@Component({
	selector: 'app-badge-filter-grid',
	templateUrl: './badge-filter-grid.component.html',
	styleUrls: ['./badge-filter-grid.component.scss']
})
export class BadgeFilterGridComponent {
	@Input() filter: any = {};
	@Input() serviceMethod = '';
	@Output() totalRows = new EventEmitter<number>();
	@Output() selectedRow = new EventEmitter<any>();

	@ViewChild('awardingProcessGrid') filterResultsGridRef!: DataGridComponent;

	columns: Array<DataGridColumn> = [
		{
			label: 'Badge Details',
			fieldValue: 'name',
			cellTemplateName: '',
			allowOrderBy: true,
			allowFilterText: false,
			allowFilterFixedValues: false,
			selected: false,
			dataType: 'string'
		},
		{
			label: 'Level',
			fieldValue: 'level',
			cellTemplateName: '',
			allowOrderBy: true,
			allowFilterText: false,
			allowFilterFixedValues: false,
			selected: false,
			dataType: 'string'
		},
		{
			label: 'Collection',
			fieldValue: 'collectionsText',
			cellTemplateName: '',
			allowOrderBy: false,
			allowFilterText: false,
			allowFilterFixedValues: false,
			selected: false,
			dataType: 'string'
		},
		{
			label: 'Created Date',
			fieldValue: 'createdAt',
			cellTemplateName: 'dateCell',
			allowOrderBy: true,
			allowFilterText: false,
			allowFilterFixedValues: false,
			selected: false,
			dataType: 'string'
		}
	];

	constructor(public badgeTemplateApiService: BadgeTemplateApiService) {}



	handleSelectedRow(selectedRow: any) {
		this.selectedRow.emit(selectedRow);
	}

	handleTotalRows(event: number) {
		this.totalRows.emit(event);
	}
}
