import { BadgeStatus } from '@/core/model/entities';
import { Component, Input, OnChanges, SimpleChanges } from '@angular/core';

@Component({
	selector: 'app-status-bar',
	templateUrl: './status-bar.component.html',
	styleUrls: ['./status-bar.component.scss']
})
export class StatusBarComponent implements OnChanges {
	private readonly statusWithSpace: any = {
		SubmittedForApproval: 'Submitted For Approval',
		AwaitingApproval: 'Awaiting Approval',
		AttentionRequired: 'Attention Required',
		InProgress: 'In Progress'
	};
	@Input() set status(badgeStatus: BadgeStatus) {
		const isValueWithSpace =
			badgeStatus === BadgeStatus.SubmittedForApproval ||
			BadgeStatus.AwaitingApproval ||
			BadgeStatus.AttentionRequired ||
			BadgeStatus.InProgress;

		this.badgeStatus = badgeStatus;
		this.badgeStatusText = this.statusWithSpace[badgeStatus] ?? badgeStatus;
	}
	@Input() templateInfo: { status: string; text: string } | null = null;

	badgeStatusText!: BadgeStatus;
	badgeStatus!: BadgeStatus;

	constructor() {}

	ngOnChanges(changes: SimpleChanges) {
		if (changes['templateInfo'].currentValue !== null) {
			this.badgeStatus = changes['templateInfo'].currentValue.status;
			this.badgeStatusText = changes['templateInfo'].currentValue.text;
		}
	}
}
