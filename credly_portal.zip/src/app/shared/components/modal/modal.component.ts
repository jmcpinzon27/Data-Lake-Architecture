import { ModalValues } from '@/core/model/common/actions';
import { Component, OnInit, Input } from '@angular/core';
import { Themes } from '@usitsdasdesign/dds-ng/shared';
import { ModalService } from '@usitsdasdesign/dds-ng/modal';
import { RadioButton } from '@usitsdasdesign/dds-ng/radio';

@Component({
	selector: 'app-modal',
	templateUrl: './modal.component.html',
	styleUrls: ['./modal.component.scss']
})
export class ModalComponent implements OnInit {
	readonly confirmButton = {
		theme: Themes.dark,
		ariaLabel: 'confirm button'
	};

	@Input()
	modal: ModalValues = {} as ModalValues;

	@Input()
	showFeedback: boolean = false;

	@Input()
	showReleaseNotes: boolean = false;

	@Input()
	showSkipButton: boolean = false;

	@Input()
	defaultValueFeedback: string = '';

	@Input()
	isEditable: boolean = true;

	@Input()
	updatesText!: string;

	@Input()
	showUpdates: boolean = false;

	isLoading: boolean = false;
	isActiveArchiveDate: boolean = false;
	isDisabledAcceptButton: boolean = false;
	currentDay: Date = new Date();

	radioBtns: RadioButton[] = [
		{
			options: {
				label: 'Apply for all Practitioners',
				theme: Themes.dark
			},
			value: 'radio1'
		},
		{
			options: {
				label: 'Apply only to initiated practitioners',
				theme: Themes.dark
			},
			value: 'radio2'
		}
	];

	constructor(private modalService: ModalService) {}

	ngOnInit(): void {
		this.isDisabledAcceptButton = this.modal.showReleaseNotes ? true : this.showReleaseNotes ? true : false;
	}

	validateText(e: any) {
		this.isDisabledAcceptButton = e.target.value.length > 0 ? false : true;
	}

	close() {
		this.modalService.close();
		this.modal.actionForCancelButton();
	}

	confirmButtonAction() {
		this.isLoading = true;
		this.modal.actionForAceptButton();
	}

	actionForHiddenButton() {
		this.isLoading = true;
		this.modal.actionForHiddenButton();
	}

	stateChanged(value: boolean | string) {
		this.isActiveArchiveDate = Boolean(value);
	}

	changeValueDate(e: any) {}
}
