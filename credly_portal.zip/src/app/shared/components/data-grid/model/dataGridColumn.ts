export default interface DataGridColumn {
	label: string;
	fieldValue: string;
	cellTemplateName: string;
	allowOrderBy: boolean;
	allowFilterText: boolean;
	allowFilterFixedValues: boolean;
	selected: boolean;
	dataType: string;
	customField?: string;
}
