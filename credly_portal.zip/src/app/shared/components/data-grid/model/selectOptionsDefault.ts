export default interface SelectOptionsDefault {
	size: string;
	placeholder: string;
	stickerWidth: number;
	stickerShift: number;
	stickerMaxHeight: string;
	stickerIsDisabled: boolean;
	stickerPosition: string;
	stickerIndent: number;
	stickerCustomClass: string;
	customClass: string;
}
