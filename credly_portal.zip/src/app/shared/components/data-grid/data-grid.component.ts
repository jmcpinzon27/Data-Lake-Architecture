import {
	Component,
	ContentChildren,
	Input,
	Output,
	OnInit,
	QueryList,
	TemplateRef,
	EventEmitter,
	OnDestroy
} from '@angular/core';
import { DataGridColumn } from './model';
import {
	SortOptions,
	Themes,
	SortingStates,
	Size,
	LabelPosition,
	ErrorState,
	ButtonKind,
	WidthState
} from '@usitsdasdesign/dds-ng/shared';
import { Mode } from '@usitsdasdesign/dds-ng/pagination';
import { FilterColumn, ListRequest, ListResponse, OrderBy } from '@/core/model/common';
import { SelectOptionsDefault } from './model';
import { SelectItemOptions, SelectOptions } from '@usitsdasdesign/dds-ng/select';
import { BadgeTemplateQuery, BadgeTemplateStatus } from '@/core/model/entities';
import { ButtonOptions } from '@usitsdasdesign/dds-ng/button';
import { GridService } from '@/core/services/store';
import { Subscription, catchError, of } from 'rxjs';
import { map } from 'rxjs/operators';

@Component({
	selector: 'app-data-grid',
	templateUrl: './data-grid.component.html',
	styleUrls: ['./data-grid.component.scss']
})
export class DataGridComponent implements OnInit, OnDestroy {
	badgeTemplateStatus = BadgeTemplateStatus;
	isNewStatus: boolean = false;
	cohortId: number = 0;
	canShowLoading: boolean = false;

	watchFillTable$: Subscription;

	selectOptions: SelectOptionsDefault = {
		size: Size.md,
		placeholder: '..Select Filter',
		customClass: 'select-dds',
		stickerWidth: 0,
		stickerShift: 0,
		stickerMaxHeight: '',
		stickerIsDisabled: false,
		stickerPosition: 'bottom-left',
		stickerIndent: 0,
		stickerCustomClass: 'select-dds'
	};

	backButton: ButtonOptions = {
		theme: Themes.dark,
		kind: ButtonKind.primaryLoud,
		size: Size.md,
		width: WidthState.fixed,
		isLoading: false,
		icon: '',
		isInverse: false,
		isDisabled: false,
		ariaLabel: 'Back button',
		customClass: '',
		role: 'button'
	};

	paginationValues = {
		size: 'md',
		pageLength: 1,
		pageNumberInSection: 10,
		isDisabled: false,
		ariaLabel: 'pagination',
		customClass: '',
		mode: Mode.icon,
		theme: Themes.dark,
		value: 1
	};

	filterColumn: Array<FilterColumn> = [];
	orderByFilter: OrderBy = {
		column: '',
		desc: false
	};

	dataRequest: ListRequest = {
		pageIndex: 1,
		pageSize: 10,
		filterColumns: this.filterColumn,
		SearchText: '',
		orderBy: this.orderByFilter
	};
	setUrlSub: string = 'badges-list';
	isVisibleDeepLinks: boolean = false;

	@Output() rowClick = new EventEmitter<string>();
	@Output() triggerEvent = new EventEmitter<void>();
	@Output() emitValuesFromService = new EventEmitter<BadgeTemplateQuery[]>();

	constructor(private gridService: GridService) {}

	@Input()
	pageSize: number = 10;

	@Input()
	service!: any;

	@Input()
	serviceMethod!: string;

	@Input()
	extraParam: Array<string> = [];

	@Input()
	showStatusInBadgeCatalog: boolean = false;

	@Input()
	showPrivateEye: boolean = false;

	@Input()
	filter!: any;

	@Input()
	columns: Array<DataGridColumn> = [];

	@Input()
	initialSortColumn: number = 0;

	@Input()
	showPagination: boolean = true;

	@Input()
	showBoxShadow: boolean = true;

	@Input()
	canSelectCell: boolean = false;

	@Input()
	isAvailableShowMore: boolean = false;

	@Input()
	title_grid: string = '';

	@Input()
	defaultColumnOrderBy: string = '';

	@Input()
	title_per_screen: string = '';

	@Input()
	emptyMessage: string = 'No results';

	@Input()
	showConnectWithCredly: boolean = false;

	@Output()
	selectRowGrid = new EventEmitter<any>();

	@Output()
	totalRows = new EventEmitter<any>();

	sortingState: SortOptions = {};
	public isShownFilter: boolean = false;
	public filteringColumn: any = {};

	@ContentChildren(TemplateRef<any>) cellTemplates!: QueryList<TemplateRef<any>>;

	currentPage: Array<any> = [];
	dataFilter: Array<any> = [];
	public isAllSelected: boolean = false;
	public selectedRowCount: number | boolean = 0;

	selectOptionsPerScreen: SelectOptions = {
		label: '',
		labelPosition: LabelPosition.external,
		description: '',
		placeholder: '',
		size: Size.md,
		isDisabled: false,
		isResponsive: false,
		isRequired: false,
		isError: false,
		errorMessage: '',
		errorState: ErrorState.default,
		customClass: 'style-per-screen',
		stickerWidth: 0,
		stickerShift: 0,
		stickerMaxHeight: '',
		stickerIsDisabled: false,
		stickerPosition: 'top-left',
		stickerIndent: 0,
		stickerCustomClass: ''
	};

	selectItems: SelectItemOptions[] = [
		{
			heading: '10',
			value: '10'
		},
		{
			heading: '20',
			value: '20'
		},
		{
			heading: '100',
			value: '100'
		}
	];
	selectedItem: string = '10';

	@Input()
	newRegistry!: any;

	valueChangedLengthPage(newLength: string) {
		this.dataRequest.pageSize = Number(newLength);
		this.pageSize = Number(newLength);
		this.getInformationToFillTable();
	}

	valueChanged(val: string) {}

	@Input()
	isActiveTab!: boolean;

	availablePages: SelectItemOptions[] = [];
	currentPageSelector: string = '1';

	valueChangedGoToPage(page: string) {
		this.paginationValues.value = parseInt(page);
		this.goToPage(parseInt(page));
	}

	valueChangedFixedText(val: string, column: DataGridColumn) {
		this.filterColumn = [
			{
				column: column.label,
				value: val,
				freeText: true
			}
		];
		this.dataRequest.filterColumns = this.filterColumn;

		this.getInformationToFillTable();
	}

	changeValueFreeText(val: string, column: DataGridColumn) {
		if (val.length < 3) return;
		this.filterColumn = [
			{
				column: column.label,
				value: val,
				freeText: true
			}
		];
		this.dataRequest.filterColumns = this.filterColumn;
		this.getInformationToFillTable();
	}

	stateChanged(state: boolean) {
		console.log(state);
	}

	toggleFilter(column: DataGridColumn) {
		this.dataFilter = this.currentPage.map((data) => {
			return {
				value: data[column.fieldValue]
			};
		});

		this.filteringColumn = column;
		this.isShownFilter = true;
	}

	filterOnHidden(): void {
		this.isShownFilter = false;
	}

	filterSorted(sortedState: string): void {
		this.sortingState = {
			property: this.filteringColumn.fieldValue,
			descending: sortedState === SortingStates.descending,
			dataType: this.filteringColumn.dataType
		};

		this.filterHide();
	}

	filterHide(): void {
		this.isShownFilter = false;
	}

	toggleRow(rowData: DataGridColumn): void {
		rowData.selected = !rowData.selected;
		//this.checkSelectedRow(this.currentPage);
		this.selectRowGrid.emit(rowData);
	}

	selectAllRows(status: boolean, data: Array<DataGridColumn>): void {
		data.forEach((item) => (item.selected = status));
		this.checkSelectedRow(data);
	}

	checkSelectedRow(data: Array<DataGridColumn>): void {
		this.selectedRowCount = data.filter((row) => row.selected).length;
		this.isAllSelected = data.length === this.selectedRowCount;
	}

	sortColumn(column: DataGridColumn, event: Event): void {
		event.preventDefault();
		if (!column.allowOrderBy) return;

		this.dataRequest.filterColumns = this.filterColumn;
		this.dataRequest.orderBy.column = column.customField ? column.customField : column.fieldValue;
		this.dataRequest.orderBy.desc = this.dataRequest.orderBy.desc ? false : true;

		this.sortingState = {
			property: column.label,
			descending: this.dataRequest.orderBy.desc,
			dataType: column.dataType
		};

		this.getInformationToFillTable();
	}

	ngOnInit(): void {
		this.watchFillTable$ = this.gridService.updateGrid.subscribe(() => this.getInformationToFillTable());

		this.sortingState = {
			property: this.columns[this.initialSortColumn].label,
			descending: true,
			dataType: 'string'
		};

		this.dataRequest.orderBy.column =
			this.defaultColumnOrderBy != ''
				? this.defaultColumnOrderBy
				: this.columns[this.initialSortColumn].fieldValue;

		this.dataRequest.orderBy.desc = true;

		const getCurrentUrl = `${window.location.href}`;
		
		this.isVisibleDeepLinks = getCurrentUrl.includes('catalog') && !getCurrentUrl.includes('collection');
		
		if (this.isVisibleDeepLinks) {
			this.isVisibleDeepLinks = getCurrentUrl.includes('catalog') && !getCurrentUrl.includes('badges-list') 
		}

		this.getInformationToFillTable();
	}

	setSortingIconClass = (columnLabel: string = ''): string => {
		let iconClass: string = '';
		if (this.sortingState.property === columnLabel) {
			iconClass = this.sortingState?.descending ? 'dds-icon_sort-down' : 'dds-icon_sort-up';
		} else {
			iconClass = 'dds-icon_sort-down grayed-icon';
		}
		return iconClass;
	};

	getCellTemplate = (name: string = ''): TemplateRef<any> | undefined => {
		return this.cellTemplates.find((e: any) => e._declarationTContainer.localNames?.indexOf(name) >= 0);
	};

	getInformationToFillTable(value: number = 1) {
		this.canShowLoading = true;
		const method = this.serviceMethod || 'get';
		const myObj: Record<string, any> = {};

		if (this.extraParam) {
			for (let i = 0; i < this.extraParam.length; i++) {
				const parts = this.extraParam[i].split('=');
				myObj[parts[0]] = parts[1];
			}
		}

		const filter = { ...this.dataRequest, ...(this.filter || {}), ...(myObj || {}) };

		this.dataRequest.pageIndex = value;
		if (this.filterUserActivy.filter != '') {
			let sortFilter = '';
			if (this.dataRequest.orderBy.column != '') {
				sortFilter =
					'&OrderBy.Column=' +
					this.dataRequest.orderBy.column +
					'&OrderBy.Desc=' +
					this.dataRequest.orderBy.desc;
			}
			this.getByFilterColumns(this.filterUserActivy.method, this.filterUserActivy.filter, value, '', sortFilter);
		} else {
			this.service[method](filter)
				.pipe(
					map((response: any) => {
						//looks for collections, and if it exists creates a new property, collectionsText, a string separated with commas with only the names.
						if (
							response.hasOwnProperty('data') &&
							Array.isArray(response.data) &&
							response.data.length > 0
						) {
							const transformedData = response.data.map((dataItem: any) => {
								if (dataItem.hasOwnProperty('collections') && Array.isArray(dataItem.collections)) {
									const names = dataItem.collections
										.filter((item: any) => item.name)
										.map((item: any) => item.name)
										.join(', ');
									return { ...dataItem, collectionsText: names };
								}
								return dataItem;
							});
							return { ...response, data: transformedData };
						}
						return response;
					}),
					catchError(() => of(false))
				)
				.subscribe((e: ListResponse<any>) => {
					if (!e) {
						this.canShowLoading = false;
						return;
					}

					if (this.isNewStatus) {
						this.setNewStatus(e.data);
					} else {
						this.currentPage = e.data;
					}

					if (this.service.newRegistry || this.newRegistry) this.setAsNewEntry();
					this.emitValuesFromService.emit(e.data);
					this.paginationValues.pageLength = Math.ceil(e.count / this.pageSize);
					this.availablePages = [];
					for (let i = 1; i <= this.paginationValues.pageLength; ++i) {
						this.availablePages.push({
							heading: String(i),
							value: i
						});
					}
					this.canShowLoading = false;
					this.totalRows.emit(e.count);
					this.isNewStatus = false;
					this.cohortId = 0;
				});
		}
	}

	setNewStatus(data: any[]): void {
		let newData: any[] = [];

		for (let i = 0; i < data.length; i++) {
			newData.push(data[i]);
			newData[i].new = false;

			if (data[i].cohortId == this.cohortId) newData[i].new = true;
		}
		this.currentPage = newData.sort((a, b) => (a.new > b.new ? -1 : 1));
	}

	goToPage(page: number) {
		this.dataRequest.pageIndex = page;
		this.getInformationToFillTable(page);
	}

	filterUserActivy: any = {
		method: '',
		filter: ''
	};

	messageFilter: string = '';
	getByFilterColumns(method: any, filter: string, page: any, message: string, sort: string = '') {
		this.messageFilter = message;
		this.canShowLoading = true;
		this.filterUserActivy.method = method;
		this.filterUserActivy.filter = filter;
		let pagefilter: string = page != '' ? '&pageIndex=' + page : '';

		this.service[method](filter + pagefilter + sort).subscribe((e: ListResponse<any>) => {
			this.currentPage = e.data;
			if (this.service.newRegistry || this.newRegistry) this.setAsNewEntry();
			this.emitValuesFromService.emit(e.data);
			this.paginationValues.pageLength = Math.ceil(e.count / this.pageSize);
			this.canShowLoading = false;
			this.totalRows.emit(e.count);
		});
	}

	private setAsNewEntry() {
		if (!this.newRegistry) {
			this.newRegistry = { ...this.service.newRegistry };
		}
		let newEntry: any;
		if (!this.service.newRegistry) {
			newEntry = { ...this.newRegistry };
		} else {
			newEntry = { ...this.service.newRegistry };
		}
		this.service.newRegistry = undefined;
		const howToDetectNewEntry = this.service.toDetectNew;
		if (this.dataRequest.pageIndex > 1) return; // this avoid the row in other pag
		const newEntryIndex = this.currentPage.findIndex(
			(e) => e[howToDetectNewEntry] === newEntry[howToDetectNewEntry]
		);
		if (newEntry && newEntryIndex >= 0) this.currentPage.splice(newEntryIndex, 1);
		if (this.isActiveTab) {
			newEntry.selected = true;
			this.currentPage.unshift(newEntry);
		}
	}

	back() {
		history.back();
	}

	onRowClick(event: any) {
		this.selectRowGrid.emit(event);
		this.rowClick.emit(event?.id);
	}

	ngOnDestroy(): void {
		this.watchFillTable$.unsubscribe();
	}
}
