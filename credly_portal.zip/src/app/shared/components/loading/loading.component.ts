import { Component, Input } from '@angular/core';
import { SpinnerThemes } from '@usitsdasdesign/dds-ng/shared';
import { SpinnerOptions } from '@usitsdasdesign/dds-ng/spinner';

@Component({
	selector: 'app-loading',
	templateUrl: './loading.component.html',
	styleUrls: ['./loading.component.scss']
})
export class LoadingComponent {
	@Input()
	isActive: boolean = false;

	@Input()
	colorTheme: SpinnerThemes = SpinnerThemes.dark;

	spinnerOptions: SpinnerOptions = {
		theme: this.colorTheme,
		thickness: '4px',
		size: '20px',
		customClass: 'custom-loading'
	};

	constructor() {}


}
