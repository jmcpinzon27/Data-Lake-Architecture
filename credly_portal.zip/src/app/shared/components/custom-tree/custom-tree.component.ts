import { Component, Input } from '@angular/core';

@Component({
	selector: 'app-custom-tree',
	templateUrl: './custom-tree.component.html',
	styleUrls: ['./custom-tree.component.scss']
})
export class CustomTreeComponent {
	@Input()
	items: Array<any> = [];
	isCollpased: boolean = false;

	constructor() {}
}
