import { BadgeTemplate, Skill } from '@/core/model/entities';
import SkillType from '@/core/model/entities/skillType';
import { BadgeTemplateStoreService } from '@/core/services/store';
import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';

@Component({
	selector: 'app-proficiency-skill',
	templateUrl: './proficiency-skill.component.html',
	styleUrls: ['./proficiency-skill.component.scss']
})
export class ProficiencySkillComponent implements OnInit {
	readonly maxProficiency: number[] = [1, 2, 3, 4];
	@Input()
	indexSkill: number = 0;

	@Input()
	adjacentSkill: boolean = false;

	@Input()
	showBorderBoxProficiency: boolean = true;

	@Input()
	readonly: boolean = false;

	@Input()
	skillType: any;

	@Input()
	orderBy: boolean = false;

	@Output() skillLevel: any = new EventEmitter<any>();

	skilsProf: number[] = [];
	entity: BadgeTemplate;
	skills: Array<Skill> = [];
	skillsTemp: Array<Skill> = [];
	skillsAdjacent: Array<Skill> = [];

	viewLevel: boolean = false;
	constructor(public badgeTemplateStoreService: BadgeTemplateStoreService) {}

	ngOnInit(): void {
		if (typeof this.skillType == 'object') {
			const getValue = this.skillType.value;
			this.skillType = getValue.skillType;
		}

		this.badgeTemplateStoreService.entity$.subscribe((e: any) => {
			let getAdjacentSkills: Skill[] = [];
			let getCoreSkills: Skill[] = [];

			this.entity = { ...e };

			if (this.entity.skillsAdjacent) {
				getCoreSkills = this.entity?.skills !== undefined ? [...this.entity.skills] : [];
				getAdjacentSkills = this.entity?.skillsAdjacent !== undefined ? [...this.entity.skillsAdjacent] : [];
			} else {
				getCoreSkills = this.entity.skills?.filter((item) => item.skillType === SkillType.Core);
				getAdjacentSkills = this.entity.skills?.filter((item) => item.skillType === SkillType.Adjacent);
			}

			if (getCoreSkills) this.skills = [...getCoreSkills];
			if (getAdjacentSkills) this.skillsAdjacent = [...getAdjacentSkills];

			if (this.orderBy) {
				this.skills.sort((a, b) => -(a.proficiency - b.proficiency || b.skillName.localeCompare(a.skillName)));
			}
		});
	}

	selectLevelProfSkill(e: any, i: number, skillType: string) {
		const setLevel = {
			index: e,
			proficiency: i,
			skillType: this.adjacentSkill ? SkillType.Adjacent : SkillType.Core
		};

		this.skillLevel.emit(setLevel);
		this.skilsProf[e] = i;
	}

	skillProf(e: any, i: number, skillType: string) {
		if (skillType == 'Core') {
			this.skilsProf[e] = isNaN(this.skills[e]?.proficiency) ? undefined : this.skills[e]?.proficiency;
			return this.skilsProf[e] === undefined || i > this.skilsProf[e] ? false : true;
		} else if (skillType == 'Adjacent') {
			this.skilsProf[e] = isNaN(this.skillsAdjacent[e]?.proficiency)
				? undefined
				: this.skillsAdjacent[e]?.proficiency;
			return this.skilsProf[e] === undefined || i > this.skilsProf[e] ? false : true;
		}

		return false;
	}
}
