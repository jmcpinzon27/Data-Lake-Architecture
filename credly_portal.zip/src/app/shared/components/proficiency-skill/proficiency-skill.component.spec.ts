import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ProficiencySkillComponent } from './proficiency-skill.component';

describe('ProficiencySkillComponent', () => {
  let component: ProficiencySkillComponent;
  let fixture: ComponentFixture<ProficiencySkillComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ProficiencySkillComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ProficiencySkillComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
