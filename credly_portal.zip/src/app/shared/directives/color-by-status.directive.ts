import { BadgeStatus } from '@/core/model/entities';
import { Directive, HostBinding, Input } from '@angular/core';

const dttColors = {
	green: '#43B02A',
	grey: '#A7A8AA',
	orange: '#DA291C',
	skyBlue: '#00A3E0'
};
const colors: Record<string, string> = {
	[BadgeStatus.Initiated]: dttColors.skyBlue,
	[BadgeStatus.InProgress]: dttColors.skyBlue,
	[BadgeStatus.SubmittedForApproval]: dttColors.skyBlue,

	[BadgeStatus.Accepted]: dttColors.green,
	[BadgeStatus.Approved]: dttColors.green,
	[BadgeStatus.Awarded]: dttColors.green,

	[BadgeStatus.AttentionRequired]: dttColors.orange,

	[BadgeStatus.Revoked]: dttColors.grey,
	[BadgeStatus.Withdrawn]: dttColors.grey,
	[BadgeStatus.Expired]: dttColors.grey,
	[BadgeStatus.Deleted]: dttColors.grey,
	[BadgeStatus.Rejected]: dttColors.grey,
	[BadgeStatus.Archived]: dttColors.grey
};
const defaultColor = '#000000';

@Directive({ selector: '[appColorByStatus]' })
export class ColorByStatusDirective {
	@HostBinding('style.backgroundColor')
	color: string;

	@Input()
	set status(key: string) {
		this.color = colors[key] ? colors[key] : defaultColor;
	}
}
