import { ColorByStatusDirective } from './color-by-status.directive';

xdescribe('ColorByStatusDirective', () => {
  it('should create an instance', () => {
    const directive = new ColorByStatusDirective();
    expect(directive).toBeTruthy();
  });
});
