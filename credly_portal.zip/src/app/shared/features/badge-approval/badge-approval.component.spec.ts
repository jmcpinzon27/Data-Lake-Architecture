import { ComponentFixture, TestBed } from '@angular/core/testing';

import { BadgeApprovalComponent } from './badge-approval.component';

xdescribe('BadgeApprovalComponent', () => {
  let component: BadgeApprovalComponent;
  let fixture: ComponentFixture<BadgeApprovalComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ BadgeApprovalComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(BadgeApprovalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
