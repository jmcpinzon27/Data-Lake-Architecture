import { Component, OnInit, OnDestroy, ViewChild, TemplateRef } from '@angular/core';
import { Themes, Size, ButtonKind } from '@usitsdasdesign/dds-ng/shared';
import { ButtonOptions } from '@usitsdasdesign/dds-ng/button';
import { BadgeApiService, BadgeTemplateApiService, BlobFileApiService } from '@/core/services/apis';
import {
	Badge,
	BadgeStatus,
	BadgeTemplate,
	CriteriaType,
	EducationCriteria,
	EminenceCriteria,
	ExperienceCriteria
} from '@/core/model/entities';
import { BreadCrumbService, PageStoreService } from '@/core/services/store';
import { SessionStoreService } from '@/core/services/store';
import { ActivatedRoute, Router } from '@angular/router';
import { ModalService } from '@usitsdasdesign/dds-ng/modal';
import { ModalComponent } from '@/shared/components/modal/modal.component';
import { AccordionOptions, AccordionItemOptions } from '@usitsdasdesign/dds-ng/accordion';
import { AccordionItemsCustom } from '@/shared/components/badge-wizard/model';
import Criteria from '@/core/model/entities/criteria';
import { catchError, of } from 'rxjs';
import { filterCriteriaByPath } from '@/modules/shared/helpers';

@Component({
	selector: 'app-badge-approval',
	templateUrl: './badge-approval.component.html',
	styleUrls: ['./badge-approval.component.scss']
})
export class BadgeApprovalComponent implements OnInit, OnDestroy {
	@ViewChild('contentTemplate', { read: TemplateRef }) contentTemplate!: TemplateRef<any>;
	@ViewChild('leftActionsTemplate', { read: TemplateRef }) leftActionsTemplate!: TemplateRef<any>;
	@ViewChild('rightActionsTemplate', { read: TemplateRef }) rightActionsTemplate!: TemplateRef<any>;
	constructor(
		private sessionService: SessionStoreService,
		private router: Router,
		private modal: ModalService,
		private breadCrumbService: BreadCrumbService,
		private badgeService: BadgeApiService,
		private badgeTemplateService: BadgeTemplateApiService,
		private route: ActivatedRoute,
		private blobFileService: BlobFileApiService,
		private pageStoreService: PageStoreService
	) {}

	badgeServiceMethod: string;
	badgeApprovalStatus: string = 'Awaiting for Approval';
	showBadgePreview: boolean = false;
	showBadgeDescription: boolean = true;
	isEducationTabOpen: boolean = false;
	isExperienceTabOpen: boolean = false;
	isExposureTabOpen: boolean = false;
	badgeId: string;
	badgeTemplateId: string;
	badgePreview: BadgeTemplate = {};
	badgeData: Badge;
	criteriaDescription: Criteria;
	practitionerName: string;
	badgeStatus = BadgeStatus;

	accordionItemsCustom: AccordionItemsCustom[] = [];

	accordionOptions: AccordionOptions = {
		size: Size.md,
		isDisabled: false,
		isOpen: false,
		isMulti: true,
		customClass: ''
	};

	accordionItems: { options: AccordionItemOptions; content: string }[] = [
		{
			options: {
				heading: 'Education',
				text: '',
				isDisabled: false,
				isOpen: false,
				customClass: 'title-tab-template'
			},
			content: ``
		},
		{
			options: {
				heading: 'Experience',
				customClass: 'title-tab-template'
			},
			content: ``
		},
		{
			options: {
				heading: 'Eminence',
				customClass: 'title-tab-template'
			},
			content: ``
		}
	];

	optionsPrimary: ButtonOptions = {
		theme: Themes.dark,
		kind: ButtonKind.primaryLoud
	};

	optionsSecondary: ButtonOptions = {
		theme: Themes.white,
		customClass: 'btn-custom-white',
		kind: ButtonKind.primaryLoud
	};

	ngOnInit(): void {
		this.setMethodByRole();
		this.badgeId = this.route.snapshot.paramMap.get('id');
		this.practitionerName = sessionStorage.getItem('selectedPractitioner');
		this.getBadgeInfo();
	}

	private setMethodByRole() {
		this.sessionService.UserSession.subscribe({
			next: (userData) => {
				if (userData.isBusinessRep) {
					this.breadCrumbService.setHideBreadcrumbs(true);
					this.badgeServiceMethod = 'getBadgesBusinessRep';
				} else {
					this.badgeServiceMethod = 'getBadgesAdmin';
				}
			}
		});
	}

	private getBadgeInfo() {
		this.badgeService.getBadgeById(this.badgeId).subscribe((response: any) => {
			this.badgeTemplateId = response.badgeTemplateId;
			this.badgeData = response;
			if (response.badgeTemplateId) this.getBadgeTemplateData(this.badgeTemplateId);
			this.setAccordionItems();
		});
	}

	private setAccordionItems() {
		const { education, experience, eminence } = this.badgeData;
		const pathSubmited = this.badgeData.alternativeCriteriaSelected ? 'alternate' : 'standard';
		const educationItems = filterCriteriaByPath(education, pathSubmited) as EducationCriteria[];
		const experienceItems = filterCriteriaByPath(experience, pathSubmited) as ExperienceCriteria[];
		const eminenceItems = filterCriteriaByPath(eminence, pathSubmited) as EminenceCriteria[];

		this.badgeData.education = educationItems;
		this.badgeData.experience = experienceItems;
		this.badgeData.eminence = eminenceItems;

		if (educationItems.length > 0) {
			this.accordionItemsCustom.push({
				heading: 'Education',
				isItemCompleted: false,
				options: educationItems.map((item: EducationCriteria) => ({ name: item.title, isCompleted: false }))
			});
		}
		if (experienceItems.length > 0) {
			this.accordionItemsCustom.push({
				heading: 'Experience',
				isItemCompleted: false,
				options: experienceItems.map((item: ExperienceCriteria) => ({ name: item.title, isCompleted: false }))
			});
		}
		if (eminenceItems.length > 0) {
			this.accordionItemsCustom.push({
				heading: 'Eminence',
				isItemCompleted: false,
				options: eminenceItems.map((item: EminenceCriteria) => ({ name: item.title, isCompleted: false }))
			});
		}
	}

	showPreview() {
		this.showBadgeDescription = !this.showBadgeDescription;
		this.showBadgePreview = !this.showBadgePreview;
	}

	getBadgeTemplateData(id: string) {
		this.badgeTemplateService.getBadgeTemplateInfo(id).subscribe((response) => {
			this.badgePreview = response;
		});
	}

	downloadEvidenceFile(criteria: Criteria) {
		this.blobFileService.downloadById(criteria?.upload).subscribe({
			next: (blob) => {
				let dataType = blob.type;
				let binaryData = [];
				binaryData.push(blob);
				let downloadLink = document.createElement('a');
				downloadLink.href = window.URL.createObjectURL(new Blob(binaryData, { type: dataType }));
				downloadLink.setAttribute('download', criteria.upload);
				document.body.appendChild(downloadLink);
				downloadLink.click();
			},
			error: (err: any) => console.error(err)
		});
	}

	openDeclineModal() {
		const rejectionModal = {
			title: 'Providing Rationale for Rejection',
			hasFooter: true,
			contentTitle: '',
			contentText: [
				`Please provide the reason why this badge has been rejected. The status of this badge
				will change to Rejected for the practitioner and cannot be undone`
			],
			aceptButtonText: 'Send Feedback',
			cancelButtonText: 'Cancel',
			actionForAceptButton: () => this.rejectBadge()
		};

		this.modal.open(ModalComponent, { modal: rejectionModal, showFeedback: true });
	}

	openApproveModal() {
		const approveModal = {
			title: 'Are you sure you want to approve the awarding of this badge?',
			hasFooter: true,
			contentTitle: '',
			contentText: [
				`Clicking "Yes" indicates that you have verified that the submitted criteria meets the qualifying standards of this badge.<br> Clicking "No" does not prevent you from approving in the future once the criteria has been validated.`
			],
			aceptButtonText: 'Yes, Approve',
			cancelButtonText: 'Cancel',
			actionForAceptButton: this.approveBadge.bind(this)
		};
		this.modal.open(ModalComponent, { modal: approveModal });
	}

	openAttentionRequiredModal() {
		const approveModal = {
			title: 'Providing Feedback',
			hasFooter: true,
			contentTitle: '',
			contentText: [
				`You’re going to give some feedback to the practitioner, so they can continue progress and update with all the
				required data. Please be very specific on each stage of the form, so they can update it correctly. The status of
				this badge will change to "Attention Required" for the practitioner.`
			],
			aceptButtonText: 'Send Feedback',
			cancelButtonText: 'Cancel',
			actionForAceptButton: () => this.attentionRequiredBadge()
		};

		this.modal.open(ModalComponent, { modal: approveModal, showFeedback: true });
	}

	approveBadge() {
		const payload = {
			id: this.badgeData.id,
			feedback: '',
			status: BadgeStatus.Approved
		};
		this.badgeService.manageBadgeStatus(payload).subscribe((e) => {
			this.closeModal();
			this.pageStoreService.setBadgesActiveTabIndex(2);
			this.router.navigate([`/badges`]);
		});
	}

	rejectBadge() {
		let feedback: any = document.querySelector('textarea');
		const payload = {
			id: this.badgeData.id,
			status: BadgeStatus.Rejected,
			feedback: feedback.value
		};
		this.badgeService
			.manageBadgeStatus(payload)
			.pipe(catchError(() => of(false)))
			.subscribe((e) => {
				if (!e) {
					this.closeModal();
					return;
				}
				this.closeModal();
				this.pageStoreService.setBadgesActiveTabIndex(0);
				this.router.navigate([`/badges`]);
			});
	}

	attentionRequiredBadge() {
		let feedback: any = document.querySelector('textarea');
		const payload = {
			id: this.badgeData.id,
			feedback: feedback.value,
			status: BadgeStatus.AttentionRequired
		};
		this.badgeService.manageBadgeStatus(payload).subscribe((e) => {
			this.closeModal();
			this.pageStoreService.setBadgesActiveTabIndex(1);
			this.router.navigate([`/badges`]);
		});
	}

	closeModal() {
		this.modal.close();
	}

	itemChanged(status: any) {
		switch (status.heading) {
			case CriteriaType.Education:
				this.isEducationTabOpen = false;
				break;

			case CriteriaType.Experience:
				this.isExperienceTabOpen = false;
				break;

			case CriteriaType.Eminence:
				this.isExposureTabOpen = false;
				break;

			default:
				break;
		}
	}

	ngOnDestroy(): void {
		this.breadCrumbService.setHideBreadcrumbs(false);
	}
}
