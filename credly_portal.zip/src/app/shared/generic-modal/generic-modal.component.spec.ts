import { ComponentFixture, TestBed } from '@angular/core/testing';

import { GenericModalComponent } from './generic-modal.component';
import { ModalService } from '@usitsdasdesign/dds-ng/modal';

describe('GenericModalComponent', () => {
  let component: GenericModalComponent;
  let fixture: ComponentFixture<GenericModalComponent>;
  let service : ModalService;
  const modalServiceMock ={
    open : jasmine.createSpy('open').and.returnValue({ modalRef: { close: jasmine.createSpy('close')}})
  }

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ GenericModalComponent ],
      providers: [{ provide: ModalService, useValue: modalServiceMock}]
    })
    .compileComponents();

    fixture = TestBed.createComponent(GenericModalComponent);
    component = fixture.componentInstance;
    service = TestBed.inject(ModalService);
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });



});
