import { Component, Input, TemplateRef } from '@angular/core';
import { ModalService } from '@usitsdasdesign/dds-ng/modal';

@Component({
	selector: 'app-generic-modal',
	templateUrl: './generic-modal.component.html',
	styleUrls: ['./generic-modal.component.scss']
})
export class GenericModalComponent {
	@Input() isFooter: boolean;
	@Input() size: string;
	@Input() minWidth: string = '';
	@Input() width: string = '';
	@Input() title: string;
	@Input() contentTemplate: TemplateRef<any>;
	@Input() leftActionsTemplate: TemplateRef<any>;
	@Input() rightActionsTemplate: TemplateRef<any>;

	constructor(public modalService: ModalService) {}



	close() {
		this.modalService.close();
	}
}
