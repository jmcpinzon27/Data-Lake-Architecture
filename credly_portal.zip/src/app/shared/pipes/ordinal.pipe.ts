import { Pipe, PipeTransform } from '@angular/core';

@Pipe({ name: 'ordinal' })
export default class OrdinalPipe implements PipeTransform {
	transform(value: string): string {
		const valueAsNumber = Number(value);
		let suffix = 'th';
		if (valueAsNumber % 10 === 1 && valueAsNumber % 100 !== 11) suffix = 'st';
		if (valueAsNumber % 10 === 2 && valueAsNumber % 100 !== 12) suffix = 'nd';
		if (valueAsNumber % 10 === 3 && valueAsNumber % 100 !== 13) suffix = 'rd';
		return suffix;
	}
}
