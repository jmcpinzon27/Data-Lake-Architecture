import { Pipe, PipeTransform } from '@angular/core';

@Pipe({ name: 'splitByUpper' })
export default class SplitByUpperPipe implements PipeTransform {
	transform(value: any, ...args: any[]): string {
		return value.match(/[A-Z][a-z]+/g).join(' ');
	}
}
