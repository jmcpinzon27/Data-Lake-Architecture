import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
	name: 'statusBulkAwarded'
})
export default class StatusBulkAwardedPipe implements PipeTransform {
	transform(value: string, ...args: any): string {
		const statuses = args[0];
		return statuses[value];
	}
}
