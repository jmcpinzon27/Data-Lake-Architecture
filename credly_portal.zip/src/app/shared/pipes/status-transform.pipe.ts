import { Pipe, PipeTransform } from '@angular/core';

@Pipe({ name: 'statusTransform' })
export default class StatusTransformPipe implements PipeTransform {
	transform(value: string, ifItIs: string, should: string): string {
		return value === ifItIs ? should : value;
	}
}
