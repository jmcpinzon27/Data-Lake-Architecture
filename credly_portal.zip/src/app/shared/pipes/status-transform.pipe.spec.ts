import StatusTransformPipe from "./status-transform.pipe";
let ordinalPipe : StatusTransformPipe;

beforeEach(() => {
  ordinalPipe = new StatusTransformPipe();
});

describe('StatusTransformPipe', () => {

  it('create an instance', () => {
    expect(ordinalPipe).toBeTruthy();
  });
  
  it('should transform return 0', () => {
    expect(ordinalPipe.transform('1','1','0')).toBe('0');
  });

  it('should transform return 1', () => {
    expect(ordinalPipe.transform('1','2','0')).toBe('1');
  });

});
