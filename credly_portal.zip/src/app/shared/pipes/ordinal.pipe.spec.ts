import OrdinalPipe from './ordinal.pipe';

describe('OrdinalPipe', () => {

  let ordinalPipe : OrdinalPipe;

  beforeEach(() => {
    ordinalPipe = new OrdinalPipe();
  });

  it('create an instance', () => {
    expect(ordinalPipe).toBeTruthy();
  });

  it('convert value 0 in th', () => {
    expect(ordinalPipe.transform('0')).toBe('th');
  });

  it('convert value 1 in st', () => {
    expect(ordinalPipe.transform('1')).toBe('st');
  });

  it('convert value 2 in nd', () => {
    expect(ordinalPipe.transform('2')).toBe('nd');
  });

  it('convert value 3 in rd', () => {
    expect(ordinalPipe.transform('3')).toBe('rd');
  });
});
