import { APP_INITIALIZER, NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';

import { ButtonModule } from '@usitsdasdesign/dds-ng/button';
import { BreadcrumbsModule } from '@usitsdasdesign/dds-ng/breadcrumbs';

import { CoreModule } from './core/core.module';
import { HTTP_INTERCEPTORS, HttpClientModule } from '@angular/common/http';
import {
	MsalGuard,
	MsalInterceptor,
	MsalBroadcastService,
	MsalModule,
	MsalService,
	MSAL_GUARD_CONFIG,
	MSAL_INSTANCE,
	MSAL_INTERCEPTOR_CONFIG,
	MsalRedirectComponent
} from '@azure/msal-angular';
import { SharedModule } from './shared/shared.module';
import { MSALInstanceFactory, MSALGuardConfigFactory, MSALInterceptorConfigFactory } from './core/security/factories';

import { SettingsStoreService } from './core/services/store';
import { ErrorService } from './core/services/error.service';

// const appInitFactory = (settingsStoreService: SettingsStoreService) => {
// 	return () => settingsStoreService.loadSettings();
// };

@NgModule({
	declarations: [AppComponent],
	imports: [
		BrowserModule,
		AppRoutingModule,
		ButtonModule,
		CoreModule,
		HttpClientModule,
		MsalModule,
		SharedModule,
		BreadcrumbsModule
	],
	providers: [
		// {
		// 	provide: APP_INITIALIZER,
		// 	useFactory: appInitFactory,
		// 	multi: true,
		// 	deps: [SettingsStoreService]
		// },
		{
			provide: HTTP_INTERCEPTORS,
			useClass: MsalInterceptor,
			multi: true
		},
		{
			provide: HTTP_INTERCEPTORS,
			useClass: ErrorService,
			multi: true
		},
		{
			provide: MSAL_INSTANCE,
			useFactory: MSALInstanceFactory
		},
		{
			provide: MSAL_GUARD_CONFIG,
			useFactory: MSALGuardConfigFactory
		},
		{
			provide: MSAL_INTERCEPTOR_CONFIG,
			useFactory: MSALInterceptorConfigFactory
		},
		MsalService,
		MsalGuard,
		MsalBroadcastService
	],
	bootstrap: [AppComponent, MsalRedirectComponent]
})
export class AppModule {}
