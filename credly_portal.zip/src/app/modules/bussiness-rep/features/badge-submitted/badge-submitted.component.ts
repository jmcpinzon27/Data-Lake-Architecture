import { Component, OnInit, OnDestroy, ViewChild, Renderer2 } from '@angular/core';
import { TabComponent, TabsOptions, TabOptions } from '@usitsdasdesign/dds-ng/tabs';
import { Themes, Size, TabThemeType, ButtonKind, WidthState } from '@usitsdasdesign/dds-ng/shared';
import { DataGridColumn } from '@/shared/components/data-grid/model';
import { BadgeApiService, BadgeTemplateApiService } from '@/core/services/apis';
import {
	BadgeStatus,
	BadgeTemplate,
	BadgeTemplateQuery,
	BadgeTemplateReleaseNote,
	BadgeTemplateStatus
} from '@/core/model/entities';
import { BreadCrumbService, PageStoreService } from '@/core/services/store';
import { SessionStoreService } from '@/core/services/store';
import { Router } from '@angular/router';
import { StickerDirective } from '@usitsdasdesign/dds-ng/sticker';
import { ModalService } from '@usitsdasdesign/dds-ng/modal';
import { ModalComponent } from '@/shared/components/modal/modal.component';
import { ToastOptions, ToastService } from '@usitsdasdesign/dds-ng/toast';
import { Action } from '@/core/model/common/actions';
import { DataGridComponent } from '@/shared/components/data-grid/data-grid.component';
import { catchError, forkJoin, of, Subscription } from 'rxjs';

import {
	myQueueBrSubmittedColumns,
	attentionRequiredBrSubmittedColumns,
	completedBrSubmittedColumns,
	myQueueAdminColumns,
	attentionRequiredAdminColumns,
	completedAdminColumns
} from './columns';
import { ButtonOptions } from '@usitsdasdesign/dds-ng/button';
import { validateStickerOpenOrClosed, setActionPrivateOrPublic } from '@/modules/shared/helpers/helpers';
@Component({
	selector: 'app-badge-submitted',
	templateUrl: './badge-submitted.component.html',
	styleUrls: ['./badge-submitted.component.scss']
})
export class BadgeSubmittedComponent implements OnInit, OnDestroy {
	constructor(
		public serviceBadgeTemplate: BadgeTemplateApiService,
		public service: BadgeApiService,
		public sessionService: SessionStoreService,
		private router: Router,
		private modal: ModalService,
		private toastService: ToastService,
		private breadCrumbService: BreadCrumbService,
		private renderer: Renderer2,
		private pageStoreService: PageStoreService
	) {}
	@ViewChild('tab1') completedGridRefA!: DataGridComponent;
	@ViewChild('tab2') completedGridRefB!: DataGridComponent;
	@ViewChild('tab3') completedGridRef!: DataGridComponent;
	@ViewChild('tab4') hiddendGridRef!: DataGridComponent;
	@ViewChild('actionStickerDir') actionStickerDir: StickerDirective;
	myQueue!: Array<DataGridColumn>;
	attentionRequired!: Array<DataGridColumn>;
	completed!: Array<DataGridColumn>;
	badgesApprovedFilter: any = {
		status: [BadgeStatus.Approved, BadgeStatus.Rejected],
		showExternals: false
	};
	badgesPendingFilter: any = { status: [BadgeStatus.SubmittedForApproval], showExternals: false };
	badgesAttentionRequiredFilter: any = { status: [BadgeTemplateStatus.AttentionRequired], showExternals: false };
	badgesHiddenFilter: any = {
		status: [BadgeTemplateStatus.HideForEdit, BadgeTemplateStatus.HideForArchive]
	};
	badgeServiceMethod: string;
	badgeSelectedId: string;

	readonly hiddenStatusLabel: any = {
		HideForEdit: 'To be edited',
		HideForArchive: 'To be archived'
	};

	dataReleaseNote: BadgeTemplateReleaseNote = {};

	showTabA: boolean = true;
	showTabB: boolean = false;
	showTabC: boolean = false;
	showTabD: boolean = false;

	options: ButtonOptions = {
		theme: Themes.dark,
		kind: ButtonKind.primaryLoud,
		size: Size.md,
		width: WidthState.fixed,
		isLoading: false,
		icon: '',
		isInverse: false,
		isDisabled: false,
		ariaLabel: 'Button',
		customClass: '',
		role: 'button'
	};

	actionsList: Action[] = [] as Action[];
	row: BadgeTemplateQuery;
	isAdminTemplateRoute = location.href.includes('admin/template');
	pageStoreSubs$: Subscription;

	/*  Todo: First version only show message then next US will be to generate actions. */

	noQueueToast: ToastOptions = {
		title: `You have no badges ${this.isAdminTemplateRoute ? 'templates' : ''} to approve at this time!`,
		message: ``,
		lifeTime: 5000,
		position: 'bottom-left',
		closeBtnIcon: 'dds-icon_close',
		isCloseIcon: true,
		customClass: 'simple-toast',
		limit: 3,
		theme: Themes.dark
	};

	badgesInQueueToast: ToastOptions = {
		title: `You have new badge ${
			this.isAdminTemplateRoute ? 'templates submissions' : 'submissions'
		} to be reviewed!`,
		message: ``,
		lifeTime: 5000,
		position: 'bottom-left',
		closeBtnIcon: 'dds-icon_close',
		isCloseIcon: true,
		customClass: 'simple-toast',
		limit: 3,
		theme: Themes.dark
	};

	hideForEditToast: ToastOptions = {
		title: `Badge template has been hidden`,
		message: ``,
		lifeTime: 5000,
		position: 'bottom-left',
		closeBtnIcon: 'dds-icon_close',
		isCloseIcon: true,
		customClass: 'simple-toast toast-blue',
		limit: 3,
		theme: Themes.white
	};

	myQueueActions: Action[] = [];

	attentionRequiredActions: Action[] = [
		{
			label: 'Review',
			disabled: false
		},
		{
			label: 'Move to my queue',
			disabled: false,
			modal: {
				title: 'Move this Badge to My Queue',
				hasFooter: true,
				contentTitle: 'Are you sure you want to move this badge to My Queue?',
				contentText: [`Once moved, you won't be able to return it.`],
				aceptButtonText: 'Yes, move',
				cancelButtonText: 'Cancel',
				actionForAceptButton: this.isAdminTemplateRoute
					? this.changeBadgeTemplateStatus.bind(this, BadgeTemplateStatus.Submitted, 2)
					: this.changeBadgeStatus.bind(this, BadgeStatus.SubmittedForApproval, 2)
			}
		},
		{
			label: 'Delete',
			disabled: false,
			modal: {
				title: `${
					this.isAdminTemplateRoute ? 'Delete Badge Template' : 'Are you sure you want to delete this badge?'
				}`,
				hasFooter: true,
				contentTitle: `Are you sure you want to delete this badge template?`,
				contentText: [
					this.isAdminTemplateRoute
						? `Deleting a badge template cannot be undone.
                            A deleted badge template will no longer be available to practitioners in the Deloitte Badge Catalog.<br/>
                            Please ensure that no practitioners are currently "In progress" on this badge.`
						: `Once deleted, you won't be able to return it.`
				],
				aceptButtonText: 'Yes, delete',
				cancelButtonText: 'Cancel',
				actionForAceptButton: this.changeBadgeStatus.bind(this, 'Deleted', 2)
			}
		}
	];

	completedActions: Action[] = [
		{
			label: 'Hide',
			disabled: false,
			modal: {
				title: 'Hide Badge',
				hasFooter: true,
				contentTitle: `Are you sure you want to hide this badge?`,
				contentText: [`Once hidden, it won't be able for the Practitioner's view.`],
				aceptButtonText: 'Yes, hide',
				cancelButtonText: 'Cancel',
				actionForAceptButton: this.changeBadgeStatus.bind(this, 'Hidden', 3)
			}
		},
		{
			label: 'Archive',
			disabled: false,
			modal: {
				title: 'Archive Badge',
				hasFooter: true,
				contentTitle: 'Are you sure you want to archive this badge?',
				contentText: [`Once archived, it won't be able for the Practitioner's view.`],
				aceptButtonText: 'Yes, archive',
				cancelButtonText: 'Cancel',
				actionForAceptButton: this.changeBadgeStatus.bind(this, 'Archived', 3)
			}
		}
	];

	completedAcceptedActions: Action[] = [
		{
			label: 'Hide for Archive',
			disabled: false,
			modal: {
				title: 'Hide for Archive',
				hasFooter: true,
				contentTitle: `Are you sure you want to hide the badge for archiving?`,
				contentText: [
					`Once hidden, a badge will not be available in the Deloitte Badge catalog, however,
					practitioners who are currently “Initiated” or “In progress” can still submit the badge for approval.`
				],
				aceptButtonText: 'Yes, hide',
				cancelButtonText: 'Cancel',
				actionForAceptButton: () => {
					this.modal.close();
					this.openSetupDateModal();
				},
				actionForCancelButton: () => {}
			}
		},
		{
			label: 'Hide for Edit',
			disabled: false,
			modal: {
				title: 'Hide Badge for Editing',
				hasFooter: true,
				contentTitle: `Are you sure you want to hide this badge for editing?`,
				contentText: [
					`Once hidden, a badge will not be available in the Deloitte Badge Catalog,`,
					`and practitioners who are currently “Initiated” or “In progress” will NOT be able to submit the badge for approval until it has been unhidden.`
				],
				aceptButtonText: 'Yes, hide',
				cancelButtonText: 'Cancel',
				actionForAceptButton: () => {
					this.changeBadgeTemplateStatus(BadgeTemplateStatus.HideForEdit, 4);
				}
			}
		},
		{
			label: 'Make Private',
			disabled: false
		}
	];

	completedHidedActions: Action[] = [
		{
			label: 'Archive',
			disabled: false,
			modal: {
				title: 'Archive Badge',
				hasFooter: true,
				contentTitle: 'Are you sure you want to archive this badge?',
				contentText: [`Once archived, it won't be able for the Practitioner's view.`],
				aceptButtonText: 'Yes, archive',
				cancelButtonText: 'Cancel',
				actionForAceptButton: this.changeBadgeTemplateStatus.bind(this, 'Archived', 3)
			}
		},
		{
			label: 'Unhide',
			disabled: false,
			modal: {
				title: 'Unhide Badge',
				hasFooter: true,
				contentTitle: `Are you sure you want to unhide this badge?`,
				contentText: [`Once unhidden, it will be active again for the Practitioner's view.`],
				aceptButtonText: 'Yes, unhide',
				cancelButtonText: 'Cancel',
				actionForAceptButton: () => {
					this.changeBadgeTemplateStatus('Accepted', 3);
				}
			}
		}
	];

	hiddenActions: Action[] = [
		{
			label: 'Archive',
			disabled: false,
			modal: {
				title: 'Archive Badge',
				hasFooter: true,
				contentTitle: `Are you sure you want to archive this badge?`,
				contentText: [`Once hidden, it won't be able for the Practitioner's view.`],
				aceptButtonText: 'Yes, archive',
				cancelButtonText: 'Cancel',
				actionForAceptButton: () => {
					this.changeBadgeTemplateStatus('Archive', 4);
				}
			}
		},
		{
			label: 'Add Archive Date',
			disabled: false,
			modal: {
				title: 'Add Archive Badge',
				hasFooter: true,
				contentTitle: 'Are you sure you want to add an archive date to this badge?',
				contentText: [
					`Once archived, practitioners will not be able to view this badge in the Deloitte Badge Catalog.
					Archived badges that have already been earned by practitioners will still display in their Deloitte Certified Digital Wallet.`
				],
				aceptButtonText: 'Yes, add archive date',
				cancelButtonText: 'Cancel',
				actionForAceptButton: () => {
					this.modal.close();
					this.openSetupDateModal();
				}
			}
		},
		{
			label: 'Unhide',
			disabled: false,
			modal: {
				title: 'Unhide Badge Template',
				hasFooter: true,
				contentTitle: 'Are you sure you want to unhide this badge?',
				contentText: [`Once archived, it won't be able for the Practitioner's view.`],
				aceptButtonText: 'Yes, unhide',
				cancelButtonText: 'Cancel',
				actionForAceptButton: () => {
					this.changeBadgeTemplateStatus(BadgeTemplateStatus.Accepted, 4);
				}
			}
		}
	];

	hiddenActionsWithDate: Action[] = [
		{
			label: 'Edit Archive Date',
			disabled: false,
			modal: {
				title: 'Add Archive Date',
				hasFooter: true,
				contentTitle: 'Are you sure you want to add an archive date to this badge?',
				contentText: [
					`Once archived, practitioners will not be able to view this badge in the Deloitte Badge Catalog.
					Archived badges that have already been earned by practitioners will still display in their Deloitte Certified Digital Wallet.`
				],
				aceptButtonText: 'Yes, add archive date',
				cancelButtonText: 'Cancel',
				actionForAceptButton: () => {
					this.modal.close();
					this.openSetupDateModal();
				}
			}
		},

		{
			label: 'Unhide',
			disabled: false,
			modal: {
				title: 'Unhide Badge Template',
				hasFooter: true,
				contentTitle: 'Are you sure you want to unhide this badge?',
				contentText: [`Once archived, it won't be able for the Practitioner's view.`],
				aceptButtonText: 'Yes, unhide',
				cancelButtonText: 'Cancel',
				actionForAceptButton: () => {
					this.changeBadgeTemplateStatus(BadgeTemplateStatus.Accepted, 4);
				}
			}
		}
	];

	hiddenForEditActions: Action[] = [
		{
			label: 'Edit',
			disabled: false
		},
		{
			label: 'Unhide',
			disabled: false,
			modal: {
				title: 'Provide edit details',
				hasFooter: true,
				showFeedback: false,
				showReleaseNotes: true,
				showUnhideBtnReleaseNotes: true,
				contentTitle: '',
				contentText: [
					`The message below will be visible to practitioners. To ensure practitioners understand the changes,
					please provide specific details about changes applied to this badge`
				],
				aceptButtonText: 'Save as Draft',
				cancelButtonText: 'Cancel',
				actionForAceptButton: () => {
					this.updateReleaseNote(BadgeTemplateStatus.HideForEdit);
				},
				actionForHiddenButton: () => {
					this.updateReleaseNote(BadgeTemplateStatus.HideForEdit, true);
				}
			}
		}
	];

	private updateReleaseNote(status: string, actionForHidden: boolean = false) {
		const notes = this.renderer.selectRootElement(
			'app-modal > .dds-modal > .dds-modal__body dds-textarea > .dds-textarea > div:last-child > textarea',
			true
		).value;

		const onlyInitiated = this.renderer.selectRootElement(
			'app-modal > .dds-modal > .dds-modal__body dds-radio-group > div > dds-radio:last-child > label > input',
			true
		).checked;

		this.dataReleaseNote = {
			id: this.badgeSelectedId,
			notes: notes == '' ? null : notes,
			applyOnlyInitiated: Boolean(onlyInitiated)
		};
		const { id } = this.row;

		if (this.dataReleaseNote.notes !== null && this.dataReleaseNote.notes?.length > 0) {
			forkJoin({
				releaseNote: this.serviceBadgeTemplate.patch(this.dataReleaseNote),
				badgeTemplate: this.serviceBadgeTemplate.changeBadgeTemplateStatus({ id, status })
			})
				.pipe(catchError(() => of(false)))
				.subscribe((response: any) => {
					if (!response) {
						this.modal.close();
						return;
					}

					this.refreshGrid(3);
					setTimeout(() => {
						this.refreshGrid(4);
					}, 1500);
					this.selectTab(3);
					this.modal.close();

					if (actionForHidden) this.changeBadgeTemplateStatus(BadgeTemplateStatus.Accepted, 4);
				});
		} else {
			this.changeBadgeTemplateStatus(BadgeTemplateStatus.Accepted, 4);
		}
	}

	setAction(sticker: StickerDirective, row: BadgeTemplateQuery) {
		// This type must be any to avoid typing errors using variables to access to the values
		this.myQueueActions = this.initMyQueueActions();

		if (!this.isAdminTemplateRoute) {
			this.attentionRequiredActions = this.attentionRequiredActions.filter((e: any) => {
				return e.label != 'Archive';
			});
		}

		if (row.status == BadgeTemplateStatus.Draft) {
			this.myQueueActions = this.myQueueActions.map((e: any) => {
				e.disabled = e.label == 'Edit' && row.status == BadgeTemplateStatus.Draft ? false : e.disabled;
				e.disabled = e.label == 'Review' && row.status == BadgeTemplateStatus.Draft ? true : e.disabled;
				return e;
			});
		} else {
			this.myQueueActions = this.myQueueActions.map((e: any) => {
				e.disabled = e.label == 'Edit' ? true : e.disabled;
				return e;
			});
		}

		const posibleActions: any = {
			myQueue: this.myQueueActions,
			attentionRequired: this.attentionRequiredActions,
			completed:
				row.status == BadgeTemplateStatus.Accepted
					? this.completedAcceptedActions
					: row.status == BadgeTemplateStatus.HideForArchive && row.archiveDate === null
					? this.hiddenActions
					: row.status == BadgeTemplateStatus.HideForArchive && row.archiveDate !== null
					? this.hiddenActionsWithDate
					: row.status == BadgeTemplateStatus.HideForEdit
					? this.hiddenForEditActions
					: this.completedActions
		};

		const { stickerCustomClass } = sticker;
		if (row.status == BadgeTemplateStatus.Archived || row.status == BadgeTemplateStatus.Rejected) {
			this.actionsList = [] as Action[];
		} else {
			this.actionsList = posibleActions[stickerCustomClass] as Action[];
		}

		this.badgeSelectedId = row.id;
		this.row = row;
		setActionPrivateOrPublic(this.completedAcceptedActions, this.row);
	}

	initMyQueueActions() {
		return [
			{
				label: 'Review',
				disabled: false
			},
			{
				label: 'Edit',
				disabled: true
			},
			{
				label: 'Delete',
				disabled: false,
				modal: {
					title: `${this.isAdminTemplateRoute ? 'Delete Badge Template' : 'Delete Badge'}`,
					hasFooter: true,
					contentTitle: `Are you sure you want to delete this badge template?`,
					contentText: [
						this.isAdminTemplateRoute
							? `Deleting a badge template cannot be undone.
                                A deleted badge template will no longer be available to practitioners in the Deloitte Badge Catalog.<br/>
                                Please ensure that no practitioners are currently "In progress" on this badge.`
							: `Once deleted, you won't be able to return it.`
					],
					aceptButtonText: 'Yes, delete',
					cancelButtonText: 'Cancel',
					actionForAceptButton: this.isAdminTemplateRoute
						? this.changeBadgeTemplateStatus.bind(this, BadgeTemplateStatus.Deleted, 1)
						: this.changeBadgeStatus.bind(this, BadgeStatus.Deleted, 1)
				}
			}
		];
	}

	changeBadgeTemplateStatus(status: string, tab: number): void {
		const { id } = this.row;
		if (this.changeStatusHiddenActions(status)) return;

		this.serviceBadgeTemplate.changeBadgeTemplateStatus({ id, status }).subscribe(() => {
			if (status == BadgeTemplateStatus.AwaitingApproval) {
				this.refreshGrid(1);
				this.refreshGrid(2);
			} else if (status == BadgeTemplateStatus.Archived && tab == 2) {
				this.refreshGrid(2);
				this.refreshGrid(3);
			} else if (status === BadgeTemplateStatus.Submitted) {
				this.refreshGrid(1);
				this.refreshGrid(tab);
				this.pageStoreService.setBadgesActiveTabIndex(0);
			} else if (status == BadgeTemplateStatus.Accepted) {
				this.refreshGrid(3);

				setTimeout(() => {
					this.refreshGrid(4);
					this.selectTab(2);
				}, 1500);
			} else if (status == BadgeTemplateStatus.Deleted) {
				this.refreshGrid(1);
				this.hideForEditToast.title = `You have successfully deleted this Badge Template`
				this.hideForEditToast.message = `The ${this.row.name} template has been deleted successfully`;
				this.toastService.createToast(this.hideForEditToast);
			}

			if (status == BadgeTemplateStatus.Hidden) {
				this.selectTab(3);
				this.refreshGrid(tab);
				this.hideForEditToast.message = `The ${this.row.name} has been hidden and it's going to be archived. The date
				has already being set up.`;

				this.toastService.createToast(this.hideForEditToast);
			}

			if (status == BadgeTemplateStatus.HideForArchive) {
				this.refreshGrid(3);
				setTimeout(() => {
					this.refreshGrid(4);
				}, 2000);
				this.selectTab(3);
				this.hideForEditToast.message = `The ${this.row.name} has been hidden. You can unhide it, archive it or set a date to archive it.`;
				this.toastService.createToast(this.hideForEditToast);
			} else if (status == BadgeTemplateStatus.HideForEdit) {
				this.refreshGrid(3);
				setTimeout(() => {
					this.refreshGrid(4);
				}, 1000);
				this.selectTab(3);
				this.hideForEditToast.message = `The ${this.row.name} has been hidden. `;
				this.toastService.createToast(this.hideForEditToast);
			}

			this.modal.close();
		});
	}

	changeBadgeTemplateArchiveStatus(status: string, tab: number): void {
		const { id } = this.row;
		if (this.changeStatusHiddenActions(status)) return;

		let archiveDate: any = this.renderer.selectRootElement('.dds-datepicker__input', true);
		let checkDate: any = this.renderer.selectRootElement("input[type='checkbox']", true);
		this.serviceBadgeTemplate
			.changeBadgeTemplateArchiveStatus({
				badgeTemplateId: id,
				status,
				archiveDate: checkDate.checked ? null : new Date(archiveDate.value),
				result: true
			})
			.pipe(catchError(() => of(false)))
			.subscribe((response: any) => {
				if (!response) {
					this.modal.close();
					return;
				}

				if (status == BadgeTemplateStatus.HideForEdit) {
					this.refreshGrid(3);
					this.refreshGrid(4);
					this.selectTab(3);
					this.hideForEditToast.message = `The ${this.row.name} has been hidden.`;
					this.toastService.createToast(this.hideForEditToast);
				} else if (status == BadgeTemplateStatus.HideForArchive) {
					this.refreshGrid(3);
					this.refreshGrid(4);
					this.selectTab(3);
					this.hideForEditToast.message = `The ${this.row.name} has been hidden. You can unhide it, archive it or set a date to archive it. `;
					this.toastService.createToast(this.hideForEditToast);
				}

				this.modal.close();
			});
	}

	changeBadgeStatus(status: string, tab: number) {
		const { id } = this.row;
		if (status == BadgeStatus.Deleted) {
			this.serviceBadgeTemplate.delete(id).subscribe(() => {
				this.refreshGrid(tab);
				this.modal.close();
				this.hideForEditToast.title = `You have succesfully deleted this badge`
				this.hideForEditToast.message = `The ${this.row?.badgeTemplateName}'s Badge was successfully deleted.`;
				this.toastService.createToast(this.hideForEditToast);
			});
		} else {
			if (status == BadgeStatus.AwaitingApproval) {
				status = BadgeStatus.SubmittedForApproval;
			}

			this.service.changeBadgeStatus({ id, status }).subscribe(() => {
				if (status == BadgeStatus.SubmittedForApproval) {
					this.refreshGrid(1);
					this.refreshGrid(2);
				} else {
					this.refreshGrid(tab);
				}

				this.modal.close();
			});
		}
	}

	changeStatusHiddenActions(status: string): boolean {
		switch (status) {
			case 'Archive':
				//TODO - Implement call service for Archive action (change status)
				console.log('Call service Archive');

				this.changeBadgeTemplateStatus(BadgeTemplateStatus.Archived, 4);
				break;

			case 'AddArchiveDate':
				//TODO - Implement call service for AddArchiveDate action (change status)
				console.log('Call service AddArchiveDate');
				break;

			case 'Unhide':
				//TODO - Implement call service for Unhide action (change status)
				console.log('Call service Unhide');
				break;

			default:
				return false;
		}

		this.modal.close();
		return true;
	}

	refreshGrid(tab: number = 1) {
		if (tab == 1 && this.showTabA) {
			this.completedGridRefA.getInformationToFillTable();
		} else if (tab == 2 || this.showTabB) {
			this.completedGridRefB.getInformationToFillTable();
		} else if (tab == 3 || this.showTabC) {
			this.completedGridRef.getInformationToFillTable();
		} else if (tab == 4 || this.showTabD) {
			this.hiddendGridRef.getInformationToFillTable();
		}
	}

	ngOnInit(): void {
		this.sessionService.UserSession.subscribe({
			next: (userData) => {
				if (userData.roles[0] == 'BusinessRep') {
					this.breadCrumbService.setHideBreadcrumbs(true);
					this.badgeServiceMethod = 'getBadgesBusinessRep';
					this.myQueue = myQueueBrSubmittedColumns;
					this.attentionRequired = attentionRequiredBrSubmittedColumns;
					this.completed = completedBrSubmittedColumns;
				} else {
					if (location.href.indexOf('badges/admin/templates') > -1) {
						this.badgesApprovedFilter.status = [
							BadgeTemplateStatus.Accepted,
							BadgeTemplateStatus.Archived,
							BadgeTemplateStatus.Rejected
						];
						this.badgesPendingFilter.status = [BadgeTemplateStatus.Draft, BadgeTemplateStatus.Submitted];
						this.badgeServiceMethod = 'getBadgesTemplatesAdmin';
					} else {
						this.badgeServiceMethod = 'getBadgesAdmin';
					}

					this.setColumns();
				}
			}
		});
		this.pageStoreSubs$ = this.pageStoreService.badgesActiveTabIndex.subscribe((index: number) =>
			this.selectTab(index ?? 0)
		);
	}

	verifyBadgesQueue(queueItems: any) {
		if (queueItems === 0) {
			this.toastService.createToast(this.noQueueToast);
		} else {
			this.toastService.createToast(this.badgesInQueueToast);
		}
	}

	private setColumns() {
		this.myQueue = this.isAdminTemplateRoute ? myQueueAdminColumns : myQueueBrSubmittedColumns;
		this.attentionRequired = this.isAdminTemplateRoute
			? attentionRequiredAdminColumns
			: attentionRequiredBrSubmittedColumns;
		this.completed = this.isAdminTemplateRoute ? completedAdminColumns : completedBrSubmittedColumns;
	}

	selectTab(indexTab: number) {
		this.showTabA = indexTab == 0;
		this.showTabB = indexTab == 1;
		this.showTabC = indexTab == 2;
		this.showTabD = indexTab == 3;
	}

	tabContainerOptions: TabsOptions = {
		theme: Themes.green,
		themeType: TabThemeType.border,
		size: Size.md,
		ariaLabel: 'Horizontal tabs',
		isDisabled: false,
		customClass: 'repor-badge-submitted',
		isResponsive: false
	};

	tabOptions1: TabOptions = {
		label: 'My Queue'
	};
	tabOptions2: TabOptions = {
		label: 'Attention Required'
	};
	tabOptions3: TabOptions = {
		label: 'Completed',
		customClass: ''
	};
	tabOptions4: TabOptions = {
		label: 'Hidden',
		customClass: ''
	};

	tabChanged(tabItem: TabComponent) {}

	openSetupDateModal() {
		let modal: any = {
			title: 'Set up the Archive Date',
			hasFooter: true,
			contentTitle: ``,
			contentText: [`Please select the specific date that this badge might be archived.`],
			aceptButtonText: 'Continue',
			cancelButtonText: 'Cancel',
			actionForAceptButton: () => {
				this.changeBadgeTemplateArchiveStatus(BadgeTemplateStatus.HideForArchive, 3);
			},
			actionForCancelButton: () => {}
		};

		this.modal.open(ModalComponent, { modal, showSkipButton: true });
	}

	showPreview(rowValue: BadgeTemplateQuery) {
		const { id, status } = rowValue;
		this.badgeSelectedId = id;
		if (validateStickerOpenOrClosed('completed', status)) {
			this.router.navigate(['/badges/templates/review/' + this.badgeSelectedId]);
		}
	}

	selectRowGrid(row: any) {
		if (
			row.status == BadgeTemplateStatus.HideForArchive &&
			validateStickerOpenOrClosed('completed', BadgeTemplateStatus.Accepted)
		) {
			this.router.navigate(['/badges/templates/edit/' + row.id]);
		}
	}

	onEditClick(actionClicked: Action) {
		const { label, modal } = actionClicked;
		const isModalAction =
			label != 'Edit' &&
			label != 'Review' &&
			label != 'Make Private' &&
			label != 'Make Public' &&
			label != 'Edit Archive Date';
		if (isModalAction) {
			this.modal.open(ModalComponent, { modal });
		}

		if (label == 'Edit Archive Date') {
			this.openSetupDateModal();
		}

		if (label == 'Review') {
			sessionStorage.setItem('selectedPractitioner', this.row.employeeName);
			if (location.href.indexOf('/badges/admin/templates') > 1) {
				this.router.navigate(['/badges/templates/review/' + this.badgeSelectedId]);
			} else {
				this.router.navigate([`/badge-approval/${this.badgeSelectedId}`]);
			}
		}

		if (label == 'Edit') {
			if (location.href.indexOf('/badges/admin/templates') > 1) {
				this.router.navigate(['/badges/templates/edit/' + this.badgeSelectedId]);
			}
		}

		if (label === 'Make Private' || label === 'Make Public') this.makePrivateOrPublic();

		this.setInfoReleaseNote(label);
		this.actionStickerDir.hide();
	}

	setInfoReleaseNote(label: string): void {
		if (label === BadgeTemplateStatus.Unhide) {
			this.serviceBadgeTemplate
				.getBadgeTemplateInfo(this.badgeSelectedId)
				.subscribe((response: BadgeTemplate) => {
					const getElementText = this.renderer.selectRootElement(
						'app-modal > .dds-modal > .dds-modal__body dds-textarea > .dds-textarea > div:last-child > textarea',
						true
					);
					const getElementRadioFirst = this.renderer.selectRootElement(
						'app-modal > .dds-modal > .dds-modal__body dds-radio-group > div > dds-radio:first-child > label > input',
						true
					);
					const getElementRadioLast = this.renderer.selectRootElement(
						'app-modal > .dds-modal > .dds-modal__body dds-radio-group > div > dds-radio:last-child > label > input',
						true
					);

					const textValue = response.releaseNotes !== null ? response.releaseNotes : '';
					const radioValue =
						response.applyReleaseNotesOnlyInitiated !== null
							? response.applyReleaseNotesOnlyInitiated
							: false;

					this.renderer.setProperty(getElementText, 'value', textValue);
					this.renderer.setProperty(getElementRadioFirst, 'checked', !radioValue);
					this.renderer.setProperty(getElementRadioLast, 'checked', radioValue);
				});
		}
	}

	private makePrivateOrPublic() {
		const { id, issuer, isPublic } = this.row;
		const params = { id, issuer, isPublic: !isPublic };
		this.serviceBadgeTemplate.changePrivacy(params).subscribe(() => {
			this.refreshGrid();
		});
	}

	createNewTemplate(): void {
		this.router.navigate(['/badges/templates/create']);
	}

	ngOnDestroy(): void {
		this.pageStoreService.setBadgesActiveTabIndex(0);
		this.pageStoreSubs$.unsubscribe();
		this.breadCrumbService.setHideBreadcrumbs(false);
	}
}
