import { DataGridColumn } from '@/shared/components/data-grid/model';

export const myQueueBrColumns: DataGridColumn[] = [
	{
		label: 'Practitioner Name',
		fieldValue: 'ownerName',
		cellTemplateName: '',
		allowOrderBy: true,
		allowFilterText: false,
		allowFilterFixedValues: false,
		selected: false,
		dataType: 'string'
	},
	{
		label: 'Badge Name',
		fieldValue: 'name',
		cellTemplateName: '',
		allowOrderBy: true,
		allowFilterText: false,
		allowFilterFixedValues: false,
		selected: false,
		dataType: 'string'
	},
	{
		label: 'Level',
		fieldValue: 'level',
		cellTemplateName: '',
		allowOrderBy: true,
		allowFilterText: false,
		allowFilterFixedValues: false,
		selected: false,
		dataType: 'string'
	},
	{
		label: 'Date added to Queue',
		fieldValue: 'createdAt',
		cellTemplateName: 'dateCell',
		allowOrderBy: true,
		allowFilterText: false,
		allowFilterFixedValues: false,
		selected: false,
		dataType: 'string'
	},
	{
		label: 'Actions',
		fieldValue: '',
		cellTemplateName: 'editCell',
		allowOrderBy: false,
		allowFilterText: false,
		allowFilterFixedValues: false,
		selected: false,
		dataType: 'string'
	}
];

export const attentionRequiredBrColumns: DataGridColumn[] = [
	{
		label: 'Practitioner Name',
		fieldValue: 'ownerName',
		cellTemplateName: '',
		allowOrderBy: true,
		allowFilterText: false,
		allowFilterFixedValues: false,
		selected: false,
		dataType: 'string'
	},
	{
		label: 'Badge Name',
		fieldValue: 'name',
		cellTemplateName: '',
		allowOrderBy: true,
		allowFilterText: false,
		allowFilterFixedValues: false,
		selected: false,
		dataType: 'string'
	},
	{
		label: 'Date added to Queue',
		fieldValue: 'createdAt',
		cellTemplateName: 'dateCell',
		allowOrderBy: true,
		allowFilterText: false,
		allowFilterFixedValues: false,
		selected: false,
		dataType: 'string'
	},
	{
		label: 'Status',
		fieldValue: 'status',
		cellTemplateName: 'splitByUpperCell',
		allowOrderBy: true,
		allowFilterText: false,
		allowFilterFixedValues: false,
		selected: false,
		dataType: 'string'
	},
	{
		label: 'Actions',
		fieldValue: '',
		cellTemplateName: 'editCell',
		allowOrderBy: false,
		allowFilterText: false,
		allowFilterFixedValues: false,
		selected: false,
		dataType: 'string'
	}
];

export const completedBrColumns: DataGridColumn[] = [
	{
		label: 'Practitioner Name',
		fieldValue: 'ownerName',
		cellTemplateName: '',
		allowOrderBy: true,
		allowFilterText: false,
		allowFilterFixedValues: false,
		selected: false,
		dataType: 'string'
	},
	{
		label: 'Badge Name',
		fieldValue: 'name',
		cellTemplateName: '',
		allowOrderBy: true,
		allowFilterText: false,
		allowFilterFixedValues: false,
		selected: false,
		dataType: 'string'
	},
	{
		label: 'Date added to Queue',
		fieldValue: 'createdAt',
		cellTemplateName: 'dateCell',
		allowOrderBy: true,
		allowFilterText: false,
		allowFilterFixedValues: false,
		selected: false,
		dataType: 'string'
	},
	{
		label: 'Status',
		fieldValue: 'status',
		cellTemplateName: 'splitByUpperCell',
		allowOrderBy: true,
		allowFilterText: false,
		allowFilterFixedValues: false,
		selected: false,
		dataType: 'string'
	}
];

export const myQueueBrSubmittedColumns: DataGridColumn[] = [
	{
		label: 'Practitioner Name',
		fieldValue: 'employeeName',
		cellTemplateName: '',
		allowOrderBy: true,
		allowFilterText: false,
		allowFilterFixedValues: false,
		selected: false,
		dataType: 'string'
	},
	{
		label: 'Badge Name',
		fieldValue: 'badgeTemplateName',
		cellTemplateName: '',
		allowOrderBy: true,
		allowFilterText: false,
		allowFilterFixedValues: false,
		selected: false,
		dataType: 'string'
	},
	{
		label: 'Level',
		fieldValue: 'badgeTemplateLevel',
		cellTemplateName: '',
		allowOrderBy: true,
		allowFilterText: false,
		allowFilterFixedValues: false,
		selected: false,
		dataType: 'string'
	},
	{
		label: 'Date added to Queue',
		fieldValue: 'submittedAt',
		cellTemplateName: 'dateCell',
		allowOrderBy: true,
		allowFilterText: false,
		allowFilterFixedValues: false,
		selected: false,
		dataType: 'string'
	},
	{
		label: 'Actions',
		fieldValue: '',
		cellTemplateName: 'editCell',
		allowOrderBy: false,
		allowFilterText: false,
		allowFilterFixedValues: false,
		selected: false,
		dataType: 'string'
	}
];

export const attentionRequiredBrSubmittedColumns: DataGridColumn[] = [
	{
		label: 'Practitioner Name',
		fieldValue: 'employeeName',
		cellTemplateName: '',
		allowOrderBy: true,
		allowFilterText: false,
		allowFilterFixedValues: false,
		selected: false,
		dataType: 'string'
	},
	{
		label: 'Badge Name',
		fieldValue: 'badgeTemplateName',
		cellTemplateName: '',
		allowOrderBy: true,
		allowFilterText: false,
		allowFilterFixedValues: false,
		selected: false,
		dataType: 'string'
	},
	{
		label: 'Date added to Queue',
		fieldValue: 'submittedAt',
		cellTemplateName: 'dateCell',
		allowOrderBy: true,
		allowFilterText: false,
		allowFilterFixedValues: false,
		selected: false,
		dataType: 'string'
	},
	{
		label: 'Status',
		fieldValue: 'status',
		cellTemplateName: 'splitByUpperCell',
		allowOrderBy: true,
		allowFilterText: false,
		allowFilterFixedValues: false,
		selected: false,
		dataType: 'string'
	},
	{
		label: 'Actions',
		fieldValue: '',
		cellTemplateName: 'editCell',
		allowOrderBy: false,
		allowFilterText: false,
		allowFilterFixedValues: false,
		selected: false,
		dataType: 'string'
	}
];

export const completedBrSubmittedColumns: DataGridColumn[] = [
	{
		label: 'Practitioner Name',
		fieldValue: 'employeeName',
		cellTemplateName: '',
		allowOrderBy: true,
		allowFilterText: false,
		allowFilterFixedValues: false,
		selected: false,
		dataType: 'string'
	},
	{
		label: 'Badge Name',
		fieldValue: 'badgeTemplateName',
		cellTemplateName: '',
		allowOrderBy: true,
		allowFilterText: false,
		allowFilterFixedValues: false,
		selected: false,
		dataType: 'string'
	},
	{
		label: 'Date added to Queue',
		fieldValue: 'submittedAt',
		cellTemplateName: 'dateCell',
		allowOrderBy: true,
		allowFilterText: false,
		allowFilterFixedValues: false,
		selected: false,
		dataType: 'string'
	},
	{
		label: 'Status',
		fieldValue: 'status',
		cellTemplateName: 'splitByUpperCell',
		allowOrderBy: true,
		allowFilterText: false,
		allowFilterFixedValues: false,
		selected: false,
		dataType: 'string'
	}
];

export const myQueueAdminColumns: DataGridColumn[] = [
	{
		label: 'Name template',
		fieldValue: 'name',
		cellTemplateName: 'nameCell',
		allowOrderBy: true,
		allowFilterText: false,
		allowFilterFixedValues: false,
		selected: false,
		dataType: 'string'
	},
	{
		label: 'Badge Owner',
		fieldValue: 'ownerName',
		cellTemplateName: '',
		allowOrderBy: true,
		allowFilterText: false,
		allowFilterFixedValues: false,
		selected: false,
		dataType: 'string'
	},
	{
		label: 'Collection',
		fieldValue: 'collections',
		cellTemplateName: '',
		allowOrderBy: true,
		allowFilterText: false,
		allowFilterFixedValues: false,
		selected: false,
		dataType: 'string'
	},
	{
		label: 'Level',
		fieldValue: 'level',
		cellTemplateName: '',
		allowOrderBy: true,
		allowFilterText: false,
		allowFilterFixedValues: false,
		selected: false,
		dataType: 'string'
	},
	{
		label: 'Date added to Queue',
		fieldValue: 'createdAt',
		cellTemplateName: 'dateCell',
		allowOrderBy: true,
		allowFilterText: false,
		allowFilterFixedValues: false,
		selected: false,
		dataType: 'string'
	},
	{
		label: 'Actions',
		fieldValue: '',
		cellTemplateName: 'editCell',
		allowOrderBy: false,
		allowFilterText: false,
		allowFilterFixedValues: false,
		selected: false,
		dataType: 'string'
	}
];

export const attentionRequiredAdminColumns: DataGridColumn[] = [
	{
		label: 'Name template',
		fieldValue: 'name',
		cellTemplateName: '',
		allowOrderBy: true,
		allowFilterText: false,
		allowFilterFixedValues: false,
		selected: false,
		dataType: 'string'
	},
	{
		label: 'Badge Owner',
		fieldValue: 'ownerName',
		cellTemplateName: '',
		allowOrderBy: true,
		allowFilterText: false,
		allowFilterFixedValues: false,
		selected: false,
		dataType: 'string'
	},
	{
		label: 'Collection',
		fieldValue: 'collections',
		cellTemplateName: '',
		allowOrderBy: true,
		allowFilterText: false,
		allowFilterFixedValues: false,
		selected: false,
		dataType: 'string'
	},
	{
		label: 'Level',
		fieldValue: 'level',
		cellTemplateName: '',
		allowOrderBy: true,
		allowFilterText: false,
		allowFilterFixedValues: false,
		selected: false,
		dataType: 'string'
	},
	{
		label: 'Date added to Queue',
		fieldValue: 'createdAt',
		cellTemplateName: 'dateCell',
		allowOrderBy: true,
		allowFilterText: false,
		allowFilterFixedValues: false,
		selected: false,
		dataType: 'string'
	},
	{
		label: 'Actions',
		fieldValue: '',
		cellTemplateName: 'editCell',
		allowOrderBy: false,
		allowFilterText: false,
		allowFilterFixedValues: false,
		selected: false,
		dataType: 'string'
	}
];

export const completedAdminColumns: DataGridColumn[] = [
	{
		label: 'Name template',
		fieldValue: 'name',
		cellTemplateName: '',
		allowOrderBy: true,
		allowFilterText: false,
		allowFilterFixedValues: false,
		selected: false,
		dataType: 'string'
	},
	{
		label: 'Badge Owner',
		fieldValue: 'ownerName',
		cellTemplateName: '',
		allowOrderBy: true,
		allowFilterText: false,
		allowFilterFixedValues: false,
		selected: false,
		dataType: 'string'
	},
	{
		label: 'Collection',
		fieldValue: 'collections',
		cellTemplateName: '',
		allowOrderBy: true,
		allowFilterText: false,
		allowFilterFixedValues: false,
		selected: false,
		dataType: 'string'
	},
	{
		label: 'Level',
		fieldValue: 'level',
		cellTemplateName: '',
		allowOrderBy: true,
		allowFilterText: false,
		allowFilterFixedValues: false,
		selected: false,
		dataType: 'string'
	},
	{
		label: 'Date added to Queue',
		fieldValue: 'createdAt',
		cellTemplateName: 'dateCell',
		allowOrderBy: true,
		allowFilterText: false,
		allowFilterFixedValues: false,
		selected: false,
		dataType: 'string'
	},
	{
		label: 'Status',
		fieldValue: 'status',
		cellTemplateName: 'approvedStatusCell',
		allowOrderBy: true,
		allowFilterText: false,
		allowFilterFixedValues: false,
		selected: false,
		dataType: 'string'
	},
	{
		label: 'Actions',
		fieldValue: '',
		cellTemplateName: 'editCell',
		allowOrderBy: false,
		allowFilterText: false,
		allowFilterFixedValues: false,
		selected: false,
		dataType: 'string'
	}
];
