import { ComponentFixture, TestBed } from '@angular/core/testing';

import { BadgeSubmittedComponent } from './badge-submitted.component';

xdescribe('BadgeSubmittedComponent', () => {
  let component: BadgeSubmittedComponent;
  let fixture: ComponentFixture<BadgeSubmittedComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ BadgeSubmittedComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(BadgeSubmittedComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
