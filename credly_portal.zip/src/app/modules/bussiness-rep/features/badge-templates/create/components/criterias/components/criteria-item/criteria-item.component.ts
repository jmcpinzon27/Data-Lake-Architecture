import { BadgeTemplateCriteria, CriteriaType } from '@/core/model/entities';
import { Component, Input, Output, EventEmitter } from '@angular/core';

@Component({
	selector: 'app-criteria-item',
	templateUrl: './criteria-item.component.html',
	styleUrls: ['./criteria-item.component.scss']
})
export class CriteriaItemComponent {
	@Input() criteria: BadgeTemplateCriteria;
	@Input() index: number;
	@Input() isAlternative: boolean;

	@Output() criteriaChange: EventEmitter<BadgeTemplateCriteria> = new EventEmitter<BadgeTemplateCriteria>();
	@Output() add = new EventEmitter<{ index: number; type: CriteriaType }>();
	@Output() remove = new EventEmitter<{ index: number; type: CriteriaType }>();

	constructor() {}
}
