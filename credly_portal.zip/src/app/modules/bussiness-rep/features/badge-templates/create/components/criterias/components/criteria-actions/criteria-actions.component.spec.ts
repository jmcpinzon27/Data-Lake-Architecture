import { ComponentFixture, TestBed } from '@angular/core/testing';
import { CriteriaActionsComponent } from './criteria-actions.component';
import { CriteriaType } from '@/core/model/entities';

describe('CriteriaActionsComponent', () => {
  let component: CriteriaActionsComponent;
  let fixture: ComponentFixture<CriteriaActionsComponent>;
  let objectEmit = { index: 1, type: CriteriaType.Education };

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CriteriaActionsComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(CriteriaActionsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should emit event add', () => {
    spyOn(component.add, 'emit');  
    component.add.emit(objectEmit); 
    fixture.detectChanges(); 

    expect(component.add.emit).toHaveBeenCalled();
  });

  it('should emit event remove', () => {
    spyOn(component.remove, 'emit');  
    component.remove.emit(objectEmit); 
    fixture.detectChanges(); 

    expect(component.remove.emit).toHaveBeenCalled();
  });
});
