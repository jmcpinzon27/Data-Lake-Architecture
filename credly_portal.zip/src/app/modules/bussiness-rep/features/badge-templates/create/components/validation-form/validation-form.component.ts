import { Component, Input, OnInit, ViewChild } from '@angular/core';
import { Size, ErrorState, LabelPosition } from '@usitsdasdesign/dds-ng/shared';
import { InputOptions } from '@usitsdasdesign/dds-ng/input';
import { SelectItemOptions, SelectOptions } from '@usitsdasdesign/dds-ng/select';
import { BadgeTemplate } from '@/core/model/entities';
import BadgeTemplateStoreService from '@/core/services/store/badgeTemplateStoreService';
import { ExpirationRange } from '@/core/model/entities';
import { EmployeeApiService } from '@/core/services/apis';
import { FilterColumn, ListRequest, OrderBy } from '@/core/model/common';
import { StickerDirective } from '@usitsdasdesign/dds-ng/sticker';

@Component({
	selector: 'app-validation-form',
	templateUrl: './validation-form.component.html',
	styleUrls: ['./validation-form.component.scss']
})
export class ValidationFormComponent implements OnInit {
	@ViewChild('stickerDir') stickerDir: StickerDirective;

	@Input()
	validationInfo: string = '';

	validationDefault: any;

	filterColumn: Array<FilterColumn> = [
		{
			column: '',
			value: '',
			freeText: false
		}
	];

	orderByFilter: OrderBy = {
		column: '',
		desc: false
	};

	request: ListRequest = {
		pageIndex: 1,
		pageSize: 10,
		filterColumns: this.filterColumn,
		SearchText: '',
		orderBy: this.orderByFilter,
		Roles: 'Admin|BusinessRep'
	};

	constructor(
		private badgeTemplateStoreService: BadgeTemplateStoreService,
		private employeeService: EmployeeApiService
	) {}

	@ViewChild('form') form: any;

	entity: BadgeTemplate;

	@ViewChild('inputSponsor', { static: false }) inputSponsor: any;
	@ViewChild('inputOwner', { static: false }) inputOwner: any;
	@ViewChild('inputApprover', { static: false }) inputApprover: any;
	@ViewChild('inputOpApprover', { static: false }) inputOpApprover: any;

	@Input()
	showListSponsor: boolean = false;

	@Input()
	showListOwner: boolean = false;

	@Input()
	showListApprover: boolean = false;

	@Input()
	showListOptionalApprover: boolean = false;
	badgeSponsor: string = '';
	badgeOwner: string = '';
	badgeApprover: string = '';
	badgeOptionalApprover: string = '';
	listSponsor: any[] = [];
	listOwner: any[] = [];
	listApprover: any[] = [];
	listOptionalApprover: any[] = [];

	ngOnInit(): void {
		this.badgeTemplateStoreService.entity$.subscribe((e) => {
			this.entity = { ...e };
			if (this.validationInfo !== '') {
				this.entity.reviewDate =
					this.validationDefault?.reviewDate !== null && this.validationDefault?.reviewDate !== undefined
						? new Date(this.validationDefault?.reviewDate)
						: null;
			}
		});

		if (this.validationInfo !== '') {
			this.validationDefault = JSON.parse(this.validationInfo);
			this.badgeSponsor = this.validationDefault?.sponsor
				? this.validationDefault?.sponsor.firstName + ' ' + this.validationDefault?.sponsor.lastName
				: '';
			this.badgeOwner = this.validationDefault?.owner
				? this.validationDefault?.owner.firstName + ' ' + this.validationDefault?.owner.lastName
				: '';
			this.badgeApprover = this.validationDefault?.approver ? this.validationDefault?.approver.email : '';
			this.badgeOptionalApprover = this.validationDefault?.optionalApprover
				? this.validationDefault?.optionalApprover.email
				: '';
			this.selectedItem = this.validationDefault?.expiresAt;
			this.entity.sponsorPersonID = this.validationDefault?.sponsorPersonID;
			this.entity.ownerPersonID = this.validationDefault?.ownerPersonID;
			this.entity.approverPersonID = this.validationDefault?.approverPersonID;
			this.entity.expiresAt = this.validationDefault?.expiresAt;
			this.entity.reviewDate = this.validationDefault?.reviewDate;
			this.badgeTemplateStoreService.updateForm(this.entity);
		}
	}

	inputOpts: InputOptions = {
		isRequired: true
	};

	expirationSelect: SelectOptions = {
		label: 'Expiration',
		labelPosition: LabelPosition.external,
		description: '(Showing to Badge Details)',
		placeholder: 'Select Expiration',
		size: Size.md,
		isDisabled: false,
		isResponsive: true,
		isRequired: true,
		isError: false,
		errorMessage: '',
		errorState: ErrorState.default,
		customClass: 'input-badge-template',
		stickerWidth: 0,
		stickerShift: 0,
		stickerMaxHeight: '',
		stickerIsDisabled: false,
		stickerPosition: 'bottom-left',
		stickerIndent: 0,
		stickerCustomClass: ''
	};

	selectItems: SelectItemOptions[] = [
		{
			heading: ExpirationRange.None,
			value: 'None',
			isDisabled: false,
			customClass: ''
		},
		{
			heading: ExpirationRange._1year,
			value: '_1year'
		},
		{
			heading: ExpirationRange._2years,
			value: '_2years'
		},
		{
			heading: ExpirationRange._3years,
			value: '_3years'
		},
		{
			heading: ExpirationRange._4years,
			value: '_4years'
		},
		{
			heading: ExpirationRange._5years,
			value: '_5years'
		}
	];
	selectedItem: string;

	valueChangedExpiration(value: string) {
		this.entity.expiresAt = value;

		this.badgeTemplateStoreService.updateForm(this.entity);
	}

	changeValueSponsor(value: string) {
		this.request.SearchText = value;
		this.employeeService.getByRoles(this.request).subscribe((data: any) => {
			this.listSponsor = data.data;
			if (data.data.length > 0) {
				this.showListSponsor = true;
			}
		});
	}

	changeValueOwner(value: string) {
		this.request.SearchText = value;
		this.employeeService.getByRoles(this.request).subscribe((data: any) => {
			this.listOwner = data.data;
			if (data.data.length > 0) {
				this.showListOwner = true;
			}
		});
	}

	changeValueApprover(value: string) {
		this.request.SearchText = value;
		this.employeeService.getByRoles(this.request).subscribe((data: any) => {
			this.listApprover = data.data;
			if (data.data.length > 0) {
				this.showListApprover = true;
			}
		});
	}

	changeValueOptionalApprover(value: string) {
		this.request.SearchText = value;
		this.employeeService.getByRoles(this.request).subscribe((data: any) => {
			this.listApprover = data.data;
			if (data.data.length > 0) {
				this.showListOptionalApprover = true;
			}
		});
	}

	changeValue(value: string) {
		this.request.SearchText = value;
		this.employeeService.get(this.request).subscribe((data: any) => {
			this.listSponsor = data.data;
		});
	}

	optionSelectedSponsor(option: any) {
		this.badgeSponsor = option.firstName + ' ' + option.lastName;
		this.entity.sponsorPersonID = option.personID;
		this.showListSponsor = false;

		this.badgeTemplateStoreService.updateForm(this.entity);
	}

	resetValidation() {
		if (this.showListSponsor && this.entity.sponsorPersonID === undefined) {
			this.inputSponsor._value = '';
			this.inputSponsor.focus();
		}

		if (this.showListOwner && this.entity.ownerPersonID === undefined) {
			this.inputOwner._value = '';
			this.inputOwner.focus();
		}

		if (this.showListApprover && this.entity.approverPersonID === undefined) {
			this.inputApprover._value = '';
			this.inputApprover.focus();
		}

		if (this.showListOptionalApprover && this.entity.optionalApproverPersonID === undefined) {
			this.inputOpApprover._value = '';
			this.inputOpApprover.focus();
		}
	}

	optionSelectedOwner(option: any) {
		this.badgeOwner = option.firstName + ' ' + option.lastName;
		this.entity.ownerPersonID = option.personID;
		this.showListOwner = false;

		this.badgeTemplateStoreService.updateForm(this.entity);
	}

	optionSelectedApprover(option: any) {
		this.badgeApprover = option.email;
		this.entity.approverPersonID = option.personID;
		this.showListApprover = false;

		this.badgeTemplateStoreService.updateForm(this.entity);
	}

	optionSelectedOptionalApprover(option: any) {
		this.badgeOptionalApprover = option.email;
		this.entity.optionalApproverPersonID = option.personID;
		this.showListOptionalApprover = false;

		this.badgeTemplateStoreService.updateForm(this.entity);
	}

	onBlur(value: string) {
		this.resetValidation();
	}

	dateChanged(value: any) {
		this.entity.reviewDate = value;
		this.badgeTemplateStoreService.updateForm(this.entity);
	}

	addTemplate(): void {}

	closeSticker() {
		this.resetValidation();
	}
}
