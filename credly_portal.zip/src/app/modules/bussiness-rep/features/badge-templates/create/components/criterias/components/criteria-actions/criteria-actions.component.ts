import { CriteriaType } from '@/core/model/entities';
import { Component, Input, Output, EventEmitter } from '@angular/core';

@Component({
	selector: 'app-criteria-actions',
	templateUrl: './criteria-actions.component.html',
	styleUrls: ['./criteria-actions.component.scss']
})
export class CriteriaActionsComponent {
	@Input() index: number;
	@Input() type: CriteriaType;

	@Output() add = new EventEmitter<{ index: number; type: CriteriaType }>();
	@Output() remove = new EventEmitter<{ index: number; type: CriteriaType }>();

	constructor() {}


}
