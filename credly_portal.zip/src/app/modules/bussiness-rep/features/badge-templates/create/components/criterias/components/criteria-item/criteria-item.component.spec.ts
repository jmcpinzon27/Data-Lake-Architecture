import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CriteriaItemComponent } from './criteria-item.component';
import { BadgeTemplateCriteria, CriteriaType } from '@/core/model/entities';

xdescribe('CriteriaItemComponent', () => {
  let component: CriteriaItemComponent;
  let fixture: ComponentFixture<CriteriaItemComponent>;
  let objectEmit = { index: 1, type: CriteriaType.Education };
  let objectBadgeTemplateCriteria : BadgeTemplateCriteria;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CriteriaItemComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(CriteriaItemComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

    /* it('should emit event add', () => {
    spyOn(component.add, 'emit');  
    component.add.emit(objectEmit); 
    fixture.detectChanges(); 

    expect(component.add.emit).toHaveBeenCalled();
  });

it('should emit event remove', () => {
    spyOn(component.remove, 'emit');  
    component.remove.emit(objectEmit); 
    fixture.detectChanges(); 

    expect(component.remove.emit).toHaveBeenCalled();
  });

  it('should emit event criteriaChange', () => {
    spyOn(component.criteriaChange, 'emit');  
    component.criteriaChange.emit(objectBadgeTemplateCriteria); 
    fixture.detectChanges(); 

    expect(component.criteriaChange.emit).toHaveBeenCalled();
  });*/


});
