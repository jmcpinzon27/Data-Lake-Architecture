import { File } from '@/core/model/common';
import { BadgeTemplate, BadgeTemplateCriteria, CriteriaType } from '@/core/model/entities';
import Criteria from '@/core/model/entities/criteria';
import { BadgeTemplateApiService } from '@/core/services/apis';
import { BadgeTemplateStoreService } from '@/core/services/store';
import { Component, OnInit, Input, OnDestroy } from '@angular/core';
import { Themes, Size, TabThemeType } from '@usitsdasdesign/dds-ng/shared';

@Component({
	selector: 'app-criterias',
	templateUrl: './criterias.component.html',
	styleUrls: ['./criterias.component.scss']
})
export class CriteriasComponent implements OnInit, OnDestroy {
	@Input()
	criteriasInfo: string = '';

	@Input()
	isAlternative : boolean = false;

	criteriasDefault: any;

	showTabA: boolean = false;
	showTabB: boolean = false;
	showTabC: boolean = false;

	tabsSize: Size = Size.md;
	educationType: CriteriaType = CriteriaType.Education;
	experienceType: CriteriaType = CriteriaType.Experience;
	eminenceType: CriteriaType = CriteriaType.Eminence;
	criteriaItems: Array<Criteria> = [];
	criterias: { [id: string]: Array<BadgeTemplateCriteria> } = {
		[CriteriaType.Education]: [],
		[CriteriaType.Experience]: [],
		[CriteriaType.Eminence]: []
	};

	entity: BadgeTemplate;

	constructor(public badgeTemplateStoreService: BadgeTemplateStoreService) {}

	ngOnInit(): void {
		if (this.criteriasInfo !== '') {
			this.criteriasDefault = JSON.parse(this.criteriasInfo);
			this.criterias['Education'] = this.criteriasDefault.criterias
				.filter((e: any) => {
					if (e.type == 'Education') e.isAlternative = e.isAlternative ? e.isAlternative : false;
					return e.type == 'Education' && e.isAlternative === this.isAlternative;
				})
				.map((e: any) => {
					return {
						id: e.id,
						badgeTemplateId: e.badgeTemplateId,
						type: e.type,
						badgeTemplateCriteriaType: e.badgeTemplateCriteriaType,
						title: e.name,
						infoUrl: e.infoUrl,
						description: e.description,
						name: e.name,
						businessValidation: e.businessValidation,
						evidenceExpected: e.evidenceExpected,
						sabaCourseID: e.sabaCourseID,
						sabaCourseName: e.sabaCourseName,
						sabaCourseValidated: false,
						isAlternative: e.isAlternative ? e.isAlternative : false
					};
				});

			this.criterias['Experience'] = this.criteriasDefault.criterias
				.filter((e: any) => {
					if (e.type == 'Experience') e.isAlternative = e.isAlternative ? e.isAlternative : false;
					return e.type == 'Experience' && e.isAlternative === this.isAlternative;
				})
				.map((e: any) => {
					return {
						id: e.id,
						badgeTemplateId: e.badgeTemplateId,
						badgeTemplateCriteriaType: e.badgeTemplateCriteriaType,
						type: e.type,
						title: e.name,
						infoUrl: e.infoUrl,
						description: e.description,
						name: e.name,
						businessValidation: e.businessValidation,
						evidenceExpected: e.evidenceExpected,
						isAlternative: e.isAlternative ? e.isAlternative : false
					};
				});

			this.criterias['Eminence'] = this.criteriasDefault.criterias
				.filter((e: any) => {
					if (e.type == 'Eminence') e.isAlternative = e.isAlternative ? e.isAlternative : false;
					return e.type == 'Eminence' && e.isAlternative === this.isAlternative;
				})
				.map((e: any) => {
					return {
						id: e.id,
						badgeTemplateId: e.badgeTemplateId,
						badgeTemplateCriteriaType: e.badgeTemplateCriteriaType,
						type: e.type,
						title: e.name,
						infoUrl: e.infoUrl,
						description: e.description,
						name: e.name,
						businessValidation: e.businessValidation,
						evidenceExpected: e.evidenceExpected,
						isAlternative: e.isAlternative ? e.isAlternative : false
					};
				});

			if (this.criterias['Education'].length > 0) {
				this.selectTab(0);
			} else if (this.criterias['Experience'].length > 0) {
				this.selectTab(1);
			} else if (this.criterias['Eminence'].length > 0) {
				this.selectTab(2);
			}
		}

		this.badgeTemplateStoreService.entity$.subscribe((e) => {
			this.entity = { ...e };
		});
	}

	selectTab(indexTab: number) {
		if (indexTab == 0) {
			this.showTabA = true;
			this.showTabB = false;
			this.showTabC = false;
		} else if (indexTab == 1) {
			this.showTabA = false;
			this.showTabB = true;
			this.showTabC = false;
		} else if (indexTab == 2) {
			this.showTabA = false;
			this.showTabB = false;
			this.showTabC = true;
		}
	}

	onAddCriteria(e: { index: number; type: CriteriaType }): void {
		this.criterias[e.type].push({
			type: e.type,
			title: '',
			name: '',
			badgeTemplateCriteriaType: { id: null, description: null },
			infoUrl: '',
			description: '',
			isAlternative: this.isAlternative
		});
	}

	refreshEntityCriterias(): void {
		this.entity.criterias = [];

		for (let i = 0; i < this.criterias[CriteriaType.Education].length; i++) {
			this.entity.criterias.push(this.criterias[CriteriaType.Education][i]);
		}

		for (let i = 0; i < this.criterias[CriteriaType.Eminence].length; i++) {
			this.entity.criterias.push(this.criterias[CriteriaType.Eminence][i]);
		}

		for (let i = 0; i < this.criterias[CriteriaType.Experience].length; i++) {
			this.entity.criterias.push(this.criterias[CriteriaType.Experience][i]);
		}

		this.badgeTemplateStoreService.updateForm(this.entity);
	}

	onRemoveCriteria(e: { index: number; type: CriteriaType }): void {
		this.criterias[e.type].splice(e.index, 1);
		this.refreshEntityCriterias();
	}

	ngOnDestroy(): void {
		this.criterias = {
			[CriteriaType.Education]: [],
			[CriteriaType.Experience]: [],
			[CriteriaType.Eminence]: []
		};
	}
}
