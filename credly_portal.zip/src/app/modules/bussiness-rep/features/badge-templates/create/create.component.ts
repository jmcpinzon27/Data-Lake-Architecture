import { Component, OnInit, TemplateRef, ViewChild, OnDestroy } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';

import { ErrorState, Themes } from '@usitsdasdesign/dds-ng/shared';
import { ToastService } from '@usitsdasdesign/dds-ng/toast';
import { ModalService } from '@usitsdasdesign/dds-ng/modal';
import { ToggleOptions, ToggleGroupOptions } from '@usitsdasdesign/dds-ng/toggle';

import { BadgeTemplateStoreService, PageStoreService } from '@/core/services/store';
import { BadgeTemplateApiService } from '@/core/services/apis';
import { BadgeTemplate, BadgeTemplateStatus, Skill } from '@/core/model/entities';
import { ConstBadgeTemplate } from '@/modules/bussiness-rep/features/badge-templates/constants/badge-template';
import { BadgeTemplatesClass } from '@/modules/bussiness-rep/features/badge-templates/classes/badge-templates.class';
import { BadgeTemplateActionsClass } from '@/modules/bussiness-rep/features/badge-templates/classes/badge-template-actions.class';
import { GenericModalComponent } from '@/shared/generic-modal/generic-modal.component';
import SessionStoreService from '@/core/services/store/sessionStoreService';
import { take } from 'rxjs';
import SkillType from '@/core/model/entities/skillType';

@Component({
	selector: 'app-create',
	templateUrl: './create.component.html',
	styleUrls: ['./create.component.scss']
})
export class CreateComponent implements OnInit, OnDestroy {
	@ViewChild('contentTemplate', { read: TemplateRef }) contentTemplate!: TemplateRef<any>;
	@ViewChild('validationTemplate', { static: false }) validationTemplate: any;

	// TODO:  add child components viewChild references
	entity: BadgeTemplate;
	badgeTemplateForm: FormGroup;
	showModalSuccess: boolean = false;
	flagIncomplete: boolean = false;
	isSubmitted: boolean = false;
	badgeNameTitleTemp: string = '';
	acceptRetryAfterCompleteWihtoutLeave: boolean = false;
	entityId: string;
	role: 'admin' | 'practitioner' | 'businessrep' = 'practitioner';
	mainActionLabel = 'Submit';

	adjTemp: Skill[];

	options = { ...ConstBadgeTemplate.options };
	submitButtonOptions = { ...ConstBadgeTemplate.options };
	saveChangesButtonOptions = { ...ConstBadgeTemplate.options };
	optionsToast = ConstBadgeTemplate.optionsToastCreate;
	accordionOptions = ConstBadgeTemplate.accordionOptions;

	badgeTemplatesClass = new BadgeTemplatesClass();
	badgeTemplateActionsClass = new BadgeTemplateActionsClass(
		this.modalServices,
		null,
		this,
		this.badgeTemplateStoreService,
		this.router
	);

	standardTabActive = true;
	alternateTabActive = false;
	alternateTabFirstTime = true;

	toggleOptions: ToggleOptions = {
		theme: Themes.green,
		ariaLabel: '',
		isDisabled: false,
		isError: false,
		errorState: ErrorState.default,
		isProcessingStatusActive: false,
		isRequired: false,
		customClass: ''
	};

	get isEmptyEntity(): boolean {
		return Object.keys(this.entity).length === 0;
	}

	constructor(
		public badgeTemplateStoreService: BadgeTemplateStoreService,
		public badgeTemplateApiService: BadgeTemplateApiService,
		private modalServices: ModalService,
		private router: Router,
		private toastService: ToastService,
		private formBuilder: FormBuilder,
		private sessionStore: SessionStoreService,
		private pageStoreService: PageStoreService
	) {}

	ngOnInit(): void {
		this.role = this.sessionStore.getActiveRole();
		this.badgeTemplateActionsClass.setRole(this.role);
		this.mainActionLabel = this.role === 'admin' ? 'Create and Approve' : 'Submit';
		this.badgeTemplateStoreService.entity$.subscribe((e: BadgeTemplate) => {
			this.entity = e;
			if (this.entityId) this.entity.id = this.entityId;

			if (this.entity.ownerPersonID == null || this.entity.ownerPersonID == '') {
				this.sessionStore.UserSession.pipe(take(2)).subscribe((session) => {
					this.entity.ownerPersonID = session.personID;
				});
			}
		});

		this.badgeTemplateForm = this.formBuilder.group({
			id: [],
			badgeName: ['', [Validators.required, Validators.maxLength(60)]]
		});
	}

	changBadgeName(e: string): void {
		this.badgeNameTitleTemp = e;
	}

	goToList(): void {
		this.navigateTo(['templates']);
	}

	preview() {
		this.modalServices.open(GenericModalComponent, {
			size: 'lg',
			contentTemplate: this.contentTemplate
		});
	}

	navigateTo(path: string[]): void {
		this.router.navigate(path);
	}

	validateRequiredFields(): boolean {
		const response = this.badgeTemplatesClass.validateRequiredFields(this.entity);
		this.flagIncomplete = response?.flagIncomplete;
		return response?.validate;
	}

	validateRequiredFieldsDraft(): boolean {
		this.flagIncomplete = false;
		let validate: boolean = true;
		if (this.entity?.name === undefined || this.entity?.name == '') {
			this.flagIncomplete = true;
			validate = false;
		}

		if (this.entity?.logo === undefined) {
			this.flagIncomplete = true;
			validate = false;
		} else if (this.entity?.logo.fileName === undefined || this.entity?.logo.fileName == '') {
			this.flagIncomplete = true;
			validate = false;
		}

		return validate;
	}

	revertSkillsBeforeAddAdjacent() {
		this.adjTemp = this.entity.skills.filter((s) => s.skillType === SkillType.Adjacent);
		this.entity.skills = this.entity.skills.filter((s) => s.skillType === SkillType.Core);
		this.entity.skillsAdjacent = this.adjTemp;
		this.badgeTemplateStoreService.updateForm(this.entity);
	}

	addBadgeTemplate(status: string = 'Submitted'): void {
		for (let index = 0; index < this.entity.skillsAdjacent.length; index++) {
			this.entity.skills.push(this.entity.skillsAdjacent[index]);
		}

		this.entity.status = status == 'Submitted' ? BadgeTemplateStatus.Submitted : BadgeTemplateStatus.Draft;
		this.entity.issuer = 'Deloitte';
		if (!this.validateRequiredFields() && status == 'create-approve') {
			this.optionsToast.title = 'Badge Template';
			this.optionsToast.message = "Can't save Badge Template. Complete required information";
			this.toastService.createToast(this.optionsToast);
			this.revertSkillsBeforeAddAdjacent();
		} else if (!this.validateRequiredFields() && status == BadgeTemplateStatus.Submitted) {
			this.optionsToast.title = 'Badge Template';
			this.optionsToast.message = "Can't save Badge Template. Complete required information";
			this.toastService.createToast(this.optionsToast);
			this.revertSkillsBeforeAddAdjacent();
		} else if (!this.validateRequiredFieldsDraft() && status == BadgeTemplateStatus.Draft) {
			this.optionsToast.title = 'Badge Template';
			this.optionsToast.message = "Can't save Badge Template. Complete at least the Name and Logo ";
			this.toastService.createToast(this.optionsToast);
			this.revertSkillsBeforeAddAdjacent();
		} else {
			try {
				if (status == 'create-approve') {
					this.isSubmitted = true;
					status = 'Draft';
					this.entity.status = BadgeTemplateStatus.Draft;
					this.submitButtonOptions.isLoading = true;
				} else {
					this.saveChangesButtonOptions.isLoading = true;
				}

				if (this.entityId) this.entity.id = this.entityId;
				this.badgeTemplateApiService[this.acceptRetryAfterCompleteWihtoutLeave ? 'put' : 'post'](
					this.entity
				).subscribe({
					next: (res: any) => {
						this.entity = res;
						if (!this.entityId) this.entityId = res.id;
						this.clearLoaders();
					},
					error: (err) => {
						this.changeTextToastForError();
						this.clearLoaders();
						this.revertSkillsBeforeAddAdjacent();
					},
					complete: () => {
						if (status == 'Submitted') {
							this.optionsToast = this.badgeTemplatesClass.optionsToastSubmitted(this.optionsToast);
							this.toastService.createToast(this.optionsToast);
							this.badgeTemplateActionsClass.returnListBadge();
							this.clearLoaders();
						} else if (this.isSubmitted) {
							this.changeBadgeTemplateStatus();
						} else {
							this.badgeTemplateActionsClass.onSave();
							this.clearLoaders();
						}
						this.entity.issuer = 'Deloitte';
						this.entity.skillsAdjacent = [];
					}
				});
			} catch (ex: any) {
				this.changeTextToastForError();
				this.toastService.createToast(this.optionsToast);
				this.revertSkillsBeforeAddAdjacent();
				this.clearLoaders();
			}
		}
	}

	selectTab(indexTab: number) {
		if (indexTab == 0) {
			this.standardTabActive = true;
			this.alternateTabActive = false;
		} else {
			this.standardTabActive = false;
			this.alternateTabActive = true;
			if (this.alternateTabFirstTime) {
				this.alternativeCriteriasChanged(true);
				this.alternateTabFirstTime = false;
			}
		}
	}

	private clearLoaders() {
		this.submitButtonOptions.isLoading = false;
		this.saveChangesButtonOptions.isLoading = false;
	}

	changeBadgeTemplateStatus(): void {
		this.submitButtonOptions.isLoading = true;
		this.saveChangesButtonOptions.isLoading = true;
		this.badgeTemplateApiService.getBadgeTemplateInfo(this.entityId).subscribe((res: any) => {
			res.criterias.forEach(
				(c: any) =>
					(c.badgeTemplateCriteriaType = c.badgeTemplateCriteriaType ?? { id: null, description: null })
			);
			this.entity = res;
			this.revertSkillsBeforeAddAdjacent();
			if (!this.validateRequiredFields()) {
				this.optionsToast.title = 'Badge Template';
				this.optionsToast.message = "Can't save Badge Template. Complete required information";
				this.toastService.createToast(this.optionsToast);
				this.acceptRetryAfterCompleteWihtoutLeave = true;
				this.clearLoaders();
				this.redirectionEditBadgeTemplate();
			} else {
				try {
					this.entity.status = BadgeTemplateStatus.Submitted;
					this.pageStoreService.setBadgesActiveTabIndex(this.role === 'admin' ? 2 : 0);
					this.badgeTemplateApiService
						.changeBadgeTemplateStatus({
							id: this.entity.id,
							status: this.role === 'admin' ? BadgeTemplateStatus.Accepted : BadgeTemplateStatus.Submitted
						})
						.subscribe(
							(res: any) => {
								this.entity = res;
							},
							(err) => {
								this.clearLoaders();
								this.changeTextToastForError();
								this.toastService.createToast(this.optionsToast);
								this.revertSkillsBeforeAddAdjacent();
								this.redirectionEditBadgeTemplate();
							},
							() => {
								this.optionsToast = this.badgeTemplatesClass.optionsToastSubmitted(
									this.optionsToast,
									this.role === 'admin'
								);
								this.toastService.createToast(this.optionsToast);
								this.clearLoaders();
								this.badgeTemplateActionsClass.returnListBadge();

								this.navigateTo(['templates']);
							}
						);
				} catch (ex: any) {
					this.changeTextToastForError();
					this.clearLoaders();
					this.toastService.createToast(this.optionsToast);
					this.revertSkillsBeforeAddAdjacent();
				}
			}
		});
	}

	changeTextToastForError(): void {
		this.optionsToast = this.badgeTemplatesClass.changeTextToastForError(this.optionsToast);
	}

	close(): void {
		this.showModalSuccess = false;
	}

	closeSticker(): void {
		this.validationTemplate.showListSponsor = false;
		this.validationTemplate.showListOwner = false;
		this.validationTemplate.showListApprover = false;
		this.validationTemplate.showListOptionalApprover = false;
	}

	alternativeCriteriasChanged(value: boolean) {
		this.entity.haveAlternativeCriteria = value;
		this.badgeTemplateStoreService.updateForm(this.entity);
	}

	changeDescriptionsText(event: string) {
		this.entity.alternativeDescription = event;
		this.badgeTemplateStoreService.updateForm(this.entity);
	}

	redirectionEditBadgeTemplate() : void {
		const getRol = localStorage.getItem('role');
		const url = getRol === 'admin'  ? `/badges/templates/edit/${this.entity?.id}` 
										: `/templates/edit/${this.entity?.id}`;	
		this.router.navigateByUrl(url);
	}

	ngOnDestroy(): void {
		this.entity = {};
		this.entityId = null;
		this.acceptRetryAfterCompleteWihtoutLeave = false;
		this.badgeTemplateStoreService.updateForm(this.entity);
	}
}
