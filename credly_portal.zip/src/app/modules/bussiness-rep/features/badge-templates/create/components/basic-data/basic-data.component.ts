import { Component, OnInit, ViewChild, Input, Output, EventEmitter, OnDestroy } from '@angular/core';
import { SelectItemOptions } from '@usitsdasdesign/dds-ng/select';
import { BadgeTemplate, Skill } from '@/core/model/entities';
import { BadgeTemplateStoreService } from '@/core/services/store';
import LogoBadge from '@/core/model/entities/logoBadge';

import { outputAst } from '@angular/compiler';
import SkillType from '@/core/model/entities/skillType';
import { FormArray, FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { debounceTime } from 'rxjs';

@Component({
	selector: 'app-basic-data',
	templateUrl: './basic-data.component.html',
	styleUrls: ['./basic-data.component.scss']
})
export class BasicDataComponent implements OnInit, OnDestroy {
	@ViewChild('form') form: any;
	entity: BadgeTemplate;
	skills: Array<Skill> = [];
	logoBadge: LogoBadge = {
		base64: '',
		prefix: '',
		fileName: ''
	};
	reactiveForm: FormGroup;

	@Output() newBadgeName = new EventEmitter<string>();

	@Input()
	basicDataInfo: string = '';

	basicDataDefault: any;
	failedLoadImage: boolean = false;
	itemSkill: number;

	addNewBadgeName(name: string) {
		this.newBadgeName.emit(name);
	}

	constructor(public badgeTemplateStoreService: BadgeTemplateStoreService, private fb: FormBuilder) {}

	getSkillLevel(event : any) : void {
		if(event.skillType == 'Adjacent') {
			this.entity.skillsAdjacent[event.index].proficiency = event?.proficiency;
			this.entity.skillsAdjacent[event.index].skillType = event?.skillType;
		} else {
			this.entity.skills[event.index].proficiency = event?.proficiency;
			this.entity.skills[event.index].skillType = event?.skillType;
			this.skills[event.index].proficiency = event?.proficiency;
			this.skills[event.index].skillType = event?.skillType;
		}
		this.badgeTemplateStoreService.updateForm(this.entity);
	}

	ngOnInit(): void {
		this.itemSkill = 3;
		this.badgeTemplateStoreService.entity$.subscribe((e) => {
			this.entity = { ...e };
			if(this.entity?.skillsAdjacent == undefined) this.entity.skillsAdjacent = [];

			if (this.entity?.skills == undefined) {
				this.entity.skills = [];

				for (let index = 0; index < 3; index++) {
					this.skills.push({
						id: null,
						name: "",
						skillName: "",
						skillType: SkillType.Core
					})					
				}
				this.entity.skills = [...this.skills];
				this.badgeTemplateStoreService.updateForm(this.entity);
			}
		});

		this.initFormAdjacentSkills();

		if (this.basicDataInfo != '') {
			this.basicDataDefault = JSON.parse(this.basicDataInfo);
			this.logoBadge.fileName = this.basicDataDefault.logo?.fileName;
			this.logoBadge.base64 = this.basicDataDefault.logo?.base64;
			this.entity.logo = this.logoBadge;
			this.skills = this.basicDataDefault.skills.map((e: any) => {
				return {
					id: e.skillId,
					name: e.name,
					skillType: e.skillType,
					skillName: e.skillName || e.name,
					proficiency: e.proficiency
				};
			});

			const skillTypeValid = this.skills.find(x => x.skillType === SkillType.Core);

			if (skillTypeValid) {
					const getAdjacentSkills = this.skills.filter((item) => item.skillType === SkillType.Adjacent);
					const getCoreSkills = this.skills.filter((item) => item.skillType === SkillType.Core);
					this.skills = [...getCoreSkills];

					if (getAdjacentSkills.length > 0 ) {
						this.removeItem(0);
						for (let index = 0; index < getAdjacentSkills.length; index++) {
							const newItem = this.fb.group({
								id: new FormControl(getAdjacentSkills[index]?.id, []),
								name: new FormControl(getAdjacentSkills[index]?.name, [Validators.minLength(1)]),
								skillType: new FormControl(getAdjacentSkills[index]?.skillType, []),
								skillName: new FormControl(getAdjacentSkills[index]?.skillName, [Validators.minLength(1)]),
								proficiency: new FormControl(getAdjacentSkills[index]?.proficiency, [])
							});
							this.itemsFormArray.push(newItem);
						}
			
						this.entity.skillsAdjacent = [...getAdjacentSkills];
					}
			}

			this.entity.id = this.basicDataDefault?.id;
			this.entity.name = this.basicDataDefault?.name;
			this.entity.description = this.basicDataDefault?.description;
			this.entity.learningObjectives = this.basicDataDefault?.learningObjectives;
			this.entity.level = this.basicDataDefault?.level;
			this.entity.skills = [...this.skills];
			this.itemSkill = this.entity.skills.length > 3 ? this.entity.skills.length : 3;
			this.badgeTemplateStoreService.updateForm(this.entity);
		}
	}

	isImgPreviewAdded: boolean = false;
	files: File[] = [];

	addSkill() {
		++this.itemSkill;
		if (this.skills.length >= 3) {
			this.skills.push({
				id: null,
				name: '',
				skillName: '',
				skillType: SkillType.Core
			});
			this.entity.skills = [...this.skills];
			this.badgeTemplateStoreService.updateForm(this.entity);
		}
	}

	removeSkill(index: number) {
		this.skills.splice(index, 1);
		this.entity.skills = [...this.skills];
		--this.itemSkill;
		this.badgeTemplateStoreService.updateForm(this.entity);
	}

	updateSkillValue(index: number, e: any) {
		if (this.skills[index] === undefined) {
			this.skills[index] = {
				id: null,
				name: e.target.value,
				skillName: e.target.value
			};
		} else {
			this.skills[index].name = e.target.value;
			this.skills[index].skillName = e.target.value;
		}

		this.entity.skills = [...this.skills]
		this.badgeTemplateStoreService.updateForm(this.entity);
	}

	getValueSkill(index: number) {
		let skill: string = '';
		if (index > 2) {
			if (this.skills[index]) {
				skill = this.skills[index].skillName || this.skills[index].name;
			}
		} else if (this.skills[index] !== undefined && this.basicDataInfo != '') {
			skill = this.skills[index].skillName || this.skills[index].name;
		}

		return skill;
	}

	editImageBadge(e: any) {
		let inputFile: any = document.querySelector('#inputImgBadge');
		inputFile.click();
	}

	uploadImgBadge() {
		let inputFile: any = document.querySelector('#inputImgBadge');
		let imgPreview: any = document.querySelector('.img-badge');

		if (inputFile.files[0] === undefined) {
			return;
		}

		let urlPreview: any = URL.createObjectURL(inputFile.files[0]);
		imgPreview.src = urlPreview;
		this.isImgPreviewAdded = true;
	}

	addPreviewImg() {
		let inputFile: any = document.querySelector('#inputImgBadge');
		inputFile.click();
	}

	onSelect(event: any) {
		if (event.rejectedFiles.length) this.setError();
		this.files = [];
		this.files.push(...event.addedFiles);
		const formData = new FormData();

		for (var i = 0; i < this.files.length; i++) {
			let img: any;
			let _URL = window.URL || window.webkitURL;
			formData.append('file[]', this.files[i]);
			this.logoBadge.fileName = this.files[i]?.name;
			const fileReader = new FileReader();
			fileReader.onload = () => {
				const srcData = fileReader.result;
				this.logoBadge.prefix = 'logoBadge';
				this.logoBadge.base64 = String(srcData);
				this.entity.logo = this.logoBadge;
				this.badgeTemplateStoreService.updateForm(this.entity);
			};
			fileReader.readAsDataURL(this.files[i]);

			if (this.files[i].type != 'image/png') {
				this.setError();
			} else if (this.files[i]) {
				img = new Image();
				let objectUrl: any = _URL.createObjectURL(this.files[i]);
				img.onload = () => {
					if (
						parseInt(img.width) < 600 ||
						parseInt(img.width) > 2048 ||
						parseInt(img.height) < 600 ||
						parseInt(img.height) > 2048 ||
						parseInt(img.height) !== parseInt(img.width)
					) {
						this.files = [];
						this.logoBadge.base64 = '';
						this.failedLoadImage = true;
						this.entity.logo = this.logoBadge;
						this.badgeTemplateStoreService.updateForm(this.entity);
					} else {
						this.failedLoadImage = false;
					}
					_URL.revokeObjectURL(objectUrl);
				};

				img.src = objectUrl;
			}
		}
	}

	onRemove(event: any) {
		this.files.splice(this.files.indexOf(event), 1);
	}

	changeBadgeName(e: string) {
		this.addNewBadgeName(e);
		this.entity.name = e;
		this.badgeTemplateStoreService.updateForm(this.entity);
	}

	changeDescription(e: string) {
		this.entity.description = e;
		this.badgeTemplateStoreService.updateForm(this.entity);
	}

	changeLearningObjectives(e: string) {
		this.entity.learningObjectives = e;
		this.badgeTemplateStoreService.updateForm(this.entity);
	}

	changeLevel(e: any) {
		this.entity.level = e;
		this.badgeTemplateStoreService.updateForm(this.entity);
	}

	indexSkillTemp: number = 0;

	indexSkill(index: number) {
		this.indexSkillTemp = index;
	}

	onBlurSkill(skill: string) {
		this.skills[this.indexSkillTemp] = {
			id: null,
			name: skill,
			skillName: skill
		};

		this.entity.skills =[...this.skills];
		this.badgeTemplateStoreService.updateForm(this.entity);
	}

	selectItems: SelectItemOptions[] = [
		{
			heading: 'Foundation',
			value: 'Foundation',
			isDisabled: false,
			customClass: ''
		},
		{
			heading: 'Intermediate',
			value: 'Intermediate'
		},
		{
			heading: 'Advanced',
			value: 'Advanced'
		},
		{
			heading: 'Luminary',
			value: 'Luminary'
		}
	];

	private setError() {
		this.files = [];
		this.logoBadge = {
			base64: '',
			prefix: '',
			fileName: ''
		};
		this.failedLoadImage = true;
	}

	initFormAdjacentSkills(): void {
		this.reactiveForm = this.fb.group({
			skills: this.fb.array([])
		});
		this.addItem();
		this.reactiveForm.valueChanges.pipe(debounceTime(500)).subscribe((value) => {
			for (let index = 0; index < value.skills.length; index++) {
				this.entity.skillsAdjacent[index].name = value.skills[index]?.skillName == undefined 
																? '' 
																: value.skills[index]?.skillName;	
				this.entity.skillsAdjacent[index].skillName = value.skills[index]?.skillName == undefined 
																? '' 
																: value.skills[index]?.skillName;				
			}
		});
	}

	public get itemsControls(): FormGroup[] {
		return this.itemsFormArray.controls as FormGroup[];
	}

	private get itemsFormArray(): FormArray {
		return this.reactiveForm.get('skills') as FormArray;
	}

	addItem(): void {
		const newItem = this.fb.group({
			id: new FormControl(null, []),
			skillType: new FormControl('Adjacent', []),
			skillName: new FormControl('', [Validators.minLength(1)])
		});
		this.itemsFormArray.push(newItem);
		this.entity.skillsAdjacent.push({
				id: null,
				name: '',
				skillName: '',
				skillType: SkillType.Adjacent
			});		
	}

	removeItem(index: number): void {
		this.itemsFormArray.removeAt(index);
		this.entity.skillsAdjacent.splice(index, 1);
		this.badgeTemplateStoreService.updateForm(this.entity);
	}

	refreshArraySkills(): void {
		this.entity.skills = [];
		const getArray =[...this.itemsFormArray.value];

		for (let index = 0; index < this.skills.length; index++) {
			if (this.skills[index]?.skillName.length > 0) this.entity.skills.push(this.skills[index]);
		}

		for (let index = 0; index < getArray.length; index++) {
			if (getArray[index]?.skillName.length > 0) this.entity.skills.push(getArray[index]);
		}
	}

	ngOnDestroy(): void {
		this.skills = [];
		this.entity.skills = [];
		this.entity.skillsAdjacent = [];
	}
}
