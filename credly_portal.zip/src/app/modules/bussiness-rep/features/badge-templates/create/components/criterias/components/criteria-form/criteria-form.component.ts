import { BadgeTemplate, BadgeTemplateCriteria, CriteriaType } from '@/core/model/entities';
import { BadgeApiService, BadgeTemplateApiService } from '@/core/services/apis';
import { BadgeTemplateStoreService } from '@/core/services/store';
import {
	Component,
	Input,
	Output,
	OnInit,
	EventEmitter,
	ViewChild,
	Renderer2,
	OnDestroy,
	AfterViewInit
} from '@angular/core';
import { CriteriaFields } from '@/core/model/entities/criteriaFields';
import { take } from 'rxjs';
import SessionStoreService from '@/core/services/store/sessionStoreService';
import { catchError, of } from 'rxjs';
import { ICourseSaba } from '@/core/model/entities/courseSaba';
@Component({
	selector: 'app-criteria-form',
	templateUrl: './criteria-form.component.html',
	styleUrls: ['./criteria-form.component.scss']
})
export class CriteriaFormComponent implements OnInit, OnDestroy, AfterViewInit {
	@Input() criteria: BadgeTemplateCriteria;
	@Output() criteriaChange: EventEmitter<BadgeTemplateCriteria> = new EventEmitter<BadgeTemplateCriteria>();
	@Input() indexCriteria: number = 0;
	@Input() isAlternative: boolean;
	entity: BadgeTemplate;
	educationType: CriteriaType = CriteriaType.Education;
	criteriaEducation: Array<BadgeTemplateCriteria> = [];
	criteriaEducationB: Array<any> = [];
	listCriteriaType: any[] = [];
	criteriaType: string = '';
	radioBtns: any[] = [
		{
			value: '1',
			options: {
				label: 'Yes',
				isDisabled: false,
				theme: 'dark'
			}
		},
		{
			value: '2',
			options: {
				label: 'No',
				isDisabled: false,
				theme: 'dark'
			}
		}
	];
	radioGroupOptions: any = {
		isDisabled: false,
		title: 'Business Validation Needed',
		isRequired: true,
		name: ''
	};
	radioSabaBtns: any[] = [
		{
			value: '1',
			options: {
				label: 'Yes',
				isDisabled: false,
				theme: 'dark'
			}
		},
		{
			value: '2',
			options: {
				label: 'No',
				isDisabled: false,
				theme: 'dark'
			}
		}
	];
	radioSabaOptions: any = {
		isDisabled: false,
		title: 'SABA Validation Needed',
		isRequired: true,
		name: ''
	};
	criteriaFields = CriteriaFields;
	criteriaTypeEnum = CriteriaType;
	isVisibleEvidenceExpect: boolean = true;
	isVisibleBusinessValidation: boolean = true;
	courseId: string = '';
	optionsSearchBtn: any = {
		theme: 'dark',
		isLoading: false,
		icon: '',
		isInverse: false,
		isDisabled: false,
		ariaLabel: 'Search',
		customClass: '',
		role: 'button'
	};

	@ViewChild('criteriaTypeChild', { static: false }) criteriaTypeChild: any;

	constructor(
		public badgeTemplateStoreService: BadgeTemplateStoreService,
		private badgeTemplateApiService: BadgeTemplateApiService,
		private renderer: Renderer2,
		private sessionService: SessionStoreService
	) {}

	ngOnInit(): void {
		this.criteria.sabaCourseValidated = this.criteria.sabaCourseID?.length > 0;
		this.badgeTemplateStoreService.entity$.subscribe((e) => {
			this.entity = { ...e };
		});

		if (this.entity.criterias === undefined) {
			this.entity.criterias = [];
			this.entity.criterias.push(this.criteria);
			this.badgeTemplateStoreService.updateForm(this.entity);
		} else {
			this.entity.criterias.push(this.criteria);
			this.badgeTemplateStoreService.updateForm(this.entity);
		}

		this.validationSession();
		this.radioGroupOptions.name = `${this.criteria.type}_${this.indexCriteria}`;
	}

	validationSession(): void {
		this.sessionService.UserSession.pipe(take(2)).subscribe((session: any) => {
			if (session) {
				if (session.isAdmin || session.isBusinessRep) {
					this.isVisibleEvidenceExpect = true;
					this.isVisibleBusinessValidation = true;
				}
			}
		});
	}

	ngAfterViewInit(): void {
		this.criteriaTypeChild.selectedItem =
			this.criteria.badgeTemplateCriteriaType?.description != '' &&
			this.criteria.badgeTemplateCriteriaType?.description !== undefined
				? this.criteria.badgeTemplateCriteriaType?.description
				: '';
		this.criteriaTypeChild._value =
			this.criteria.badgeTemplateCriteriaType?.id != '' &&
			this.criteria.badgeTemplateCriteriaType?.id !== undefined
				? this.criteria.badgeTemplateCriteriaType?.id
				: '';

		this.criteriaTypeChild.selectBtn.nativeElement.firstElementChild.innerHTML =
			this.criteria.badgeTemplateCriteriaType?.description !== undefined
				? this.criteria.badgeTemplateCriteriaType?.description
				: '';

		this.badgeTemplateApiService.getBadgeTemplateCriteriaType().subscribe((e: any) => {
			this.listCriteriaType = e;
		});
	}

	changeCriteriaType(type: string, criteriaTypeId: any) {
		let criteriaTypeSelected: any = this.listCriteriaType.filter((e: any) => {
			return e.id == criteriaTypeId;
		});

		let flagIndex: number = 0;
		this.entity.criterias
			.filter((e: BadgeTemplateCriteria) => e.isAlternative === this.isAlternative)
			.map((e: any) => {
				if (e.type == type) {
					if (flagIndex == this.indexCriteria) {
						e.badgeTemplateCriteriaType = {
							id: criteriaTypeSelected[0].id,
							description: criteriaTypeSelected[0].description
						};
					}
					++flagIndex;
				}
				return e;
			});

		this.badgeTemplateStoreService.updateForm(this.entity);
	}

	changeEducationTitle(type: string, education: any) {
		let flagIndex: number = 0;
		this.entity.criterias
			.filter((e: BadgeTemplateCriteria) => e.isAlternative === this.isAlternative)
			.map((e: any) => {
				if (e.type == type) {
					if (flagIndex == this.indexCriteria) {
						e.title = education;
						e.name = education;
					}
					++flagIndex;
				}
				return e;
			});

		this.badgeTemplateStoreService.updateForm(this.entity);
	}

	changeEducationUrl(type: string, url: any) {
		let flagIndex: number = 0;
		this.entity.criterias
			.filter((e: BadgeTemplateCriteria) => e.isAlternative === this.isAlternative)
			.map((e: any) => {
				if (e.type == type) {
					if (flagIndex == this.indexCriteria) {
						e.infoUrl = url;
					}
					++flagIndex;
				}
				return e;
			});
		this.badgeTemplateStoreService.updateForm(this.entity);
	}

	changeDescriptionsText(type: string, description: any, field: string) {
		let flagIndex: number = 0;
		this.entity.criterias
			.filter((e: BadgeTemplateCriteria) => e.isAlternative === this.isAlternative)
			.map((e: any) => {
				if (e.type == type) {
					if (flagIndex == this.indexCriteria) {
						if (field === CriteriaFields.Description) e.description = description;
						if (field === CriteriaFields.EvidenceDescription) e.evidenceExpected = description;
					}
					++flagIndex;
				}
				return e;
			});
		this.badgeTemplateStoreService.updateForm(this.entity);
	}

	changeBusinessValidation(type: string, option: any) {
		let flagIndex: number = 0;
		this.entity.criterias
			.filter((e: BadgeTemplateCriteria) => e.isAlternative === this.isAlternative)
			.map((e: any) => {
				if (e.type == type) {
					if (flagIndex == this.indexCriteria) {
						e.businessValidation = option == '1' ? true : false;
					}
					++flagIndex;
				}
				return e;
			});
		this.badgeTemplateStoreService.updateForm(this.entity);
	}

	sizeSelectCriteriaType(): void {
		const getElement = this.renderer.selectRootElement('dds-sticker > dds-context-menu > .dds-context-menu', true);
		this.renderer.setStyle(getElement, 'max-height', 'calc(300px)');
	}

	ngOnDestroy(): void {
		this.entity = {};
	}

	changeSabaValidation(type: string, option: any) {
		let flagIndex: number = 0;
		this.entity.criterias
			.filter((e: BadgeTemplateCriteria) => e.isAlternative === this.isAlternative)
			.map((e: any) => {
				if (e.type == type) {
					if (flagIndex == this.indexCriteria) {
						e.sabaCourseValidated = option == '1' ? true : false;
					}
					if (option == 2) {
						e.sabaCourseID = '';
						e.sabaCourseName = '';
					}
					++flagIndex;
				}
				return e;
			});
		this.badgeTemplateStoreService.updateForm(this.entity);
	}

	searchCourseSabaById(type: string, event: any = null): void {
		if (event !== null) {
			this.courseId = event;
			if (this.courseId.length === 0) this.changeCourseName(type, '');
		} else if (this.courseId.length > 0) {
			this.badgeTemplateApiService
				.getSABACourseById(this.courseId)
				.pipe(catchError(() => of({ error: true })))
				.subscribe((response: ICourseSaba) => {
					if (response.error) {
						this.changeCourseName(type, '');
						return;
					}
					this.changeCourseName(type, response?.name);
				});
		} else if (event === null) this.changeCourseName(type, '');
	}

	changeCourseName(type: string, courseName: any) {
		let flagIndex: number = 0;
		this.entity.criterias
			.filter((e: BadgeTemplateCriteria) => e.isAlternative === this.isAlternative)
			.map((e: any) => {
				if (e.type == type) {
					if (flagIndex == this.indexCriteria) {
						e.sabaCourseName = courseName;
						e.sabaCourseID = this.courseId;
					}
					++flagIndex;
				}
				return e;
			});

		this.badgeTemplateStoreService.updateForm(this.entity);
	}
}
