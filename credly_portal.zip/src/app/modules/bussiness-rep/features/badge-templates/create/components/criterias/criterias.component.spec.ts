import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CriteriasComponent } from './criterias.component';

xdescribe('CriteriasComponent', () => {
  let component: CriteriasComponent;
  let fixture: ComponentFixture<CriteriasComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CriteriasComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(CriteriasComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
