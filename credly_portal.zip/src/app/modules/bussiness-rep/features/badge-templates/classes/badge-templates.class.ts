import SkillType from '@/core/model/entities/skillType';
export class BadgeTemplatesClass {
	validateRequiredFields(entity: any) {
		let validate: boolean = true;
		let flagIncomplete: boolean = false;

		if (entity?.name === undefined || entity?.name == null || entity?.name == '') {
			flagIncomplete = true;
			validate = false;
		}

		if (entity?.description === undefined || entity?.description == null || entity?.description == '') {
			flagIncomplete = true;
			validate = false;
		}

		if (entity?.logo === undefined || entity?.logo == null) {
			flagIncomplete = true;
			validate = false;
		} else if (
			entity?.logo.fileName === undefined ||
			entity?.logo.fileName == null ||
			entity?.logo.fileName == ''
		) {
			flagIncomplete = true;
			validate = false;
		}
		if (entity?.level === undefined || entity?.level == null) {
			flagIncomplete = true;
			validate = false;
		}

		if (entity?.skills === undefined || entity?.skills?.length < 3) {
			flagIncomplete = true;
			validate = false;
		}

		if (!entity?.skillsAdjacent) {
			flagIncomplete = true;
			validate = false;
		}

		entity.skills?.forEach((s: any) => {
			const coreValidation = (!s.skillName || !s.proficiency) && s.skillType === SkillType.Core;
			const adjValidation = !s.skillName && s.skillType === SkillType.Adjacent;
			if (coreValidation || adjValidation) {
				flagIncomplete = true;
				validate = false;
			}
		});

		if (
			entity?.approverPersonID === undefined ||
			entity?.approverPersonID == null ||
			entity?.approverPersonID == ''
		) {
			flagIncomplete = true;
			validate = false;
		}

		if (entity?.ownerPersonID === undefined || entity?.ownerPersonID == null || entity?.ownerPersonID == '') {
			flagIncomplete = true;
			validate = false;
		}

		if (entity?.sponsorPersonID === undefined || entity?.sponsorPersonID == null || entity?.sponsorPersonID == '') {
			flagIncomplete = true;
			validate = false;
		}

		if (entity?.expiresAt === undefined || entity?.expiresAt == null || entity?.expiresAt == '') {
			flagIncomplete = true;
			validate = false;
		}

		// Criterias validations (standard and alternate)
		const existAlternativeCriteria: boolean = entity.haveAlternativeCriteria;
		const standardCriterias = entity?.criterias?.filter((item: any) => !item.isAlternative);
		const alternateCriterias = entity?.criterias?.filter((item: any) => item.isAlternative);
		if (standardCriterias?.length === 0) {
			flagIncomplete = true;
			validate = false;
		}
		entity?.criterias
			?.filter((item: any) => !item.isAlternative || existAlternativeCriteria)
			.forEach((item: any) => {		
				if (item.businessValidation && (!item.evidenceExpected || item.evidenceExpected.length === 0 || item.evidenceExpected === null)) {
					flagIncomplete = true;
					validate = false;
				}

				if (!item.name || !item.description || !item.badgeTemplateCriteriaType?.id) {
					flagIncomplete = true;
					validate = false;
				}
			});

		if (existAlternativeCriteria && (!entity.alternativeDescription || alternateCriterias?.length === 0)) {
			flagIncomplete = true;
			validate = false;
		}

		return { validate, flagIncomplete };
	}

	changeTextToastForError(optionsToast: any) {
		optionsToast.title = 'Badge Template';
		optionsToast.message = "Can't save Badge Template";

		return optionsToast;
	}

	optionsToastSubmitted(optionsToast: any, isAdmin = false) {
		optionsToast.title = isAdmin
			? 'New Badge Template Approved'
			: 'You have successfully sent this badge template for approval!';
		optionsToast.message = isAdmin
			? 'The Badge Template was successfully approved.'
			: 'The status of this badge has been changed to "Submitted for approval". You will be notified once your submission has been reviewed!';

		return optionsToast;
	}
}
