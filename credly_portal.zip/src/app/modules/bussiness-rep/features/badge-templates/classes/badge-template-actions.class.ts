import { BadgeTemplateStoreService } from '@/core/services/store';
import { ModalService } from '@usitsdasdesign/dds-ng/modal';
import { EditComponent } from '@/modules/bussiness-rep/features/badge-templates/edit/edit.component';
import { CreateComponent } from '@/modules/bussiness-rep/features/badge-templates/create/create.component';
import { ModalComponent } from '@/shared/components/modal/modal.component';
import { BadgeTemplateStatus } from '@/core/model/entities';
import { Router } from '@angular/router';
export class BadgeTemplateActionsClass {
	editComponent: EditComponent;
	createComponent: CreateComponent;

	role: string = 'businessrep';

	constructor(
		private modalServices: ModalService,
		private _editComponent: EditComponent,
		private _createComponent: CreateComponent,
		private badgeTemplateStoreService: BadgeTemplateStoreService,
		private router: Router,
	) {
		this.editComponent = this._editComponent;
		this.createComponent = this._createComponent;
	}

	modal(): void {
		let modal: any = {
			title: 'Are you sure you want to leave without saving?',
			hasFooter: true,
			contentTitle: ``,
			contentText: [
				`If you don’t save, you will lose all data entered. Click "Save" so you can finish it later.
                    You will see it in your Template List with an ‘In Progress’ status!`
			],
			aceptButtonText: 'Yes, Save',
			cancelButtonText: 'Cancel',
			actionForAceptButton: () => {
				if (this.createComponent !== null) this.createComponent.addBadgeTemplate('Draft');
				if (this.editComponent !== null) this.editComponent.addBadgeTemplate('Draft');
				this.modalServices.close();
			},
			actionForCancelButton: () => {
				this.returnListBadge();
			}
		};

		this.modalServices.open(ModalComponent, { modal });
	}

	onSave(): void {
		const contentText =
			this.role === 'businessrep'
				? `Now, you are able to submit this new template to be reviewed.`
				: `Now, you are able to see this new template in My Queue list.`;
		let modal: any = {
			title: 'Congratulations!',
			hasFooter: true,
			contentTitle: `You have successfully saved this new template!`,
			contentText: [contentText],
			aceptButtonText: this.role === 'businessrep' ? 'Submit now' : 'Create and Approve',
			cancelButtonText: "I'll it do later",
			actionForAceptButton: () => {
				if (this.createComponent !== null) this.createComponent.changeBadgeTemplateStatus();
				if (this.editComponent !== null) this.editComponent.addBadgeTemplate(BadgeTemplateStatus.Submitted);
				this.modalServices.close();
			},
			actionForCancelButton: () => {
				this.returnListBadge();
			}
		};
		this.modalServices.open(ModalComponent, { modal });
	}

	onSaveHideForEdit(): void {
		let modal: any = {
			title: 'Save Changes',
			hasFooter: true,
			contentTitle: `Are you sure you want to save the changes?`,
			contentText: [
				`You will save all the changes that you applied on this template.
            To see it active again you will need to 'unhide' it first in order to be shown on
            the Deloitte Badge Catalog
            `
			],
			aceptButtonText: 'Yes,save',
			cancelButtonText: 'Cancel',
			actionForAceptButton: () => {
				if (this.editComponent !== null) this.editComponent.addBadgeTemplate('Draft');
				this.modalServices.close();
			},
			actionForCancelButton: () => {
				this.returnListBadge();
			}
		};
		this.modalServices.open(ModalComponent, { modal });
	}

	returnListBadge(validate: boolean = false): void {
		if (this.createComponent !== null) this.createComponent.validateRequiredFields();
		if (this.editComponent !== null) this.editComponent.validateRequiredFields();

		if (validate) {
			this.modal();
		} else {
			const getRol = localStorage.getItem('role');
			const url = getRol === 'admin' ? '/badges/admin/templates' : '/templates';	
			this.router.navigateByUrl(url);
			
			if (this.createComponent !== null) {
				this.createComponent.entity = {};
				this.badgeTemplateStoreService.updateForm(this.createComponent.entity);
			}
			if (this.editComponent !== null) {
				this.editComponent.entity = {};
				this.badgeTemplateStoreService.updateForm(this.editComponent.entity);
			}
			this.modalServices.close();
		}
	}

	setRole(role: string = 'businessRep') {
		this.role = role;
	}
}
