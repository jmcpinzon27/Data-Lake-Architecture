import { Component, OnInit, TemplateRef, ViewChild, OnDestroy, Renderer2 } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

import { ToastOptions, ToastService } from '@usitsdasdesign/dds-ng/toast';
import { ModalService } from '@usitsdasdesign/dds-ng/modal';

import SessionStoreService from '@/core/services/store/sessionStoreService';
import { BadgeTemplateStoreService, PageStoreService } from '@/core/services/store';
import { BadgeTemplateApiService } from '@/core/services/apis';
import { BadgeTemplate, BadgeTemplateReleaseNote, BadgeTemplateStatus, Skill } from '@/core/model/entities';
import { ConstBadgeTemplate } from '@/modules/bussiness-rep/features/badge-templates/constants/badge-template';
import { BadgeTemplatesClass } from '@/modules/bussiness-rep/features/badge-templates/classes/badge-templates.class';
import { BadgeTemplateActionsClass } from '@/modules/bussiness-rep/features/badge-templates/classes/badge-template-actions.class';
import { GenericModalComponent } from '@/shared/generic-modal/generic-modal.component';
import { ModalComponent } from '@/shared/components/modal/modal.component';
import { take } from 'rxjs';
import { ErrorState, Themes } from '@usitsdasdesign/dds-ng/shared';
import { ToggleOptions, ToggleGroupOptions } from '@usitsdasdesign/dds-ng/toggle';
import SkillType from '@/core/model/entities/skillType';

@Component({
	selector: 'app-edit',
	templateUrl: './edit.component.html',
	styleUrls: ['./edit.component.scss']
})
export class EditComponent implements OnInit, OnDestroy {
	@ViewChild('contentTemplate', { read: TemplateRef }) contentTemplate!: TemplateRef<any>;

	// TODO:  add child components viewChild references
	entity: BadgeTemplate;
	role: 'admin' | 'practitioner' | 'businessrep' = 'practitioner';
	mainActionLabel = 'Submit';
	showModalSuccess: boolean = false;
	badgeNameTitleTemp: string = '';
	badgeTemplateForm: FormGroup;
	idBadgeTemplate: string = '';
	badgeInfo: any = {};
	badgeInfoString: string = '';
	isLoadedData: boolean = false;
	dataReleaseNote!: BadgeTemplateReleaseNote;
	hideForEditStatus = BadgeTemplateStatus.HideForEdit;
	hideForArchiveStatus = BadgeTemplateStatus.HideForArchive;

	options = ConstBadgeTemplate.options;
	optionsToast = ConstBadgeTemplate.optionsToast;
	accordionOptions = ConstBadgeTemplate.accordionOptions;

	flagIncomplete: boolean = false;
	badgeTemplatesClass = new BadgeTemplatesClass();
	badgeTemplateActionsClass = new BadgeTemplateActionsClass(
		this.modalServices,
		this,
		null,
		this.badgeTemplateStoreService,
		this.router
	);

	hideForEditToast: ToastOptions = {
		title: `The Badge is hidden, now you can edit it`,
		message: `Now you can edit the template by changing the details and Criteria.
		Also, you can archive it, if it is purposeless or too old`,
		lifeTime: 5000,
		position: 'bottom-left',
		closeBtnIcon: 'dds-icon_close',
		isCloseIcon: true,
		customClass: 'simple-toast',
		limit: 1,
		theme: Themes.white
	};

	saveReleaseNoteToast: ToastOptions = {
		title: `The Badge Template was successfully saved`,
		message: ``,
		lifeTime: 5000,
		position: 'bottom-left',
		closeBtnIcon: 'dds-icon_close',
		isCloseIcon: true,
		customClass: 'simple-toast',
		limit: 1,
		theme: Themes.white
	};

	standardTabActive = true;
	alternateTabActive = false;

	alternativeDescription = '';
	hasAlternativeCriterias = false;

	toggleOptions: ToggleOptions = {
		theme: Themes.green,
		ariaLabel: '',
		isDisabled: false,
		isError: false,
		errorState: ErrorState.default,
		isProcessingStatusActive: false,
		isRequired: false,
		customClass: ''
	};

	adjTemp: Skill[];

	get isEmptyEntity(): boolean {
		return Object.keys(this.entity).length === 0;
	}

	constructor(
		public badgeTemplateStoreService: BadgeTemplateStoreService,
		public badgeTemplateApiService: BadgeTemplateApiService,
		public modalServices: ModalService,
		private router: Router,
		private toastService: ToastService,
		private formBuilder: FormBuilder,
		private _router: ActivatedRoute,
		private sessionService: SessionStoreService,
		private renderer: Renderer2,
		private pageStoreService: PageStoreService
	) {}

	ngOnInit(): void {
		this.role = this.sessionService.getActiveRole();
		this.mainActionLabel =
			this.badgeInfo.status !== this.hideForEditStatus
				? this.role === 'admin'
					? 'Save Changes'
					: 'Submit'
				: 'Save Changes';

		this.badgeTemplateActionsClass.setRole(this.role);
		this.idBadgeTemplate = this._router.snapshot.paramMap.get('id');
		this.badgeTemplateApiService.getBadgeTemplateInfo(this.idBadgeTemplate).subscribe((e: any) => {
			this.alternativeDescription = e.alternativeDescription;
			this.hasAlternativeCriterias = e.haveAlternativeCriteria;
			if (e.lastFeedback && e.lastFeedback !== '' && this.sessionService.getActiveRole() == 'businessrep') {
				this.showFeedback(e.lastFeedback);
			}
			this.badgeInfo = e;
			this.entity.alternativeDescription = this.badgeInfo.alternativeDescription;
			this.badgeTemplateStoreService.updateForm(this.entity);

			if (this.badgeInfo.status == BadgeTemplateStatus.HideForEdit) {
				this.toastHidenForEdit();
			}
			this.entity.haveAlternativeCriteria = this.badgeInfo.haveAlternativeCriteria;
			this.badgeTemplateStoreService.updateForm(this.entity);

			this.badgeInfoString = JSON.stringify(e);
			this.isLoadedData = true;
		});

		this.badgeTemplateStoreService.entity$.subscribe((e: BadgeTemplate) => {
			return (this.entity = e);
		});
		this.badgeTemplateForm = this.formBuilder.group({
			id: [],
			badgeName: ['', Validators.required]
		});
	}

	toastHidenForEdit() {
		this.toastService.createToast(this.hideForEditToast);
	}

	changBadgeName(e: string): void {
		this.badgeNameTitleTemp = e;
	}

	goToList(): void {
		this.navigateTo(['templates']);
	}

	preview(): void {
		this.modalServices.open(GenericModalComponent, {
			size: 'lg',
			contentTemplate: this.contentTemplate
		});
	}

	navigateTo(path: string[]): void {
		this.router.navigate(path);
	}

	showFeedback(feedback: string) {
		let modal: any = {
			title: 'Attention required',
			hasFooter: true,
			contentTitle: '',
			contentText: [
				`You received a comment from your administrator. Please read the comment and make the necessary changes to submit the form correctly:<br><br>
			${feedback}`
			],
			aceptButtonText: "Let's start!",
			cancelButtonText: 'Cancel',
			actionForAceptButton: () => {
				this.modalServices.close();
			},
			actionForCancelButton: () => {}
		};

		this.modalServices.open(ModalComponent, {
			showFeedback: false,
			defaultValueFeedback: feedback,
			modal
		});
	}

	showReleaseNotes() {
		let modal: any = {
			title: 'Provide edit details',
			hasFooter: true,
			contentTitle: '',
			contentText: [
				`The message below will be visible to practitioners. To ensure practitioners understand the changes,
				please provide specific details about changes applied to this badge.
			`
			],
			aceptButtonText: 'Save as Draft',
			cancelButtonText: 'Cancel',
			actionForAceptButton: () => {
				const result = this.validateFormReleaseNotes();
				if (result) {
					this.modalServices.close();
					this.saveChangesReleaseNotes();
				} else {
					this.optionsToast.title = 'Release Notes form';
					this.optionsToast.message = 'Complete required fields';
					this.optionsToast.customClass = 'toast-error-badge';
					this.toastService.createToast(this.optionsToast);
				}
			},
			actionForCancelButton: () => {}
		};

		this.modalServices.open(ModalComponent, {
			showFeedback: false,
			showReleaseNotes: true,
			modal
		});
	}

	private validateFormReleaseNotes(): boolean {
		const notes = this.renderer.selectRootElement(
			'app-modal > .dds-modal > .dds-modal__body dds-textarea > .dds-textarea > div:last-child > textarea',
			true
		).value;

		const allPractitioner = this.renderer.selectRootElement(
			'app-modal > .dds-modal > .dds-modal__body dds-radio-group > div > dds-radio:first-child > label > input',
			true
		).ariaChecked;

		const onlyInitiated = this.renderer.selectRootElement(
			'app-modal > .dds-modal > .dds-modal__body dds-radio-group > div > dds-radio:last-child > label > input',
			true
		).checked;

		this.dataReleaseNote = {
			id: this.idBadgeTemplate,
			notes,
			applyOnlyInitiated: Boolean(onlyInitiated)
		};

		return notes.length > 0 && (Boolean(allPractitioner) || Boolean(onlyInitiated));
	}

	saveChangesReleaseNotes() {
		let modal: any = {
			title: 'Are you sure you want to save the changes?',
			hasFooter: true,
			contentTitle: '',
			contentText: [
				`You will save all the changes that you applied on this template.
				To see it active again you will need to 'unhide' it first in order to be shown on
				the Deloitte Badge Catalog.
			`
			],
			aceptButtonText: 'Yes, save',
			cancelButtonText: 'Cancel',
			actionForAceptButton: () => {
				this.modalServices.close();
				this.updateReleaseNote();
			},
			actionForCancelButton: () => {}
		};

		this.modalServices.open(ModalComponent, {
			showFeedback: false,
			showReleaseNotes: false,
			modal
		});
	}

	private updateReleaseNote() {
		this.badgeTemplateApiService.patch(this.dataReleaseNote).subscribe((resp) => console.log(resp));
	}

	validateRequiredFields(): boolean {
		const { flagIncomplete, validate } = this.badgeTemplatesClass.validateRequiredFields(this.entity);
		this.flagIncomplete = flagIncomplete;
		return validate;
	}

	revertSkillsBeforeAddAdjacent() {
		this.adjTemp = this.entity.skills.filter((s) => s.skillType === SkillType.Adjacent);
		this.entity.skills = this.entity.skills.filter((s) => s.skillType === SkillType.Core);
		this.entity.skillsAdjacent = this.adjTemp;
		this.badgeTemplateStoreService.updateForm(this.entity);
	}

	addBadgeTemplate(status: string = 'Submitted'): void {
		for (let index = 0; index < this.entity.skillsAdjacent.length; index++) {
			this.entity.skills.push(this.entity.skillsAdjacent[index]);
		}
		this.entity.skillsAdjacent = [];
		this.entity.status = status == 'Submitted' ? BadgeTemplateStatus.Submitted : BadgeTemplateStatus.Draft;
		this.entity.issuer = 'Deloitte';
		this.entity.id = this.idBadgeTemplate;

		if (this.entity.ownerPersonID == null || this.entity.ownerPersonID == '') {
			this.sessionService.UserSession.pipe(take(2)).subscribe((session) => {
				this.entity.ownerPersonID = session.personID;
			});
		}

		if (!this.validateRequiredFields() && status == 'Submitted') {
			this.optionsToast.title = 'Badge Template';
			this.optionsToast.message = "Can't save Badge Template. Complete required information";
			this.optionsToast.customClass = 'toast-error-badge';
			this.toastService.createToast(this.optionsToast);
			this.revertSkillsBeforeAddAdjacent();
		} else if (!this.validateRequiredFields() && this.badgeInfo.status === this.hideForEditStatus) {
			this.optionsToast.title = 'Badge Template';
			this.optionsToast.message = "Can't save Badge Template. Complete required information";
			this.optionsToast.customClass = 'toast-error-badge';
			this.toastService.createToast(this.optionsToast);
			this.revertSkillsBeforeAddAdjacent();
		} else {
			if (this.badgeInfo?.status === BadgeTemplateStatus.HideForEdit) {
				this.entity.status =
					this.role === 'admin' ? BadgeTemplateStatus.HideForEdit : BadgeTemplateStatus.Submitted;
			} else if (
				(this.badgeInfo?.status === BadgeTemplateStatus.Draft ||
					this.badgeInfo?.status === BadgeTemplateStatus.AttentionRequired) &&
				status === BadgeTemplateStatus.Draft
			) {
				this.entity.status = BadgeTemplateStatus.Draft;
			} else {
				this.entity.status =
					this.role === 'admin' ? BadgeTemplateStatus.Accepted : BadgeTemplateStatus.Submitted;
			}

			try {
				this.badgeTemplateApiService.put(this.entity).subscribe({
					next: () => {},
					error: (err) => {
						this.changeTextToastForError();
						this.revertSkillsBeforeAddAdjacent();
					},
					complete: () => {
						if (status == 'Submitted') {
							this.optionsToast = this.badgeTemplatesClass.optionsToastSubmitted(
								this.optionsToast,
								this.role === 'admin'
							);
							this.optionsToast.customClass = 'submitted-bulk';
							this.toastService.createToast(this.optionsToast);
							this.badgeTemplateActionsClass.returnListBadge();
						} else if (this.badgeInfo.status == BadgeTemplateStatus.HideForEdit) {
							this.optionsToast.title = 'The Badge Template was sucessfully saved';
							this.optionsToast.message = `The Badge Template ${this.badgeInfo.name} was sucessfully saved.
							 Now to be active again in the Deloitte Badge Catalog, you need to 'unhide' it.`;
							this.toastService.createToast(this.optionsToast);
							this.pageStoreService.setBadgesActiveTabIndex(3);
							this.badgeTemplateActionsClass.returnListBadge();
						} else {
							this.badgeTemplateActionsClass.onSave();
						}

						this.entity.issuer = 'Deloitte';
					}
				});
			} catch (ex: any) {
				this.revertSkillsBeforeAddAdjacent();
				this.changeTextToastForError();
				this.toastService.createToast(this.optionsToast);
			}
		}
	}

	changeTextToastForError(): void {
		this.optionsToast = this.badgeTemplatesClass.changeTextToastForError(this.optionsToast);
	}

	close(): void {
		this.showModalSuccess = false;
	}

	selectTab(indexTab: number) {
		if (indexTab == 0) {
			this.standardTabActive = true;
			this.alternateTabActive = false;
		} else {
			this.standardTabActive = false;
			this.alternateTabActive = true;
		}
	}

	alternativeCriteriasChanged(value: boolean) {
		this.entity.haveAlternativeCriteria = value;
		this.badgeTemplateStoreService.updateForm(this.entity);
	}

	changeDescriptionsText(value: string) {
		this.entity.alternativeDescription = value;
		this.badgeTemplateStoreService.updateForm(this.entity);
	}

	ngOnDestroy(): void {
		this.entity = {};
		this.badgeTemplateStoreService.updateForm(this.entity);
	}
}
