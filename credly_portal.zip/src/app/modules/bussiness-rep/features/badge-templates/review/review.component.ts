import { Component, OnInit } from '@angular/core';

import { ButtonOptions } from '@usitsdasdesign/dds-ng/button';
import { Size } from '@usitsdasdesign/dds-ng/shared';
import { AccordionOptions } from '@usitsdasdesign/dds-ng/accordion';
import { BadgeTemplateStoreService, PageStoreService } from '@/core/services/store';
import { BadgeTemplateApiService } from '@/core/services/apis';
import { BadgeTemplate, BadgeLevel, BadgeStatus, BadgeTemplateStatus, ExpirationRange } from '@/core/model/entities';
import { ModalService } from '@usitsdasdesign/dds-ng/modal';
import { ModalComponent } from '@/shared/components/modal/modal.component';
import { ActivatedRoute, Router } from '@angular/router';
import { ToastOptions, ToastService } from '@usitsdasdesign/dds-ng/toast';
import { ConstBadgeTemplate } from '../constants/badge-template';

@Component({
	selector: 'app-review',
	templateUrl: './review.component.html',
	styleUrls: ['./review.component.scss']
})
export class ReviewComponent implements OnInit {
	options: ButtonOptions = { ...ConstBadgeTemplate.options };
	optionsMakePublic: ButtonOptions = { ...ConstBadgeTemplate.options };
	optionsToast: ToastOptions = { ...ConstBadgeTemplate.optionsToast };
	accordionItems = { ...ConstBadgeTemplate.accordionItemsForReview };

	accordionOptions: AccordionOptions = {
		size: Size.md,
		isDisabled: false,
		isOpen: false,
		isMulti: true,
		customClass: '-'
	};

	entity: BadgeTemplate = {
		name: '',
		description: '',
		learningObjectives: '',
		level: BadgeLevel.Foundation,
		skills: []
	};

	educationList: any[] = [];
	experienceList: any[] = [];
	eminenceList: any[] = [];
	dataBadgeTemplate: any = {};
	showModalSuccess: boolean = false;
	isVisibleBtns: boolean = true;
	showBackBtn: boolean = false;
	showActions: boolean = false;
	idBadgeTemplate: string = '';
	logo: any = '';
	changeFeedbackValue: string = '';
	expirationRange: any = ExpirationRange;
	constructor(
		public badgeTemplateStoreService: BadgeTemplateStoreService,
		public badgeTemplateApiService: BadgeTemplateApiService,
		private pageStoreService: PageStoreService,
		private router: Router,
		private _router: ActivatedRoute,
		private toastService: ToastService,
		private modal: ModalService
	) {}

	ngOnInit(): void {
		this.idBadgeTemplate = this._router.snapshot.paramMap.get('id');
		this.badgeTemplateApiService.getBadgeTemplateInfo(this.idBadgeTemplate).subscribe((data: any) => {
			this.showActions = data.status === BadgeTemplateStatus.Submitted && data.isPublic;
			this.isVisibleBtns = data.status !== BadgeTemplateStatus.AttentionRequired && !this.showBackBtn;
			this.dataBadgeTemplate = data;
			this.entity.name = data.name;
			this.entity.description = data.description;
			this.entity.learningObjectives = data.learningObjectives;
			this.entity.level = data.level;
			this.entity.skills = data.skills;
			this.logo = data.logo?.base64;
			this.educationList = data.criterias.filter((e: any) => {
				return e.type == 'Education';
			});

			this.experienceList = data.criterias.filter((e: any) => {
				return e.type == 'Experience';
			});

			this.eminenceList = data.criterias.filter((e: any) => {
				return e.type == 'Eminence';
			});
		});
	}

	defineLimitSkill(skills: any) {
		let limit: number = 3;
		if (skills.lenth > 6) {
			limit = Math.ceil(skills.length / 2);
		}
		return limit;
	}

	formatExpiration(data: any) {
		let info: string = '';
		switch (data) {
			case '_1year':
				info = '1 year';
				break;
			case '_2years':
				info = '2 years';
				break;
			case '_3years':
				info = '3 years';
				break;
			case '_4years':
				info = '4 years';
				break;
			case '_5years':
				info = '5 years';
				break;
			default:
				info = data;
		}

		return info;
	}

	returnListBadge() {
		if (location.href.indexOf('badges/templates') > -1) {
			this.router.navigate(['/badges/admin/templates']);
		} else {
			this.router.navigate(['/templates']);
		}
	}

	onSave() {
		let modal: any = {
			title: 'Are you sure you want to approve this badge template?',
			hasFooter: true,
			contentTitle: '',
			contentText: [
				`Clicking "Yes" indicates that you have verified that the submitted badge details are complete and ready to be created in Credly.
				<br>Clicking "No" does not prevent you from approving in the future once the badge template is ready.`
			],
			aceptButtonText: 'Yes, approve',
			cancelButtonText: 'Cancel',
			actionForAceptButton: this.approveBadgeTemplate.bind(this),
			actionForCancelButton: () => {}
		};

		this.modal.open(ModalComponent, { modal });
	}

	onAttention() {
		let modal: any = {
			title: 'Attention required',
			hasFooter: true,
			contentTitle: '',
			contentText: [
				`You are going to give some feedback to the Business Rep, so they can continue progress and update with all the required data.<br>
			Please be very specific on each stage of the form, so they can update it correctly:

			`
			],
			aceptButtonText: 'Send Feedback',
			cancelButtonText: 'Cancel',
			actionForAceptButton: this.sendFeedbackBadgeTemplate.bind(this),
			actionForCancelButton: () => {}
		};

		this.modal.open(ModalComponent, {
			showFeedback: true,
			modal
		});
	}

	onDecline() {
		let modal: any = {
			title: 'Are you sure you want to reject this badge application?',
			hasFooter: true,
			contentTitle: '',
			contentText: [
				`This action cannot be undone and should only be performed after the practitioner has been given the opportunity to correct their submission evidence but no resolution is possible.`
			],
			aceptButtonText: 'Yes, reject',
			cancelButtonText: 'Cancel',
			actionForAceptButton: this.declineBadgeTemplate.bind(this),
			actionForCancelButton: () => {}
		};

		this.modal.open(ModalComponent, { modal });
	}

	makePublic() {
		const { id, issuer, isPublic } = this.dataBadgeTemplate;
		const params = { id, issuer, isPublic: !isPublic };
		this.badgeTemplateApiService.changePrivacy(params).subscribe(() => {
			const role = localStorage.getItem('role');
			this.pageStoreService.setBadgesActiveTabIndex(role === 'admin' ? 2 : 1);
			this.returnListBadge();
		});
	}

	approveBadgeTemplate() {
		let dataUpdate: any = {
			id: this.idBadgeTemplate,
			status: BadgeStatus.Accepted
		};
		this.badgeTemplateApiService.changeBadgeTemplateStatus(dataUpdate).subscribe((data: any) => {
			this.optionsToast.title = 'New Badge Template Approved';
			this.optionsToast.message = this.entity.name + ' Template was successfully approved.';
			this.optionsToast.customClass = 'submitted-bulk';
			this.toastService.createToast(this.optionsToast);
			this.pageStoreService.setBadgesActiveTabIndex(2);
			this.returnListBadge();
		});
		this.modal.close();
	}

	sendFeedbackBadgeTemplate() {
		let feedback: any = document.querySelector('textarea');
		let dataUpdate: any = {
			id: this.idBadgeTemplate,
			status: BadgeStatus.AttentionRequired,
			feedback: feedback.value
		};
		this.badgeTemplateApiService.changeBadgeTemplateStatus(dataUpdate).subscribe((data: any) => {
			this.optionsToast.title = 'New Badge has been sent it with attention required';
			this.optionsToast.message = 'The template user is going to receive the badge recently changed';
			this.optionsToast.customClass = 'submitted-bulk';
			this.toastService.createToast(this.optionsToast);
			this.pageStoreService.setBadgesActiveTabIndex(1);
			this.returnListBadge();
		});
		this.modal.close();
	}

	declineBadgeTemplate() {
		let dataUpdate: any = {
			id: this.idBadgeTemplate,
			status: BadgeStatus.Rejected
		};
		this.badgeTemplateApiService.changeBadgeTemplateStatus(dataUpdate).subscribe(() => {
			this.optionsToast.title = 'New Badge Rejected';
			this.optionsToast.message = 'The template user is going to receive the badge recently rejected.';
			this.optionsToast.customClass = 'submitted-bulk';
			this.toastService.createToast(this.optionsToast);
			this.pageStoreService.setBadgesActiveTabIndex(2);
			this.returnListBadge();
		});
		this.modal.close();
	}

	close() {
		this.showModalSuccess = false;
	}
}
