import { ButtonOptions } from '@usitsdasdesign/dds-ng/button';
import { Themes, Size, WidthState, ButtonKind } from '@usitsdasdesign/dds-ng/shared';
import { ToastOptions } from '@usitsdasdesign/dds-ng/toast';
import { AccordionItemOptions, AccordionOptions } from '@usitsdasdesign/dds-ng/accordion';

export namespace ConstBadgeTemplate {
	export const options: ButtonOptions = {
		theme: Themes.dark,
		kind: ButtonKind.primaryLoud,
		size: Size.md,
		width: WidthState.fixed,
		isLoading: false,
		icon: '',
		isInverse: false,
		isDisabled: false,
		ariaLabel: 'Button',
		customClass: '',
		role: 'button'
	};

	export const optionsToast: ToastOptions = {
		title: 'Badge Template',
		message: "Can't save Badge Template",
		lifeTime: 6000,
		position: 'bottom-left',
		closeBtnIcon: 'dds-icon_close',
		isCloseIcon: true,
		customClass: 'simple-toast',
		limit: 5,
		theme: Themes.white
	};

	export const optionsToastCreate: ToastOptions = {
		title: 'Badge Template',
		message: "Can't save Badge Template",
		lifeTime: 6000,
		position: 'bottom-left',
		closeBtnIcon: 'dds-icon_close',
		isCloseIcon: true,
		customClass: 'simple-toast',
		limit: 5,
		theme: Themes.white
	};

	export const accordionOptions: AccordionOptions = {
		size: Size.md,
		isDisabled: false,
		isOpen: false,
		isMulti: true,
		customClass: '-'
	};

	export const noQueueToast: ToastOptions = {
		title: `You have no badges templates to approve at this time!`,
		message: ``,
		lifeTime: 5000,
		position: 'bottom-left',
		closeBtnIcon: 'dds-icon_close',
		isCloseIcon: true,
		customClass: 'simple-toast',
		limit: 5,
		theme: Themes.dark
	};

	export const badgesInQueueToast: ToastOptions = {
		title: `You have new badge templates submissions to be reviewed!`,
		message: ``,
		lifeTime: 5000,
		position: 'bottom-left',
		closeBtnIcon: 'dds-icon_close',
		isCloseIcon: true,
		customClass: 'simple-toast',
		limit: 5,
		theme: Themes.dark
	};

	export const accordionItemsForReview: { options: AccordionItemOptions; content: string }[] = [
		{
			options: {
				heading: `<span><b>1</b>Description</span>`,
				text: '',
				isDisabled: false,
				isOpen: false,
				customClass: 'title-tab-template'
			},
			content: ``
		},
		{
			options: {
				heading: '<span><b>2</b>Criterias Needed</span>',
				customClass: 'title-tab-template'
			},
			content: ``
		},
		{
			options: {
				heading: '<span><b>3</b>Validation</span>',
				customClass: 'title-tab-template'
			},
			content: ``
		}
	];
}
