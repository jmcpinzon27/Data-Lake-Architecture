import { DataGridColumn } from '@/shared/components/data-grid/model';

export const inProgressColumns: DataGridColumn[] = [
	{
		label: 'Name Template',
		fieldValue: 'name',
		cellTemplateName: '',
		allowOrderBy: true,
		allowFilterText: false,
		allowFilterFixedValues: false,
		selected: false,
		dataType: 'string'
	},
	{
		label: 'Collection',
		fieldValue: 'collections',
		cellTemplateName: '',
		allowOrderBy: true,
		allowFilterText: false,
		allowFilterFixedValues: false,
		selected: false,
		dataType: 'string'
	},
	{
		label: 'Level',
		fieldValue: 'level',
		cellTemplateName: '',
		allowOrderBy: true,
		allowFilterText: false,
		allowFilterFixedValues: false,
		selected: false,
		dataType: 'string'
	},
	{
		label: 'Status',
		fieldValue: 'status',
		cellTemplateName: 'splitByUpperCell',
		allowOrderBy: true,
		allowFilterText: false,
		allowFilterFixedValues: false,
		selected: false,
		dataType: 'string'
	},
	{
		label: 'Modified',
		fieldValue: 'updateAt',
		cellTemplateName: 'dateCell',
		allowOrderBy: true,
		allowFilterText: false,
		allowFilterFixedValues: false,
		selected: false,
		dataType: 'string'
	},
	{
		label: 'Actions',
		fieldValue: '',
		cellTemplateName: 'editCell',
		allowOrderBy: false,
		allowFilterText: false,
		allowFilterFixedValues: false,
		selected: false,
		dataType: 'string'
	}
];

export const approvedColumns: DataGridColumn[] = [
	{
		label: 'Name Template',
		fieldValue: 'name',
		cellTemplateName: '',
		allowOrderBy: true,
		allowFilterText: false,
		allowFilterFixedValues: false,
		selected: false,
		dataType: 'string'
	},
	{
		label: 'Collection',
		fieldValue: 'collections',
		cellTemplateName: '',
		allowOrderBy: true,
		allowFilterText: false,
		allowFilterFixedValues: false,
		selected: false,
		dataType: 'string'
	},
	{
		label: 'Level',
		fieldValue: 'level',
		cellTemplateName: '',
		allowOrderBy: true,
		allowFilterText: false,
		allowFilterFixedValues: false,
		selected: false,
		dataType: 'string'
	},
	{
		label: 'Status',
		fieldValue: 'status',
		cellTemplateName: '',
		allowOrderBy: true,
		allowFilterText: false,
		allowFilterFixedValues: false,
		selected: false,
		dataType: 'string'
	},
	{
		label: 'Approved Date',
		fieldValue: 'approvedAt',
		cellTemplateName: 'dateCell',
		allowOrderBy: true,
		allowFilterText: false,
		allowFilterFixedValues: false,
		selected: false,
		dataType: 'string'
	},
	{
		label: 'Actions',
		fieldValue: '',
		cellTemplateName: 'editCell',
		allowOrderBy: false,
		allowFilterText: false,
		allowFilterFixedValues: false,
		selected: false,
		dataType: 'string'
	}
];

export const columnsC: DataGridColumn[] = [
	{
		label: 'Practitioner Name',
		fieldValue: 'title',
		cellTemplateName: '',
		allowOrderBy: true,
		allowFilterText: false,
		allowFilterFixedValues: false,
		selected: false,
		dataType: 'string'
	},
	{
		label: 'Badge Name',
		fieldValue: 'description',
		cellTemplateName: '',
		allowOrderBy: true,
		allowFilterText: false,
		allowFilterFixedValues: false,
		selected: false,
		dataType: 'string'
	},
	{
		label: 'Date added to Queue',
		fieldValue: 'date',
		cellTemplateName: '',
		allowOrderBy: true,
		allowFilterText: false,
		allowFilterFixedValues: false,
		selected: false,
		dataType: 'string'
	},
	{
		label: 'Status',
		fieldValue: 'date',
		cellTemplateName: '',
		allowOrderBy: true,
		allowFilterText: false,
		allowFilterFixedValues: false,
		selected: false,
		dataType: 'string'
	}
];
