import { Component, OnInit, ViewChild, Renderer2 } from '@angular/core';
import { Router } from '@angular/router';

import { TabsOptions, TabOptions } from '@usitsdasdesign/dds-ng/tabs';
import { Themes, Size, TabThemeType } from '@usitsdasdesign/dds-ng/shared';
import { DataGridColumn } from '@/shared/components/data-grid/model';
import { ButtonOptions } from '@usitsdasdesign/dds-ng/button';
import { BadgeTemplateApiService } from '@/core/services/apis';
import { BadgeTemplateQuery, BadgeTemplateStatus, Session } from '@/core/model/entities';
import { inProgressColumns, approvedColumns, columnsC } from './constants/column-initialized';
import { PageStoreService, SessionStoreService } from '@/core/services/store';
import { StickerDirective } from '@usitsdasdesign/dds-ng/sticker';
import { ModalService } from '@usitsdasdesign/dds-ng/modal';
import { ToastOptions, ToastService } from '@usitsdasdesign/dds-ng/toast';
import { Action } from '@/core/model/common/actions';
import { DataGridComponent } from '@/shared/components/data-grid/data-grid.component';
import { ConstBadgeTemplate } from './constants/badge-template';
import { validateStickerOpenOrClosed, setActionPrivateOrPublic } from '@/modules/shared/helpers';

@Component({
	selector: 'app-badge-templates',
	templateUrl: './badge-templates.component.html',
	styleUrls: ['./badge-templates.component.scss']
})
export class BadgeTemplatesComponent implements OnInit {
	@ViewChild('tab1') inProgressGridRef!: DataGridComponent;
	@ViewChild('tab2') approvedGridRef!: DataGridComponent;
	@ViewChild('actionStickerDir') actionStickerDir: StickerDirective;

	constructor(
		public service: BadgeTemplateApiService,
		public sessionService: SessionStoreService,
		private router: Router,
		private pageStoreService: PageStoreService,
		private modal: ModalService,
		private toastService: ToastService,
		private renderer: Renderer2
	) {}
	columns!: Array<DataGridColumn>;
	columnsB!: Array<DataGridColumn>;
	columnsC!: Array<DataGridColumn>;

	badgeTemplatesInProgessFilter: any = {
		status: [BadgeTemplateStatus.Draft, BadgeTemplateStatus.Submitted, BadgeTemplateStatus.AttentionRequired],
		ShowExternals: false
	};

	badgeTemplatesApprovedFilter: any = {
		status: [BadgeTemplateStatus.Accepted, BadgeTemplateStatus.Archived],
		ShowExternals: false
	};

	isAdminTemplateRoute = location.href.includes('admin/template');

	badgeServiceMethod: string;

	inProgressActions: Action[] = [
		{
			label: 'Edit',
			disabled: false
		}
	];

	tabContainerOptions: TabsOptions = {
		theme: Themes.green,
		themeType: TabThemeType.border,
		size: Size.md,
		ariaLabel: 'Horizontal tabs',
		isDisabled: false,
		customClass: 'repor-badge-templates',
		isResponsive: false
	};

	tabOptions1: TabOptions = {
		label: 'In Progress Badge Templates'
	};

	tabOptions2: TabOptions = {
		label: 'Approved Badge Templates'
	};

	options: ButtonOptions = ConstBadgeTemplate.options;
	noQueueToast: ToastOptions = ConstBadgeTemplate.noQueueToast;
	badgesInQueueToast: ToastOptions = ConstBadgeTemplate.badgesInQueueToast;

	approvedActions: Action[] = [
		{
			label: 'Make Private',
			disabled: false
		}
	];

	// This type must be any to avoid typing errors using variables to access to the values
	posibleActions: any = {
		progress: this.inProgressActions,
		approved: this.approvedActions
	};

	actionsList: Action[] = [] as Action[];
	tabSelected: string = '';
	rowSelected!: BadgeTemplateQuery;
	showTabA: boolean = true;
	showTabB: boolean = false;

	ngOnInit(): void {
		this.sessionService.UserSession.subscribe((e: Session) => {
			this.badgeServiceMethod = e.isAdmin ? 'getBadgesTemplatesAdmin' : 'getBadgeTemplatesBusinessRep';
		});

		this.pageStoreService.badgesActiveTabIndex.subscribe((index: number) => this.selectTab(index));

		this.columns = inProgressColumns;
		this.columnsB = approvedColumns;
		this.columnsC = columnsC;
	}

	setAction(sticker: StickerDirective, row: BadgeTemplateQuery) {
		this.rowSelected = row;
		const { stickerCustomClass } = sticker; // takes this property from sticker to set the actions
		this.actionsList = this.posibleActions[stickerCustomClass];
		setActionPrivateOrPublic(this.approvedActions, this.rowSelected);
		this.disableAction(row.status);
	}

	private disableAction(status: string) {
		const isApprovedRow = status === BadgeTemplateStatus.Accepted;
		const isSubmittedRow = status === BadgeTemplateStatus.Submitted;

		this.actionsList.forEach((action: Action) => {
			(isApprovedRow && action.label === 'Archive') || (isSubmittedRow && action.label === 'Edit')
				? (action.disabled = true)
				: (action.disabled = false);
		});
	}

	onEditClick(actionClicked: Action) {
		const changePrivacyValues = ['Make Public', 'Make Private'];
		if (changePrivacyValues.includes(actionClicked.label)) this.changePrivacy();
		if (actionClicked.label === 'Edit') this.router.navigate(['templates', 'edit', this.rowSelected.id]);
		this.actionStickerDir.hide();
	}

	private changePrivacy() {
		const { id, issuer, isPublic } = this.rowSelected;
		const params = { id, issuer, isPublic: !isPublic };
		this.service.changePrivacy(params).subscribe(() => this.approvedGridRef.getInformationToFillTable());
		this.actionStickerDir.hide();
	}

	showPreview(rowValue: BadgeTemplateQuery) {
		const { id, status } = rowValue;
		if (validateStickerOpenOrClosed('approved', status as BadgeTemplateStatus)) {
			this.router.navigate(['/templates/review/' + id]);
		}
	}

	changeBadgeStatus(status: string) {
		const { id } = this.rowSelected;
		this.service.changeBadgeTemplateStatus({ id, status }).subscribe(() => {
			this.approvedGridRef.getInformationToFillTable();
			this.modal.close();
		});
	}

	createNewTemplate(): void {
		if (location.href.indexOf('badges/templates') > -1) {
			this.router.navigate(['/badges/templates/create']);
		} else {
			this.router.navigate(['/templates/create']);
		}
	}

	verifyBadgesQueue(queueItems: any) {
		if (this.isAdminTemplateRoute) {
			if (queueItems === 0) {
				this.toastService.createToast(this.noQueueToast);
			} else {
				this.toastService.createToast(this.badgesInQueueToast);
			}
		}
	}

	selectTab(indexTab: number): void {
		this.showTabA = indexTab === 0;
		this.showTabB = indexTab === 1;
	}
}
