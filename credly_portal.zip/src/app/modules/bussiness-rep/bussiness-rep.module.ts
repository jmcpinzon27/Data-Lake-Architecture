import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SharedModule } from '@/shared/shared.module';

import { BussinessRepRoutingModule } from './bussiness-rep-routing.module';
import { BadgeSubmittedComponent } from './features/badge-submitted/badge-submitted.component';
import { BadgeTemplatesComponent } from './features/badge-templates/badge-templates.component';
import { CreateComponent } from './features/badge-templates/create/create.component';
import { CriteriasComponent } from './features/badge-templates/create/components/criterias/criterias.component';
import { BasicDataComponent } from './features/badge-templates/create/components/basic-data/basic-data.component';
import { CriteriaActionsComponent } from './features/badge-templates/create/components/criterias/components/criteria-actions/criteria-actions.component';
import { CriteriaFormComponent } from './features/badge-templates/create/components/criterias/components/criteria-form/criteria-form.component';
import { CriteriaItemComponent } from './features/badge-templates/create/components/criterias/components/criteria-item/criteria-item.component';
import { ValidationFormComponent } from './features/badge-templates/create/components/validation-form/validation-form.component';
import { NgxDropzoneModule } from 'ngx-dropzone';
import { StickerModule } from '@usitsdasdesign/dds-ng/sticker';
import { LibModule } from '@usitsdasdesign/dds-ng';
import { ModalComponent } from '@/shared/components/modal/modal.component';
import { ReviewComponent } from './features/badge-templates/review/review.component';
import { ReactiveFormsModule } from '@angular/forms';
import { EditComponent } from './features/badge-templates/edit/edit.component';

@NgModule({
	declarations: [
		BadgeSubmittedComponent,
		BadgeTemplatesComponent,
		CreateComponent,
		CriteriasComponent,
		BasicDataComponent,
		CriteriaActionsComponent,
		CriteriaFormComponent,
		CriteriaItemComponent,
		ValidationFormComponent,
		ReviewComponent,
  EditComponent
	],
	imports: [
		CommonModule,
		SharedModule,
		BussinessRepRoutingModule,
		NgxDropzoneModule,
		StickerModule,
		LibModule,
		ReactiveFormsModule
	]
})
export class BussinessRepModule {}
