import { BadgeApprovalComponent } from '@/shared/features/badge-approval/badge-approval.component';
import { BadgePreviewComponent } from '@/shared/components/badge-preview/badge-preview.component';
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { MsalGuard } from '@azure/msal-angular';
import { BadgeSubmittedComponent } from './features/badge-submitted/badge-submitted.component';
import { BadgeTemplatesComponent } from './features/badge-templates/badge-templates.component';
import { CreateComponent } from './features/badge-templates/create/create.component';
import { EditComponent } from './features/badge-templates/edit/edit.component';

import { ReviewComponent } from './features/badge-templates/review/review.component';
import { NotificationsComponent } from '../admin/features/notifications/notifications.component';

enum AppRoutes {
	List = '',
	Main = '',
	Template = 'templates',
	CreateTemplate = 'templates/create',
	EditTemplate = 'templates/edit/:id',
	ReviewTemplate = 'templates/review/:id',

	BadgeApproval = 'badge-approval/:id',
	ViewTemplate = 'templates/preview/:id',
	BulkAwarding = 'bulk-awarding',
	AdminTemplate = 'admin/templates',
	Notifications = 'notifications',
	Badges = 'badges'
}

const routes: Routes = [
	{
		path: AppRoutes.Badges,
		component: BadgeSubmittedComponent,
		canActivate: [MsalGuard]
	},
	{
		path: AppRoutes.Main,
		component: BadgeSubmittedComponent,
		canActivate: [MsalGuard]
	},
	{
		path: AppRoutes.Template,
		component: BadgeTemplatesComponent,
		canActivate: [MsalGuard]
	},
	{
		path: AppRoutes.AdminTemplate,
		component: BadgeSubmittedComponent,
		canActivate: [MsalGuard]
	},
	{
		path: AppRoutes.CreateTemplate,
		component: CreateComponent,
		canActivate: [MsalGuard]
	},
	{
		path: AppRoutes.EditTemplate,
		component: EditComponent,
		canActivate: [MsalGuard]
	},
	{
		path: AppRoutes.ReviewTemplate,
		component: ReviewComponent,
		canActivate: [MsalGuard]
	},
	{
		path: AppRoutes.BadgeApproval,
		component: BadgeApprovalComponent,
		canActivate: [MsalGuard]
	},
	{
		path: AppRoutes.ViewTemplate,
		component: BadgePreviewComponent,
		canActivate: [MsalGuard]
	},
	{
		path: AppRoutes.BulkAwarding,
		loadChildren: () =>
			import('../shared/bulk-awarding/bulk-awarding-routing.module').then((m) => m.BulkAwardingRoutingModule),
		canActivate: [MsalGuard]
	},
	{
		path: AppRoutes.Notifications,
		component: NotificationsComponent,
		canActivate: [MsalGuard]
	}
];

@NgModule({
	imports: [RouterModule.forChild(routes)],
	exports: [RouterModule]
})
export class BussinessRepRoutingModule {}
