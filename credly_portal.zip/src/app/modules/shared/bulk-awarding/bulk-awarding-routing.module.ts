import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { MsalGuard } from '@azure/msal-angular';
import { BulkAwardingListComponent } from './bulk-awarding-list/bulk-awarding-list.component';

const routes: Routes = [{ path: '', component: BulkAwardingListComponent, canActivate: [MsalGuard] }];

@NgModule({
	imports: [RouterModule.forChild(routes)],
	exports: [RouterModule]
})
export class BulkAwardingRoutingModule {}
