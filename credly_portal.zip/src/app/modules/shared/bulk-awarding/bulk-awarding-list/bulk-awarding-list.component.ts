import { Component, OnInit, TemplateRef, ViewChild, Renderer2 } from '@angular/core';
import { Themes, Size, WidthState, ButtonKind, LabelPosition, ErrorState } from '@usitsdasdesign/dds-ng/shared';
import { ButtonOptions } from '@usitsdasdesign/dds-ng/button';
import { ModalService } from '@usitsdasdesign/dds-ng/modal';
import { BadgeTemplateApiService, BulkAwardingApiService } from '@/core/services/apis';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { SelectItemOptions, SelectOptions } from '@usitsdasdesign/dds-ng/select';
import { DatepickerOptions, DatepickerStates } from '@usitsdasdesign/dds-ng/datepicker';
import { UploaderOptions } from '@usitsdasdesign/dds-ng/uploader';
import { CheckboxOptions, CheckboxGroupOptions } from '@usitsdasdesign/dds-ng/checkbox';
import { DataGridColumn } from '@/shared/components/data-grid/model';
import { Action, ModalValues } from '@/core/model/common/actions';
import { StickerDirective } from '@usitsdasdesign/dds-ng/sticker';

import { ModalComponent } from '@/shared/components/modal/modal.component';
import { GenericModalComponent } from '@/shared/generic-modal/generic-modal.component';
import { forkJoin } from 'rxjs';
import { BadgeTemplate, BadgeTemplateStatus, RoleType } from '@/core/model/entities';
import { EmployeeApiService } from '@/core/services/apis';
import { FilterColumn, ListRequest, OrderBy } from '@/core/model/common';
import { ToastOptions, ToastService } from '@usitsdasdesign/dds-ng/toast';
import BulkAwarding from '@/core/model/entities/bulkAwarding';
import { DataGridComponent } from '@/shared/components/data-grid/data-grid.component';
import { SessionStoreService } from '@/core/services/store';
import { BlobFileApiService } from '@/core/services/apis';
import {
	BulkAwardingProcessFormTypes,
	BulkAwardingProcessStatuses,
	BulkAwardingProcessStatusesNumeric,
	ReadableStatuses
} from '@/core/constants/AwardingProcess';

@Component({
	selector: 'app-bulk-awarding-list',
	templateUrl: './bulk-awarding-list.component.html',
	styleUrls: ['./bulk-awarding-list.component.scss']
})
export class BulkAwardingListComponent implements OnInit {
	@ViewChild('contentTemplate', { read: TemplateRef }) contentTemplate: TemplateRef<any>;
	@ViewChild('actionStickerDir') actionStickerDir: StickerDirective;
	@ViewChild('awardingProcessGrid') awardinProcessGridRef!: DataGridComponent;

	showListApprover: boolean = false;
	formType: BulkAwardingProcessFormTypes = BulkAwardingProcessFormTypes.Create;
	role: RoleType = RoleType.BusinessRep;

	/**
	 * This filter is going to avoid the draft status
	 */
	bulkAwardingFilter = {
		filterColumns: [
			{
				freeText: false,
				column: 'Status',
				value: BulkAwardingProcessStatusesNumeric.Draft,
				exclude: true
			}
		]
	};

	bulkAwardingForm: FormGroup;
	badgeTemplates: BadgeTemplate[];
	btnOptionsOpenModal: ButtonOptions = {
		theme: Themes.dark,
		kind: ButtonKind.primaryLoud,
		size: Size.md,
		width: WidthState.fixed,
		isLoading: false,
		icon: '',
		isInverse: false,
		isDisabled: false,
		ariaLabel: 'Button',
		customClass: '',
		role: 'button'
	};
	btnOptionsSubmit: ButtonOptions = {
		theme: Themes.dark,
		kind: ButtonKind.primaryLoud,
		size: Size.lg,
		width: WidthState.fixed,
		isLoading: false,
		icon: '',
		isInverse: false,
		isDisabled: false,
		ariaLabel: 'Button',
		role: 'button',
		customClass: 'btn-bigger'
	};
	btnOptionsCancel: ButtonOptions = {
		theme: Themes.dark,
		kind: ButtonKind.secondary,
		size: Size.lg,
		width: WidthState.fixed,
		isLoading: false,
		icon: '',
		isInverse: false,
		isDisabled: false,
		ariaLabel: 'Button',
		role: 'button',
		customClass: 'btn-bigger'
	};
	selectOptionsTemplates: SelectOptions = {
		label: 'Badge Name',
		labelPosition: LabelPosition.external,
		description: '',
		placeholder: 'Select the Name of the Badge',
		size: Size.md,
		isDisabled: false,
		isResponsive: false,
		isRequired: true,
		isError: true,
		errorMessage: '',
		errorState: ErrorState.focusOut,
		stickerWidth: 350,
		stickerShift: 0,
		stickerMaxHeight: '',
		stickerIsDisabled: false,
		stickerPosition: 'bottom-left',
		stickerIndent: 0,
		stickerCustomClass: ''
	};

	itemsListBadgeTemplates: SelectItemOptions[] = [];
	optionsCompletionDate: DatepickerOptions = {
		label: 'Issue Date',
		labelPosition: LabelPosition.external,
		size: Size.md,
		format: 'MM/dd/yyyy',
		minMode: DatepickerStates.day,
		errorState: ErrorState.focusOut,
		isManualInput: true,
		isRequired: true,
		isResponsive: false,
		isDisabled: false
	};
	maxSizeFile: number = 5242880;
	uploadCsvOptions: UploaderOptions = {
		heading: 'Upload CSV',
		description: 'Max Size of 5MB',
		url: '/success',
		isDragAndDrop: false,
		isMultiple: false,
		maxSize: 5000,
		maxTotalSize: 5000,
		acceptFormats: 'csv',
		btnLabel: 'Choose file',
		unknownExtensionsIcon: 'dds-icon_file',
		isDownloadable: true,
		allowFilesWithoutType: true,
		isDisabled: false,
		isRequired: true
	};
	uploadZipOptions: UploaderOptions = {
		heading: 'Upload ZIP',
		description: 'Max Size of 5MB',
		url: '/success',
		isDragAndDrop: false,
		isMultiple: false,
		maxSize: 5000,
		maxTotalSize: 5000,
		acceptFormats: 'csv',
		btnLabel: 'Choose file',
		unknownExtensionsIcon: 'dds-icon_file',
		customClass: '',
		isDownloadable: true,
		allowFilesWithoutType: true,
		isDisabled: false,
		isRequired: true
	};

	options: CheckboxOptions = {
		label: '',
		theme: Themes.dark,
		isIndeterminate: false,
		isDisabled: false,
		isError: false,
		isRequired: false,
		errorState: ErrorState.focusOut,
		ariaLabel: '',
		customClass: ''
	};

	listApprover: any[] = [];
	filteredListApprover: any[] = [];
	backUpFilteredListApprover: any[] = [];
	filterColumn: Array<FilterColumn> = [
		{
			column: '',
			value: '',
			freeText: false
		}
	];

	orderByFilter: OrderBy = {
		column: '',
		desc: false
	};

	request: ListRequest = {
		pageIndex: 1,
		pageSize: 10,
		filterColumns: this.filterColumn,
		SearchText: '',
		orderBy: this.orderByFilter
	};

	cohortId: number = 0;
	activeRow: BulkAwarding = {
		id: '',
		cohortId: 0
	};

	files: File[] = [];
	filesZip: File[] = [];
	downloadedFileIds: string[] = [];

	optionsToast: ToastOptions = {
		title: 'Cohort ID submitted',
		message: 'The #  Cohort ID has been submitted for reviewing and being approved.',
		lifeTime: 7000,
		position: 'bottom-left',
		closeBtnIcon: 'dds-icon_close',
		isCloseIcon: true,
		customClass: 'simple-toast',
		limit: 5,
		theme: Themes.white
	};
	columns: Array<DataGridColumn> = [
		{
			label: 'Cohort ID',
			fieldValue: 'cohortId',
			cellTemplateName: '',
			allowOrderBy: true,
			allowFilterText: false,
			allowFilterFixedValues: false,
			selected: false,
			dataType: 'number'
		},
		{
			label: 'Status',
			fieldValue: 'status',
			cellTemplateName: 'statusCell',
			allowOrderBy: true,
			allowFilterText: false,
			allowFilterFixedValues: false,
			selected: false,
			dataType: 'string'
		},
		{
			label: 'Optional Title',
			fieldValue: 'title',
			cellTemplateName: '',
			allowOrderBy: false,
			allowFilterText: false,
			allowFilterFixedValues: false,
			selected: false,
			dataType: 'string'
		},
		{
			label: 'Date Created',
			fieldValue: 'createdate',
			cellTemplateName: 'dateCell',
			allowOrderBy: true,
			allowFilterText: false,
			allowFilterFixedValues: false,
			selected: false,
			dataType: 'string'
		},
		{
			label: 'Requested By',
			fieldValue: 'createdBy',
			cellTemplateName: '',
			allowOrderBy: true,
			allowFilterText: false,
			allowFilterFixedValues: false,
			selected: false,
			dataType: 'string'
		},
		{
			label: 'Action',
			fieldValue: '',
			cellTemplateName: 'editCell',
			allowOrderBy: false,
			allowFilterText: false,
			allowFilterFixedValues: false,
			selected: false,
			dataType: 'string'
		}
	];

	readableStatuses = ReadableStatuses;

	dataRequest : ListRequest = {
		filterColumns: [
			{
				freeText: false,
				column: 'Status',
				value: 3
			}
		],
		orderBy : {
			column : 'name',
			desc : false
		}
	}

	constructor(
		public badgeTemplateApiService: BadgeTemplateApiService,
		public bulkAwardingApiService: BulkAwardingApiService,
		private modal: ModalService,
		private fb: FormBuilder,
		private employeeService: EmployeeApiService,
		private sessionService: SessionStoreService,
		private toastService: ToastService,
		private blobFileApiService: BlobFileApiService,
		private renderer: Renderer2
	) {}

	ngOnInit(): void {
		const maxUsersPerRole = 100;
		const requestAdminAndBusinessRep = {
			pageIndex: 1,
			pageSize: maxUsersPerRole,
			filterColumns: this.filterColumn,
			SearchText: '',
			orderBy: this.orderByFilter,
			Roles: `${RoleType.Admin}|${RoleType.BusinessRep}`
		};

		this.employeeService.getByRoles(requestAdminAndBusinessRep).subscribe({
			next: (response) => {
				// it sorts the admins and businessReps
				this.listApprover = response.data.sort(function (a, b) {
					let x = a.firstName?.toLocaleLowerCase();
					let y = b.firstName?.toLocaleLowerCase();
					if (x < y) {
						return -1;
					}
					if (x > y) {
						return 1;
					}
					return 0;
				});
				this.filteredListApprover = this.listApprover;
			},
			error: (err) => console.error(err)
		});

		this.sessionService.UserSession.subscribe({
			next: (userData) => {
				this.role = userData.isBusinessRep ? RoleType.BusinessRep : RoleType.Admin;
			}
		});
	}

	onSelect(event: any) {
		this.files.push(...event.addedFiles);
		if (event.addedFiles.length > 0) {
			const file = event.addedFiles[0];
			const reader = new FileReader();
			reader.readAsDataURL(file);
			reader.onloadend = () => {
				this.bulkAwardingForm.get('csvUrlFileBase64').get('base64').setValue(reader.result);
				this.bulkAwardingForm.get('csvUrlFileBase64').get('fileName').setValue(file.name);
			};
		} else {
			const file = event.rejectedFiles[0];
			if (file.reason === 'size') {
				this.showErrorForFileSize();
			}
		}
	}

	onSelectZip(event: any) {
		this.filesZip.push(...event.addedFiles);
		if (event.addedFiles.length > 0) {
			const file = event.addedFiles[0];
			const reader = new FileReader();
			reader.readAsDataURL(file);
			reader.onloadend = () => {
				this.bulkAwardingForm.get('zipUrlFileBase64').get('base64').setValue(reader.result);
				this.bulkAwardingForm.get('zipUrlFileBase64').get('fileName').setValue(file.name);
			};
		} else {
			const file = event.rejectedFiles[0];
			if (file.reason === 'size') {
				this.showErrorForFileSize();
			}
		}
	}

	onRemove(event: any) {
		this.files.splice(this.files.indexOf(event), 1);
		this.bulkAwardingForm.get('csvUrlFileBase64').get('base64').setValue('');
	}

	onRemoveZip(event: any) {
		this.filesZip.splice(this.filesZip.indexOf(event), 1);
		this.bulkAwardingForm.get('zipUrlFileBase64').get('base64').setValue('');
	}

	showErrorForFileSize() {
		const optionsToast: ToastOptions = {
			title: '',
			message: `The file you are trying to upload is bigger than 5MB.`,
			lifeTime: 12000,
			position: 'bottom-left',
			closeBtnIcon: 'dds-icon_close',
			isCloseIcon: true,
			customClass: 'simple-toast',
			limit: 5,
			theme: Themes.danger
		};
		this.toastService.createToast(optionsToast);
	}

	optionSelectedApprover(item: any) {
		this.showListApprover = false;
		this.bulkAwardingForm.get('approver_Id').setValue(item?.personID);
		this.bulkAwardingForm.get('approverLabel').setValue(`${item?.firstName} ${item?.lastName} / ${item?.email}`);
	}

	onApproverBlur() {
		this.showListApprover = false;
	}

	showToast() {
		this.optionsToast.message =
			'The #' + this.cohortId + ' Cohort ID has been submitted for reviewing and being approved.';
		this.toastService.createToast(this.optionsToast);
	}

	onButtonClickForm(action: string) {
		switch (action) {
			case 'delete-bulk':
				this.confirmationDeleteBulkAwarding();
				break;
			case 'attention-required':
				this.confirmationAttentionRequired();
				break;
			case 'approve':
				this.approveBulkAwarding();
				break;
			case 'create-approve':
				this.bulkAwardingForm.get('status').setValue(BulkAwardingProcessStatuses.Approved);
				this.createAndApproveBulkAwarding();
				break;
			case 'submit':
				this.confirmationSubmitBulkAwarding();
				break;
			case 'cancel':
				this.modal.close();
				break;
		}
	}

	openBulkAwardingForm(formType: string): void {
		this.formType =
			formType === BulkAwardingProcessFormTypes.Create
				? BulkAwardingProcessFormTypes.Create
				: BulkAwardingProcessFormTypes.Edit;
		this.initForm();
		this.bulkAwardingForm.get('approverLabel').valueChanges.subscribe((term: string) => {
			this.filteredListApprover = this.listApprover.filter((approver) => {
				term = term.toLocaleLowerCase();
				const firstName = approver.firstName?.toLocaleLowerCase();
				const lastName = approver.lastName?.toLocaleLowerCase();
				const email = approver.email?.toLocaleLowerCase();
				return firstName?.includes(term) || lastName?.includes(term) || email?.includes(term);
			});
			this.showListApprover = this.filteredListApprover.length > 0;
		});

		if (this.formType === BulkAwardingProcessFormTypes.Create) {
			forkJoin([
				this.bulkAwardingApiService.createForAdmin(),
				this.badgeTemplateApiService.get(this.dataRequest)
			]).subscribe({
				next: (responses) => {
					const cohortId = responses[0]['cohortId'];
					const id = responses[0]['id'];

					this.bulkAwardingForm.get('cohortId').setValue(cohortId);
					this.bulkAwardingForm.get('id').setValue(id);
					this.bulkAwardingForm.get('csvUrlFileBase64').get('fileName').setValue(`csv_${cohortId}`);
					this.bulkAwardingForm.get('zipUrlFileBase64').get('fileName').setValue(`zip_${cohortId}`);

					const getPageSize = responses[1]?.count;
					this.getBadgeTemplatesAll(getPageSize);

					let modalRef = this.modal.open(GenericModalComponent, {
						title: 'Create New Bulk Award Request',
						size: 'lg',
						contentTemplate: this.contentTemplate
					});
					this.centeredTitleModal();
				},
				error: (err) => {
					// TODO: error handler
					console.error(err);
				}
			});
		} else {
			// Editing form
			this.badgeTemplateApiService.get(this.dataRequest).subscribe({
				next: (response) => {
					const getPageSize = response?.count;
					this.getBadgeTemplatesAll(getPageSize, BulkAwardingProcessFormTypes.Edit);
					let modalRef = this.modal.open(GenericModalComponent, {
						title: 'Edit Bulk Award Request',
						size: 'lg',
						contentTemplate: this.contentTemplate
					});
					this.centeredTitleModal();
					this.filteredListApprover = this.listApprover;
					this.backUpFilteredListApprover =
						this.filteredListApprover.length > 0
							? this.filteredListApprover
							: this.backUpFilteredListApprover;
					const getBadgeApprover = this.backUpFilteredListApprover.find(
						(item) => item?.personID == this.activeRow.approver_Id
					);

					this.bulkAwardingApiService.getById(this.activeRow.id).subscribe((e: any) => {
						if (
							e.lastFeedback &&
							e.lastFeedback != '' &&
							e.status == BadgeTemplateStatus.AttentionRequired &&
							this.role == RoleType.BusinessRep
						) {
							this.showFeedbackAttentionRequired(e.lastFeedback);
						}
					});
					this.optionSelectedApprover(getBadgeApprover);
					this.loadPreviewFile();
				},
				error: (err) => {
					// TODO: error handler
					console.error(err);
				}
			});
		}
	}

	getBadgeTemplatesAll(pageSize: number, typeForm: string = '') {
		this.badgeTemplateApiService.getBadgeTemplateAll(pageSize, this.dataRequest).subscribe({
			next: (response: any) => {
				this.badgeTemplates = response.data;
				this.itemsListBadgeTemplates = this.badgeTemplates.map((template) => {
					return {
						heading: template.name,
						value: template.id
					};
				});
				if (typeForm === BulkAwardingProcessFormTypes.Edit) {
					setTimeout(() => this.valueChanged(this.bulkAwardingForm.get('badgeTemplate_Id').value), 250);
				}
			}
		});
	}

	loadPreviewFile(): void {
		const nameCsv = this.activeRow.csvUrlFile.split('/').pop();
		const nameZip = this.activeRow.zipUrlFile.split('/').pop();
		const fileCsv = new File(['CSV'], nameCsv, { type: 'text/csv' });
		const fileZip = new File(['ZIP'], nameZip, { type: 'application/zip' });

		this.files.push(fileCsv);
		this.filesZip.push(fileZip);
		this.blobFileApiService.downloadById(this.activeRow.csvUrlFile).subscribe((blob) => {
			var reader = new FileReader();
			reader.readAsDataURL(blob);
			reader.onloadend = () => {
				this.bulkAwardingForm.get('csvUrlFileBase64').get('base64').setValue(reader.result);
				this.bulkAwardingForm.get('csvUrlFileBase64').get('fileName').setValue('awardingprocesscsv.csv');
			};
		});
		this.blobFileApiService.downloadById(this.activeRow.zipUrlFile).subscribe((blob) => {
			var reader = new FileReader();
			reader.readAsDataURL(blob);
			reader.onloadend = () => {
				this.bulkAwardingForm.get('zipUrlFileBase64').get('base64').setValue(reader.result);
				this.bulkAwardingForm.get('zipUrlFileBase64').get('fileName').setValue('awardingprocesszip.zip');
			};
		});
	}

	initForm(): void {
		const isCreate = this.formType === BulkAwardingProcessFormTypes.Create ? true : false;
		this.bulkAwardingForm = this.fb.group({
			id: [isCreate ? '' : this.activeRow.id, Validators.required],
			cohortId: [isCreate ? '' : this.activeRow.cohortId, Validators.required],
			title: [isCreate ? '' : this.activeRow.title],
			badgeTemplate_Id: [isCreate ? '' : this.activeRow.badgeTemplate_Id, Validators.required],
			badgeTemplate_externalId: ['', Validators.required],
			badgeLevelId: ['', Validators.required],
			completionDate: [isCreate ? '' : new Date(this.activeRow.completionDate), Validators.required],
			accept: [isCreate ? false : true, Validators.requiredTrue],
			status: [isCreate ? 'Submitted' : this.activeRow.status, Validators.required],
			approverLabel: ['', Validators.required],
			approver_Id: [isCreate ? '' : this.activeRow.approver_Id, Validators.required]
		});
		const csvUrlFileBase64 = this.fb.group({
			fileName: ['', Validators.required],
			base64: ['', Validators.required]
		});
		const zipUrlFileBase64 = this.fb.group({
			fileName: ['', Validators.required],
			base64: ['', Validators.required]
		});
		this.bulkAwardingForm.addControl('csvUrlFileBase64', csvUrlFileBase64);
		this.bulkAwardingForm.addControl('zipUrlFileBase64', zipUrlFileBase64);
		this.files = [];
		this.filesZip = [];
	}

	valueChanged(value: string) {
		const [selectedBadgeTemplate] = this.badgeTemplates.filter((badgeTemplate) => badgeTemplate.id === value);
		this.bulkAwardingForm.get('badgeLevelId').setValue(selectedBadgeTemplate?.level);
		this.bulkAwardingForm.get('badgeTemplate_Id').setValue(selectedBadgeTemplate?.id);
		this.bulkAwardingForm.get('badgeTemplate_externalId').setValue(selectedBadgeTemplate?.externalId);
	}

	getExtension(name: string) {
		let splitName: any = name.split('.');
		return splitName[1];
	}

	onActionClickPopover(row: Action) {
		// this performs the action from popover according to the clicked option
		const { label, modal } = row;

		switch (label) {
			case 'Edit':
				this.openBulkAwardingForm(BulkAwardingProcessFormTypes.Edit);
				break;
			case 'CSV':
				this.downloadFile(this.activeRow.csvUrlFile);
				break;
			case 'Zip':
				this.downloadFile(this.activeRow.zipUrlFile);
				break;
			case 'Approve':
				if (modal) {
					this.modal.open(ModalComponent, { modal });
				}
				break;
		}
		this.actionStickerDir.hide();
	}

	setAction(template: StickerDirective, row: BulkAwarding) {
		// This builds the popover actions with the proper status
		const disableEditAction = !(
			(this.role === RoleType.BusinessRep &&
				(row.status === BulkAwardingProcessStatuses.Submitted ||
					row.status === BulkAwardingProcessStatuses.AttentionRequired)) ||
			(this.role === RoleType.Admin && row.status === BulkAwardingProcessStatuses.Submitted)
		);
		const disableDownloadAction = !(
			(this.role === RoleType.BusinessRep &&
				(row.status === BulkAwardingProcessStatuses.Submitted ||
					row.status === BulkAwardingProcessStatuses.AttentionRequired ||
					row.status === BulkAwardingProcessStatuses.Approved)) ||
			(this.role === RoleType.Admin &&
				(row.status === BulkAwardingProcessStatuses.Submitted ||
					row.status === BulkAwardingProcessStatuses.Approved))
		);
		this.activeRow = row;
		this.editAction.disabled = disableEditAction;
		this.downloadCsvAction.disabled =
			disableDownloadAction || this.downloadedFileIds.some((blobFileId) => blobFileId === row.csvUrlFile);
		this.downloadZipAction.disabled =
			disableDownloadAction || this.downloadedFileIds.some((blobFileId) => blobFileId === row.zipUrlFile);
		this.approveAction.disabled = row.status !== BulkAwardingProcessStatuses.Submitted;
		this.actionsList = [this.editAction, this.downloadCsvAction, this.downloadZipAction];
		if (this.role === RoleType.Admin) {
			this.actionsList.push(this.approveAction);
		}
	}

	confirmationAttentionRequired() {
		let modal: ModalValues = {
			title: 'Attention required',
			hasFooter: true,
			contentTitle: '',
			contentText: [
				`You are going to give some feedback to the Business Rep., so they can fix and update all the information correctly.<br>
				Please be very specific on each stage of the form, so they can update it correctly:`
			],
			aceptButtonText: 'Send Feedback',
			cancelButtonText: 'Cancel',
			actionForAceptButton: this.sendFeedbackAwardingProcess.bind(this),
			actionForCancelButton: () => {}
		};

		this.modal.open(ModalComponent, {
			showFeedback: true,
			modal
		});

		const getElement = this.renderer.selectRootElement('app-modal > .dds-modal > .dds-modal__body', true);
		this.renderer.addClass(getElement, 'dds-modal-space__body');
	}

	showFeedbackAttentionRequired(feedback: string) {
		let modal: ModalValues = {
			title: 'Attention required',
			hasFooter: true,
			contentTitle: 'Feedback',
			contentText: [feedback],
			aceptButtonText: "Let's start!",
			cancelButtonText: 'Cancel',
			alignLeft: true,
			actionForAceptButton: () => {
				this.modal.close();
			},
			actionForCancelButton: () => {}
		};

		this.modal.open(ModalComponent, {
			showFeedback: false,
			defaultValueFeedback: feedback,
			modal
		});

		const getElement = this.renderer.selectRootElement('app-modal > .dds-modal > .dds-modal__body', true);
		this.renderer.addClass(getElement, 'dds-modal-space__body');
	}

	sendFeedbackAwardingProcess() {
		let feedback: any = document.querySelector('textarea');
		let dataUpdate: any = {
			id: this.activeRow.id,
			status: BulkAwardingProcessStatuses.AttentionRequired,
			lastFeedback: feedback.value
		};
		this.bulkAwardingApiService.updateStatus(dataUpdate).subscribe({
			next: (data: any) => {
				this.optionsToast.title = 'Cohort ID sent for Attention Required';
				this.optionsToast.message = `The #${this.activeRow.cohortId} Cohort ID has been sent it back with Attention Required status.`;
				this.optionsToast.customClass = 'submitted-bulk';
				this.toastService.createToast(this.optionsToast);
				this.awardinProcessGridRef.isNewStatus = true;
				this.awardinProcessGridRef.cohortId = this.activeRow.cohortId;
				this.awardinProcessGridRef.getInformationToFillTable();
			},
			error: (err) => console.error(err)
		});
		this.modal.close();
		this.modal.close();
	}

	confirmationDeleteBulkAwarding() {
		const modal: ModalValues = {
			title: 'Are you sure you want to delete this request?',
			hasFooter: true,
			contentTitle: ``,
			contentText: [`A bulk award request should only be deleted if it was initiated in error.`],
			aceptButtonText: 'Yes, delete',
			cancelButtonText: 'Cancel',
			actionForAceptButton: this.deleteBulkAwarding.bind(this)
		};
		this.modal.open(ModalComponent, { modal });
	}

	deleteBulkAwarding() {
		this.modal.close();
		this.modal.close();
		this.bulkAwardingApiService.deleteForAdmin(this.activeRow.id).subscribe({
			next: () => {
				// TODO: Change the message
				this.optionsToast.title = `Cohort ID deleted`;
				this.optionsToast.message = `The #${this.activeRow.cohortId} Cohort ID has been deleted.`;
				this.toastService.createToast(this.optionsToast);
				this.awardinProcessGridRef.getInformationToFillTable();
			},
			error: (err) => console.error(err)
		});
	}

	submitBulkAwarding() {
		this.modal.close();
		this.btnOptionsSubmit.isLoading = true;
		if (this.bulkAwardingForm.value.status === BulkAwardingProcessStatuses.AttentionRequired) {
			this.bulkAwardingForm.value.status = BulkAwardingProcessStatuses.Submitted;
		}
		this.bulkAwardingApiService.updateForAdmin(this.bulkAwardingForm.value).subscribe({
			next: (response) => {
				// TODO: Change the message
				this.optionsToast.title = `Cohort ID submitted`;
				this.optionsToast.message = `The #${response.cohortId} Cohort ID has been submitted for review and being approved.`;
				this.toastService.createToast(this.optionsToast);
				this.awardinProcessGridRef.getInformationToFillTable();
				this.btnOptionsSubmit.isLoading = false;
				this.modal.close();
			},
			error: (err) => (this.btnOptionsSubmit.isLoading = false)
		});
	}

	confirmationSubmitBulkAwarding() {
		const modal: ModalValues = {
			title: 'Are you sure you want to submit this request for bulk awarding a badge?',
			hasFooter: true,
			contentTitle: ``,
			contentText: [`Please ensure that the information provided is complete and accurate.`],
			aceptButtonText: 'Yes, submit',
			cancelButtonText: 'Cancel',
			actionForAceptButton: this.submitBulkAwarding.bind(this)
		};
		this.modal.open(ModalComponent, { modal });
		const getElement = this.renderer.selectRootElement('app-modal > .dds-modal > .dds-modal__header', true);
		this.renderer.setStyle(getElement, 'text-align', 'center');
	}

	createAndApproveBulkAwarding() {
		this.modal.close();
		this.bulkAwardingApiService.updateForAdmin(this.bulkAwardingForm.value).subscribe({
			next: (response) => {
				// TODO: Change the message
				this.optionsToast.title = `Cohort ID Created and Approved`;
				this.optionsToast.message = `The #${response.cohortId} Cohort ID has been created and submitted.`;
				this.toastService.createToast(this.optionsToast);
				this.awardinProcessGridRef.getInformationToFillTable();
			},
			error: (err) => console.error(err)
		});
	}

	approveBulkAwarding() {
		this.modal.close();
		this.bulkAwardingApiService
			.updateStatus({ id: this.activeRow.id, status: BulkAwardingProcessStatuses.Approved })
			.subscribe({
				next: (resp) => {
					this.optionsToast.title = `Cohort ID approved`;
					this.optionsToast.message = `The #${this.activeRow.cohortId} Cohort ID has been approved successfully.`;
					this.toastService.createToast(this.optionsToast);
					this.awardinProcessGridRef.isNewStatus = true;
					this.awardinProcessGridRef.cohortId = this.activeRow.cohortId;
					this.awardinProcessGridRef.getInformationToFillTable();
				},
				error: (err) => console.error(err)
			});
	}

	editAction: Action = {
		label: 'Edit',
		disabled: false,
		icon: 'dds-icon_edit'
	};

	downloadCsvAction: Action = {
		label: 'CSV',
		disabled: false,
		icon: 'dds-icon_download'
	};

	downloadZipAction: Action = {
		label: 'Zip',
		disabled: false,
		icon: 'dds-icon_download'
	};

	approveAction: Action = {
		label: 'Approve',
		disabled: false,
		icon: 'dds-icon_check',
		modal: {
			title: 'Are you sure you want to approve this request?',
			hasFooter: true,
			contentTitle: ``,
			contentText: [`Approving indicates that you have awarded this badge in Credly.`],
			aceptButtonText: 'Yes, approve',
			cancelButtonText: 'Cancel',
			actionForAceptButton: this.approveBulkAwarding.bind(this)
		}
	};

	actionsList: Action[] = [];

	downloadFile(blobFileId: string) {
		this.downloadedFileIds.push(blobFileId);
		this.blobFileApiService.downloadById(blobFileId).subscribe({
			next: (blob) => {
				let dataType = blob.type;
				let binaryData = [];
				binaryData.push(blob);
				let downloadLink = document.createElement('a');
				downloadLink.href = window.URL.createObjectURL(new Blob(binaryData, { type: dataType }));
				downloadLink.setAttribute('download', blobFileId);
				document.body.appendChild(downloadLink);
				downloadLink.click();
			},
			error: (err) => console.error(err) // TODO: how to handle errors
		});
	}

	centeredTitleModal(): void {
		const getElement = this.renderer.selectRootElement('.dds-modal__header', true);
		this.renderer.addClass(getElement, 'dds-modal-center__header');
	}

	sizeSelectBadgeName(): void {
		const getElement = this.renderer.selectRootElement('dds-sticker > dds-context-menu > .dds-context-menu', true);
		this.renderer.setStyle(getElement, 'max-height', 'calc(300px)');
	}
}
