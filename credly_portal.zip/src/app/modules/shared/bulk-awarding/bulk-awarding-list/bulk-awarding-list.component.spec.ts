import { ComponentFixture, TestBed } from '@angular/core/testing';

import { BulkAwardingListComponent } from './bulk-awarding-list.component';

xdescribe('BulkAwardingListComponent', () => {
  let component: BulkAwardingListComponent;
  let fixture: ComponentFixture<BulkAwardingListComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ BulkAwardingListComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(BulkAwardingListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
