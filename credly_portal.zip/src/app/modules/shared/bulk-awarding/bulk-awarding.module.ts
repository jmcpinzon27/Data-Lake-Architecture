import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SharedModule } from '@/shared/shared.module';
import { UploaderModule } from '@usitsdasdesign/dds-ng/uploader';
import { CheckboxModule } from '@usitsdasdesign/dds-ng/checkbox';

import { BulkAwardingRoutingModule } from './bulk-awarding-routing.module';
import { BulkAwardingListComponent } from './bulk-awarding-list/bulk-awarding-list.component';
import { ReactiveFormsModule } from '@angular/forms';
import { NgxDropzoneModule } from 'ngx-dropzone';
import { TagsModule } from '@usitsdasdesign/dds-ng/tags';
import { ToastModule } from '@usitsdasdesign/dds-ng/toast';

@NgModule({
	declarations: [BulkAwardingListComponent],
	imports: [
		CommonModule,
		ReactiveFormsModule,
		BulkAwardingRoutingModule,
		SharedModule,
		UploaderModule,
		CheckboxModule,
		NgxDropzoneModule,
		TagsModule,
		ToastModule
	]
})
export class BulkAwardingModule {}
