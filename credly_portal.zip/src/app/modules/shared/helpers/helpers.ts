import {
	BadgeTemplateStatus,
	CriteriaType,
	EducationCriteria,
	EminenceCriteria,
	Employee,
	ExperienceCriteria
} from '@/core/model/entities';
import { Action } from '@/core/model/common/actions';
import { BadgeTemplateQuery } from '@/core/model/entities';
import { ListResponse } from '@/core/model/common';
import { EmployeeApiService } from '@/core/services/apis';
import { AbstractControl, FormGroup, Validators } from '@angular/forms';
import { distinctUntilChanged, filter, debounceTime, switchMap, Subscription, tap } from 'rxjs';

export const showExternalUrl = (url: string) => {
	const httpPrefix = 'https://';
	const hassHttpPrefix = url.includes('https://');
	window.open(`${hassHttpPrefix ? '' : httpPrefix}${url}`, '_blank');
};

/**
 * isStickerClosed is used to validate if the sticker is open or closed
 * if the sticker with actions is open the length is greater than 0 and shouldnt redirect.
 * @param name - stickerCustomClass of the button in the ng-template #editCell on each tab
 * @param status - statys
 * @return boolean depending
 */
export const validateStickerOpenOrClosed = (name: string, status: BadgeTemplateStatus | string) => {
	const isStickerClosed = document.getElementsByClassName(name).length === 0;
	return isStickerClosed && status === BadgeTemplateStatus.Accepted;
};

/**
 * This method is used to set if the actions menu is
 * going to show a 'make public' or make 'private action'
 * @param listOfActionsToModify - the list of actions to validate
 * @param workedRow - information about the badge template in the row selected
 */
export const setActionPrivateOrPublic = (listOfActionsToModify: Action[], workedRow: BadgeTemplateQuery) => {
	const publicText = 'Make Public';
	const privateText = 'Make Private';
	listOfActionsToModify = listOfActionsToModify.map((action) => {
		if (!workedRow?.isPublic && action.label === privateText) {
			action.label = publicText;
		}
		if (workedRow?.isPublic && action.label === publicText) {
			action.label = privateText;
		}
		return action;
	});
};

/**
 * @param formToObserv Control who has the validatorEmail control to be observed
 * @param service The service wich contains the users to be selected as validators
 * @returns Subscription to be pushed in a Subscription array to unsubscribe in ngondestroy
 */
export const validatorEmailObserver = (formToObserv: FormGroup, service: EmployeeApiService): Subscription => {
	const emailChange$ = formToObserv
		.get('validatorEmail')
		.valueChanges.pipe(
			distinctUntilChanged(),
			tap((text: string) => {
				if (text?.length < 4) {
					formToObserv.patchValue({ emailList: [] });
					formToObserv.patchValue({ showEmailList: false });
				}
			}),
			filter((text: string) => (text && text.length >= 4 && !text.includes('@') ? true : false)),
			debounceTime(500),
			switchMap((text) => service.get({ Searchtext: text }))
		)
		.subscribe(({ data }: ListResponse<Employee>) => {
			formToObserv.patchValue({ emailList: data });
			formToObserv.patchValue({ showEmailList: true });
		});
	return emailChange$;
};

/**
 *
 * @param criteria - criteria from the badge as response from the API. Should be Education, Expererience or Eminence
 * @param path - alternate or standard | standard is the default
 * @returns an array with the criterias filtered by the path assigned in 'path' param
 */
export const filterCriteriaByPath = (
	criteria: any[],
	path: 'standard' | 'alternate' = 'standard'
): EducationCriteria[] | ExperienceCriteria[] | EminenceCriteria[] => {
	return path === 'standard'
		? criteria.filter((item: any) => (!item.isAlternative ? item : null))
		: criteria.filter((item: any) => (item.isAlternative ? item : null));
};

export const validateWbsCode = (control: FormGroup | AbstractControl, isWbs: boolean) => {
	const uploadBase64 = control.get('uploadBase64') as FormGroup;
	const wbsCodeGroup = control.get('wbsCodeGroup') as FormGroup;
	const fileName = control.get('fileName');
	const upload = control.get('upload');
	if (isWbs) {
		isWbsCase(uploadBase64, wbsCodeGroup);
		fileName.clearValidators();
		fileName.removeValidators(Validators.required);
		fileName.reset();
		upload.reset();
	} else {
		fileName.addValidators(Validators.required);
		notWbsCase(uploadBase64, wbsCodeGroup);
	}
	fileName.updateValueAndValidity();
};

const isWbsCase = (uploadBase64: FormGroup, wbsCodeGroup: FormGroup) => {
	uploadBase64.reset();
	uploadBase64.get('base64').clearValidators();
	uploadBase64.get('fileHours').clearValidators();
	uploadBase64.disable();
	wbsCodeGroup.enable();
	wbsCodeGroup.get('code').addValidators(Validators.required);
	wbsCodeGroup.get('hours').setValidators([Validators.required, Validators.max(999999)]);
	wbsCodeGroup.get('code').updateValueAndValidity();
	wbsCodeGroup.get('hours').updateValueAndValidity();
};

const notWbsCase = (uploadBase64: FormGroup, wbsCodeGroup: FormGroup) => {
	wbsCodeGroup.reset();
	wbsCodeGroup.get('code').clearValidators();
	wbsCodeGroup.get('hours').clearValidators();
	wbsCodeGroup.disable();
	uploadBase64.enable();
	uploadBase64.get('fileHours').setValidators([Validators.required, Validators.max(999999)]);
	uploadBase64.get('fileHours').updateValueAndValidity();
};
