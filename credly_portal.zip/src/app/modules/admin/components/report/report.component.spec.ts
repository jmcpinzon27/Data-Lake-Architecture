import { ComponentFixture, TestBed } from '@angular/core/testing';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { ReportComponent } from './report.component';
import { of } from 'rxjs';
import { ReportApiService } from '@/core/services/apis';
import { BadgesByPeriod } from '@/core/model/entities';

describe('ReportComponent', () => {
  let component: ReportComponent;
  let fixture: ComponentFixture<ReportComponent>;
  let reportApiService : ReportApiService;
  let response : BadgesByPeriod[] = [{
    period : 'Month',
    badgesCount : 1
  }];

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ReportComponent ],
      imports : [ HttpClientTestingModule ],
      providers : [ ReportApiService ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ReportComponent);
    component = fixture.componentInstance;
    reportApiService= TestBed.inject(ReportApiService);
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('the services should return data', () => {
    spyOn(reportApiService, 'getBadgesByPeriod').and.returnValue(of(response));
    component.ngOnInit();
    fixture.detectChanges();
  
    expect(component.reportApiService).toBeTruthy();
  });

});
