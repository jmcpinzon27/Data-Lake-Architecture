import moment from 'moment';
import { Component, Input, OnInit } from '@angular/core';
import { SelectItemOptions, SelectOptions } from '@usitsdasdesign/dds-ng/select';
import { ErrorState, LabelPosition, Size } from '@usitsdasdesign/dds-ng/shared';
import * as Highcharts from 'highcharts';
import { BadgesByPeriod } from '@/core/model/entities';
import { ReportApiService } from '@/core/services/apis';

@Component({
	selector: 'app-report',
	templateUrl: './report.component.html',
	styleUrls: ['./report.component.scss']
})
export class ReportComponent implements OnInit {
	@Input()
	dataChart: any = [{ name: 1, data: [0] }];

	constructor(public reportApiService: ReportApiService) {}

	ngOnInit(): void {
		this.changeFrequency(2);
	}

	changeFrequency(period: any) {
		this.reportApiService.getBadgesByPeriod(parseInt(period)).subscribe((data: Array<BadgesByPeriod>) => {
			let quarter: number = 1;
			let week: number = 1;

			const categories = data.map((e) =>
				period == 3
					? quarter++ + 'qt'
					: period == 1
					? moment(e.period).format('MMM') + '- Week ' + week++
					: moment(e.period).format('MMM')
			);

			const series = [{ name: '', data: data.map((e) => e.badgesCount) }];

			this.updateChartFrequency(categories, series);
		});
	}

	selectOptions: SelectOptions = {
		label: '',
		labelPosition: LabelPosition.internal,
		description: '',
		placeholder: 'Select frequency',
		size: Size.md,
		isDisabled: false,
		isResponsive: false,
		isRequired: false,
		isError: false,
		errorMessage: '',
		errorState: ErrorState.default,
		customClass: '',
		stickerWidth: 0,
		stickerShift: 0,
		stickerMaxHeight: '',
		stickerIsDisabled: false,
		stickerPosition: 'bottom-left',
		stickerIndent: 0,
		stickerCustomClass: ''
	};

	selectItems: SelectItemOptions[] = [
		{
			heading: 'Weekly',
			value: 1
		},
		{
			heading: 'Monthly',
			value: 2
		},
		{
			heading: 'Quarter',
			value: 3
		}
	];

	selectedItem: string = 'Monthly';

	updateChartFrequency(categories: Array<string>, series: Array<{ name: string; data: Array<number> }>) {

        const maxNum : number =  Math.max(...series[0].data);
		// @ts-ignore
		Highcharts.chart('container-chart', {
			chart: {
				type: 'line'
			},
			title: {
				text: ''
			},
			subtitle: {
				text: ''
			},
			xAxis: {
				title: {
					text: ''
				},
				categories: categories
			},
			yAxis: {
				title: {
					text: ''
				},
                tickInterval : maxNum > 2 ? null : 1,
                min : 0,
                max : maxNum
			},
			plotOptions: {
				spline: {
					dataLabels: {
						enabled: false
					},
					marker: {
						enabled: false
					}
				}
			},
			series: series
		});
	}
}
