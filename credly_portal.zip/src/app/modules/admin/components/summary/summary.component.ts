import { AdminSummaryReport } from '@/core/model/entities';
import { Component, Input } from '@angular/core';
import { Router } from '@angular/router';

@Component({
	selector: 'app-summary',
	templateUrl: './summary.component.html',
	styleUrls: ['./summary.component.scss']
})
export class SummaryComponent {
	@Input()
	dataSummary: AdminSummaryReport;

	constructor(private router: Router) {}


	goToBadges() {
		this.router.navigate(['/badges']);
	}

	goToBadgeTemplates() {
		this.router.navigate(['/badges/admin/templates']);
	}

	goToNotifications() {
		this.router.navigate(['/notifications']);
	}
}
