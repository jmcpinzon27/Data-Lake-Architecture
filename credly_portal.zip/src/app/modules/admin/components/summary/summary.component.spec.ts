import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SummaryComponent } from './summary.component';
import { Router } from '@angular/router';
import { RouterTestingModule } from '@angular/router/testing';

describe('SummaryComponent', () => {
  let component: SummaryComponent;
  let fixture: ComponentFixture<SummaryComponent>;
  let router: Router;
  
  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SummaryComponent ],
      imports : [RouterTestingModule]
    })
    .compileComponents();

    router = TestBed.inject(Router);
    fixture = TestBed.createComponent(SummaryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should navigate to badges', () => {
      spyOn(router, 'navigate');
      component.goToBadges();

      expect(router.navigate).toHaveBeenCalledWith(['/badges'])
  });

  it('should navigate to templates', () => {
    spyOn(router, 'navigate');
    component.goToBadgeTemplates();

    expect(router.navigate).toHaveBeenCalledWith(['/badges/admin/templates'])
  });

  it('should navigate to notifications', () => {
    spyOn(router, 'navigate');
    component.goToNotifications();

    expect(router.navigate).toHaveBeenCalledWith(['/notifications'])
  });

});
