import { DataGridColumn } from '@/shared/components/data-grid/model';
import { ButtonOptions } from '@usitsdasdesign/dds-ng/button';
import { MultiSelectItem } from '@usitsdasdesign/dds-ng/multi-select';
import {
	Themes,
	ButtonKind,
	Size,
	WidthState,
	TabThemeType,
	LabelPosition,
	ErrorState
} from '@usitsdasdesign/dds-ng/shared';
import { TabsOptions } from '@usitsdasdesign/dds-ng/tabs';
import { Action } from '@/core/model/common/actions';
import { SelectItemOptions, SelectOptions } from '@usitsdasdesign/dds-ng/select';
import { ListRequest } from '@/core/model/common';
import { ToastOptions } from '@usitsdasdesign/dds-ng/toast';
import { RoleManagementComponent } from './role-management.component';

export const addButtonOptions: ButtonOptions = {
	theme: Themes.dark,
	kind: ButtonKind.primaryLoud,
	size: Size.lg,
	width: WidthState.full,
	isLoading: false,
	isInverse: false,
	isDisabled: false,
	ariaLabel: 'Add new user button',
	role: 'button'
};

export const cancelButtonOptions: ButtonOptions = {
	theme: Themes.white,
	kind: ButtonKind.primaryLoud,
	size: Size.md,
	width: WidthState.full,
	isLoading: false,
	isInverse: false,
	isDisabled: false,
	ariaLabel: 'Close modal button',
	role: 'button'
};

export const formSaveButtonOptions: ButtonOptions = {
	theme: Themes.dark,
	kind: ButtonKind.primaryLoud,
	size: Size.md,
	width: WidthState.full,
	isLoading: false,
	isInverse: false,
	isDisabled: false,
	ariaLabel: 'Save changes button',
	role: 'button'
};

export const tabContainerOptions: TabsOptions = {
	theme: Themes.dark,
	themeType: TabThemeType.border,
	size: Size.md,
	ariaLabel: 'Horizontal tabs',
	isDisabled: false,
	customClass: 'repor-badge-templates',
	isResponsive: false
};

export const tabs = {
	tab1: 'Business Representative',
	tab2: 'Administrators'
};

export const businessRepColumns: DataGridColumn[] = [
	{
		label: 'Business Rep Name',
		fieldValue: 'name',
		cellTemplateName: '',
		allowOrderBy: true,
		allowFilterText: false,
		allowFilterFixedValues: false,
		selected: false,
		dataType: 'string'
	},
	{
		label: 'E-mail account',
		fieldValue: 'email',
		cellTemplateName: '',
		allowOrderBy: true,
		allowFilterText: false,
		allowFilterFixedValues: false,
		selected: false,
		dataType: 'string'
	},
	{
		label: 'Start Date',
		fieldValue: 'startDate',
		cellTemplateName: 'dateCell',
		allowOrderBy: true,
		allowFilterText: false,
		allowFilterFixedValues: false,
		selected: false,
		dataType: 'string'
	},
	{
		label: 'Action',
		fieldValue: '',
		cellTemplateName: 'editCell',
		allowOrderBy: false,
		allowFilterText: false,
		allowFilterFixedValues: false,
		selected: false,
		dataType: 'string'
	}
];

export const administratorColumns: DataGridColumn[] = [
	{
		label: 'Administrator Name',
		fieldValue: 'name',
		cellTemplateName: '',
		allowOrderBy: true,
		allowFilterText: false,
		allowFilterFixedValues: false,
		selected: false,
		dataType: 'string'
	},
	{
		label: 'E-mail account',
		fieldValue: 'email',
		cellTemplateName: '',
		allowOrderBy: true,
		allowFilterText: false,
		allowFilterFixedValues: false,
		selected: false,
		dataType: 'string'
	},
	{
		label: 'Start Date',
		fieldValue: 'startDate',
		cellTemplateName: 'dateCell',
		allowOrderBy: true,
		allowFilterText: false,
		allowFilterFixedValues: false,
		selected: false,
		dataType: 'string'
	},
	{
		label: 'Actions',
		fieldValue: '',
		cellTemplateName: 'editCell',
		allowOrderBy: false,
		allowFilterText: false,
		allowFilterFixedValues: false,
		selected: false,
		dataType: 'string'
	}
];

export const possibleActions: Action[] = [
	{
		label: 'Edit',
		disabled: false,
		modal: {
			title: 'Edit Role',
			hasFooter: true,
			contentTitle: 'Are you sure you want to edit this user’s role?',
			contentText: [``],
			aceptButtonText: 'Yes, change',
			cancelButtonText: 'Cancel',
			actionForAceptButton: null,
			actionForCancelButton: null
		}
	},
	{
		label: 'Delete',
		disabled: false,
		modal: {
			title: 'Delete User',
			hasFooter: true,
			contentTitle: 'Are you sure you want to delete this user?',
			contentText: [
				`Once deleted, you won’t be able to undo this action.`,
				`If you decide you want to add the user back as administrator or business representative, you will need to click "add new"`
			],
			aceptButtonText: 'Yes, delete',
			cancelButtonText: 'Cancel',
			actionForAceptButton: null,
			actionForCancelButton: null
		}
	}
];

export const selectOptionsForModal: SelectOptions = {
	labelPosition: LabelPosition.internal,
	placeholder: 'Select role',
	size: Size.md,
	isDisabled: false,
	isResponsive: false,
	isRequired: true,
	errorState: ErrorState.default,
	customClass: '',
	stickerWidth: 0,
	stickerShift: 0,
	stickerMaxHeight: '',
	stickerIsDisabled: false,
	stickerPosition: 'bottom-left',
	stickerIndent: 0,
	stickerCustomClass: ''
};

export const listRequest: ListRequest = {
	pageIndex: 1,
	pageSize: 10,
	filterColumns: [
		{
			column: '',
			value: '',
			freeText: false
		}
	],
	SearchText: '',
	orderBy: {
		column: '',
		desc: false
	}
};

export const toast: ToastOptions = {
	title: '',
	message: ``,
	lifeTime: 10000,
	position: 'bottom-left',
	closeBtnIcon: 'dds-icon_close',
	customClass: 'simple-toast',
	limit: 300,
	theme: Themes.white
};
