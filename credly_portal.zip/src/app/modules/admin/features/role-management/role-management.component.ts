import { Action } from '@/core/model/common/actions';
import { RoleManagementUser, RoleType, Session, UserInfo } from '@/core/model/entities';
import { EmployeeApiService, RoleManagmentService } from '@/core/services/apis';
import { DataGridComponent } from '@/shared/components/data-grid/data-grid.component';
import { Component, OnInit, TemplateRef, ViewChild, OnDestroy } from '@angular/core';
import { StickerDirective } from '@usitsdasdesign/dds-ng/sticker';
import { GenericModalComponent } from '@/shared/generic-modal/generic-modal.component';
import {
	addButtonOptions,
	administratorColumns,
	businessRepColumns,
	cancelButtonOptions,
	formSaveButtonOptions,
	possibleActions,
	selectOptionsForModal,
	tabContainerOptions,
	tabs,
	listRequest,
	toast
} from './initial-values';
import { ModalService } from '@usitsdasdesign/dds-ng/modal';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { debounceTime, filter, switchMap } from 'rxjs/operators';
import { ToastService } from '@usitsdasdesign/dds-ng/toast';
import { ModalComponent } from '@/shared/components/modal/modal.component';
import { HttpErrorResponse } from '@angular/common/http';
import { Router } from '@angular/router';
import { SessionStoreService } from '@/core/services/store';
import { BehaviorSubject } from 'rxjs';

@Component({
	selector: 'app-role-management',
	templateUrl: './role-management.component.html',
	styleUrls: ['./role-management.component.scss']
})
export class RoleManagementComponent implements OnInit, OnDestroy {
	// Used to reference the modal contentTemplate
	@ViewChild('contentTemplate', { read: TemplateRef }) contentTemplate: TemplateRef<any>;
	// Used to refresh the grid after change
	@ViewChild('tab2') businessRepGridRef!: DataGridComponent;
	@ViewChild('tab1') adminGridRef!: DataGridComponent;
	@ViewChild('tabAdmin') tabAdmin: any;

	// Initial/Static values
	readonly tabOptions = tabs;
	readonly businessTabColumns = businessRepColumns;
	readonly adminTabColumns = administratorColumns;
	readonly businessRepUsersFilter = { roles: 'businessRep' };
	readonly adminUsersFilter = { roles: 'admin' };
	readonly selectItems = this.service.availableRoles;
	readonly defaultImg = 'assets/images/newRole.svg';

	isActiveTab: boolean = false;

	brValues = this.selectItems[1];
	adminValues = this.selectItems[0];

	toast = toast;
	addButtonsOptions = addButtonOptions;
	cancelButtonOptions = cancelButtonOptions;
	formSaveButtonOptions = formSaveButtonOptions;
	tabContainer = tabContainerOptions;
	actionsList = possibleActions;
	selectOptions = selectOptionsForModal;
	request = listRequest;

	showUserOptionsList: boolean = false;
	userOptionsList: any[] = [];
	tabSelected: string = this.brValues.description;
	selectedItem: string;
	email: string;
	rowInformation: RoleManagementUser = {} as RoleManagementUser;
	actionStickerDir: StickerDirective;
	roleManagementForm: FormGroup;
	userSelectedInformation: UserInfo = {} as UserInfo;
	buttonName: string = 'Add new';
	editAction: boolean = false;
	hasError = {
		errorMessage: '',
		error: false
	};
	showTabA: boolean = true;
	showTabB: boolean = false;
	session?: Session = null;
	private session$: BehaviorSubject<Session | null> = new BehaviorSubject<Session>(null);
	brRoleId: string = '55e80e5c-b55b-4228-bdbe-e1646fb365a0';
	adminRoleId: string = '8d5f56e2-e11b-431f-951c-15a543a3d216';

	get getPersonFromForm() {
		return this.roleManagementForm.get('name');
	}
	get getRoleFromForm() {
		return this.roleManagementForm.get('roleId');
	}
	get getPersonId() {
		return this.roleManagementForm.get('employeeId');
	}
	get getPersonLength() {
		return this.getPersonFromForm.value?.length ?? '';
	}
	get formatedName() {
		const nameSplited = this.getPersonFromForm.value.split('/')[0].split(' ');
		const name = `${nameSplited[1]}, ${nameSplited[0]}`;
		return name;
	}

	constructor(
		public service: RoleManagmentService,
		private modal: ModalService,
		private fb: FormBuilder,
		private toastService: ToastService,
		private employeeService: EmployeeApiService,
		private sessionService: SessionStoreService,
		private router: Router
	) {}

	ngOnInit(): void {
		this.initForm();
		this.trackPersonText();
		this.sessionService.UserSession.subscribe((session) => {
			this.session = session;
		});
	}

	private initForm() {
		this.roleManagementForm = this.fb.group({
			name: ['', [Validators.required]],
			roleId: ['', [Validators.required]],
			employeeId: ['', [Validators.required]]
		});
	}

	private trackPersonText() {
		this.getPersonFromForm.valueChanges
			.pipe(
				filter((term) => term !== '' && term.length >= 4),
				debounceTime(500),
				switchMap((term) => {
					this.request.SearchText = term;
					return this.employeeService.get(this.request);
				})
			)
			.subscribe((response: any) => {
				this.userOptionsList = response.data;
				if (response.data.length > 0) {
					this.showUserOptionsList = true;
				}
			});
	}

	addNewUser() {
		this.clearValues();
		this.buttonName = 'Add new';
		this.editAction = false;
		this.modal.open(GenericModalComponent, {
			size: 'lg',
			contentTemplate: this.contentTemplate
		});
	}

	setAction(actionStickerDir: StickerDirective, row: RoleManagementUser) {
		this.rowInformation = row;
		this.actionStickerDir = actionStickerDir;
	}

	onEditClick({ label }: Action) {
		const labelEdit = this.actionsList[0].label;
		this.actionsList[1].modal.title = `Delete User`;
		this.actionsList[1].modal.contentTitle = `Are you sure you want to delete this user?`;
		label === labelEdit ? this.edit() : this.deleteModal();
		this.actionStickerDir.hide();
	}

	roleSelected(role: string) {
		this.getRoleFromForm.patchValue(role);
		this.userSelectedInformation.role =
			this.adminValues.id === role ? this.adminValues.description : this.brValues.description;
	}

	private edit() {
		this.fillValuesToEdit();
		this.modal.open(GenericModalComponent, {
			size: 'lg',
			contentTemplate: this.contentTemplate
		});
	}

	private fillValuesToEdit() {
		this.buttonName = 'Save changes';
		this.editAction = true;
		this.roleManagementForm.patchValue(this.rowInformation);
		this.getPersonFromForm.disable();
		this.userSelectedInformation.name = this.rowInformation.name;
		this.userSelectedInformation.email = this.rowInformation.email;
		if (this.rowInformation.roleId === this.adminValues.id) {
			this.userSelectedInformation.role = this.adminValues.description;
			this.userSelectedInformation.roleId = this.adminValues.id;
			this.selectedItem = this.adminValues.id;
		} else {
			this.userSelectedInformation.role = this.brValues.description;
			this.userSelectedInformation.roleId = this.brValues.id;
			this.selectedItem = this.brValues.id;
		}
	}

	saveButtonAction() {
		this.editAction ? this.confirmationEditModal() : this.save();
	}

	private confirmationEditModal() {
		this.modal.close();
		const { modal } = this.actionsList[0]; // Edit action
		modal.actionForAceptButton = this.save.bind(this);
		modal.actionForCancelButton = this.close.bind(this);
		this.modal.open(ModalComponent, { modal });
	}

	private save() {
		this.service.roleAssignament(this.getPersonId.value, this.getRoleFromForm.value, this.editAction).subscribe(
			(resp) => {
				this.isActiveTab = true;
				this.showToast(this.editAction ? 'changed' : 'added');
				this.refreshGrid();
				this.close();
			},
			({ status, error }: HttpErrorResponse) => {
				this.hasError.error = true;
				const { messages } = error.result;
				if (status === 400) {
					this.hasError.errorMessage = messages[0];
				}
			}
		);
	}

	newRegBusRep: any;
	newRegAdmin: any;
	newRegistry: any;

	private updateNewRegistry(tabSelected: string) {
		this.newRegistry = {
			employeeId: this.getPersonId.value,
			name: this.userSelectedInformation.name,
			email: this.userSelectedInformation.email,
			roleId: this.getRoleFromForm.value,
			startDate: new Date()
		};

		if (this.tabSelected == 'Administrator') {
			this.newRegAdmin = this.newRegistry;
			this.newRegBusRep = null;
		} else {
			this.newRegBusRep = this.newRegistry;
			this.newRegAdmin = null;
		}
	}

	private refreshGrid() {
		this.tabSelected =
			this.userSelectedInformation.role === undefined || this.userSelectedInformation.role == ''
				? this.tabSelected
				: this.userSelectedInformation.role;
		let btnTabs: any = document.querySelectorAll('button.dds-tabs__header-item');

		this.updateNewRegistry(this.tabSelected);
		if (this.tabSelected == 'Administrator') {
			btnTabs[1].click();
			this.adminGridRef.getInformationToFillTable();
			this.businessRepGridRef.getInformationToFillTable();
		} else {
			btnTabs[0].click();
			this.businessRepGridRef.getInformationToFillTable();
			this.adminGridRef.getInformationToFillTable();
		}
		this.userSelectedInformation.role = '';
	}

	private deleteModal() {
		this.getPersonFromForm.setValue(this.rowInformation.name);
		this.userSelectedInformation.role;
		const deleteAction: Action = this.actionsList[1];
		deleteAction.modal.actionForAceptButton = this.delete.bind(this);
		deleteAction.modal.actionForCancelButton = this.close.bind(this);
		this.modal.open(ModalComponent, { modal: deleteAction.modal });
	}

	private delete() {
		const { employeeId, roleId } = this.rowInformation;
		this.service.deleteRole(employeeId, roleId).subscribe((resp) => {
			this.isActiveTab = false;
			this.showToast('deleted');
			this.refreshGrid();
			this.close();
		});
	}

	roleTemp: string = '';
	optionSelected(user: any) {
		this.getPersonFromForm.setValue(`${user.firstName} ${user.lastName} / ${user.email.toLowerCase()}`);
		this.getPersonId.setValue(user.personID);
		this.email = user.email;
		this.setInfoFromUserSelected(user);
		this.showUserOptionsList = false;
	}

	private setInfoFromUserSelected(user: any) {
		this.userSelectedInformation.name = `${user.firstName} ${user.lastName}`;
		this.userSelectedInformation.email = user.email.toLowerCase();
	}

	clearValues() {
		this.getPersonFromForm.enable();
		this.getPersonFromForm.setValue('');
		this.rowInformation = {} as RoleManagementUser;
		this.userSelectedInformation = {} as UserInfo;
		this.selectedItem = '';
		this.showUserOptionsList = false;
	}

	close() {
		this.clearValues();
		this.modal.closeAll();
	}

	private showToast(action: 'added' | 'deleted' | 'changed') {
		this.toast.customClass = 'submitted-bulk';
		if (action === 'added') {
			this.updateToast(action);
			this.toast.position = 'bottom-left';
		}
		if (action === 'deleted') {
			this.updateToast(action);
			this.toast.position = 'bottom-left';
		}
		if (action === 'changed') {
			this.updateToast(action);
			this.toast.position = 'bottom-left';
		}
		this.toastService.createToast(this.toast);
	}

	private updateToast(actionType: string) {
		let rolSelected: string = this.tabSelected == 'Administrators' ? 'Administrator' : this.tabSelected;
		rolSelected =
			this.userSelectedInformation.role === undefined || this.userSelectedInformation.role == ''
				? rolSelected
				: this.userSelectedInformation.role;
		const phrase =
			actionType === 'added' ? 'a new ' : actionType === 'changed' ? `successfully ${actionType} as a ` : 'a ';
		this.toast.title = `You have successfully changed the role management`;
		this.toast.message = `${this.formatedName} has been successfully ${
			actionType == 'deleted' ? 'removed' : actionType
		} as a${this.tabSelected == 'Business Representative' ? 'n' : ''} ${rolSelected}`;
	}

	ngOnDestroy(): void {
		this.service.newRegistry = null;
	}

	selectTab(indexTab: number): void {
		this.showTabA = indexTab == 0;
		this.showTabB = indexTab == 1;
	}
}
