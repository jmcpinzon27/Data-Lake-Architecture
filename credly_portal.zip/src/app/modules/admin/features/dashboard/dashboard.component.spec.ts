import { ComponentFixture, TestBed } from '@angular/core/testing';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { DashboardComponent } from './dashboard.component';
import { BreadCrumbService } from '@/core/services/store';
import { ToastService } from '@usitsdasdesign/dds-ng/toast';
import { AdminSummaryReport } from '@/core/model/entities';
import { ReportApiService } from '@/core/services/apis';
import { of } from 'rxjs';
describe('DashboardComponent', () => {
  let component: DashboardComponent;
  let fixture: ComponentFixture<DashboardComponent>;
  let breadCrumbService : BreadCrumbService;
  let reportApiService : ReportApiService;
  let data : AdminSummaryReport = {
      badgesApproved: 100,
      pendingBadges: 100,
      badgesTemplatesReviewed: 100,
      badgesTemplatesToReview: 100,
      unreadBadgeTemplateNotifications: 100,
      unreadBadgeNotifications: 100,
  };

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DashboardComponent ],
      imports : [ HttpClientTestingModule ],
      providers: [BreadCrumbService, ToastService, ReportApiService]
    })
    .compileComponents();

    fixture = TestBed.createComponent(DashboardComponent);
    component = fixture.componentInstance;
    breadCrumbService = TestBed.inject(BreadCrumbService);
    reportApiService =  TestBed.inject(ReportApiService);
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('the services should return data', () => {
    spyOn(reportApiService, 'getAdminSummary').and.returnValue(of(data));
    component.ngOnInit();
    fixture.detectChanges();
  
    expect(component.dataSummary).toEqual(data);
  });
});
