import { AdminSummaryReport } from '@/core/model/entities';
import { ReportApiService } from '@/core/services/apis/';
import { Component, OnInit, OnDestroy, ViewChild } from '@angular/core';
import { ButtonOptions } from '@usitsdasdesign/dds-ng/button';
import { ButtonKind, ErrorState, LabelPosition, Size, Themes, WidthState } from '@usitsdasdesign/dds-ng/shared';
import { ReportComponent } from '../../components/report/report.component';
import { MultiSelectItem } from '@usitsdasdesign/dds-ng/multi-select';
import { BreadCrumbService } from '@/core/services/store';

@Component({
	selector: 'app-dashboard',
	templateUrl: './dashboard.component.html',
	styleUrls: ['./dashboard.component.scss']
})
export class DashboardComponent implements OnInit, OnDestroy {
	constructor(public reportApiService: ReportApiService, private breadCrumbService: BreadCrumbService) {}

	dataSummary: AdminSummaryReport;

	@ViewChild('chartReport', { static: false }) chartReport: ReportComponent;

	ngOnInit(): void {
		this.breadCrumbService.setHideBreadcrumbs(true);
		this.reportApiService.getAdminSummary().subscribe((data: AdminSummaryReport) => {
			this.dataSummary = data;
			this.dataSummary.badgesApproved = parseInt(
				(
					(this.dataSummary.badgesApproved /
						(this.dataSummary.badgesApproved + this.dataSummary.pendingBadges)) *
					100
				).toString()
			);

			this.dataSummary.badgesTemplatesReviewed = parseInt(
				(
					(this.dataSummary.badgesTemplatesReviewed /
						(this.dataSummary.badgesTemplatesReviewed + this.dataSummary.badgesTemplatesToReview)) *
					100
				).toString()
			);
		});
	}

	ngOnDestroy(): void {
		this.breadCrumbService.setHideBreadcrumbs(false);
	}
}
