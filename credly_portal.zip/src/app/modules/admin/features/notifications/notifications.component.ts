import { Component, OnInit, OnDestroy } from '@angular/core';
import { TabComponent, TabsOptions, TabOptions } from '@usitsdasdesign/dds-ng/tabs';
import { Themes, Size, TabThemeType, ButtonKind, WidthState } from '@usitsdasdesign/dds-ng/shared';
import { DataGridColumn } from '@/shared/components/data-grid/model';
import { NotificationApiService } from '@/core/services/apis';
import { BadgeTemplateQuery } from '@/core/model/entities';
import { BreadCrumbService } from '@/core/services/store';
import { ButtonOptions } from '@usitsdasdesign/dds-ng/button';
@Component({
	selector: 'app-notifications',
	templateUrl: './notifications.component.html',
	styleUrls: ['./notifications.component.scss']
})
export class NotificationsComponent implements OnInit, OnDestroy {
	constructor(public service: NotificationApiService, private breadCrumbService: BreadCrumbService) {}

	showTabA: boolean = true;
	showTabB: boolean = false;
	showTabC: boolean = false;

	badgesSubmitted!: Array<DataGridColumn>;
	badgesTemplates!: Array<DataGridColumn>;
	bulkAwardingRequests!: Array<DataGridColumn>;
	row: BadgeTemplateQuery;

	options: ButtonOptions = {
		theme: Themes.dark,
		kind: ButtonKind.primaryLoud,
		size: Size.md,
		width: WidthState.fixed,
		isLoading: false,
		icon: '',
		isInverse: false,
		isDisabled: false,
		ariaLabel: 'Button',
		customClass: '',
		role: 'button'
	};

	ngOnInit(): void {
		this.badgesSubmitted = [
			{
				label: 'Title',
				fieldValue: 'title',
				cellTemplateName: '',
				allowOrderBy: true,
				allowFilterText: false,
				allowFilterFixedValues: false,
				selected: false,
				dataType: 'string'
			},
			{
				label: 'Type',
				fieldValue: 'status',
				cellTemplateName: '',
				allowOrderBy: true,
				allowFilterText: false,
				allowFilterFixedValues: false,
				selected: false,
				dataType: 'string'
			},
			{
				label: 'Description',
				fieldValue: 'description',
				cellTemplateName: '',
				allowOrderBy: true,
				allowFilterText: false,
				allowFilterFixedValues: false,
				selected: false,
				dataType: 'string'
			},
			{
				label: 'Date',
				fieldValue: 'date',
				cellTemplateName: 'dateCell',
				allowOrderBy: true,
				allowFilterText: false,
				allowFilterFixedValues: false,
				selected: false,
				dataType: 'string'
			}
		];
		this.badgesTemplates = [
			{
				label: 'Title',
				fieldValue: 'title',
				cellTemplateName: '',
				allowOrderBy: true,
				allowFilterText: false,
				allowFilterFixedValues: false,
				selected: false,
				dataType: 'string'
			},
			{
				label: 'Type',
				fieldValue: 'status',
				cellTemplateName: '',
				allowOrderBy: true,
				allowFilterText: false,
				allowFilterFixedValues: false,
				selected: false,
				dataType: 'string'
			},
			{
				label: 'Description',
				fieldValue: 'description',
				cellTemplateName: '',
				allowOrderBy: true,
				allowFilterText: false,
				allowFilterFixedValues: false,
				selected: false,
				dataType: 'string'
			},
			{
				label: 'Date',
				fieldValue: 'date',
				cellTemplateName: 'dateCell',
				allowOrderBy: true,
				allowFilterText: false,
				allowFilterFixedValues: false,
				selected: false,
				dataType: 'string'
			}
		];
		this.bulkAwardingRequests = [
			{
				label: 'Title',
				fieldValue: 'title',
				cellTemplateName: '',
				allowOrderBy: true,
				allowFilterText: false,
				allowFilterFixedValues: false,
				selected: false,
				dataType: 'string'
			},
			{
				label: 'Type',
				fieldValue: 'status',
				cellTemplateName: '',
				allowOrderBy: true,
				allowFilterText: false,
				allowFilterFixedValues: false,
				selected: false,
				dataType: 'string'
			},
			{
				label: 'Description',
				fieldValue: 'description',
				cellTemplateName: '',
				allowOrderBy: true,
				allowFilterText: false,
				allowFilterFixedValues: false,
				selected: false,
				dataType: 'string'
			},
			{
				label: 'Date',
				fieldValue: 'date',
				cellTemplateName: 'dateCell',
				allowOrderBy: true,
				allowFilterText: false,
				allowFilterFixedValues: false,
				selected: false,
				dataType: 'string'
			}
		];
	}

	selectTab(indexTab: number) {
		if (indexTab == 0) {
			this.showTabA = true;
			this.showTabB = false;
			this.showTabC = false;
		} else if (indexTab == 1) {
			this.showTabA = false;
			this.showTabB = true;
			this.showTabC = false;
		} else if (indexTab == 2) {
			this.showTabA = false;
			this.showTabB = false;
			this.showTabC = true;
		}
	}

	tabContainerOptions: TabsOptions = {
		theme: Themes.green,
		themeType: TabThemeType.border,
		size: Size.md,
		ariaLabel: 'Horizontal tabs',
		isDisabled: false,
		customClass: 'repor-badge-submitted',
		isResponsive: false
	};

	tabOptions1: TabOptions = {
		label: 'Badge Submissions'
	};
	tabOptions2: TabOptions = {
		label: 'Template Submissions'
	};
	tabOptions3: TabOptions = {
		label: 'Bulk Award Requests'
	};

	tabChanged(tabItem: TabComponent) {
		console.log(tabItem);
	}

	ngOnDestroy(): void {
		this.breadCrumbService.setHideBreadcrumbs(false);
	}
}
