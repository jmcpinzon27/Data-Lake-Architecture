import { Component, OnInit, OnDestroy, ViewChild } from '@angular/core';
import { Themes, Size } from '@usitsdasdesign/dds-ng/shared';
import { MultiSelectItem } from '@usitsdasdesign/dds-ng/multi-select';
import { DataGridColumn } from '@/shared/components/data-grid/model';
import { Collection } from '@/core/model/entities';
import { BreadCrumbService } from '@/core/services/store';
import { SessionStoreService } from '@/core/services/store';
import { Router } from '@angular/router';
import { StickerDirective } from '@usitsdasdesign/dds-ng/sticker';
import { ModalService } from '@usitsdasdesign/dds-ng/modal';
import { ModalComponent } from '@/shared/components/modal/modal.component';

import { Action } from '@/core/model/common/actions';
import CollectionApiService from '@/core/services/apis/collectionApiService';
import { ButtonOptions } from '@usitsdasdesign/dds-ng/button';
import { ToastOptions, ToastService } from '@usitsdasdesign/dds-ng/toast';
import { BaseTemplateCollectionApiService } from '@/core/services/apis';
import { DataGridComponent } from '@/shared/components/data-grid/data-grid.component';
import UserActivityApiService from '@/core/services/apis/userActivityApiService';
import { SelectItemOptions } from '@usitsdasdesign/dds-ng/select';

@Component({
	selector: 'app-user-activities',
	templateUrl: './user-activities.component.html',
	styleUrls: ['./user-activities.component.scss']
})
export class UserActivitiesComponent implements OnInit, OnDestroy {
	constructor(
		public service: CollectionApiService,
		public sessionService: SessionStoreService,
		private router: Router,
		private modal: ModalService,
		private breadCrumbService: BreadCrumbService,
		private toastService: ToastService,
		private collectionApiService: BaseTemplateCollectionApiService,
		public userActivityApiService: UserActivityApiService
	) {}

	@ViewChild('actionStickerDir') actionStickerDir: StickerDirective;
	@ViewChild('collectionList') collectionGridRef!: DataGridComponent;

	columns!: Array<DataGridColumn>;

	actionsList: Action[] = [] as Action[];
	row: Collection;

	optionsToast: ToastOptions = {
		title: 'You have create a new Collection',
		message: 'You have successfully created a new collection. You can edit it later.',
		lifeTime: 7000,
		position: 'bottom-left',
		closeBtnIcon: 'dds-icon_close',
		isCloseIcon: true,
		customClass: 'simple-toast',
		limit: 5,
		theme: Themes.white
	};

	optionsUserRole: SelectItemOptions[] = [
		{
			heading: 'Practitioners',
			value: 'Practitioner'
		},
		{
			heading: 'Business Representative',
			value: 'BusinessRep'
		},
		{
			heading: 'Administrators',
			value: 'Admin'
		}
	];

	optionsActivityType: SelectItemOptions[] = [
		{
			heading: 'Badge Template Created',
			value: 'BadgeTemplateCreated'
		},
		{
			heading: 'Badge Template Approve',
			value: 'BadgeTemplateApproved'
		},
		{
			heading: 'Badge Template Rejected',
			value: 'BadgeTemplateRejected'
		},
		{
			heading: 'Badge Template Updated',
			value: 'BadgeTemplateUpdated'
		},
		{
			heading: 'Badge Initiated',
			value: 'BadgeInitiated'
		},
		{
			heading: 'Badge Withdrawn',
			value: 'BadgeWithdrawn'
		},
		{
			heading: 'Badge Approved',
			value: 'BadgeApproved'
		},
		{
			heading: 'Badge Rejected',
			value: 'BadgeRejected'
		},
		{
			heading: 'Badge Attention Required',
			value: 'BadgeAttentionRequired'
		},
		{
			heading: 'Badge Criteria Approved',
			value: 'BadgeCriteriaApproved'
		},
		{
			heading: 'Badge Criteria Rejected',
			value: 'BadgeCriteriaRejected'
		},
		{
			heading: 'Badge Criteria Attention Required',
			value: 'BadgeCriteriaAttentionRequired'
		},
		{
			heading: 'Employee Updated',
			value: 'EmployeeRoleUpdated'
		},
		{
			heading: 'Employee Added',
			value: 'EmployeeRoleAdded'
		},
		{
			heading: 'Employee Deleted',
			value: 'EmployeeRoleDeleted'
		}
	];

	ngOnInit(): void {
		const params: any = new URL(location.href).searchParams;
		if (params.get('showNotification')) {
			this.toastService.createToast(this.optionsToast);
		}
		this.columns = [
			{
				label: 'Name',
				fieldValue: 'employee',
				customField: 'employee.lastName',
				cellTemplateName: 'employeeInfo',
				allowOrderBy: true,
				allowFilterText: false,
				allowFilterFixedValues: false,
				selected: false,
				dataType: 'string'
			},
			{
				label: 'User Role',
				fieldValue: 'employee',
				cellTemplateName: 'employeeRole',
				allowOrderBy: false,
				allowFilterText: false,
				allowFilterFixedValues: false,
				selected: false,
				dataType: 'string'
			},
			{
				label: 'Department',
				fieldValue: 'employee',
				customField: 'employee.businessAreaDesc',
				cellTemplateName: 'employeeDepartment',
				allowOrderBy: true,
				allowFilterText: false,
				allowFilterFixedValues: false,
				selected: false,
				dataType: 'string'
			},
			{
				label: 'Email',
				fieldValue: 'employee',
				customField: 'employee.email',
				cellTemplateName: 'employeeEmail',
				allowOrderBy: true,
				allowFilterText: false,
				allowFilterFixedValues: false,
				selected: false,
				dataType: 'string'
			},
			{
				label: 'Activity Type',
				fieldValue: 'type',
				cellTemplateName: 'employeeActivityType',
				allowOrderBy: true,
				allowFilterText: false,
				allowFilterFixedValues: false,
				selected: false,
				dataType: 'string'
			},
			{
				label: 'Date',
				fieldValue: 'date',
				cellTemplateName: 'dateCell',
				allowOrderBy: true,
				allowFilterText: false,
				allowFilterFixedValues: false,
				selected: false,
				dataType: 'string'
			}
		];
		/*
    {
				label: 'Actions',
				fieldValue: '',
				cellTemplateName: 'editCell',
				allowOrderBy: false,
				allowFilterText: false,
				allowFilterFixedValues: false,
				selected: false,
				dataType: 'string'
			}
      */
	}

	getActivyValue(type: string) {
		let activityType: any = this.optionsActivityType.filter((e: any) => {
			return e.value == type;
		});
		return activityType[0]?.heading;
	}

	options: ButtonOptions = {
		theme: Themes.dark,
		size: Size.md,
		isLoading: false,
		icon: '',
		isInverse: false,
		isDisabled: false,
		ariaLabel: 'Button',
		customClass: '',
		role: 'button'
	};

	myQueueActions: Action[] = [
		{
			label: 'Edit',
			disabled: false
		},
		{
			label: 'Delete',
			disabled: false,
			modal: {
				title: 'Delete Collection',
				hasFooter: true,
				contentTitle: 'Are you sure you want to delete this Collection?',
				contentText: [`Once deleted, you won't be able to return it.`],
				aceptButtonText: 'Yes, delete',
				cancelButtonText: 'Cancel',
				actionForAceptButton: () => {
					this.deleteCollection();
				},
				actionForCancelButton: () => {}
			}
		}
	];

	searchFilter(e: any) {
		let filter: string = '';
		let message: string = '';
		this.columnsIni();

		if (e.PersonID != '') {
			filter = filter + 'PersonID=' + e.PersonID + '&';
			this.columns = this.columns.filter((e: any) => {
				return e.label != 'Name';
			});
			message = e.UserName + ' / ';
		}

		if (e.BadgeTemplateId != '') {
			filter = filter + 'BadgeTemplateId=' + e.BadgeTemplateId + '&';
			message = message + e.BadgeName + ' / ';
		}

		if (e.role != '' && e.showRole) {
			filter = filter + 'Roles=' + e.role + '&';
			this.columns = this.columns.filter((e: any) => {
				return e.label != 'User Role';
			});
			message = message + e.role + ' / ';
		}
		if (e.role != '' && e.showRole && e.PersonID) {
			this.columns = this.columns.filter((e: any) => {
				return e.label != 'Department';
			});
		}

		if (e.type != '' && e.showActivity) {
			filter = filter + 'Type=' + e.type + '&';
			this.columns = this.columns.filter((e: any) => {
				return e.label != 'Activity Type';
			});
			message = message + e.type + ' / ';
		}

		if (e.from != '' && e.showPeriod) {
			filter = filter + 'From=' + e.from + '&';
			message = message + e.from + ' - ';
		}

		if (e.to != '' && e.showPeriod) {
			filter = filter + 'To=' + e.to + '&';
			message = message + e.to + '  ';
		}

		if (message != '') {
			message = ' for ' + message.substring(0, message.length - 2);
		}

		this.collectionGridRef.getByFilterColumns('getFilterUserActivity', filter, 1, message);
	}

	columnsIni() {
		this.columns = [
			{
				label: 'Name',
				fieldValue: 'employee',
				cellTemplateName: 'employeeInfo',
				allowOrderBy: true,
				allowFilterText: false,
				allowFilterFixedValues: false,
				selected: false,
				dataType: 'string'
			},
			{
				label: 'User Role',
				fieldValue: 'employee',
				cellTemplateName: 'employeeRole',
				allowOrderBy: true,
				allowFilterText: false,
				allowFilterFixedValues: false,
				selected: false,
				dataType: 'string'
			},
			{
				label: 'Department',
				fieldValue: 'employee',
				cellTemplateName: 'employeeDepartment',
				allowOrderBy: true,
				allowFilterText: false,
				allowFilterFixedValues: false,
				selected: false,
				dataType: 'string'
			},
			{
				label: 'Email',
				fieldValue: 'employee',
				cellTemplateName: 'employeeEmail',
				allowOrderBy: true,
				allowFilterText: false,
				allowFilterFixedValues: false,
				selected: false,
				dataType: 'string'
			},
			{
				label: 'Activity Type',
				fieldValue: 'type',
				cellTemplateName: '',
				allowOrderBy: true,
				allowFilterText: false,
				allowFilterFixedValues: false,
				selected: false,
				dataType: 'string'
			},
			{
				label: 'Date',
				fieldValue: 'date',
				cellTemplateName: 'dateCell',
				allowOrderBy: true,
				allowFilterText: false,
				allowFilterFixedValues: false,
				selected: false,
				dataType: 'string'
			}
		];
	}

	onEditClick(row: Action) {
		const { label, modal } = row;
		// Must change the redirect of '/' for the edit route
		if (label != 'Edit' && label != 'Delete') {
			this.modal.open(ModalComponent, { modal });
		}

		if (label == 'Edit') {
			this.router.navigate([`/collections/edit/${this.row.id}`]);
		}

		if (label == 'Delete') {
			this.modal.open(ModalComponent, { modal });
		}
		this.actionStickerDir.hide();
	}

	deleteCollection() {
		this.collectionApiService.delete(this.row.id).subscribe((data: any) => {
			this.optionsToast.title = 'Collection succesfully delete it';
			this.optionsToast.message = 'You have successfully delete the Collection. You can create a new one.';
			this.toastService.createToast(this.optionsToast);
			this.refreshGrid();
		});
		this.modal.close();
	}

	refreshGrid() {
		this.collectionGridRef.getInformationToFillTable();
	}

	setAction(sticker: StickerDirective, row: Collection) {
		const posibleActions: any = {
			myQueue: this.myQueueActions
		};
		const { stickerCustomClass } = sticker;
		this.actionsList = posibleActions[stickerCustomClass] as Action[];
		this.row = row;
	}

	ngOnDestroy(): void {
		this.breadCrumbService.setHideBreadcrumbs(false);
	}

	goToCreate() {
		this.router.navigate([`/collections/create`]);
	}
}
