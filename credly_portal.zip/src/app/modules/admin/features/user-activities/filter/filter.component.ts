import { Component, OnInit, Input, Output, EventEmitter, ViewChild } from '@angular/core';
import { debounceTime, switchMap, BehaviorSubject } from 'rxjs';

import { filter } from 'rxjs/operators';

import { LabelPosition, Size, ErrorState, Themes, ButtonKind, WidthState } from '@usitsdasdesign/dds-ng/shared';

import { SelectItemOptions, SelectOptions } from '@usitsdasdesign/dds-ng/select';
import { ButtonOptions } from '@usitsdasdesign/dds-ng/button';
import { BadgeApiService, BadgeTemplateApiService, EmployeeApiService } from '@/core/services/apis';

import {
	MultiSelectOptions,
	MultiSelectItem,
	SelectType,
	SelectControlTypes
} from '@usitsdasdesign/dds-ng/multi-select';
import {
	SuggestionsTagsInputComponent,
	SuggestionsTagsInputOptions
} from '@usitsdasdesign/dds-ng/suggestions-tags-input';
import { BadgeTemplateQuery } from '@/core/model/entities';
import ListResponse from '@/core/model/common/listResponse';
import { DataFilterBadgeTemplate as DataFilterBadge } from '@/shared/components/badge-filter/model';
import { FilterColumn, ListRequest, OrderBy } from '@/core/model/common';

@Component({
	selector: 'app-filter',
	templateUrl: './filter.component.html',
	styleUrls: ['./filter.component.scss']
})
export class FilterComponent implements OnInit {
	@Input()
	optionsUserRole: SelectItemOptions[] = [];

	@Input()
	optionsActivityType: SelectItemOptions[] = [];

	@Input()
	listSuggestionSearch: string[] = [];

	@Input()
	urlRedirect: string = '/';

	@Input()
	selectedSkills: string[] = [];

	@Input()
	selectedLevels: string[] = [];

	@Input()
	keyWordTyped: string = '';

	@Output() getDataFilter = new EventEmitter<any>();

	@Output() actionSearch = new EventEmitter<any>();

	@ViewChild(SuggestionsTagsInputComponent) searchBox: SuggestionsTagsInputComponent;

	dataSendFilter: DataFilterBadge = {
		filterSkill: [],
		filterLevel: [],
		searchTextFilter: ''
	};
	userNameValue: string = '';
	catchChangesFromUserName$ = new BehaviorSubject<string>(this.userNameValue);
	badgeNameValue: string = '';
	catchChangesFromBadgeName$ = new BehaviorSubject<string>(this.badgeNameValue);
	listUserName: any[] = [];
	listBadgeName: any[] = [];
	showListUserName: boolean = false;
	showListBadge: boolean = false;
	filterColumn: Array<FilterColumn> = [
		{
			column: '',
			value: '',
			freeText: false
		}
	];

	orderByFilter: OrderBy = {
		column: '',
		desc: false
	};

	request: ListRequest = {
		pageIndex: 1,
		pageSize: 10,
		filterColumns: this.filterColumn,
		SearchText: '',
		showExternals: false,
		orderBy: this.orderByFilter
	};

	requestBadge: ListRequest = {
		pageIndex: 1,
		pageSize: 10,
		filterColumns: this.filterColumn,
		SearchText: '',
		showExternals: false,
		orderBy: this.orderByFilter
	};

	dataFilter: any = {
		user: '',
		from: '',
		to: '',
		type: '',
		role: '',
		PersonID: '',
		UserName: '',
		BadgeTemplateId: '',
		BadgeName: ''
	};
	constructor(
		public badgeTemplateApiService: BadgeTemplateApiService,
		public badgeApiService: BadgeApiService,
		public employeeApiService: EmployeeApiService
	) {}

	ngOnInit(): void {
		this.trackUserNameValue();
		this.trackBadgeNameValue();

		this.selectOptions = {
			label: '',
			labelPosition: LabelPosition.internal,
			description: 'Label',
			placeholder: 'Placeholder',
			size: Size.md,
			isDisabled: false,
			isResponsive: false,
			isRequired: false,
			isError: false,
			errorMessage: '',
			errorState: ErrorState.default,
			customClass: '',
			stickerWidth: 0,
			stickerShift: 0,
			stickerMaxHeight: '',
			stickerIsDisabled: false,
			stickerPosition: 'bottom-left',
			stickerIndent: 0,
			stickerCustomClass: ''
		};
	}

	options: ButtonOptions = {
		theme: Themes.dark,
		kind: ButtonKind.primaryLoud,
		size: Size.md,
		width: WidthState.fixed,
		isLoading: false,
		icon: '',
		isInverse: false,
		isDisabled: false,
		ariaLabel: 'Button',
		customClass: '',
		role: 'button'
	};

	searchFilter(): void {
		this.actionSearch.emit(this.dataFilter);
	}

	selectOptions: SelectOptions = {};

	selectedItem: string;

	controlType: SelectControlTypes = SelectControlTypes.icon;

	multiSelectOptions: MultiSelectOptions = {
		label: 'Label',
		size: Size.md,
		description: '',
		placeholder: 'Placeholder',
		type: SelectType.tags,
		controlType: SelectControlTypes.icon,
		isDisabled: false,
		isResponsive: true,
		isError: false,
		isRequired: false,
		displayTickAllBtn: true,
		errorMessage: '',
		errorState: ErrorState.default,
		customClass: 'dds-multi-select-custom',
		stickerWidth: 0,
		stickerShift: 0,
		stickerMaxHeight: '300px',
		stickerIsDisabled: false,
		stickerPosition: 'bottom-left',
		stickerIndent: 0,
		stickerCustomClass: 'dds-multi-select-custom'
	};

	valueChangedMultiSelect(value: any, filter: string) {
		if (filter === 'activity') {
			this.dataFilter.type = value;
		}

		if (filter === 'role') {
			this.dataFilter.role = value;
		}
	}

	changeValueSuggestion(value: string[] | string) {
		this.dataSendFilter.searchTextFilter = String(value);
		// this.searchFilter();
	}

	changeUserName(userName: string) {
		// this is used to track the userNameValue
		this.catchChangesFromUserName$.next(userName);
		if (userName == '') {
			this.showListUserName = false;
			this.dataFilter.PersonID = '';
			return;
		}
		this.request.SearchText = userName;
		this.dataFilter.UserName = userName;
	}

	changeBadgeName(badgeName: string) {
		// this is used to track the badgesNameValue
		this.catchChangesFromBadgeName$.next(badgeName);
		if (badgeName == '') {
			this.showListBadge = false;
			this.dataFilter.BadgeTemplateId = '';
			return;
		}
		this.requestBadge.SearchText = badgeName;
	}

	optionSelectedUserName(item: any) {
		this.userNameValue = item.firstName + ' ' + item.lastName;
		this.dataFilter.UserName = item.firstName + ' ' + item.lastName;
		this.dataFilter.PersonID = item.personID;
		this.showListUserName = false;
	}

	optionSelectedBadgeName(item: any) {
		this.badgeNameValue = item.name;
		this.dataFilter.BadgeName = item.name;
		this.dataFilter.BadgeTemplateId = item.id;
		this.showListBadge = false;
	}

	disabledUserRole: boolean = true;
	disabledActivity: boolean = true;
	disabledPeriodTime: boolean = true;

	stateChangedUserRoleFilter(state: any) {
		this.disabledUserRole = state ? false : true;
		this.dataFilter.showRole = state;
	}

	stateChangedActivityFilter(state: any) {
		this.disabledActivity = state ? false : true;
		this.dataFilter.showActivity = state;
	}

	stateChangedPeriodTimeFilter(state: any) {
		this.disabledPeriodTime = state ? false : true;
		this.dataFilter.showPeriod = state;
	}

	dateChangedFrom(data: any) {
		let from: any = new Date(data);
		let mes: string =
			(from.getMonth() + 1).toString().length == 1 ? '0' + (from.getMonth() + 1).toString() : from.getMonth() + 1;
		let dia: string = from.getDate().toString().length == 1 ? '0' + from.getDate().toString() : from.getDate();
		let anio: string = from.getFullYear();
		from = anio + '-' + mes + '-' + dia;
		this.dataFilter.from = from;
	}
	dateChangedTo(data: any) {
		let to: any = new Date(data);
		let mes: string =
			(to.getMonth() + 1).toString().length == 1 ? '0' + (to.getMonth() + 1).toString() : to.getMonth() + 1;
		let dia: string = to.getDate().toString().length == 1 ? '0' + to.getDate().toString() : to.getDate();
		let anio: string = to.getFullYear();
		to = anio + '-' + mes + '-' + dia;
		this.dataFilter.to = to;
	}

	private trackUserNameValue() {
		this.catchChangesFromUserName$
			.pipe(
				filter((value) => value !== '' && value.length >= 4),
				debounceTime(500),
				switchMap(() => this.employeeApiService.get(this.request))
			)
			.subscribe((data: any) => {
				if (this.request.SearchText) {
					this.listUserName = data.data;
					this.showListUserName = true;
				} else {
					this.showListUserName = false;
				}
			});
	}

	private trackBadgeNameValue() {
		this.catchChangesFromBadgeName$
			.pipe(
				filter((value) => value !== '' && value.length >= 4),
				debounceTime(500),
				switchMap(() => this.badgeTemplateApiService.getBadgesTemplatesAdmin(this.requestBadge))
			)
			.subscribe((data: any) => {
				if (this.requestBadge.SearchText) {
					this.listBadgeName = data.data;
					this.showListBadge = true;
				} else {
					this.showListBadge = false;
				}
			});
	}
}
