import { Component, OnInit, OnDestroy, ViewChild } from '@angular/core';
import { Themes, Size } from '@usitsdasdesign/dds-ng/shared';
import { MultiSelectItem } from '@usitsdasdesign/dds-ng/multi-select';
import { DataGridColumn } from '@/shared/components/data-grid/model';
import { Collection } from '@/core/model/entities';
import { BreadCrumbService } from '@/core/services/store';
import { SessionStoreService } from '@/core/services/store';
import { Router } from '@angular/router';
import { StickerDirective } from '@usitsdasdesign/dds-ng/sticker';
import { ModalService } from '@usitsdasdesign/dds-ng/modal';
import { ModalComponent } from '@/shared/components/modal/modal.component';

import { Action } from '@/core/model/common/actions';
import CollectionApiService from '@/core/services/apis/collectionApiService';
import { ButtonOptions } from '@usitsdasdesign/dds-ng/button';
import { ToastOptions, ToastService } from '@usitsdasdesign/dds-ng/toast';
import { BaseTemplateCollectionApiService } from '@/core/services/apis';
import { DataGridComponent } from '@/shared/components/data-grid/data-grid.component';
@Component({
	selector: 'app-collections',
	templateUrl: './collections.component.html',
	styleUrls: ['./collections.component.scss']
})
export class CollectionsComponent implements OnInit, OnDestroy {
	constructor(
		public service: CollectionApiService,
		public sessionService: SessionStoreService,
		private router: Router,
		private modal: ModalService,
		private breadCrumbService: BreadCrumbService,
		private toastService: ToastService,
		private collectionApiService: BaseTemplateCollectionApiService
	) {}

	@ViewChild('actionStickerDir') actionStickerDir: StickerDirective;
	@ViewChild('collectionList') collectionGridRef!: DataGridComponent;

	columns!: Array<DataGridColumn>;

	actionsList: Action[] = [] as Action[];
	row: Collection;

	optionsToast: ToastOptions = {
		title: 'You have create a new Collection',
		message: 'You have successfully created a new collection. You can edit it later.',
		lifeTime: 7000,
		position: 'bottom-left',
		closeBtnIcon: 'dds-icon_close',
		isCloseIcon: true,
		customClass: 'simple-toast',
		limit: 1,
		theme: Themes.white
	};

	ngOnInit(): void {
		const params: any = new URL(location.href).searchParams;
		if (params.get('showNotification')) {
			this.toastService.createToast(this.optionsToast);
		}
		this.columns = [
			{
				label: 'Collection Name',
				fieldValue: 'name',
				cellTemplateName: '',
				allowOrderBy: true,
				allowFilterText: false,
				allowFilterFixedValues: false,
				selected: false,
				dataType: 'string'
			},
			{
				label: 'Number of Badges',
				fieldValue: 'numberOfBadges',
				cellTemplateName: '',
				allowOrderBy: true,
				allowFilterText: false,
				allowFilterFixedValues: false,
				selected: false,
				dataType: 'string'
			},
			{
				label: 'Date Created',
				fieldValue: 'dateCreated',
				cellTemplateName: 'dateCell',
				allowOrderBy: true,
				allowFilterText: false,
				allowFilterFixedValues: false,
				selected: false,
				dataType: 'string'
			},
			{
				label: 'Owner',
				fieldValue: 'owner',
				cellTemplateName: '',
				allowOrderBy: true,
				allowFilterText: false,
				allowFilterFixedValues: false,
				selected: false,
				dataType: 'string'
			},
			{
				label: 'Actions',
				fieldValue: '',
				cellTemplateName: 'editCell',
				allowOrderBy: false,
				allowFilterText: false,
				allowFilterFixedValues: false,
				selected: false,
				dataType: 'string'
			}
		];
	}

	options: ButtonOptions = {
		theme: Themes.dark,
		size: Size.md,
		isLoading: false,
		icon: '',
		isInverse: false,
		isDisabled: false,
		ariaLabel: 'Button',
		customClass: '',
		role: 'button'
	};

	myQueueActions: Action[] = [
		{
			label: 'Edit',
			disabled: false
		},
		{
			label: 'Delete',
			disabled: false,
			modal: {
				title: 'Delete Collection',
				hasFooter: true,
				contentTitle: 'Are you sure you want to delete this Collection?',
				contentText: [`Once deleted, you won't be able to return it.`],
				aceptButtonText: 'Yes, delete',
				cancelButtonText: 'Cancel',
				actionForAceptButton: () => {
					this.deleteCollection();
				},
				actionForCancelButton: () => {}
			}
		}
	];

	onEditClick(row: Action) {
		const { label, modal } = row;
		// Must change the redirect of '/' for the edit route
		if (label != 'Edit' && label != 'Delete') {
			this.modal.open(ModalComponent, { modal });
		}

		if (label == 'Edit') {
			this.router.navigate([`/collections/edit/${this.row.id}`]);
		}

		if (label == 'Delete') {
			this.modal.open(ModalComponent, { modal });
		}
		this.actionStickerDir.hide();
	}

	deleteCollection() {
		this.collectionApiService.delete(this.row.id).subscribe((data: any) => {
			this.optionsToast.title = 'Collection successfully deleted it';
			this.optionsToast.message = 'You have successfully deleted the Collection. You can create a new one.';
			this.toastService.createToast(this.optionsToast);
			this.refreshGrid();
		});
		this.modal.close();
	}

	refreshGrid() {
		this.collectionGridRef.getInformationToFillTable();
	}

	setAction(sticker: StickerDirective, row: Collection) {
		const posibleActions: any = {
			myQueue: this.myQueueActions
		};
		const { stickerCustomClass } = sticker;
		this.actionsList = posibleActions[stickerCustomClass] as Action[];
		this.row = row;
	}

	goToCreate() {
		this.router.navigate([`/collections/create`]);
	}

	ngOnDestroy(): void {
		this.breadCrumbService.setHideBreadcrumbs(false);
	}
}
