import { FilterColumn, ListRequest, OrderBy } from '@/core/model/common';
import {
	BadgeTemplateApiService,
	BaseTemplateCollectionApiService,
	CollectionApiService,
	EmployeeApiService
} from '@/core/services/apis';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';

import { ButtonOptions } from '@usitsdasdesign/dds-ng/button';
import { Themes, Size, WidthState, ButtonKind } from '@usitsdasdesign/dds-ng/shared';

import { ModalService } from '@usitsdasdesign/dds-ng/modal';
import { ModalComponent } from '@/shared/components/modal/modal.component';
import { ToastOptions, ToastService } from '@usitsdasdesign/dds-ng/toast';
import { BadgeTemplateStatus } from '@/core/model/entities';

@Component({
	selector: 'app-edit',
	templateUrl: './edit.component.html',
	styleUrls: ['./edit.component.scss']
})
export class EditComponent implements OnInit {
	valueBadge: string[] = [];
	listValueBadge: any[] = [];
	collectionOwnerEmail: string = '';
	collectionName: string = '';
	showListOwnerEmail: boolean = false;
	showListBadges: boolean = false;
	listOwnerEmail: any[] = [];
	listBadges: any[] = [];
	listBadgesFilter: any[] = [];

	options: ButtonOptions = {
		theme: Themes.dark,
		kind: ButtonKind.primaryLoud,
		size: Size.md,
		width: WidthState.fixed,
		isLoading: false,
		icon: '',
		isInverse: false,
		isDisabled: false,
		ariaLabel: 'Button',
		customClass: '',
		role: 'button'
	};

	optionsToast: ToastOptions = {
		title: 'You have create a new Collection',
		message: 'You have successfully created a new collection. You can edit it later.',
		lifeTime: 7000,
		position: 'bottom-left',
		closeBtnIcon: 'dds-icon_close',
		isCloseIcon: true,
		limit: 5,
		customClass: 'simple-toast',
		theme: Themes.white
	};

	filterColumn: Array<FilterColumn> = [
		{
			column: '',
			value: '',
			freeText: false
		}
	];

	orderByFilter: OrderBy = {
		column: '',
		desc: false
	};

	request: ListRequest = {
		pageIndex: 1,
		pageSize: 10,
		filterColumns: this.filterColumn,
		SearchText: '',
		showExternals: false,
		orderBy: this.orderByFilter
	};

	requestBadges: ListRequest = {
		pageIndex: 1,
		pageSize: 10,
		filterColumns: this.filterColumn,
		SearchText: '',
		showExternals: false,
		orderBy: this.orderByFilter
	};

	dataPutCollection: any = {
		collectionId: 0,
		name: '',
		description: '',
		ownerId: 0,
		listOfBadgeTemplateId: []
	};

	dataCollection: any = {};

	badgeTemplatesApprovedFilter: any = {
		status: [BadgeTemplateStatus.Accepted]
	};
	constructor(
		private router: Router,
		private _router: ActivatedRoute,
		private badgeTemplateApiService: BadgeTemplateApiService,
		private employeeService: EmployeeApiService,
		private collectionApiService: CollectionApiService,
		private badgecollectionApiService: BaseTemplateCollectionApiService,
		private modal: ModalService,
		private toastService: ToastService
	) {}

	ngOnInit(): void {
		let idCollection: any = this._router.snapshot.paramMap.get('id');
		this.badgeTemplateApiService.getBadgesTemplatesAdmin(this.requestBadges).subscribe((data: any) => {
			this.listBadges = data.data;
		});

		this.collectionApiService.getCollectionInfo(idCollection).subscribe((data: any) => {
			this.dataCollection = data;
			this.collectionOwnerEmail =
				this.dataCollection.owner.lastName != ''
					? this.dataCollection.owner.lastName +
					  ',' +
					  this.dataCollection.owner.firstName +
					  ' / ' +
					  this.dataCollection.owner.email
					: this.dataCollection.owner.firstName + ' / ' + this.dataCollection.owner.email;
			this.dataPutCollection.name = this.dataCollection.name;
			this.dataPutCollection.ownerId = this.dataCollection.owner.personID;
			this.dataPutCollection.collectionId = this.dataCollection.id;
			this.listValueBadge = this.dataCollection.badgeTemplates.map((e: any) => {
				return {
					id: e.id,
					name: e.name
				};
			});
		});
	}

	changeCollectionBadge(e: any) {
		this.dataPutCollection.name = e;
	}

	returnCollections() {
		this.router.navigate([`/collections`]);
	}

	changeOwnerEmail(value: string) {
		this.request.SearchText = value;
		this.employeeService.get(this.request).subscribe((data: any) => {
			this.listOwnerEmail = data.data;
			if (data.data.length > 0) {
				this.showListOwnerEmail = true;
			}
		});
	}

	optionSelectedOwnerEmail(item: any) {
		this.dataPutCollection.ownerId = item.personID;

		this.collectionOwnerEmail =
			item.lastName == ''
				? item.firstName + ' / ' + item.email
				: item.lastName + ',' + item.firstName + ' / ' + item.email;
		this.showListOwnerEmail = false;
	}

	changeBadge(badge: string) {
		if (badge == '') {
			this.showListBadges = false;
		} else {
			this.showListBadges = true;
			const myObj: Record<string, any> = {};
			this.requestBadges.SearchText = badge;
			const filter = { ...this.requestBadges, ...(this.badgeTemplatesApprovedFilter || {}), ...(myObj || {}) };
			this.badgeTemplateApiService.getBadgesTemplatesAdmin(filter).subscribe((data: any) => {
				if (data.data.length > 0) {
					this.listBadges = data.data;
				} else {
					this.showListBadges = false;
				}
			});
		}
	}

	optionSelectedBadge(item: any) {
		this.showListBadges = false;

		this.listValueBadge = this.listValueBadge.filter((e: any) => {
			return e.id != item.id;
		});

		this.listValueBadge.push({
			id: item.id,
			name: item.name
		});

		let badgeInput: any = document.querySelector('#formNameBadge');
		this.collectionName = '';
		badgeInput.reset();
	}

	removeBadge(item: any) {
		let modal: any = {
			title: 'Remove Badge from this Collection',
			hasFooter: true,
			contentTitle: 'Are you sure you want to remove this Badge?',
			contentText: [
				`Once removed, you can added again.
			`
			],
			aceptButtonText: 'Yes, delete',
			cancelButtonText: 'Cancel',
			actionForAceptButton: () => {
				this.listValueBadge = this.listValueBadge.filter((e: any) => {
					return e.id != item.id;
				});
				this.optionsToast.title = 'You have deleted a badge from this collection';
				this.optionsToast.message = 'You can added again later.';
				this.toastService.createToast(this.optionsToast);
				this.modal.close();
			},
			actionForCancelButton: () => {}
		};

		this.modal.open(ModalComponent, { modal });
		/*this.listValueBadge = this.listValueBadge.filter((e: any) => {
			return e.id != item.id;
		});*/
	}

	onCollection() {
		let modal: any = {
			title: 'Save changes for this Collection',
			hasFooter: true,
			contentTitle: 'Are you sure you save changes for this Collection?',
			contentText: [
				`Once Saved, you can edit it later again.
			`
			],
			aceptButtonText: 'Yes, save',
			cancelButtonText: 'Cancel',
			actionForAceptButton: this.updateCollection.bind(this),
			actionForCancelButton: () => {}
		};

		this.modal.open(ModalComponent, { modal });
	}

	updateCollection() {
		this.dataPutCollection.listOfBadgeTemplateId = this.listValueBadge.map((e: any) => {
			return e.id;
		});

		this.badgecollectionApiService.put(this.dataPutCollection).subscribe((data: any) => {
			this.optionsToast.title = 'You have edited a Collection';
			this.optionsToast.message = 'You have successfully saved the changes for this Collection.';
			this.toastService.createToast(this.optionsToast);
			this.modal.close();
			this.router.navigateByUrl(`/collections`);
		});
	}
}
