import { FilterColumn, ListRequest, OrderBy } from '@/core/model/common';
import { BadgeTemplateApiService, BaseTemplateCollectionApiService, EmployeeApiService } from '@/core/services/apis';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

import { ButtonOptions } from '@usitsdasdesign/dds-ng/button';
import { Themes, Size, WidthState, ButtonKind } from '@usitsdasdesign/dds-ng/shared';

import { ModalService } from '@usitsdasdesign/dds-ng/modal';
import { ModalComponent } from '@/shared/components/modal/modal.component';
import { ToastOptions, ToastService } from '@usitsdasdesign/dds-ng/toast';
import { RoleType } from '@/core/model/entities';
import { BadgeTemplateStatus } from '@/core/model/entities';

@Component({
	selector: 'app-create',
	templateUrl: './create.component.html',
	styleUrls: ['./create.component.scss']
})
export class CreateComponent implements OnInit {
	valueBadge: string[] = [];
	listValueBadge: any[] = [];
	collectionOwnerEmail: string = '';
	collectionName: string = '';
	showListOwnerEmail: boolean = false;
	showListBadges: boolean = false;
	listOwnerEmail: any[] = [];
	listBadges: any[] = [];
	listBadgesFilter: any[] = [];

	options: ButtonOptions = {
		theme: Themes.dark,
		kind: ButtonKind.primaryLoud,
		size: Size.md,
		width: WidthState.fixed,
		isLoading: false,
		icon: '',
		isInverse: false,
		isDisabled: false,
		ariaLabel: 'Button',
		customClass: '',
		role: 'button'
	};

	optionsToast: ToastOptions = {
		title: 'You have create a new Collection',
		message: 'You have successfully created a new collection. You can edit it later.',
		lifeTime: 7000,
		position: 'bottom-left',
		closeBtnIcon: 'dds-icon_close',
		isCloseIcon: true,
		customClass: 'simple-toast',
		limit: 5,
		theme: Themes.white
	};

	filterColumn: Array<FilterColumn> = [
		{
			column: '',
			value: '',
			freeText: false
		}
	];

	orderByFilter: OrderBy = {
		column: 'email',
		desc: false
	};

	orderBadgesByFilter: OrderBy = {
		column: 'name',
		desc: false
	};

	request: ListRequest = {
		pageIndex: 1,
		pageSize: 10,
		showExternals: false,
		filterColumns: this.filterColumn,
		SearchText: '',
		orderBy: this.orderByFilter,
		Roles: `${RoleType.BusinessRep}|${RoleType.Admin}`
	};

	requestBadges: ListRequest = {
		pageIndex: 1,
		pageSize: 10,
		filterColumns: this.filterColumn,
		SearchText: '',
		orderBy: this.orderBadgesByFilter
	};

	dataPostCollection: any = {
		name: '',
		description: '',
		ownerId: 0,
		listOfBadgeTemplateId: []
	};

	badgeTemplatesApprovedFilter: any = {
		status: [BadgeTemplateStatus.Accepted],
		showExternals: false
	};

	constructor(
		private router: Router,
		private badgeTemplateApiService: BadgeTemplateApiService,
		private employeeService: EmployeeApiService,
		private collectionApiService: BaseTemplateCollectionApiService,
		private modal: ModalService,
		private toastService: ToastService
	) {}

	ngOnInit(): void {
		this.badgeTemplateApiService.getBadgesTemplatesAdmin(this.requestBadges).subscribe((data: any) => {
			this.listBadges = data.data;
		});
	}

	changeCollectionBadge(e: any) {
		this.dataPostCollection.name = e;
	}

	returnCollections() {
		this.router.navigate([`/collections`]);
	}

	changeOwnerEmail(value: string) {
		this.request.SearchText = value;
		this.employeeService.get(this.request).subscribe((data: any) => {
			this.listOwnerEmail = data.data;
			if (data.data.length > 0) {
				this.showListOwnerEmail = true;
			}
		});
	}

	optionSelectedOwnerEmail(item: any) {
		this.dataPostCollection.ownerId = item.personID;

		this.collectionOwnerEmail =
			item.lastName == ''
				? item.firstName + ' / ' + item.email
				: item.lastName + ',' + item.firstName + ' / ' + item.email;
		this.showListOwnerEmail = false;
	}

	changeBadge(badge: string) {
		if (badge == '') {
			this.showListBadges = false;
		} else {
			const myObj: Record<string, any> = {};
			this.showListBadges = true;
			this.requestBadges.SearchText = badge;
			const filter = { ...this.requestBadges, ...(this.badgeTemplatesApprovedFilter || {}), ...(myObj || {}) };

			this.badgeTemplateApiService.getBadgesTemplatesAdmin(filter).subscribe((data: any) => {
				if (data.data.length > 0) {
					this.listBadges = data.data;
				} else {
					this.showListBadges = false;
				}
			});
		}
	}

	optionSelectedBadge(item: any) {
		this.showListBadges = false;

		this.listValueBadge = this.listValueBadge.filter((e: any) => {
			return e.id != item.id;
		});

		this.listValueBadge.push({
			id: item.id,
			name: item.name
		});

		let badgeInput: any = document.querySelector('#formNameBadge');
		this.collectionName = '';
		badgeInput.reset();
	}

	removeBadge(item: any) {
		let modal: any = {
			title: 'Remove Badge from this Collection',
			hasFooter: true,
			contentTitle: 'Are you sure you want to remove this Badge?',
			contentText: [
				`Once removed, you can added again.
			`
			],
			aceptButtonText: 'Yes, delete',
			cancelButtonText: 'Cancel',
			actionForAceptButton: () => {
				this.listValueBadge = this.listValueBadge.filter((e: any) => {
					return e.id != item.id;
				});
				this.optionsToast.title = 'You have deleted a badge from this collection';
				this.optionsToast.message = 'You can added again later.';
				this.toastService.createToast(this.optionsToast);
				this.modal.close();
			},
			actionForCancelButton: () => {}
		};

		this.modal.open(ModalComponent, { modal });
	}

	onCollection() {
		let modal: any = {
			title: 'Create this new Collection',
			hasFooter: true,
			contentTitle: 'Are you sure you create this Collection?',
			contentText: [
				`Once created, you can edit it later.
			`
			],
			aceptButtonText: 'Yes, create',
			cancelButtonText: 'Cancel',
			actionForAceptButton: this.addCollection.bind(this),
			actionForCancelButton: () => {}
		};

		this.modal.open(ModalComponent, { modal });
	}

	addCollection() {
		this.dataPostCollection.listOfBadgeTemplateId = this.listValueBadge.map((e: any) => {
			return e.id;
		});

		this.collectionApiService.post(this.dataPostCollection).subscribe((data: any) => {
			this.modal.close();
			this.router.navigateByUrl(`/collections?showNotification=true`);
		});
	}
}
