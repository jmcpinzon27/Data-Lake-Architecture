import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DashboardComponent } from './features/dashboard/dashboard.component';
import { SharedModule } from '@/shared/shared.module';
import { AdminRoutingModule } from './admin-routing.module';
import { SummaryComponent } from './components/summary/summary.component';
import { ReportComponent } from './components/report/report.component';
import { NotificationsComponent } from './features/notifications/notifications.component';
import { CollectionsComponent } from './features/collections/collections.component';
import { CreateComponent } from './features/collections/create/create.component';
import { SuggestionsTagsInputModule } from '@usitsdasdesign/dds-ng/suggestions-tags-input';
import { EditComponent } from './features/collections/edit/edit.component';
import { ReactiveFormsModule } from '@angular/forms';
import { RoleManagementComponent } from './features/role-management/role-management.component';
import { UserActivitiesComponent } from './features/user-activities/user-activities.component';
import { FilterComponent } from './features/user-activities/filter/filter.component';
import { LibModule } from '@usitsdasdesign/dds-ng';

@NgModule({
	declarations: [
		DashboardComponent,
		SummaryComponent,
		ReportComponent,
		NotificationsComponent,
		CollectionsComponent,
		CreateComponent,
		EditComponent,
		RoleManagementComponent,
		UserActivitiesComponent,
		FilterComponent
	],
	imports: [
		CommonModule,
		AdminRoutingModule,
		SharedModule,
		SuggestionsTagsInputModule,
		ReactiveFormsModule,
		LibModule
	]
})
export class AdminModule {}
