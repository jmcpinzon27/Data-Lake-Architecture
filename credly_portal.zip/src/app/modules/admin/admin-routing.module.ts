import { BadgeApprovalComponent } from '@/shared/features/badge-approval/badge-approval.component';
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { MsalGuard } from '@azure/msal-angular';
import { CollectionsComponent } from './features/collections/collections.component';
import { CreateComponent } from './features/collections/create/create.component';
import { EditComponent } from './features/collections/edit/edit.component';
import { UserActivitiesComponent } from './features/user-activities/user-activities.component';
import { DashboardComponent } from './features/dashboard/dashboard.component';
import { NotificationsComponent } from './features/notifications/notifications.component';
import { RoleManagementComponent } from './features/role-management/role-management.component';

enum AppRoutes {
	List = '',
	Notifications = 'notifications',
	Edit = 'edit',
	Badges = 'badges',
	BulkAwarding = 'bulk-awarding',
	BadgeApproval = 'badge-approval/:id',
	ReviewTemplate = 'templates/review/:id',
	Collections = 'collections',
	CollectionsCreate = 'collections/create',
	CollectionsEdit = 'collections/edit/:id',
	RoleManagement = 'role-management',
	UserActivities = 'user-activities'
}

const routes: Routes = [
	{
		path: AppRoutes.List,
		component: DashboardComponent,
		canActivate: [MsalGuard]
	},
	{
		path: AppRoutes.Notifications,
		component: NotificationsComponent
	},
	{
		path: AppRoutes.Badges,
		loadChildren: () => import('../bussiness-rep/bussiness-rep.module').then((m) => m.BussinessRepModule),
		canActivate: [MsalGuard]
	},
	{
		path: AppRoutes.BadgeApproval,
		component: BadgeApprovalComponent,
		canActivate: [MsalGuard]
	},
	{
		path: AppRoutes.BulkAwarding,
		loadChildren: () => import('../shared/bulk-awarding/bulk-awarding.module').then((m) => m.BulkAwardingModule),
		canActivate: [MsalGuard]
	},
	{
		path: AppRoutes.Collections,
		component: CollectionsComponent,
		canActivate: [MsalGuard]
	},
	{
		path: AppRoutes.CollectionsCreate,
		component: CreateComponent,
		canActivate: [MsalGuard]
	},
	{
		path: AppRoutes.CollectionsEdit,
		component: EditComponent,
		canActivate: [MsalGuard]
	},
	{
		path: AppRoutes.RoleManagement,
		component: RoleManagementComponent,
		canActivate: [MsalGuard]
	},
	{
		path: AppRoutes.UserActivities,
		component: UserActivitiesComponent,
		canActivate: [MsalGuard]
	}
];

@NgModule({
	imports: [RouterModule.forChild(routes)],
	exports: [RouterModule]
})
export class AdminRoutingModule {}
