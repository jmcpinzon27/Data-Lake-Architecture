import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { PractitionerRoutingModule } from './practitioner-routing.module';
import { NotificationsComponent } from './features/notifications/notifications.component';
import { SharedModule } from '@/shared/shared.module';
import { DashboardComponent } from './features/dashboard/dashboard.component';
import { BadgesComponent } from './features/badges/badges.component';
import { ValidationComponent } from './features/badges/validation/validation.component';
import { FaqComponent } from './features/faq/faq.component';
import { JobAidsComponent } from './features/job-aids/job-aids.component';
import { AccordionModule } from '@usitsdasdesign/dds-ng/accordion';
import { StickerModule } from '@usitsdasdesign/dds-ng/sticker';
import { TooltipModule } from '@usitsdasdesign/dds-ng/tooltip';
import { EvidenceFormComponent } from './features/badges/validation/evidence-form/evidence-form.component';
import { BadgeEvidenceCriteriasComponent } from './features/badges/validation/badge-evidence-criterias/badge-evidence-criterias.component';
import { PreviewComponent } from './features/badges/validation/badge-evidence-criterias/preview/preview.component';
import { TagsModule } from '@usitsdasdesign/dds-ng/tags';

@NgModule({
	declarations: [
		DashboardComponent,
		NotificationsComponent,
		BadgesComponent,
		ValidationComponent,
		FaqComponent,
		JobAidsComponent,
		EvidenceFormComponent,
		BadgeEvidenceCriteriasComponent,
		PreviewComponent
	],
	imports: [
		CommonModule,
		PractitionerRoutingModule,
		AccordionModule,
		SharedModule,
		StickerModule,
		TooltipModule,
		TagsModule
	]
})
export class PractitionerModule {}
