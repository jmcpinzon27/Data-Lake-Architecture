import { NotFoundComponent } from '@/shared/features/not-found/not-found.component';
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { NotificationsComponent } from './features/notifications/notifications.component';
import { DashboardComponent } from './features/dashboard/dashboard.component';
import { MsalGuard } from '@azure/msal-angular';
import { BadgesComponent } from './features/badges/badges.component';
import { ValidationComponent } from './features/badges/validation/validation.component';
import { FaqComponent } from './features/faq/faq.component';
import { JobAidsComponent } from './features/job-aids/job-aids.component';

enum AppRoutes {
	List = '',
	Notifications = 'notifications',
	Badges = 'badges',
	Catalog = 'catalog',
	BadgesValidation = 'badges/validation/:id',
	Faq = 'faq',
	JobAids = 'jobaids'
}

const routes: Routes = [
	{
		path: AppRoutes.List,
		component: DashboardComponent,
		canActivate: [MsalGuard]
	},
	{
		path: AppRoutes.Notifications,
		component: NotificationsComponent
	},
	{
		path: AppRoutes.Badges,
		component: BadgesComponent,
		canActivate: [MsalGuard]
	},
	{
		path: AppRoutes.BadgesValidation,
		component: ValidationComponent,
		canActivate: [MsalGuard]
	},
	{
		path: AppRoutes.Faq,
		component: FaqComponent,
		canActivate: [MsalGuard]
	},
	{
		path: AppRoutes.Catalog,
		loadChildren: () => import('../catalog/catalog.module').then((m) => m.CatalogModule),
		canActivate: [MsalGuard]
	},
	{
		path: AppRoutes.JobAids,
		component: JobAidsComponent,
		canActivate: [MsalGuard]
	}
];

@NgModule({
	imports: [RouterModule.forChild(routes)],
	exports: [RouterModule]
})
export class PractitionerRoutingModule {}
