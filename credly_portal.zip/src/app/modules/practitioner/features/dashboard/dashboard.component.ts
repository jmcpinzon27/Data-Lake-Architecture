import { Component, OnInit, OnDestroy, ViewChild, TemplateRef } from '@angular/core';
import { BreadcrumbsOptions } from '@usitsdasdesign/dds-ng/breadcrumbs';
import { ButtonKind, Kind, LinkOptions, Size, Themes, WidthState } from '@usitsdasdesign/dds-ng/shared';
import { ModalService } from '@usitsdasdesign/dds-ng/modal';
import { ButtonOptions } from '@usitsdasdesign/dds-ng/button';
import { ReportApiService } from '@/core/services/apis';
import { PractitionerSummaryReport } from '@/core/model/entities';
import { Router } from '@angular/router';
import { PageStoreService } from '@/core/services/store';
import { BreadCrumbService } from '@/core/services/store';

@Component({
	selector: 'app-dashboard',
	templateUrl: './dashboard.component.html',
	styleUrls: ['./dashboard.component.scss']
})
export class DashboardComponent implements OnInit, OnDestroy {
	summaryReport: PractitionerSummaryReport;
	constructor(
		private practitionerReportService: ReportApiService,
		private modalService: ModalService,
		private router: Router,
		protected pageStoreService: PageStoreService,
		private breadCrumbService: BreadCrumbService
	) {}

	ngOnInit(): void {
		this.breadCrumbService.setHideBreadcrumbs(true);
		this.getSummaryReport();
	}

	ngOnDestroy(): void {
		this.breadCrumbService.setHideBreadcrumbs(false);
	}

	options: ButtonOptions = {
		theme: Themes.dark,
		kind: ButtonKind.primaryLoud,
		size: Size.md,
		width: WidthState.fixed,
		isLoading: false,
		icon: '',
		isInverse: false,
		isDisabled: false,
		ariaLabel: 'Open Modal',
		customClass: '',
		role: 'button'
	};

	showCardsBadges: boolean = false;

	getSummaryReport() {
		this.practitionerReportService
			.getPractitionerSummaryReport()
			.subscribe((response: PractitionerSummaryReport) => {
				this.summaryReport = response;
				if (
					response.badgesInProgress > 0 ||
					response.badgesExpiringSoon > 0 ||
					response.unreadNotifications > 0
				) {
					this.showCardsBadges = true;
				}
			});
	}

	goToMyBadges(tabIndex: number) {
		//TODO: create an enum for managing indexes
		this.pageStoreService.setBadgesActiveTabIndex(tabIndex);
		this.router.navigate(['/badges']);
	}

	goToMyNotifications() {
		this.router.navigate(['/notifications']);
	}

	goToCatalog() {
		this.router.navigate(['/catalog']);
	}
}
