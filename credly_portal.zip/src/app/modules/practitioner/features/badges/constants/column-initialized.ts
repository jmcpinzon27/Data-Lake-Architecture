import { DataGridColumn } from '@/shared/components/data-grid/model';

export const inProgressBadgesColumn: DataGridColumn[] = [
	{
		label: 'Badge Name',
		fieldValue: 'badgeTemplateName',
		cellTemplateName: 'nameCell',
		allowOrderBy: false,
		allowFilterText: false,
		allowFilterFixedValues: false,
		selected: false,
		dataType: 'string'
	},
	{
		label: 'Date Initiated',
		fieldValue: 'initiatedAt',
		cellTemplateName: 'dateCell',
		allowOrderBy: true,
		allowFilterText: false,
		allowFilterFixedValues: false,
		selected: false,
		dataType: 'string'
	},
	{
		label: 'Level',
		fieldValue: 'badgeTemplateLevel',
		cellTemplateName: '',
		allowOrderBy: true,
		allowFilterText: false,
		allowFilterFixedValues: false,
		selected: false,
		dataType: 'string'
	},
	{
		label: 'Status',
		fieldValue: 'status',
		cellTemplateName: 'approvedStatusCell',
		allowOrderBy: true,
		allowFilterText: false,
		allowFilterFixedValues: false,
		selected: false,
		dataType: 'string'
	},
	{
		label: 'Actions',
		fieldValue: '',
		cellTemplateName: 'editCell',
		allowOrderBy: false,
		allowFilterText: false,
		allowFilterFixedValues: false,
		selected: false,
		dataType: 'string'
	}
];

export const awardedBadgesColumns: DataGridColumn[] = [
	{
		label: 'Issuer',
		fieldValue: 'badgeTemplateIssuer',
		cellTemplateName: '',
		allowOrderBy: false,
		allowFilterText: false,
		allowFilterFixedValues: false,
		selected: false,
		dataType: 'string'
	},
	{
		label: 'Credential Name',
		fieldValue: 'badgeTemplateName',
		cellTemplateName: 'nameCell',
		allowOrderBy: true,
		allowFilterText: false,
		allowFilterFixedValues: false,
		selected: false,
		dataType: 'string'
	},
	{
		label: 'Date Earned',
		fieldValue: 'awardedAt',
		cellTemplateName: 'dateCell',
		allowOrderBy: true,
		allowFilterText: false,
		allowFilterFixedValues: false,
		selected: false,
		dataType: 'string'
	},
	{
		label: 'Expiration Date',
		fieldValue: 'expiresAt',
		cellTemplateName: 'dateCell',
		allowOrderBy: true,
		allowFilterText: false,
		allowFilterFixedValues: false,
		selected: false,
		dataType: 'string'
	}
];
