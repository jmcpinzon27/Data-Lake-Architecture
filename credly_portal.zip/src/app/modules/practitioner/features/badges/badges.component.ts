import { Component, OnInit, OnDestroy, ViewChild } from '@angular/core';
import { ButtonKind, Size, TabThemeType, Themes, WidthState } from '@usitsdasdesign/dds-ng/shared';
import { ButtonOptions } from '@usitsdasdesign/dds-ng/button';
import { TabOptions, TabsOptions } from '@usitsdasdesign/dds-ng/tabs';
import DataGridColumn from '@/shared/components/data-grid/model/dataGridColumn';
import BadgeApiService from '@/core/services/apis/badgeApiService';
import { ToastOptions, ToastService } from '@usitsdasdesign/dds-ng/toast';
import { BadgeQuery, BadgeStatus, BadgeTemplateStatus } from '@/core/model/entities';
import { NewRegisterService, PageStoreService } from '@/core/services/store';
import { Router } from '@angular/router';
import { inProgressBadgesColumn, awardedBadgesColumns } from './constants/column-initialized';
import { getSettings } from '@/core/infrastructure/settingsLoader';
import { Settings } from '@/core/model/common';
import { StickerDirective } from '@usitsdasdesign/dds-ng/sticker';
import { Action } from '@/core/model/common/actions';
import { TooltipOptions } from '@usitsdasdesign/dds-ng/tooltip';
import { DataGridComponent } from '@/shared/components/data-grid/data-grid.component';
import { SystemParamsService } from '@/core/services/apis';
import { showExternalUrl } from '@/modules/shared/helpers';

@Component({
	selector: 'app-badges',
	templateUrl: './badges.component.html',
	styleUrls: ['./badges.component.scss']
})
export class BadgesComponent implements OnInit, OnDestroy {
	@ViewChild('actionStickerDir') actionStickerDir: StickerDirective;
	@ViewChild('badgesList') badgesGridRef!: DataGridComponent;
	actionsList: Action[] = [] as Action[];
	showRejectedBadges = true;

	myBadgeActions: Action[] = [
		{
			label: 'Edit',
			disabled: false
		},
		{
			label: 'Withdraw',
			disabled: false
		}
	];

	statusWithRejectedBadges: BadgeStatus[] = [
		BadgeStatus.Approved,
		BadgeStatus.Rejected,
		BadgeStatus.SubmittedForApproval,
		BadgeStatus.AttentionRequired,
		BadgeStatus.Initiated,
		BadgeStatus.InProgress
	];

	statusWithoutRejectedBadges: BadgeStatus[] = [
		BadgeStatus.Approved,
		BadgeStatus.SubmittedForApproval,
		BadgeStatus.AttentionRequired,
		BadgeStatus.Initiated,
		BadgeStatus.InProgress
	];

	readonly attentionRequiredText = BadgeTemplateStatus.AttentionRequired;
	readonly hideForArchiveStatus = BadgeTemplateStatus.HideForArchive;

	readonly badgesApprovedFilter: { status: BadgeStatus[] } = {
		status: [BadgeStatus.Awarded, BadgeStatus.Archived, BadgeStatus.Expired]
	};

	badgesPendingFilter: { status: BadgeStatus[] } = {
		status: this.showRejectedBadges ? this.statusWithRejectedBadges : this.statusWithoutRejectedBadges
	};

	newRegistry: any;
	activeTabIndex: number = 0;
	tagText: string = '';

	tabContainerOptions: TabsOptions = {
		theme: Themes.dark,
		themeType: TabThemeType.border,
		size: Size.md,
		ariaLabel: 'Horizontal tabs',
		isDisabled: false,
		customClass: 'custom-tab-list-badge',
		isResponsive: true
	};

	tabOptions1: TabOptions = {
		label: 'My Deloitte Badges In Progress'
	};

	tabOptions2: TabOptions = {
		label: 'My Deloitte Certified Digital Wallet'
	};

	initiateBadgeToast: ToastOptions = {
		title: 'You have initiated a new badge!',
		message: `Go to "My Badges & Certifications" and click on the badge title to access the screen to enter your earning evidence.`,
		lifeTime: 10000,
		position: 'bottom-left',
		closeBtnIcon: 'dds-icon_close',
		isCloseIcon: true,
		customClass: 'simple-toast',
		limit: 5,
		theme: Themes.dark
	};

	noBadgesToast: ToastOptions = {
		title: `It looks like you don't have any badges yet`,
		message: `You can go to the "Deloitte Badges Catalog" to discover badges available to you!`,
		lifeTime: 5000,
		position: 'bottom-left',
		closeBtnIcon: 'dds-icon_close',
		isCloseIcon: true,
		customClass: 'simple-toast',
		limit: 5,
		theme: Themes.dark
	};

	options: ButtonOptions = {
		theme: Themes.dark,
		kind: ButtonKind.primaryLoud,
		size: Size.md,
		width: WidthState.fixed,
		isLoading: false,
		icon: '',
		isInverse: false,
		isDisabled: false,
		ariaLabel: 'Open Modal',
		customClass: '',
		role: 'button'
	};

	tooltipOpts: TooltipOptions = {
		tooltipInvokeType: 'hover',
		tooltipPosition: 'top',
		tooltipIndent: 15,
		tooltipIsOutsideClick: false,
		tooltipHasBeak: true,
		tooltipIsDisabled: false,
		tooltipIsDynamic: false,
		tooltipCustomClass: '',
		tooltipType: 'regular',
		tooltipSize: 'md'
	};

	private readonly noExternalIdToast: ToastOptions = {
		title: 'Badge Notification',
		message: `The badge is not in sync with Credly. Please try again later.`,
		lifeTime: 10000,
		position: 'bottom-left',
		closeBtnIcon: 'dds-icon_close',
		customClass: 'simple-toast',
		limit: 5,
		theme: Themes.dark
	};

	totalRowsFromService: number = 0;

	inProgressColumns!: Array<DataGridColumn>;
	awardedColumns!: Array<DataGridColumn>;
	newRegisterTemplateId: string = '';
	settings: Settings;
	rowSelected: any;
	showTabA: boolean = true;
	showTabB: boolean = false;

	constructor(
		public badgeService: BadgeApiService,
		private toastService: ToastService,
		protected pageStoreService: PageStoreService,
		private router: Router,
		private newRegisterService: NewRegisterService,
		private sysParam: SystemParamsService
	) {}

	ngOnInit(): void {
		this.settings = getSettings();
		if (
			sessionStorage.getItem('showInitBadgeToast') === null ||
			sessionStorage.getItem('showInitBadgeToast') == ''
		) {
			sessionStorage.setItem('showInitBadgeToast', 'done');
		}

		if (this.badgeService.newRegistry?.status === BadgeStatus.Initiated) {
			this.showInitBadgeToast();
			this.newRegisterTemplateId = this.badgeService.newRegistry.badgeTemplateId;
		}

		this.pageStoreService.badgesActiveTabIndex.subscribe((e: number) => {
			this.selectTab(e);
		});
		this.inProgressColumns = inProgressBadgesColumn;
		this.awardedColumns = awardedBadgesColumns;

		this.newRegisterService.getNewRegister.subscribe((e: any) => {
			this.newRegistry = e;
		});
	}

	stateChangedRejectedBadges(state: any) {
		this.showRejectedBadges = state;

		this.badgesPendingFilter = {
			status: this.showRejectedBadges ? this.statusWithRejectedBadges : this.statusWithoutRejectedBadges
		};

		this.badgesGridRef.filter = { ...this.badgesPendingFilter };
		this.badgesGridRef.getInformationToFillTable();
	}

	setAction(sticker: StickerDirective, row: any) {
		this.myBadgeActions.forEach((action) => {
			if (action.label === 'Edit' || action.label === 'Withdraw') {
				action.disabled =
					row.badgeTemplateStatus === BadgeTemplateStatus.HideForEdit ||
					row.status === BadgeStatus.SubmittedForApproval ||
					row.status === BadgeStatus.Approved;
			}
			if (action.label === 'Withdraw' && row.status === BadgeStatus.Rejected) {
				action.disabled = true;
			}
		});
		this.rowSelected = row;
	}

	onEditClick(actionClicked: Action) {
		const { label, modal } = actionClicked;
		this.selectRowGrid(this.rowSelected, label);
		this.actionStickerDir.hide();
	}

	countRowsService(totalRows: any) {
		this.totalRowsFromService = totalRows;
		if (totalRows === 0) {
			this.toastService.createToast(this.noBadgesToast);
		}
	}

	showInitBadgeToast() {
		this.toastService.createToast(this.initiateBadgeToast);
	}

	closeAll() {
		this.toastService.closeAll();
	}

	onGoToCatalogClick() {
		this.router.navigate(['/catalog']);
	}

	selectRowGrid(row: BadgeQuery, label: string) {
		const isApprovedOrArchived = row?.status === BadgeStatus.Approved || row.status === BadgeStatus.Archived;
		const isAwarded = row?.status === BadgeStatus.Awarded;
		const isHiddenForEdit = row?.badgeTemplateStatus === BadgeTemplateStatus.HideForEdit;
		sessionStorage.setItem('withdraw', '0');

		if (label == 'Withdraw') {
			sessionStorage.setItem('withdraw', '1');
			this.router.navigate(['/badges/validation/' + row?.id]);
		} else if (isApprovedOrArchived) {
			this.badgeService.badge = row;
			this.router.navigate(['/catalog/preview/' + row?.badgeTemplateId]);
		} else if (isAwarded && row.isExternalCert) {
			this.credlyRedirect(row?.externalId);
		} else if (isAwarded && !row.isExternalCert) {
			this.badgeService.badge = row;
			this.router.navigate(['/catalog/preview/' + row?.badgeTemplateId]);
		} else if (isHiddenForEdit) {
			return;
		} else {
			this.router.navigate(['/badges/validation/', row?.id || row?.badgeTemplateId]);
		}
	}

	private credlyRedirect(credlyBadgeId: string) {
		credlyBadgeId
			? this.toastService.createToast(this.noExternalIdToast)
			: showExternalUrl(this.sysParam.backendParams[0].value);
	}

	setTagText(row: BadgeQuery) {
		if (row.badgeTemplateStatus === BadgeTemplateStatus.Archived) {
			this.tagText = BadgeTemplateStatus.Archived;
		} else if (row.badgeTemplateId === this.newRegisterTemplateId || row.id === this.newRegistry?.id) {
			this.tagText = 'New';
		} else if (row.badgeTemplateStatus === BadgeTemplateStatus.HideForEdit) {
			this.tagText = 'Temporarily Unavailable';
		} else if (row.status === BadgeStatus.Approved) {
			this.tagText = 'Updated';
		} else {
			this.tagText = '';
		}

		return this.tagText;
	}

	ngOnDestroy(): void {
		this.badgeService.newRegistry = null;
		this.pageStoreService.setBadgesActiveTabIndex(0);
		this.newRegisterService.setNewRegister(null);
	}

	selectTab(indexTab: number): void {
		this.showTabA = indexTab == 0;
		this.showTabB = indexTab == 1;
	}
}
