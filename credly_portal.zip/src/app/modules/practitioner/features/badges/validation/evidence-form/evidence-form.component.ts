import { Component, Input, ChangeDetectorRef, OnDestroy } from '@angular/core';
import { Subscription } from 'rxjs';
import { AbstractControl, FormGroup, FormArray, FormBuilder, Validators } from '@angular/forms';

import { EmployeeApiService } from '@/core/services/apis';

import { BadgeStatus, CriteriaType } from '@/core/model/entities';
import { validatorEmailObserver, validateWbsCode } from '@/modules/shared/helpers/helpers';

@Component({
	selector: 'app-evidence-form',
	templateUrl: './evidence-form.component.html',
	styleUrls: ['../badge-evidence-criterias/badge-evidence-criterias.component.scss', './evidence-form.component.scss']
})
export class EvidenceFormComponent implements OnDestroy {
	readonly badgeStatus = BadgeStatus;
	readonly maxHoursValid: number = 999999;

	@Input() set form(parentForm: FormGroup) {
		this.parentForm = parentForm;
		this.cd.detectChanges();
	}
	@Input() badgeId: string;
	@Input() path: string;
	@Input() isAbleToEdit: boolean;

	parentForm: FormGroup;
	addManually: boolean = false;
	defaultDate: Date = new Date();
	emailChangeSubscriptions$: Subscription[] = [];

	get educationList() {
		return (this.parentForm.get('education') as FormArray).controls as FormGroup[];
	}

	get experienceList() {
		return (this.parentForm.get('experience') as FormArray).controls as FormGroup[];
	}

	get eminenceList() {
		return (this.parentForm.get('eminence') as FormArray).controls as FormGroup[];
	}

	constructor(
		private cd: ChangeDetectorRef,
		private fb: FormBuilder,
		private employeeApiService: EmployeeApiService
	) {}

	addEducation() {
		const newControl = this.fb.group({
			badgeId: [this.badgeId],
			title: [null, [Validators.required, Validators.maxLength(100)]],
			name: [null],
			url: [null, Validators.required],
			fileName: [null, Validators.required],
			uploadBase64: [null, Validators.required],
			isAddedByUser: [true],
			isAlternative: [this.path === 'standard' ? false : true],
			type: [CriteriaType.Education],
			completionDate: [null, Validators.required]
		});
		(this.parentForm.get('education') as FormArray).push(newControl);
	}

	addExperience() {
		const newControl = this.fb.group({
			badgeId: [this.badgeId],
			title: [null, [Validators.required, Validators.maxLength(100)]],
			fileName: [null],
			wbsCodeGroup: this.fb.group({
				hours: [null, [Validators.required, Validators.max(this.maxHoursValid)]],
				code: [null, Validators.required]
			}),
			wbsSelected: [true],
			uploadBase64: this.fb.group({
				fileHours: [null],
				base64: [null],
				fileName: [null]
			}),
			upload: [null],
			isAddedByUser: [true],
			type: [CriteriaType.Experience],
			validatorEmail: [null, [Validators.required, Validators.email, Validators.pattern(/.+@deloitte\.com$/i)]],
			description: [null, [Validators.required, Validators.maxLength(500)]],
			isAlternative: [this.path === 'standard' ? false : true],
			showEmailList: [false],
			emailList: []
		});

		const uploadBase64 = newControl.get('uploadBase64') as FormGroup;
		uploadBase64.disable();

		this.emailChangeSubscriptions$.push(validatorEmailObserver(newControl, this.employeeApiService));
		(this.parentForm.get('experience') as FormArray).push(newControl);
	}

	addEminence() {
		const newControl = this.fb.group({
			badgeId: [this.badgeId],
			title: [null, [Validators.required, Validators.maxLength(100)]],
			fileName: [null],
			hours: [null, [Validators.required, Validators.max(this.maxHoursValid)]],
			uploadBase64: [null, Validators.required],
			isAddedByUser: [true],
			type: [CriteriaType.Eminence],
			validatorEmail: [null, [Validators.required, Validators.email, Validators.pattern(/.+@deloitte\.com$/i)]],
			isAlternative: [this.path === 'standard' ? false : true],
			description: [null, [Validators.required, Validators.maxLength(500)]],
			showEmailList: [false],
			emailList: []
		});

		this.emailChangeSubscriptions$.push(validatorEmailObserver(newControl, this.employeeApiService));
		(this.parentForm.get('eminence') as FormArray).push(newControl);
	}

	updateFormControl(control: AbstractControl, field: string, value: any) {
		if (field === 'wbsSelected') validateWbsCode(control, value);
		control.patchValue({ [field]: value });
		if (field === 'validatorEmail') control.patchValue({ showEmailList: false });
	}

	setValidator(control: AbstractControl, value: string) {
		this.updateFormControl(control, 'validatorEmail', value);
		this.updateFormControl(control, 'emailList', []);
		this.updateFormControl(control, 'showEmailList', false);
	}

	uploadFileByType(control: AbstractControl, event: File[], isExperience: boolean = false) {
		const file = event[0]; // Catch the unique possible file added
		const fileReader = new FileReader();

		fileReader.onload = () => {
			const base64 = fileReader.result;
			this.updateFormControl(control, 'fileName', file.name);
			this.updateFormControl(control, 'uploadBase64', { base64, filename: file.name });
			if (isExperience) {
				this.updateFormControl(control, 'upload', file.name);
			}
		};
		fileReader.readAsDataURL(file);
	}

	removeControl(index: number, type: 'education' | 'experience' | 'eminence') {
		const possibleControls: { [key: string]: FormGroup[] } = {
			education: this.educationList,
			experience: this.experienceList,
			eminence: this.eminenceList
		};
		possibleControls[type].splice(index, 1);
		this.parentForm.get(type).value.splice(index, 1);
		this.parentForm.updateValueAndValidity();
		this.parentForm.get(type).updateValueAndValidity();
	}

	getExtension(name: string) {
		if (name === null) return '';
		let splitName: any = name.split('.');
		return splitName[1];
	}

	removeUpload(control: AbstractControl, isExperience: boolean = false) {
		const uploadBase64 = control.get('uploadBase64');
		const fileName = control.get('fileName');
		const upload = control.get('upload');
		if (isExperience) {
			const hours = uploadBase64.value.fileHours;
			uploadBase64.reset({ file: null, fileName: null, fileHours: hours });
		} else uploadBase64.reset();
		fileName.reset();
		if (upload) upload.reset();
	}

	/**
	 * Used to avoid more than 6 characters in the input.
	 * @param event From keyboard, every time the user type a number
	 * @returns boolean
	 */
	validateHours(event: KeyboardEvent): boolean {
		//typed as any for errors trying to access to value property
		const { target }: any = event;
		return target.value?.length < 6 ? true : false;
	}

	preventPasteExcededHours(event: ClipboardEvent) {
		event.preventDefault();
	}

	ngOnDestroy(): void {
		this.emailChangeSubscriptions$.forEach((subs$: Subscription) => subs$.unsubscribe());
	}
}
