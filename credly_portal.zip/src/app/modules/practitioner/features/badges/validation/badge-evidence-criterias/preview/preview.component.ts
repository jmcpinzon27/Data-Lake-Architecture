import {
	Badge,
	BadgeStatus,
	BadgeTemplate,
	BadgeTemplateCriteria,
	CriteriaType,
	ExpirationRange,
	BadgeTemplateStatus,
	BadgeTemplateMessages
} from '@/core/model/entities';
import moment from 'moment';
import { BadgeTemplateApiService } from '@/core/services/apis';
import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { ModalComponent } from '@/shared/components/modal/modal.component';
import { AccordionOptions } from '@usitsdasdesign/dds-ng/accordion';
import { ModalService } from '@usitsdasdesign/dds-ng/modal';
import { showExternalUrl } from '@/modules/shared/helpers';
import { ModalValues } from '@/core/model/common/actions';
import { Router } from '@angular/router';
import { BadgeTemplateStoreService, SessionStoreService } from '@/core/services/store';
import SkillType from '@/core/model/entities/skillType';
import { Size } from '@usitsdasdesign/dds-ng/shared';
import Criteria from '@/core/model/entities/criteria';

@Component({
	selector: 'app-preview',
	templateUrl: './preview.component.html',
	styleUrls: ['./preview.component.scss']
})
export class PreviewComponent implements OnInit {
	@Input()
	badgeTemplateId: string = '';

	@Input()
	isFormEvidenceValidation: boolean = true;

	@Input()
	badgeInfo!: Badge;

	@Output()
	submitBadge = new EventEmitter<void>();

	@Output()
	badgeName = new EventEmitter<string>();

	@Output()
	alternateDescription = new EventEmitter<string>();

	@Output()
	reInitiateBadge = new EventEmitter<string>();

	readonly skillTypes = SkillType;

	showBadgePreview: boolean = false;
	showBadgeDescription: boolean = true;
	isLoading: boolean = false;
	showSubmit: boolean = false;
	showReInitiate: boolean = false;
	CriteriaTypes = CriteriaType;
	templateInfo: BadgeTemplate;
	expirationRange: any = ExpirationRange;
	templateStatusHeader: { status: string; text: string } | null = null;
	badgeTemplateStatus = BadgeTemplateStatus;
	role: 'admin' | 'practitioner' | 'businessrep' = 'practitioner';
	standardCriteriaItems: any[] = [];
	alternateCriteriaItems: any[] = [];

	accordionOptions: AccordionOptions = {
		size: Size.lg,
		isDisabled: false,
		isOpen: false,
		isMulti: true
	};
	entity: BadgeTemplate;
	templateId: string;

	constructor(
		private router: Router,
		private badgeTemplateApiService: BadgeTemplateApiService,
		private modal: ModalService,
		private badgeTemplateStoreService: BadgeTemplateStoreService,
		private sessionService: SessionStoreService
	) {}

	ngOnInit(): void {
		this.role = this.sessionService.getActiveRole();
		if (this.badgeInfo?.lastFeedback != null && this.badgeInfo.status != BadgeStatus.Rejected) {
			this.showFeedback();
		}
		if (this.badgeInfo.status === BadgeStatus.Rejected) {
			this.showRejectionFeedback();
		}

		if (this.badgeInfo?.badgeTemplateReleaseNotes && this.badgeInfo?.applyReleaseNotesOnlyInitiated !== null) {
			this.showUpdates();
		}
		this.validateStatus();
		this.getTemplateInfo();
	}

	filterSkills(): void {
		if (this.templateInfo.skills !== undefined) {
			this.templateInfo.skills = this.templateInfo.skills.filter((item) => item.skillType == SkillType.Core);
			this.templateInfo.skills = this.templateInfo.skills.sort(
				(a, b) => -(a.proficiency - b.proficiency || b.skillName.localeCompare(a.skillName))
			);
		}
	}

	private getTemplateInfo() {
		this.badgeTemplateApiService.getBadgeTemplateInfo(this.badgeTemplateId).subscribe((data: BadgeTemplate) => {
			this.templateInfo = data;
			if (this.role === 'practitioner') {
				this.templateInfo.skills = this.templateInfo.skills.filter((item) => item.skillType == SkillType.Core);
			}
			if (this.templateInfo.criterias) {
				this.groupCriteriaItems(this.templateInfo.criterias);
			}
			this.filterSkills();
			this.badgeTemplateStoreService.updateForm(this.templateInfo);
			this.badgeName.emit(this.templateInfo.name);
			this.alternateDescription.emit(this.templateInfo.alternativeDescription);
			if (this.templateInfo.status === BadgeTemplateStatus.HideForArchive) {
				const dateString = moment(this.templateInfo.archiveDate).format('MMMM Do YYYY');
				this.templateStatusHeader = {
					status: this.templateInfo.status,
					text: this.templateInfo.archiveDate
						? BadgeTemplateMessages['ArchiveWithDate'].replace('{date}', dateString)
						: BadgeTemplateMessages['ArchiveWithoutDate']
				};
			}
			this.templateId = this.templateInfo.id;
		});
	}

	private validateStatus() {
		this.showSubmit =
			this.badgeInfo.status !== (BadgeTemplateStatus.Archived as unknown as BadgeStatus) &&
			this.badgeInfo.status !== BadgeStatus.SubmittedForApproval &&
			this.badgeInfo.status !== BadgeStatus.Approved &&
			this.badgeInfo.status !== BadgeStatus.Awarded &&
			this.badgeInfo.status !== BadgeStatus.Archived &&
			this.badgeInfo.status !== BadgeStatus.Rejected;

		this.showReInitiate = this.badgeInfo.status === BadgeStatus.Rejected;
	}

	groupCriteriaItems(criteriaItems: any[]) {
		criteriaItems.forEach((item) => {
			if (item.isAlternative) {
				this.alternateCriteriaItems.push(item);
			} else {
				this.standardCriteriaItems.push(item);
			}
		});
	}

	showModal() {
		this.badgeInfo.status === BadgeStatus.Rejected ? this.showRejectionFeedback() : this.showFeedback();
	}

	private showFeedback() {
		let modal: any = {
			title: 'Attention required',
			hasFooter: true,
			contentTitle: '',
			contentText: [],
			aceptButtonText: "Let's start!",
			cancelButtonText: 'Cancel',
			actionForAceptButton: () => this.modal.close(),
			actionForCancelButton: () => {}
		};

		this.modal.open(ModalComponent, {
			defaultValueFeedback: this.badgeInfo.lastFeedback,
			showFeedback: true,
			isEditable: false,
			modal
		});
	}

	private showRejectionFeedback() {
		let modal: any = {
			title: 'Rejected',
			hasFooter: true,
			contentTitle: '',
			contentText: [],
			cancelButtonText: 'Close',
			hideAceptBtn: true,
			actionForAceptButton: () => this.modal.close()
		};

		this.modal.open(ModalComponent, {
			defaultValueFeedback: this.badgeInfo.lastFeedback,
			showFeedback: true,
			isEditable: false,
			modal
		});
	}

	SubmitPreview() {
		this.submitBadge.emit();
		this.isLoading = true;
	}

	reInitiateActionTrigger() {
		const { id } = this.badgeInfo;
		this.reInitiateBadge.emit(id);
	}

	hasCriteriaByType(criterias: Array<BadgeTemplateCriteria>, type: CriteriaType): boolean {
		return criterias.some((item) => item.type === type);
	}

	showPreview() {
		this.showBadgeDescription = !this.showBadgeDescription;
		this.showBadgePreview = !this.showBadgePreview;
	}

	showUpdates() {
		const modal: ModalValues = {
			title: 'This badge has been updated!',
			hasFooter: true,
			contentTitle: '',
			contentText: [],
			hideCancelBtn: true,
			aceptButtonText: 'Got it',
			actionForAceptButton: () => this.modal.close(),
			actionForCancelButton: () => {}
		};

		this.modal.open(ModalComponent, {
			defaultValueFeedback: this.badgeInfo.badgeTemplateReleaseNotes,
			showUpdates: true,
			modal
		});
	}

	showUrl(url: string) {
		showExternalUrl(url);
	}

	redirectToCatalog() {
		this.router.navigate(['catalog']);
	}

	getSkillLevel(event: any): void {
		if (event.skillType == SkillType.Core) {
			this.entity.skills[event.index].proficiency = event?.proficiency;
			this.entity.skills[event.index].skillType = event?.skillType;
		}
		this.badgeTemplateStoreService.updateForm(this.entity);
	}

	// This chould be added in the helper file and prepared to filter by type
	educationFiltered(path: 'standard' | 'alternate') {
		const paths = {
			standard: this.standardCriteriaItems,
			alternate: this.alternateCriteriaItems
		};
		return paths[path].filter((item) => item.type === this.CriteriaTypes.Education);
	}
}
