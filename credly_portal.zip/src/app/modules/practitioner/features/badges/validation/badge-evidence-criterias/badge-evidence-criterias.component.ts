import { Component, OnInit, OnDestroy, Input, AfterViewInit } from '@angular/core';
import { BadgeApiService, EmployeeApiService } from '@/core/services/apis';
import { Router } from '@angular/router';
import { FormArray, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Subscription } from 'rxjs';

import { BreadCrumbService, NewRegisterService, SessionStoreService } from '@/core/services/store';

import { Badge, BadgeStatus, EducationCriteria, EminenceCriteria, ExperienceCriteria } from '@/core/model/entities';

import { ListRequest } from '@/core/model/common';

import { ModalService } from '@usitsdasdesign/dds-ng/modal';
import { ModalComponent } from '@/shared/components/modal/modal.component';
import { ToastOptions, ToastService } from '@usitsdasdesign/dds-ng/toast';
import { ModalValues } from '@/core/model/common/actions';
import { AccordionItemsCustom } from '@/shared/components/badge-wizard/model';

import {
	approvedToastConst,
	archivedToastConst,
	expiredToastConst,
	optionsToastConst,
	rejectedToastConst,
	revokedToastConst,
	submittedToastConst,
	attentionRequiredToastConst,
	saveButtonOptions,
	draftButtonOptions,
	radioGroupOptions,
	switchPatchModal,
	modalWithdraw,
	modalReturnList,
	modalDraft,
	modalSubmit
} from './badge-evidence-criterias.const';

import { filterCriteriaByPath, validateWbsCode, validatorEmailObserver } from '@/modules/shared/helpers';

@Component({
	selector: 'app-badge-evidence-criterias',
	templateUrl: './badge-evidence-criterias.component.html',
	styleUrls: ['./badge-evidence-criterias.component.scss']
})
export class BadgeEvidenceCriteriasComponent implements OnInit, OnDestroy, AfterViewInit {
	private readonly optionsToast = { ...optionsToastConst };
	private readonly toastOptions: { [key: string]: ToastOptions } = {
		[BadgeStatus.AttentionRequired]: attentionRequiredToastConst,
		[BadgeStatus.SubmittedForApproval]: submittedToastConst,
		[BadgeStatus.Rejected]: rejectedToastConst,
		[BadgeStatus.Revoked]: revokedToastConst,
		[BadgeStatus.Approved]: approvedToastConst,
		[BadgeStatus.Expired]: expiredToastConst,
		[BadgeStatus.Archived]: archivedToastConst
	};
	readonly maxHoursValid: number = 999999;
	readonly pathValues: { [key: string]: string } = {
		standard: 'standard',
		alternate: 'alternate'
	};
	readonly standardCriteriaModalText: string[] = [
		`The evidence submitted is complete, accurate and meets or exceeds the specifications set forth by the badge's requirements. <br><br>
		Any submitted criteria deemed insufficient, now or in the future, may result in the rejection or revocation of this badge.`
	];
	readonly alternateCriteriaModalText: string[] = [
		`You are submitting this badge's requirements with the alternate criteria. In the case you want to change the criteria you can cancel it and select the standard criteria, and then submit. <br><br>
		By submitting this application, I confirm I completed all of the earning criteria for this badge learning and required activities in an ethical and honest manner. Search "Code of Ethics" on Dnet to learn more. <br><br>
		I also confirm that the evidence submitted is complete, accurate and meets or exceeds the specifications set forth by the badge's requirements. <br><br>
		Any submitted criteria deemed insufficient, now or in the future, may result in the rejection or revocation of this badge.`
	];

	@Input() badgeId: string = '';

	badgeInfo: Badge;
	badgeApprovalStatus!: BadgeStatus;
	standardForm: FormGroup;
	alternateForm: FormGroup;
	accordionItemsStandard: AccordionItemsCustom[] = [];
	accordionItemsAlternative: AccordionItemsCustom[] = [];
	emailChangeSubscriptions$: Subscription[] = [];

	request: ListRequest = {
		pageIndex: 1,
		pageSize: 10,
		filterColumns: [{ column: '', value: '', freeText: false }],
		SearchText: '',
		orderBy: { column: '', desc: false }
	};

	saveButton = { ...saveButtonOptions };
	draftButton = { ...draftButtonOptions };
	radioGroupOptionsInComponent = { ...radioGroupOptions };

	alternateDescription: string = '';
	badgeTemplateId: string = '';
	badgeName: string = 'Badge Name';
	selectedPath: string = 'standard';
	isAbleToEdit: boolean = false;
	newRegistry: any;
	backUpHours: string = '';

	constructor(
		private sessionService: SessionStoreService,
		private router: Router,
		private modal: ModalService,
		private breadCrumbService: BreadCrumbService,
		private toastService: ToastService,
		private badgeApiService: BadgeApiService,
		private newRegisterService: NewRegisterService,
		private employeeApiService: EmployeeApiService,
		private fb: FormBuilder
	) {}

	ngOnInit(): void {
		if (this.sessionService.getActiveRole() === 'businessrep') this.breadCrumbService.setHideBreadcrumbs(true);
		this.createForms();
		this.getBadgeInfoAndSetValues();
	}

	ngAfterViewInit(): void {
		setTimeout(() => {
			if (sessionStorage.getItem('withdraw') && sessionStorage.getItem('withdraw') === '1') this.modalWithdraw();
		}, 1800);
	}

	private createForms() {
		this.standardForm = this.basicEvidenceForm();
		this.alternateForm = this.basicEvidenceForm();
	}

	private basicEvidenceForm(): FormGroup {
		return this.fb.group({
			education: this.fb.array([]),
			experience: this.fb.array([]),
			eminence: this.fb.array([])
		});
	}

	private getBadgeInfoAndSetValues() {
		this.badgeApiService.getBadgeById(this.badgeId).subscribe({
			next: (data: Badge) => {
				this.badgeTemplateId = data.badgeTemplateId;
				this.badgeInfo = data;
				this.badgeApprovalStatus = this.badgeInfo.status;
				const { education, experience, eminence } = this.badgeInfo;
				this.showToast(this.toastOptions[this.badgeApprovalStatus]);
				this.setAccordionItems({ education, experience, eminence }, 'standard');
				this.fillForm({ education, experience, eminence }, 'standard');

				if (this.badgeInfo.badgeTemplateHaveAlternativeCriteria) {
					this.setAccordionItems({ education, experience, eminence }, 'alternate');
					this.fillForm({ education, experience, eminence }, 'alternate');
				}

				if (!data.alternativeCriteriaSelected) {
					this.setPathSelected(this.radioGroupOptionsInComponent.buttons[0]);
				} else {
					this.setPathSelected(this.radioGroupOptionsInComponent.buttons[1]);
				}
				this.setAbleToEdit();
			},
			error: (err) => console.warn(err)
		});
	}

	private setAccordionItems(
		criterias: { education: EducationCriteria[]; experience: ExperienceCriteria[]; eminence: EminenceCriteria[] },
		path: 'standard' | 'alternate' = 'standard'
	) {
		const { education, experience, eminence } = criterias;
		const accordions = {
			standard: this.accordionItemsStandard,
			alternate: this.accordionItemsAlternative
		};

		const educationItems = filterCriteriaByPath(education, path) as EducationCriteria[];
		const experienceItems = filterCriteriaByPath(experience, path) as ExperienceCriteria[];
		const eminenceItems = filterCriteriaByPath(eminence, path) as EminenceCriteria[];

		if (educationItems.length > 0) {
			accordions[path].push({
				heading: 'Education Criteria',
				isItemCompleted: false,
				options: educationItems.map((item) => ({ name: item.title, isCompleted: false }))
			});
		}
		if (experienceItems.length > 0) {
			accordions[path].push({
				heading: 'Experience Criteria',
				isItemCompleted: false,
				options: experienceItems.map((item) => ({ name: item.title, isCompleted: false }))
			});
		}
		if (eminenceItems.length > 0) {
			accordions[path].push({
				heading: 'Eminence Criteria',
				isItemCompleted: false,
				options: eminenceItems.map((item) => ({ name: item.title, isCompleted: false }))
			});
		}
	}

	private setAbleToEdit() {
		this.isAbleToEdit =
			this.badgeApprovalStatus === BadgeStatus.AttentionRequired ||
			this.badgeApprovalStatus === BadgeStatus.InProgress ||
			this.badgeApprovalStatus === BadgeStatus.Initiated;
		if (!this.isAbleToEdit) {
			this.standardForm.disable();
			this.alternateForm.disable();
			this.standardForm.updateValueAndValidity();
			this.alternateForm.updateValueAndValidity();
		}
	}

	private fillForm(
		criterias: { education: EducationCriteria[]; experience: ExperienceCriteria[]; eminence: EminenceCriteria[] },
		path: 'standard' | 'alternate' = 'standard'
	) {
		const { education, experience, eminence } = criterias;

		// Get the criterias comming from the badge response and separate
		const educationItems = filterCriteriaByPath(education, path) as EducationCriteria[];
		const experienceItems = filterCriteriaByPath(experience, path) as ExperienceCriteria[];
		const eminenceItems = filterCriteriaByPath(eminence, path) as EminenceCriteria[];

		const forms = {
			standard: this.standardForm,
			alternate: this.alternateForm
		};

		// Get the criteria form array from the 'father form' depeneding on the path selected
		const educationArray = forms[path].get('education') as FormArray;
		const experienceArray = forms[path].get('experience') as FormArray;
		const eminenceArray = forms[path].get('eminence') as FormArray;

		// Use the criteriaItems seted and then pushes each FormGroup created in the method to the form array
		this.setEducations(educationItems).forEach((formGroup) => educationArray.push(formGroup));
		this.setExperience(experienceItems).forEach((formGroup) => experienceArray.push(formGroup));
		this.setEminence(eminenceItems).forEach((formGroup) => eminenceArray.push(formGroup));
	}

	private setEducations(criteria: EducationCriteria[]): FormGroup<any>[] {
		return criteria.map((item: EducationCriteria) => {
			if (item.completionDate) item.completionDate = new Date(item.completionDate);
			const newGroup = this.fb.group({
				id: [item.id],
				badgeId: [item.badgeId],
				badgeTemplateCriteriaId: [item.badgeTemplateCriteriaId ? item.badgeTemplateCriteriaId : null],
				title: [item.title ? item.title : null, Validators.required],
				name: [item.name ? item.name : null],
				url: [item.url ? item.url : null, [Validators.required, Validators.maxLength(300)]],
				fileName: [item.fileName ? item.fileName : null, Validators.required],
				uploadBase64: [item.uploadBase64 ? item.uploadBase64 : null],
				upload: [item.upload ? item.upload : null],
				isAddedByUser: [item.badgeTemplateCriteriaId ? false : true],
				courseId: [item.criteria?.sabaCourseID ? item.criteria?.sabaCourseID : null],
				sabaCourseValidated: [item.sabaCourseValidated],
				isAlternative: [item.isAlternative],
				type: [item.type ? item.type : null],
				completionDate: [item.completionDate ? item.completionDate : null, Validators.required]
			});
			return newGroup;
		});
	}

	private setExperience(criteria: ExperienceCriteria[]): FormGroup<any>[] {
		return criteria.map((item: ExperienceCriteria) => {
			const newGroup = this.fb.group({
				id: [item.id],
				badgeId: [item.badgeId],
				badgeTemplateCriteriaId: [item.badgeTemplateCriteriaId],
				title: [item.title ? item.title : null, Validators.required],
				fileName: [item.fileName ? item.fileName : null, Validators.required],
				wbsCodeGroup: this.fb.group({
					hours: [item.hours ? item.hours : null, [Validators.required, Validators.max(this.maxHoursValid)]],
					code: [item.wbsCode ? item.wbsCode : null, Validators.required]
				}),
				uploadBase64: this.fb.group({
					fileHours: [item.hours ? item.hours : null],
					base64: [item.uploadBase64 ? item.uploadBase64 : ''],
					fileName: [item.fileName ? item.fileName : null]
				}),
				upload: [item.wbsCode === null || item.wbsCode === '' ? item.upload : null],
				wbsSelected: [item.wbsCode?.length > 0 || item.fileName?.length === 0 ? true : false],
				isAddedByUser: [item.badgeTemplateCriteriaId ? false : true],
				type: [item.type ? item.type : null],
				validatorEmail: [
					item.validatorEmail ? item.validatorEmail : null,
					[Validators.required, Validators.email, Validators.pattern(/.+@deloitte\.com$/i)]
				],
				isAlternative: [item.isAlternative],
				description: [
					item.description ? item.description : null,
					[Validators.required, Validators.maxLength(500)]
				],
				showEmailList: [false],
				emailList: []
			});

			validateWbsCode(newGroup, item.wbsCode?.length > 0 || item.fileName?.length === 0);

			this.emailChangeSubscriptions$.push(validatorEmailObserver(newGroup, this.employeeApiService));
			return newGroup;
		});
	}

	private setEminence(criteria: EminenceCriteria[]): FormGroup<any>[] {
		return criteria.map((item: EminenceCriteria) => {
			const newGroup = this.fb.group({
				id: [item.id],
				badgeId: [item.badgeId],
				badgeTemplateCriteriaId: [item.badgeTemplateCriteriaId ? item.badgeTemplateCriteriaId : null],
				title: [item.title ? item.title : null, Validators.required],
				fileName: [item.fileName ? item.fileName : null, Validators.required],
				hours: [item.hours ? item.hours : null, [Validators.required, Validators.max(this.maxHoursValid)]],
				uploadBase64: [item.uploadBase64 ? item.uploadBase64 : null],
				isAddedByUser: [item.badgeTemplateCriteriaId ? false : true],
				type: [item.type ? item.type : null],
				validatorEmail: [
					item.validatorEmail ? item.validatorEmail : null,
					[Validators.required, Validators.email, Validators.pattern(/.+@deloitte\.com$/i)]
				],
				description: [
					item.description ? item.description : null,
					[Validators.required, Validators.maxLength(500)]
				],
				isAlternative: [item.isAlternative],
				showEmailList: [false],
				emailList: []
			});
			this.emailChangeSubscriptions$.push(validatorEmailObserver(newGroup, this.employeeApiService));
			return newGroup;
		});
	}

	modalWithdraw() {
		const modal = { ...modalWithdraw };
		modal.actionForAceptButton = this.changeBadgeStatus.bind(this);
		this.modal.open(ModalComponent, { modal });
	}

	changeBadgeStatus() {
		this.badgeApiService.updateBadgeEvidence({ id: this.badgeId, status: BadgeStatus.Withdrawn }).subscribe(() => {
			this.modal.close();
			sessionStorage.removeItem('withdraw');
			history.back();
		});
	}

	returnListBadge() {
		if (!this.isAbleToEdit) {
			this.goTo();
			return;
		}

		const modal = { ...modalReturnList };
		modal.actionForAceptButton = this.draftBadge.bind(this, false);
		modal.actionForCancelButton = this.goTo.bind(this);

		// TODO: if the badge has this status SubmittedForApproval the modal wording should change
		if (this.badgeApprovalStatus === BadgeStatus.SubmittedForApproval) {
			modal.hideAceptBtn = true;
		}

		this.modal.open(ModalComponent, { modal });
	}

	submitBadge() {
		this.saveButton.isLoading = true;
		this.draftButton.isDisabled = true;

		const modal = { ...modalSubmit };
		modal.title = this.badgeName;
		modal.contentText =
			this.selectedPath == this.pathValues['alternate']
				? this.alternateCriteriaModalText
				: this.standardCriteriaModalText;
		modal.actionForAceptButton = this.submit.bind(this);
		modal.actionForCancelButton = this.modal.closeAll.bind(this);

		this.newRegistry = {
			id: this.badgeId,
			status:
				this.badgeApprovalStatus == BadgeStatus.Initiated ||
				this.badgeApprovalStatus == BadgeStatus.InProgress ||
				this.badgeApprovalStatus == BadgeStatus.AttentionRequired
					? BadgeStatus.SubmittedForApproval
					: this.badgeApprovalStatus
		};

		this.newRegisterService.setNewRegister(this.newRegistry);
		this.draftBadge(false, true);
		this.modal.open(ModalComponent, { modal });
	}

	private submit() {
		this.badgeApiService.updateBadgeEvidence(this.createBodyToSave(true)).subscribe({
			next: () => {},
			error: (err) => this.cancelBothLoaders(),
			complete: () => {
				this.cancelBothLoaders();
				this.goTo();
			}
		});
	}

	draftBadge(showDraftModal: boolean = true, isSubmit: boolean = false) {
		this.draftButton.isLoading = true;
		this.saveButton.isDisabled = true;

		const modalForDraft = { ...modalDraft };
		modalForDraft.title = this.badgeName;
		modalForDraft.actionForAceptButton = this.goTo.bind(this);

		this.badgeApiService.updateBadgeEvidence(this.createBodyToSave()).subscribe({
			next: () => {
				if (showDraftModal) this.modal.open(ModalComponent, { modal: modalForDraft });
			},
			error: () => this.cancelBothLoaders(),
			complete: () => {
				if (!showDraftModal && !isSubmit) {
					this.modal.closeAll();
					this.modal.open(ModalComponent, { modal: modalForDraft });
				}
				this.cancelBothLoaders();
			}
		});
	}

	private createBodyToSave(isSubmit: boolean = false) {
		const education = isSubmit
			? this.selectedPath == this.pathValues['alternate']
				? [...this.alternateForm.get('education').value]
				: [...this.standardForm.get('education').value]
			: [...this.alternateForm.get('education').value, ...this.standardForm.get('education').value];

		const experience = isSubmit
			? this.selectedPath == this.pathValues['alternate']
				? [...this.alternateForm.get('experience').value]
				: [...this.standardForm.get('experience').value]
			: [...this.alternateForm.get('experience').value, ...this.standardForm.get('experience').value];

		experience.forEach((item: ExperienceCriteria) => {
			let hours;
			if (item.uploadBase64) {
				hours = item.uploadBase64?.fileHours;
				this.backUpHours = hours;
				item.uploadBase64.fileName = item.fileName;
				if (!item.uploadBase64.base64 || item.uploadBase64.base64 == 'data:application') {
					item.uploadBase64 = null;
				}
			}
			if (item.wbsCodeGroup) {
				hours = item.wbsCodeGroup?.hours;
				item.wbsCode = item.wbsCodeGroup?.code;
			}
			item.hours = hours;

			if (item.uploadBase64 === null) item.hours = this.backUpHours;
		});
		const eminence = isSubmit
			? this.selectedPath == this.pathValues['alternate']
				? [...this.alternateForm.get('eminence').value]
				: [...this.standardForm.get('eminence').value]
			: [...this.alternateForm.get('eminence').value, ...this.standardForm.get('eminence').value];

		const body = {
			id: this.badgeId,
			private: true,
			badgeTemplateId: this.badgeTemplateId,
			status: isSubmit ? BadgeStatus.SubmittedForApproval : BadgeStatus.InProgress,
			state: isSubmit ? BadgeStatus.SubmittedForApproval : BadgeStatus.InProgress,
			education,
			experience,
			eminence,
			pathSelected: this.selectedPath,
			alternativeCriteriaSelected: this.radioGroupOptionsInComponent.buttons[1]?.options?.checked
		};
		return body;
	}

	private cancelBothLoaders() {
		this.draftButton.isLoading = false;
		this.draftButton.isDisabled = false;
		this.saveButton.isLoading = false;
		this.saveButton.isDisabled = false;
	}

	showToast(toastToShow: ToastOptions): void {
		toastToShow ? this.toastService.createToast(toastToShow) : '';
	}

	private goTo(route: string = '/badges/') {
		this.modal.closeAll();
		this.router.navigate([`${route}`]);
	}

	changePathModal(pathSelected: { options: { checked: boolean }; value: string }, event: Event) {
		event.preventDefault();
		const modal: ModalValues = { ...switchPatchModal };
		modal.actionForAceptButton = () => this.setPathSelected(pathSelected);
		modal.actionForCancelButton = () => {};
		if (!pathSelected.options.checked) {
			this.modal.open(ModalComponent, { modal });
		}
	}

	private setPathSelected(pathSelected: { options: { checked: boolean }; value: string }) {
		this.selectedPath = this.pathValues[pathSelected.value] as string;
		this.radioGroupOptionsInComponent.buttons.forEach(
			(button) => (button.options.checked = button.value === this.selectedPath)
		);
		this.modal.closeAll();
	}

	ngOnDestroy(): void {
		this.breadCrumbService.setHideBreadcrumbs(false);
		this.emailChangeSubscriptions$.forEach((subs$: Subscription) => subs$.unsubscribe());
	}

	reInitiateBadge(badgeId: string) {
		this.badgeApiService.reinitiateBadge(badgeId).subscribe({
			next: () => {
				this.badgeApiService.newRegistry = this.newRegistry;
				this.router.navigate(['badges']);
			},
			error: (err) => console.warn(err)
		});
	}
}
