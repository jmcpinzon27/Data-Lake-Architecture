import { ToastOptions } from '@usitsdasdesign/dds-ng/toast';
import { Themes } from '@usitsdasdesign/dds-ng/shared';
import { ButtonOptions } from '@usitsdasdesign/dds-ng/button';
import { ModalValues } from '@/core/model/common/actions';

// Toast

export const archivedToastConst: ToastOptions = {
	title: 'This badge has been archived',
	message: `This badge is no longer available to be awarded in the Deloitte Badge Catalog.`,
	lifeTime: 5000,
	position: 'bottom-left',
	closeBtnIcon: 'dds-icon_close',
	isCloseIcon: true,
	customClass: 'simple-toast',
	limit: 5,
	theme: Themes.dark
};

export const attentionRequiredToastConst: ToastOptions = {
	title: 'Attention Required!',
	message: `Your badge submission requires attention for the review process to continue. See details provided`,
	lifeTime: 5000,
	position: 'bottom-left',
	closeBtnIcon: 'dds-icon_close',
	isCloseIcon: true,
	customClass: 'simple-toast',
	limit: 5,
	theme: Themes.dark
};

export const submittedToastConst: ToastOptions = {
	title: 'You have submitted this badge to be approved!',
	message: `You will be notified when the review has been completed.`,
	lifeTime: 5000,
	position: 'bottom-left',
	closeBtnIcon: 'dds-icon_close',
	isCloseIcon: true,
	customClass: 'simple-toast',
	limit: 5,
	theme: Themes.dark
};

export const rejectedToastConst: ToastOptions = {
	title: 'This badge application has been rejected',
	message: `The evidence supplied does not meet the criteria for this badge.`,
	lifeTime: 5000,
	position: 'bottom-left',
	closeBtnIcon: 'dds-icon_close',
	isCloseIcon: true,
	customClass: 'simple-toast',
	limit: 5,
	theme: Themes.dark
};

export const revokedToastConst: ToastOptions = {
	title: 'This badge has been revoked',
	message: `Contact usdeloittecertified@deloitte.com with questions.`,
	lifeTime: 5000,
	position: 'bottom-left',
	closeBtnIcon: 'dds-icon_close',
	isCloseIcon: true,
	customClass: 'simple-toast',
	limit: 5,
	theme: Themes.dark
};

export const approvedToastConst: ToastOptions = {
	title: 'Congratulations! Your badge submission has been approved!',
	message: `Be sure to claim your badge in Credly. From there, you can share it with various social media platforms if desired. \n\nGo to Credly!`,
	lifeTime: 10000,
	position: 'bottom-left',
	closeBtnIcon: 'dds-icon_close',
	isCloseIcon: true,
	customClass: 'simple-toast',
	limit: 5,
	theme: Themes.dark
};

export const expiredToastConst: ToastOptions = {
	title: 'This badge has expired',
	message: `This badge has reached its expiration date. Explore the Deloitte Badge Catalog to discover new badges to pursue.`,
	lifeTime: 5000,
	position: 'bottom-left',
	closeBtnIcon: 'dds-icon_close',
	isCloseIcon: true,
	customClass: 'simple-toast',
	limit: 5,
	theme: Themes.dark
};

export const optionsToastConst: ToastOptions = {
	title: 'Badge',
	message: 'Badge could not save, please complete all required fields before submitting.',
	lifeTime: 6000,
	position: 'bottom-left',
	closeBtnIcon: 'dds-icon_close',
	isCloseIcon: true,
	customClass: 'simple-toast',
	limit: 5,
	theme: Themes.white
};

// End Toast

// Buttons

export let saveButtonOptions: ButtonOptions = {
	theme: Themes.dark,
	isLoading: false,
	isDisabled: false,
	ariaLabel: 'Save and Submit',
	customClass: 'btn-custom-white',
	role: 'button'
};

export let draftButtonOptions: ButtonOptions = {
	theme: Themes.white,
	isLoading: false,
	isDisabled: false,
	ariaLabel: 'Save as a Draft',
	customClass: 'btn-custom-white',
	role: 'button'
};

// End Buttons

// Radio Buttons

export const radioGroupOptions = {
	name: 'group1',
	isRequired: true,
	buttons: [
		{
			options: {
				label: 'Standard Criteria',
				theme: Themes.dark,
				isDisabled: false,
				checked: true
			},
			value: 'standard'
		},
		{
			options: {
				label: 'Alternate Criteria',
				isDisabled: false,
				theme: Themes.dark,
				checked: false
			},
			value: 'alternate'
		}
	]
};

// Modals

export const switchPatchModal: ModalValues = {
	title: 'Switch your criteria path',
	hasFooter: true,
	contentTitle: '',
	contentText: [`You are about to change your criteria path.`, `The criteria you already entered will be saved.`],
	aceptButtonText: 'Yes, switch',
	cancelButtonText: 'Cancel'
};

export const modalWithdraw: ModalValues = {
	title: 'Withdraw Badge',
	hasFooter: true,
	contentTitle: 'Are you sure you want to withdraw from this badge?',
	contentText: [
		`Withdrawing from a badge indicates that you are no longer pursuing the badge.
		This action cannot be undone and will delete any criteria you have completed on the badge submission form.
		You can always “Initiate” this badge again at any time, but any previous progress will not be retained.
		`
	],
	aceptButtonText: 'Yes, withdraw',
	cancelButtonText: 'Cancel',
	actionForCancelButton: () => history.back()
};

export const modalReturnList: ModalValues = {
	title: 'Leave without saving',
	hasFooter: true,
	contentTitle: 'Are you sure you want to leave without saving?',
	contentText: [
		`If you don’t save, you will lose all data entered. Click "Save" so you can finish it later. You will see it in your dashboard with an ‘In Progress’ status!`
	],
	aceptButtonText: 'Save and Close',
	cancelButtonText: 'Close without Saving'
};

export const modalDraft: ModalValues = {
	title: '',
	hasFooter: true,
	hideCancelBtn: true,
	contentTitle: 'You have successfully saved your progress!',
	contentText: ['You can return at any time to continue entering criteria for this badge.'],
	aceptButtonText: 'Close'
};

export const modalSubmit: ModalValues = {
	title: '',
	hasFooter: true,
	contentTitle: 'Are you sure you want to submit this badge?',
	contentText: [''],
	aceptButtonText: 'Submit!',
	cancelButtonText: 'Close'
};
