import { Component } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

@Component({
	selector: 'app-validation',
	templateUrl: './validation.component.html',
	styleUrls: ['./validation.component.scss']
})
export class ValidationComponent {
	idBadgeTemplate: string = '';
	constructor(private _router: ActivatedRoute) {
		this.idBadgeTemplate = this._router.snapshot.paramMap.get('id');
	}
}
