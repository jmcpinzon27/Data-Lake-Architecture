import { ComponentFixture, TestBed } from '@angular/core/testing';

import { BadgeEvidenceCriteriasComponent } from './badge-evidence-criterias.component';

xdescribe('BadgeEvidenceCriteriasComponent', () => {
  let component: BadgeEvidenceCriteriasComponent;
  let fixture: ComponentFixture<BadgeEvidenceCriteriasComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ BadgeEvidenceCriteriasComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(BadgeEvidenceCriteriasComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
