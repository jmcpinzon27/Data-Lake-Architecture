import { NotificationApiService } from '@/core/services/apis';
import { DataGridColumn } from '@/shared/components/data-grid/model';
import { Component, OnInit } from '@angular/core';

@Component({
	selector: 'app-notifications',
	templateUrl: './notifications.component.html',
	styleUrls: ['./notifications.component.scss']
})
export class NotificationsComponent implements OnInit {
	constructor(public service: NotificationApiService) {}

	columns!: Array<DataGridColumn>;
	ngOnInit(): void {
		this.columns = [
			{
				label: 'Title',
				fieldValue: 'title',
				cellTemplateName: '',
				allowOrderBy: true,
				allowFilterText: false,
				allowFilterFixedValues: false,
				selected: false,
				dataType: 'string'
			},
			{
				label: 'Type',
				fieldValue: 'description',
				cellTemplateName: '',
				allowOrderBy: true,
				allowFilterText: false,
				allowFilterFixedValues: false,
				selected: false,
				dataType: 'string'
			},
			{
				label: 'Description',
				fieldValue: 'detail',
				cellTemplateName: '',
				allowOrderBy: true,
				allowFilterText: false,
				allowFilterFixedValues: false,
				selected: false,
				dataType: 'string'
			},
			{
				label: 'Date',
				fieldValue: 'date',
				cellTemplateName: 'dateCell',
				allowOrderBy: true,
				allowFilterText: false,
				allowFilterFixedValues: false,
				selected: false,
				dataType: 'string'
			}
		];
	}

	onEditClick = (row: any) => {};
}
