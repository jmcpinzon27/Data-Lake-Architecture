import { Component, OnInit } from '@angular/core';
import { BlobFileApiService } from '@/core/services/apis';
import { BlobFile } from '@/core/model/common';

@Component({
	selector: 'app-job-aids',
	templateUrl: './job-aids.component.html',
	styleUrls: ['./job-aids.component.scss']
})
export class JobAidsComponent implements OnInit {
	files: BlobFile[] = [] as BlobFile[];
	loading = false;
	constructor(private blobFileApiService: BlobFileApiService) {}

	ngOnInit(): void {
		this.loading = true;
		this.blobFileApiService.getListByPrefix('jobaids').subscribe({
			next: (files) => {
				this.loading = false;
				this.files = files;
			},
			error: (err) => {
				this.loading = false;
				console.error(err); // TODO: how to handle errors
			}
		});
	}

	downloadFile(file: BlobFile) {
		this.blobFileApiService.downloadById(file.idBlob).subscribe({
			next: (blob) => {
				let dataType = blob.type;
				let binaryData = [];
				binaryData.push(blob);
				let downloadLink = document.createElement('a');
				downloadLink.href = window.URL.createObjectURL(new Blob(binaryData, { type: dataType }));
				downloadLink.setAttribute('download', file.nameFile);
				document.body.appendChild(downloadLink);
				downloadLink.click();
			},
			error: (err) => console.error(err) // TODO: how to handle errors
		});
	}
}
