import { ComponentFixture, TestBed } from '@angular/core/testing';

import { JobAidsComponent } from './job-aids.component';

xdescribe('JobAidsComponent', () => {
  let component: JobAidsComponent;
  let fixture: ComponentFixture<JobAidsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ JobAidsComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(JobAidsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
