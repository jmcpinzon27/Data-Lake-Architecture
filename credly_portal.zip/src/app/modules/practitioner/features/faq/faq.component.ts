import { Faq } from '@/core/model/entities';
import { IFaqResp } from '@/core/model/entities/faq';
import { FaqService } from '@/core/services/apis';
import { Component, OnInit } from '@angular/core';
import { AccordionOptions } from '@usitsdasdesign/dds-ng/accordion';
import { ButtonOptions } from '@usitsdasdesign/dds-ng/button';
import { ButtonKind, Size, Themes, WidthState } from '@usitsdasdesign/dds-ng/shared';

@Component({
	selector: 'app-faq',
	templateUrl: './faq.component.html',
	styleUrls: ['./faq.component.scss']
})
export class FaqComponent implements OnInit {
	manageShowByCategory: boolean[] = [];
	faqs: { [key: string]: Faq[] } = {};

	accordionOptions: AccordionOptions = {
		size: Size.lg,
		isDisabled: false,
		isOpen: false,
		isMulti: true
	};

	options: ButtonOptions = {
		theme: Themes.white,
		kind: ButtonKind.primaryLoud,
		size: Size.md,
		width: WidthState.fixed,
		icon: 'dds-icon_arrow-down',
		role: 'button'
	};

	faqsArray : IFaqResp[] = [];
	categories : Set<string>;

	constructor(private faqServices: FaqService) {}

	ngOnInit(): void {
		this.faqServices.getFaqs().subscribe((resp: any) => {
			const { data } = resp;
			this.getCategories(data);
			this.fillCategories(data);
		});
	}

	private getCategories(data: Faq[]) {
		const listOfCategories = data.map(({ category }: Faq) => category.description);
		this.categories = new Set(listOfCategories);
		this.categories.forEach((category: string) => {
			this.faqs[category] = [];
			this.manageShowByCategory.push(false);
		});
	}

	private fillCategories(data: Faq[]) {
		data.forEach(
			(faq: Faq) => (this.faqs[faq.category.description] = [...this.faqs[faq.category.description], faq])
		);

		this.orderByCategories()
	}

	orderByCategories() : void {
		const categoriesArray = Array.from(this.categories)
		this.faqsArray = [];

		for (let index = 0; index < categoriesArray.length; index++) {
				const getCateg : any = categoriesArray[index];
				this.faqsArray.push({
					nameCategory : getCateg,
					info: this.faqs[getCateg],				
				});		
		}
	}
}
