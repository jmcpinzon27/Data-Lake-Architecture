import { BadgeTemplateQuery, BadgeTemplateStatus, BadgeStatus } from '@/core/model/entities';
import { BadgeTemplateApiService, CollectionApiService } from '@/core/services/apis';
import { DataGridColumn } from '@/shared/components/data-grid/model';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { catalogColumns } from '../constants/column-initialized';
import { SessionStoreService } from '@/core/services/store';

@Component({
	selector: 'app-main',
	templateUrl: './main.component.html',
	styleUrls: ['./main.component.scss']
})
export class MainComponent implements OnInit {
	badgeTemplatesApprovedFilter: any = { status: [BadgeTemplateStatus.Accepted], ShowExternals: false };
	columns!: Array<DataGridColumn>;
	collections: string[] = [];
	method: string = '';

	private readonly methodsByRole = {
		admin: 'getBadgesTemplatesAdmin',
		practitioner: 'getBadgeTemplatesPractitioner',
		businessrep: 'getBadgeTemplatesBusinessRep'
	};

	constructor(
		public service: BadgeTemplateApiService,
		public collectionService: CollectionApiService,
		private router: Router,
		private sessionStoreService: SessionStoreService
	) {}

	ngOnInit(): void {
		this.method = this.methodsByRole[this.sessionStoreService.getActiveRole()];
		this.columns = catalogColumns;
		this.collectionService.get().subscribe((data: any) => {
			this.collections = data.data.map((e: any) => {
				return e.name;
			});
		});
	}

	getCollections(valuesFromDatagrid: BadgeTemplateQuery[]) {
		const collections = valuesFromDatagrid.flatMap((badge: BadgeTemplateQuery) => badge.collections || null);
		const setCollections = new Set(collections);
		this.collections = [...setCollections] as Array<string>;
	}

	navigateTo(to: string, isFromCollection: boolean) {
		const url = `/catalog/${isFromCollection ? `collection/${to}` : to}`;
		this.router.navigate([url]);
	}

	preview(rowSelected: BadgeTemplateQuery) {
		const { id, badgeStatusForCurrentUser, badgeIdForCurrentUser } = rowSelected;
		badgeStatusForCurrentUser && badgeStatusForCurrentUser !== BadgeStatus.Withdrawn
			? this.router.navigateByUrl(`badges/validation/${badgeIdForCurrentUser}`)
			: this.navigateTo(`preview/${id}`, false);
	}
}
