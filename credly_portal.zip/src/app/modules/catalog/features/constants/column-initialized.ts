export const catalogColumns = [
	{
		label: 'Badge Title',
		fieldValue: 'name',
		cellTemplateName: '',
		allowOrderBy: true,
		allowFilterText: false,
		allowFilterFixedValues: false,
		selected: false,
		dataType: 'string'
	},
	{
		label: 'Level',
		fieldValue: 'level',
		cellTemplateName: '',
		allowOrderBy: true,
		allowFilterText: false,
		allowFilterFixedValues: false,
		selected: false,
		dataType: 'string'
	},
	{
		label: 'Collection',
		fieldValue: 'collectionsText',
		cellTemplateName: '',
		allowOrderBy: true,
		allowFilterText: false,
		allowFilterFixedValues: false,
		selected: false,
		dataType: 'string'
	},
	{
		label: 'Date Created',
		fieldValue: 'createdAt',
		cellTemplateName: 'dateCell',
		allowOrderBy: true,
		allowFilterText: false,
		allowFilterFixedValues: false,
		selected: false,
		dataType: 'string'
	}
];

export const collectionColumns = [
	{
		label: 'Badge Title',
		fieldValue: 'name',
		cellTemplateName: '',
		allowOrderBy: true,
		allowFilterText: false,
		allowFilterFixedValues: false,
		selected: false,
		dataType: 'string'
	},
	{
		label: 'Level',
		fieldValue: 'level',
		cellTemplateName: '',
		allowOrderBy: true,
		allowFilterText: false,
		allowFilterFixedValues: false,
		selected: false,
		dataType: 'string'
	},
	{
		label: 'Created Date',
		fieldValue: 'createdAt',
		cellTemplateName: 'dateCell',
		allowOrderBy: true,
		allowFilterText: false,
		allowFilterFixedValues: false,
		selected: false,
		dataType: 'string'
	}
];
