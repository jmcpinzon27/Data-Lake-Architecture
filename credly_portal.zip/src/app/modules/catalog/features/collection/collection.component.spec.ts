import { ComponentFixture, TestBed } from '@angular/core/testing';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { CollectionComponent } from './collection.component';
import { RouterTestingModule } from '@angular/router/testing';
import { ToastService } from '@usitsdasdesign/dds-ng/toast';

describe('CollectionComponent', () => {
  let component: CollectionComponent;
  let fixture: ComponentFixture<CollectionComponent>;
  let toastService : ToastService

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CollectionComponent ],
      imports : [ HttpClientTestingModule, RouterTestingModule ],
      providers : [ToastService]
    })
    .compileComponents();

    fixture = TestBed.createComponent(CollectionComponent);
    component = fixture.componentInstance;
    toastService = TestBed.inject(ToastService);
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
