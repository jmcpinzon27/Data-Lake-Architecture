import { BadgeTemplateQuery, BadgeTemplateStatus } from '@/core/model/entities';
import { BadgeTemplateApiService } from '@/core/services/apis';
import { DataGridColumn } from '@/shared/components/data-grid/model';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { catalogColumns, collectionColumns } from '../constants/column-initialized';
import { SessionStoreService } from '@/core/services/store';

@Component({
	selector: 'app-collection',
	templateUrl: './collection.component.html',
	styleUrls: ['./collection.component.scss']
})
export class CollectionComponent implements OnInit {
	private readonly defaultCollectionName: string = 'Deloitte Badge Catalog';
	collectionName: string = '';
	serviceMethod: string = '';
	columns!: Array<DataGridColumn>;

	badgeTemplatesApprovedFilter: any = { status: [BadgeTemplateStatus.Accepted], ShowExternals: false };

	constructor(
		public service: BadgeTemplateApiService,
		private activatedRoute: ActivatedRoute,
		private router: Router,
		private sessionStoreService: SessionStoreService
	) {}

	ngOnInit(): void {
		this.setValues();
	}

	private setValues() {
		this.activatedRoute.params.subscribe((params: any) => {
			this.collectionName = params.id || this.defaultCollectionName;
			this.columns = params.id ? collectionColumns : catalogColumns;
			const activeRole = this.sessionStoreService.getActiveRole();
			this.serviceMethod = activeRole === 'admin' ? 'getCollectionsByName' : 'getBadgeTemplatesPractitioner';
			if (this.collectionName != this.defaultCollectionName) {
				this.badgeTemplatesApprovedFilter.FilterColumns = [
					{
						freeText: true,
						column: 'Collections',
						value: this.collectionName
					}
				];
			}
		});
	}

	preview(rowSelected: BadgeTemplateQuery) {
		const { id } = rowSelected;
		this.router.navigate(['catalog', 'preview', id]);
	}
}
