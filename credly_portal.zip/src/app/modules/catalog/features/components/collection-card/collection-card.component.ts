import { DeepLinksClass } from '@/shared/components/deep-links/class/deep-links.class';
import { Component, EventEmitter, Input, Output } from '@angular/core';
import { Router, UrlSerializer } from '@angular/router';
import { ToastService } from '@usitsdasdesign/dds-ng/toast';
@Component({
	selector: 'app-collection-card',
	template: `
		<section class="collection">
			<p class="collection__title">Deloitte Badges by Collections</p>
			<div class="collection__card-container">
				<ng-container *ngFor="let collection of collections.slice(0, 2); let i = index">					
					<div class="collection__text-container" *ngIf="collection">
						<app-deep-links [isCopyUrl]="true" [urlExternal]="true" (index)="deepLink(collection)"></app-deep-links>
						<p class="collection__subtitle">{{ collection }}</p>
						<span (click)="showMore.emit(collection)" aria-disabled="false" class="dds-link">
							Show me more
						</span>
					</div>
				</ng-container>
			</div>
		</section>
	`,
	styleUrls: ['./collection-card.component.scss']
})
export class CollectionCardComponent {
	@Input()
	collections: string[] = [];

	@Output()
	showMore = new EventEmitter<string>();

	urlTemp : string = '';
	deepLinksClass = new DeepLinksClass(this.toastService);

	constructor(private router: Router, private urlSerializer : UrlSerializer, private toastService: ToastService) {}

	deepLink(to : string) {		
		const urlCollection = `/${true ? `collection/${to}` : to}`;
		const getUrl = this.router.createUrlTree([urlCollection]);
		const url = `${window.location.href}${this.urlSerializer.serialize(getUrl)}`;
		this.deepLinksClass.clipCopy(url)
	}
}
