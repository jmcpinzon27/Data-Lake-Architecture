import { BadgePreviewComponent } from '@/shared/components/badge-preview/badge-preview.component';
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { MsalGuard } from '@azure/msal-angular';
import { CollectionComponent } from './features/collection/collection.component';
import { MainComponent } from './features/main/main.component';

enum AppRoutes {
	List = 'badges-list',
	Main = '',
	Collection = 'collection/:id',
	ViewTemplate = 'preview/:id'
}

const routes: Routes = [
	{
		path: AppRoutes.Main,
		component: MainComponent,
		canActivate: [MsalGuard]
	},
	{
		path: AppRoutes.List,
		component: CollectionComponent,
		canActivate: [MsalGuard]
	},
	{
		path: AppRoutes.Collection,
		component: CollectionComponent,
		canActivate: [MsalGuard]
	},
	{
		path: AppRoutes.ViewTemplate,
		component: BadgePreviewComponent,
		canActivate: [MsalGuard]
	}
];

@NgModule({
	imports: [RouterModule.forChild(routes)],
	exports: [RouterModule]
})
export class CatalogRoutingModule {}
