import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { CatalogRoutingModule } from './catalog-routing.module';
import { SharedModule } from '@/shared/shared.module';
import { SelectModule } from '@usitsdasdesign/dds-ng/select';
import { TabsModule } from '@usitsdasdesign/dds-ng/tabs';
import { MainComponent } from './features/main/main.component';
import { FocusHandlerModule } from '@usitsdasdesign/dds-ng/core/focus-handler';
import { CollectionComponent } from './features/collection/collection.component';
import { CollectionCardComponent } from './features/components/collection-card/collection-card.component';

@NgModule({
	declarations: [MainComponent, CollectionComponent, CollectionCardComponent],
	imports: [CommonModule, CatalogRoutingModule, SharedModule, SelectModule, TabsModule, FocusHandlerModule]
})
export class CatalogModule {}
