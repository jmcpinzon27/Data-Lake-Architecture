import { Injectable } from '@angular/core';
import { Settings } from '@/core/model/common';
import { HttpClient } from '@angular/common/http';

@Injectable({ providedIn: 'root' })
export default class SettingsStoreService {
	private _settings: Settings;

	constructor(private httpClient: HttpClient) {}

	loadSettings(): Promise<Settings> {
		return this.httpClient
			.get<Settings>('./settings.json')
			.toPromise()
			.then((settings) => (this._settings = settings));
	}

	public get settings(): Settings {
		return { ...this._settings };
	}
}
