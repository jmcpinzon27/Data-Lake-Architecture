import { ConnectCredlyStatus, RoleType, Session } from '@/core/model/entities';
import { Injectable } from '@angular/core';
import { FilterColumn, ListRequest, OrderBy } from '@/core/model/common';
import { BehaviorSubject, Observable, forkJoin } from 'rxjs';
import { EmployeeApiService } from '../apis';
import { take } from 'rxjs';
import ProfileApiService from '../apis/profileApiService';
import NotificationApiService from '../apis/notificationApiService';
import { ToastOptions, ToastService } from '@usitsdasdesign/dds-ng/toast';
import { Themes } from '@usitsdasdesign/dds-ng/shared';

@Injectable({ providedIn: 'root' })
export default class SessionStoreService {
	private readonly connectWithCredly: ToastOptions = {
		title: `Connect with Credly`,
		message: `
    You have successfully connected with Credly!`,
		lifeTime: 5000,
		position: 'bottom-left',
		closeBtnIcon: 'dds-icon_close',
		customClass: 'simple-toast',
		isCloseIcon: true,
		limit: 300,
		theme: Themes.white
	};
	private readonly connectWithCredlyError: ToastOptions = {
		title: `Connect with Credly`,
		message: `Something went wrong with the connection with Credly.
    Please refresh and try again`,
		lifeTime: 5000,
		position: 'bottom-left',
		closeBtnIcon: 'dds-icon_close',
		customClass: 'simple-toast',
		isCloseIcon: true,
		limit: 300,
		theme: Themes.white
	};
	private session$: BehaviorSubject<Session | null> = new BehaviorSubject<Session>(null);
	private notifications$: BehaviorSubject<any | null> = new BehaviorSubject<any>(null);
	private isCredlyOptIn$: BehaviorSubject<boolean> = new BehaviorSubject<boolean>(false);
	credlyOptInObs$: Observable<boolean> = this.isCredlyOptIn$.asObservable();

	get getUserRoles() {
		return JSON.parse(localStorage.getItem('userRoles'));
	}

	get UserSession(): Observable<Session> {
		return this.session$.pipe(take(2));
	}

	get NotificationSession(): Observable<Session> {
		return this.notifications$.pipe(take(2));
	}

	filterColumn: Array<FilterColumn> = [];
	orderByFilter: OrderBy = {
		column: '',
		desc: false
	};

	dataRequest: ListRequest = {
		pageSize: 5,
		pageIndex: 1,
		SearchText: '',
		orderBy: this.orderByFilter,
		filterColumns: this.filterColumn
	};

	noRolesToast: ToastOptions = {
		title: `You don't have roles assigned, please contact an administrator`,
		message: ``,
		lifeTime: 5000,
		position: 'bottom-left',
		closeBtnIcon: 'dds-icon_close',
		isCloseIcon: true,
		customClass: 'simple-toast',
		limit: 300,
		theme: Themes.dark
	};

	isConnectedWithCredly: boolean = false;

	constructor(
		protected employeeApiService: EmployeeApiService,
		protected profileApiService: ProfileApiService,
		protected notificationApiService: NotificationApiService,
		private toastService: ToastService
	) {}

	loadSession(account: any): void {
		forkJoin({
			userSession: this.employeeApiService.getUserSession(),
			profile: this.profileApiService.getProfile()
		}).subscribe((response: any) => {
			const session = {
				personID: response.userSession.personID,
				email: account.username,
				name: account.name,
				roles: response.userSession.roles,
				profile: response.profile,
				isAdmin: this.getUserRoles
					? this.getUserRoles.isAdmin
					: response.userSession.roles.includes(RoleType.Admin),
				isBusinessRep: this.getUserRoles
					? this.getUserRoles.isBusinessRep
					: response.userSession.roles.includes(RoleType.BusinessRep),
				isPractitioner: this.getUserRoles
					? this.getUserRoles.isPractitioner
					: response.userSession.roles.includes(RoleType.Practitioner)
			};

			const rolesEnabled = {
				isAdmin: session.isAdmin,
				isBusinessRep: session.isBusinessRep,
				isPractitioner: session.isPractitioner
			};

			this.profileApiService.getProfilePhoto().subscribe((e) => {
				let urlCreator = window.URL || window.webkitURL;
				let imageUrl = urlCreator.createObjectURL(e);
				session.profile.imageUrl = imageUrl;
			});

			this.session$.next(session);

			if (response.userSession.roles.find((e: any) => e == RoleType.Admin)) {
				this.dataRequest.pageSize = 3;
			}

			if (response.userSession.roles.length === 0) {
				this.toastService.createToast(this.noRolesToast);
			}

			this.saveUserRoles(rolesEnabled);
			this.saveUserRole();

			this.notificationApiService.getNotificationsByRole(this.dataRequest).subscribe((notifications: any) => {
				this.notifications$.next(notifications?.data);
			});
			this.isConnectedWithCredly = response.userSession.credlyEmployeeState === ConnectCredlyStatus.Accepted;
			this.changeCredlyOptIn(this.isConnectedWithCredly);
		});
	}

	saveUserRoles(roles: Object) {
		localStorage.setItem('userRoles', JSON.stringify(roles));
	}

	// this methos is used to avoid circular dependency in notificationApiService
	private saveUserRole() {
		localStorage.setItem('role', this.getActiveRole());
	}

	getActiveRole(): 'admin' | 'practitioner' | 'businessrep' {
		const pivotRoles: { [key: string]: 'admin' | 'practitioner' | 'businessrep' } = {
			isAdmin: 'admin',
			isPractitioner: 'practitioner',
			isBusinessRep: 'businessrep'
		};
		const rolesFromObjToArr = Object.entries(this.getUserRoles);
		const arrWithTrueRole = rolesFromObjToArr.filter((e) => e.at(-1)).flat();
		const roleName: string = arrWithTrueRole[0] as string;
		return pivotRoles[roleName];
	}

	changeCredlyOptIn(newValue: boolean) {
		this.isCredlyOptIn$.next(newValue);
		if (!this.isConnectedWithCredly && newValue) this.toastService.createToast(this.connectWithCredly);
	}
}
