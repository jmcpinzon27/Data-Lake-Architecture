import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';
import { BadgeTemplateApiService } from '../apis';
import { BadgeTemplate } from '../../model/entities';

@Injectable({ providedIn: 'root' })
export default class BadgeTemplateStoreService {
	private entitySubject: BehaviorSubject<BadgeTemplate> = new BehaviorSubject<BadgeTemplate>(<BadgeTemplate>{});

	constructor(protected badgeTemplateApiService: BadgeTemplateApiService) {}

	public get entity$(): Observable<BadgeTemplate> {
		return this.entitySubject.asObservable();
	}

	public updateForm(entity: BadgeTemplate) {
		this.entitySubject.next(entity);
	}

	get entityStateLastValue() {
		return this.entitySubject.getValue();
	}
}
