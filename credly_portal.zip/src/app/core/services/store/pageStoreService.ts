import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';

@Injectable({ providedIn: 'root' })
export default class PageStoreService {
	private badgesActiveTabIndex$: BehaviorSubject<number> = new BehaviorSubject<number>(0);

	constructor() {}

	public get badgesActiveTabIndex(): Observable<number> {
		return this.badgesActiveTabIndex$.pipe();
	}

	public setBadgesActiveTabIndex(index: number) {
		this.badgesActiveTabIndex$.next(index);
	}
}
