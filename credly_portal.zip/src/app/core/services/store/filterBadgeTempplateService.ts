import { Injectable } from '@angular/core';
import { Observable, BehaviorSubject, Subject } from 'rxjs';
import { MultiSelectItem } from '@usitsdasdesign/dds-ng/multi-select';

@Injectable({
	providedIn: 'root'
})
export default class FilterBadgeTemplateService {
	private refreshResults$ = new Subject<void>();
	private skills$ = new BehaviorSubject<{ icon: string; label: string }[]>([{ icon: '', label: '' }]);
	private selectedSkillFromStorage = JSON.parse(sessionStorage.getItem('selectedSkills'));
	private selectedSkills$ = new BehaviorSubject<MultiSelectItem[] | string[]>(
		this.selectedSkillFromStorage ? this.selectedSkillFromStorage : []
	);
	private levels$ = new BehaviorSubject<{ icon: string; label: string }[]>([{ icon: '', label: '' }]);
	private selectedLevelsFromStorage = JSON.parse(sessionStorage.getItem('selectedLevels'));
	private selectedLevels$ = new BehaviorSubject<MultiSelectItem[] | string[]>(
		this.selectedLevelsFromStorage ? this.selectedLevelsFromStorage : []
	);

	private keywordFromStorage = JSON.parse(sessionStorage.getItem('keyword'));
	private keyword$ = new BehaviorSubject<string | string[]>(this.keywordFromStorage ? this.keywordFromStorage : '');

	constructor() {}

	get selectedSkills(): Observable<MultiSelectItem[] | string[]> {
		return this.selectedSkills$.asObservable();
	}

	setSelectedSkills(selectedSkills: MultiSelectItem[] | string[]): void {
		this.selectedSkills$.next(selectedSkills);
		sessionStorage.setItem('selectedSkills', JSON.stringify(selectedSkills));
	}

	get skills(): Observable<{ icon: string; label: string }[]> {
		return this.skills$.asObservable();
	}

	setSkills(skills: { icon: string; label: string }[]): void {
		this.skills$.next(skills);
	}

	get selectedLevels(): Observable<MultiSelectItem[] | string[]> {
		return this.selectedLevels$.asObservable();
	}

	setSelectedLevels(selectedLevels: MultiSelectItem[] | string[]): void {
		this.selectedLevels$.next(selectedLevels);
		sessionStorage.setItem('selectedLevels', JSON.stringify(selectedLevels));
	}

	get levels(): Observable<{ icon: string; label: string }[]> {
		return this.levels$.asObservable();
	}

	setLevels(levels: { icon: string; label: string }[]): void {
		this.levels$.next(levels);
	}
	get keyword(): Observable<string | string[]> {
		return this.keyword$.asObservable();
	}

	setKeyword(keyword: string | string[]): void {
		this.keyword$.next(keyword);
		sessionStorage.setItem('keyword', JSON.stringify(keyword));
	}

	get refreshResults(): Observable<void> {
		return this.refreshResults$.asObservable();
	}

	setRefreshResults(): void {
		this.refreshResults$.next();
	}
}
