import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable, Subject } from 'rxjs';
import admin from '@/data/navigation/admin.json';
import businessRep from '@/data/navigation/businessRep.json';
import practitioner from '@/data/navigation/practitioner.json';
import { SessionStoreService } from '@/core/services/store';

@Injectable({
	providedIn: 'root'
})
export default class BreadCrumbService {
	private _breadcrumbs$ = new Subject<Array<NavigationItem>>();
	private _hideBreadcrumbs$ = new BehaviorSubject<boolean>(false);

	userNavigation: Array<NavigationItem>;

	constructor(private sessionService: SessionStoreService) {
		this.sessionService.UserSession.subscribe({
			next: (dataSession) => {
				if (dataSession) {
					this.userNavigation = dataSession.isAdmin
						? admin
						: dataSession.isBusinessRep
						? businessRep
						: practitioner;
					this._breadcrumbs$.next(this.userNavigation);
				}
			}
		});
	}

	get getNavigation(): Observable<Array<NavigationItem>> {
		return this._breadcrumbs$.asObservable();
	}

	get getHideBreadcrumbs(): Observable<boolean> {
		return this._hideBreadcrumbs$.asObservable();
	}

	setHideBreadcrumbs(hide: boolean): void {
		this._hideBreadcrumbs$.next(hide);
	}
}

export interface NavigationItem {
	path: string;
	title: string;
	items?: any;
}
