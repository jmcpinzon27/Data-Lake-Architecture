import { Injectable } from '@angular/core';
import { BehaviorSubject, Subject, Observable, forkJoin } from 'rxjs';
import { EmployeeApiService } from '../apis';
import { map, take } from 'rxjs';
import ProfileApiService from '../apis/profileApiService';
import NotificationApiService from '../apis/notificationApiService';

@Injectable({ providedIn: 'root' })
export default class NewRegisterService {
	private newRegister$: BehaviorSubject<any> = new BehaviorSubject<any>({});

	constructor() {}

	public get getNewRegister(): Observable<any> {
		return this.newRegister$.pipe();
	}

	public setNewRegister(register: any) {
		this.newRegister$.next(register);
	}
}
