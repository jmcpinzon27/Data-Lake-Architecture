import { Injectable } from '@angular/core';
import { Observable, Subject } from 'rxjs';

@Injectable({
	providedIn: 'root'
})
export default class GridService {
	private _updateGrid$ = new Subject<void>();

	constructor() {}

	get updateGrid(): Observable<void> {
		return this._updateGrid$.asObservable();
	}
	setUpdateGrid(): void {
		this._updateGrid$.next();
	}
}
