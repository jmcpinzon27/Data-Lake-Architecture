import { Injectable } from '@angular/core';
import { DomSanitizer } from '@angular/platform-browser';

@Injectable({ providedIn: 'root' })
export class DomSanitizerService {
	private readonly prefix = 'data:image/png;base64,';

	constructor(private sanitizer: DomSanitizer) {}

	imageSanitizer(base64: string) {
		return base64 ? this.sanitizer.bypassSecurityTrustResourceUrl(`${this.prefix}${base64}`) : '';
	}
}
