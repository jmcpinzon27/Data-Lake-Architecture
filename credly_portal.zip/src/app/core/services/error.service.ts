import { Injectable } from '@angular/core';
import { HttpErrorResponse, HttpEvent, HttpHandler, HttpInterceptor, HttpRequest } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { ToastOptions, ToastService } from '@usitsdasdesign/dds-ng/toast';
import { Themes } from '@usitsdasdesign/dds-ng/shared';
import { environment } from 'src/environments/environment.prod';

@Injectable({ providedIn: 'root' })
export class ErrorService implements HttpInterceptor {
	private readonly errorTitle: string = 'Check your task request. Please try again.';

	private readonly errorCodes = {
		error: 400,
		unauthorized: 401,
		serverSide: 500
	};

	errorMessage: string = '';
	urlShouldContainToShowError: string = '';
	isErrorWithCustomMessage: boolean = false;

	errorToast: ToastOptions = {
		title: `Something went wrong.`,
		message: `Your request couldn't be processed.
    If you have any questions please contact support.`,
		lifeTime: 12000,
		position: 'bottom-left',
		closeBtnIcon: 'dds-icon_close',
		isCloseIcon: true,
		customClass: 'simple-toast',
		limit: 300,
		theme: Themes.white
	};

	constructor(private toastService: ToastService) {}

	intercept(request: HttpRequest<unknown>, next: HttpHandler): Observable<HttpEvent<unknown>> {
		return next.handle(request).pipe(
			catchError(({ error, status, url }: HttpErrorResponse) => {
				const toastToShow = { ...this.errorToast };
				this.setUrlToFilter();
				const isValidToShowError = url.includes(this.urlShouldContainToShowError);
				this.isErrorWithCustomMessage = status >= this.errorCodes.error && status < this.errorCodes.serverSide;
				if (this.isErrorWithCustomMessage) this.setMessageError(error, toastToShow);
				if (status !== this.errorCodes.unauthorized && isValidToShowError) {
					this.toastService.createToast(toastToShow);
					return throwError(() => this.errorMessage);
				}
				return throwError(() => null);
			})
		);
	}

	private setUrlToFilter() {
		const splitToFilter = environment.baseUrl.split('.')[0].split('/')[2];
		this.urlShouldContainToShowError = splitToFilter;
	}

	private setMessageError(error: any, toastToShow: ToastOptions) {
		this.errorMessage = '';
		for (let i = 0; i < error?.result?.messages?.length; i++) {
			this.errorMessage += `${error.result?.messages[i]}<br>` || error.errors?.id[0];
		}

		toastToShow.title = this.errorTitle;
		toastToShow.message = `${this.isErrorWithCustomMessage ? this.errorMessage : this.errorToast.message}`;
	}
}
