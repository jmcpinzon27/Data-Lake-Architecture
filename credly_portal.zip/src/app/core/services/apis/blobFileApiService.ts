import { BlobFile, ListResponse } from '@/core/model/common';
import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import ApiResource from './apiResource';
import BaseApiService from './baseApiService';

@Injectable({ providedIn: 'root' })
export default class BlobFileApiService extends BaseApiService<BlobFile, string> {
	constructor(http: HttpClient) {
		super(http, ApiResource.BlobFile);
	}

	getListByPrefix(prefix: string): Observable<BlobFile[]> {
		const params = new HttpParams({ fromObject: { prefix } });

		return this.http.get<BlobFile[]>(`${this.settings.baseUrl}/${this.apiResource}/GetListFile`, {
			params
		});
	}

	downloadById(idBlobFile: string): Observable<any> {
		const params = new HttpParams({ fromObject: { idBlobFile } });

		return this.http.get<any>(`${this.settings.baseUrl}/${this.apiResource}/DownloadFile`, {
			params,
			responseType: 'blob' as 'json'
		});
	}
}
