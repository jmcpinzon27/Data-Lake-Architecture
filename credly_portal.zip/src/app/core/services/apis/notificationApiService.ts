import { ListResponse } from '@/core/model/common';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Notification } from '../../model/entities';
import ApiResource from './apiResource';
import BaseApiService from './baseApiService';

@Injectable({ providedIn: 'root' })
export default class NotificationApiService extends BaseApiService<Notification, string> {
	constructor(http: HttpClient) {
		super(http, ApiResource.Notification);
	}

	getNotificationsByRole(listRequest: any) {
		const role = localStorage.getItem('role');
		const flattenedObj = this.flattenObject(listRequest);
		const params = new HttpParams({ fromObject: flattenedObj });

		return this.http.get<ListResponse<Notification>>(`${this.baseUrl}/${this.apiResource}/query/${role}`, {
			params
		});
	}
}
