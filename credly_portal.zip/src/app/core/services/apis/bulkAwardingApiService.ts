import { ListRequest } from '@/core/model/common/listRequest';
import { Response, ListResponse } from '@/core/model/common';
import BadgeQuery from '@/core/model/entities/badgeQuery';
import BulkAwarding from '@/core/model/entities/bulkAwarding';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Badge } from '../../model/entities';
import ApiResource from './apiResource';
import BaseApiService from './baseApiService';

@Injectable({ providedIn: 'root' })
export default class BulkAwardingApiService extends BaseApiService<BulkAwarding, string> {
	constructor(http: HttpClient) {
		super(http, ApiResource.BulkAwarding, 'admin/Get');
	}

	updateForAdmin(data: BulkAwarding): Observable<BulkAwarding> {
		return this.http.put<BulkAwarding>(`${this.baseUrl}/${this.apiResource}/admin/Update`, data);
	}

	deleteForAdmin(id: string): Observable<void> {
		const params = new HttpParams({ fromObject: { Id: id } });
		return this.http.delete<void>(`${this.baseUrl}/${this.apiResource}/admin/Delete`, { params });
	}

	getById(id: string): Observable<void> {
		return this.http.get<void>(`${this.baseUrl}/${this.apiResource}/${id}`);
	}

	createForAdmin(): Observable<BulkAwarding> {
		return this.http.post<BulkAwarding>(`${this.baseUrl}/${this.apiResource}/admin/Create`, null);
	}

	createForBusinesRep(): Observable<BulkAwarding> {
		return this.http.post<BulkAwarding>(`${this.baseUrl}/${this.apiResource}/businessRep/Create`, null);
	}

	getAllForBusinessRep(listRequest: any): Observable<ListResponse<BulkAwarding>> {
		const params = new HttpParams({ fromObject: listRequest });

		return this.http.get<ListResponse<BulkAwarding>>(`${this.baseUrl}/${this.apiResource}/businessRep/Get`, {
			params
		});
	}

	updateStatus(data: any): Observable<Response<BulkAwarding>> {
		return this.http.put<Response<BulkAwarding>>(`${this.baseUrl}/${this.apiResource}/admin/ChangeStatus`, data);
	}
}
