import { ListResponse } from '@/core/model/common';
import { RoleManagementUser } from '@/core/model/entities';
import { Role } from '@/core/model/entities/roleManagement';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { map, Observable } from 'rxjs';
import ApiResource from './apiResource';
import BaseApiService from './baseApiService';

@Injectable({ providedIn: 'root' })
export default class RoleManagmentService extends BaseApiService<RoleManagementUser, string> {
	newRegistry: any;
	readonly toDetectNew: string = 'employeeId';
	readonly rolesIdent!: any;
	private readonly url = `${this.settings.baseUrl}/${ApiResource.RoleManagement}`;

	availableRoles!: Role[];

	constructor(http: HttpClient) {
		super(http, ApiResource.RoleManagement);
	}

	getRoles() {
		const url = `${this.settings.baseUrl}/Role`;
		this.http
			.get<Role[]>(url)
			.subscribe((resp: Role[]) => (this.availableRoles = resp.filter((value) => value.code !== 'Practitioner')));
	}

	roleAssignament(employeeId: string, roleId: string, isEdit: boolean = false) {
		const body = { employeeId, roleId, name: '', email: '' };
		const verb = isEdit ? 'put' : 'post';
		return this.http[verb](this.url, body);
	}

	deleteRole(employeeId: string, roleId: string) {
		const body = { employeeId, roleId, name: '', email: '' };
		return this.http.delete(this.url, { body });
	}
}
