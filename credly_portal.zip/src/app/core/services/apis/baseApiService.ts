import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Response, ListRequest, ListResponse, Settings } from '../../model/common';
import ApiResource from './apiResource';
import { getSettings } from '@/core/infrastructure/settingsLoader';

type GenericObject = { [key: string]: any };

export default class BaseApiService<T, F> {
	public baseUrl: string;
	public apiResource: ApiResource;
	public settings: Settings;
	public apiExtra: string;

	constructor(protected http: HttpClient, apiResource: ApiResource, apiExtra?: string) {
		this.apiResource = apiResource;
		this.apiExtra = apiExtra;
		this.settings = getSettings();
		this.baseUrl = this.settings.baseUrl;
	}

	flattenObject(obj: GenericObject, prefix = ''): GenericObject {
		if (obj === undefined || obj === null) {
			obj = {};
		}

		return Object.entries(obj).reduce((acc: GenericObject, [key, value]) => {
			const newKey = prefix ? `${prefix}.${key}` : key;
			if (Array.isArray(value)) {
				value.forEach((item, index) => {
					if (typeof item === 'object') {
						const nestedObj = this.flattenObject(item, `${newKey}[${index}]`);
						Object.assign(acc, nestedObj);
					} else {
						if (item !== undefined && item !== null && item != '') {
							acc[`${newKey}[${index}]`] = item;
						}
					}
				});
			} else if (typeof value === 'object' && value !== null) {
				const nestedObj = this.flattenObject(value, newKey);
				Object.assign(acc, nestedObj);
			} else {
				if (value !== undefined && value !== null && value != '') {
					acc[newKey] = value;
				}
			}
			return acc;
		}, {});
	}

	get(request?: any): Observable<ListResponse<T>> {
		const flattenedObj = this.flattenObject(request);

		const params = new HttpParams({ fromObject: flattenedObj });

		let temp;
		if (this.apiExtra) {
			temp = `${this.baseUrl}/${this.apiResource}/${this.apiExtra}`;
		} else {
			temp = `${this.baseUrl}/${this.apiResource}`;
		}
		return this.http.get<ListResponse<T>>(temp, {
			params
		});
	}

	post(data: T): Observable<Response<T>> {
		return this.http.post<Response<T>>(`${this.baseUrl}/${this.apiResource}`, data);
	}

	put(data: T): Observable<Response<T>> {
		return this.http.put<Response<T>>(`${this.baseUrl}/${this.apiResource}`, data);
	}

	delete(id: string): Observable<Response<T>> {
		return this.http.delete<Response<T>>(`${this.baseUrl}/${this.apiResource}/${id}`);
	}

	patch(data: T) {
		return this.http.patch<Response<T>>(`${this.baseUrl}/${this.apiResource}`, data);
	}
}
