enum ApiResource {
	Employee = 'employee',
	BadgeTemplate = 'badgeTemplate',
	Badge = 'Badge',
	Notification = 'Notification',
	Skill = 'Skill',
	Report = 'report',
	BulkAwarding = 'AwardingProcess',
	Collection = 'Collection',
	BadgeTemplateCollection = 'BadgeTemplateCollection',
	RoleManagement = 'EmployeeRole',
	BulkTemp = 'BulkTemp',
	Faq = 'Faq',
	UserActivity = 'UserActivity',
	BlobFile = 'BlobFile',
	GetEmployeesByRole = 'GetEmployeesByRole',
	SystemParams = 'System'
}

export default ApiResource;
