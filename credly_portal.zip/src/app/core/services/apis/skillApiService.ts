import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { BadgeTemplateStatus, Skill } from '../../model/entities';
import ApiResource from './apiResource';
import BaseApiService from './baseApiService';

@Injectable({ providedIn: 'root' })
export default class SkillApiService extends BaseApiService<Skill, string> {
	constructor(http: HttpClient) {
		super(http, ApiResource.Skill);
	}

	getSkillsDistinctByName(): Observable<string[]> {
		const listRequest = { Status: BadgeTemplateStatus.Accepted };
		const flattenedObj = this.flattenObject(listRequest);
		const params = new HttpParams({ fromObject: flattenedObj });
		return this.http.get<string[]>(`${this.baseUrl}/${this.apiResource}/GetSkillsByBadgeTemplateStatus`, {
			params
		});
	}
}
