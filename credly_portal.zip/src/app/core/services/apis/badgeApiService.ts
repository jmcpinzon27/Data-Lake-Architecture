import ListResponse from '@/core/model/common/listResponse';
import BadgeQuery from '@/core/model/entities/badgeQuery';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Badge, BadgeManagement, BadgeStatus, BadgeTemplateQuery } from '../../model/entities';
import ApiResource from './apiResource';
import BaseApiService from './baseApiService';

@Injectable({ providedIn: 'root' })
export default class BadgeApiService extends BaseApiService<Badge, string> {
	newRegistry!: any;
	badge!: BadgeQuery;
	readonly toDetectNew: string = 'badgeTemplateId';

	constructor(http: HttpClient) {
		super(http, ApiResource.Badge);
	}

	getPractitionerBadges(listRequest: any): Observable<ListResponse<BadgeQuery>> {
		const flattenedObj = this.flattenObject(listRequest);

		const params = new HttpParams({ fromObject: flattenedObj });

		return this.http.get<ListResponse<BadgeQuery>>(`${this.baseUrl}/${this.apiResource}/query/practitioner`, {
			params
		});
	}

	getBadgesBusinessRep(listRequest: any): Observable<ListResponse<BadgeQuery>> {
		const flattenedObj = this.flattenObject(listRequest);

		const params = new HttpParams({ fromObject: flattenedObj });

		return this.http.get<ListResponse<BadgeQuery>>(`${this.settings.baseUrl}/badge/query/businessrep`, {
			params
		});
	}

	getBadgesAdmin(listRequest: any): Observable<ListResponse<BadgeQuery>> {
		const flattenedObj = this.flattenObject(listRequest);

		const params = new HttpParams({ fromObject: flattenedObj });

		return this.http.get<ListResponse<BadgeQuery>>(`${this.settings.baseUrl}/badge/query/admin`, {
			params
		});
	}

	getBadgeById(id: string): Observable<Badge> {
		return this.http.get<Badge>(`${this.settings.baseUrl}/Badge/${id}`);
	}

	updateBadge(body: { employeePersonID: string; badgeTemplateId: string }): Observable<BadgeQuery> {
		const url = `${this.settings.baseUrl}/Badge`;
		return this.http.post<BadgeQuery>(url, body);
	}

	updateBadgeEvidence(body: any): Observable<BadgeQuery> {
		const url = `${this.settings.baseUrl}/Badge`;
		return this.http.put<BadgeQuery>(url, body);
	}

	manageBadgeStatus(body: BadgeManagement): Observable<any> {
		const url = `${this.settings.baseUrl}/Badge/admin/status`;
		return this.http.post<any>(url, body);
	}

	changeBadgeStatus(body: { id: string; status: string }) {
		return this.http.post(`${this.settings.baseUrl}/Badge/admin/status`, body);
	}

	reinitiateBadge(badgeRejectedId: string) {
		return this.http.post(`${this.settings.baseUrl}/Badge/practitioner/reinitiate/${badgeRejectedId}`, {});
	}
}
