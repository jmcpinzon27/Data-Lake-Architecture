import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { BadgeTemplateCollection } from '../../model/entities';
import ApiResource from './apiResource';
import BaseApiService from './baseApiService';

@Injectable({ providedIn: 'root' })
export default class BaseTemplateCollectionApiService extends BaseApiService<BadgeTemplateCollection, string> {
	constructor(http: HttpClient) {
		super(http, ApiResource.BadgeTemplateCollection);
	}
}
