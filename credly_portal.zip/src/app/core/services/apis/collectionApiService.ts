import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Collection } from '../../model/entities';
import ApiResource from './apiResource';
import BaseApiService from './baseApiService';

@Injectable({ providedIn: 'root' })
export default class CollectionApiService extends BaseApiService<Collection, string> {
	constructor(http: HttpClient) {
		super(http, ApiResource.Collection);
	}

	getUserSession(): Observable<{ roles: Array<string>; personID: string }> {
		return this.http.get<{ roles: Array<string>; personID: string }>(
			`${this.baseUrl}/${this.apiResource}/userSession`
		);
	}

	getCollectionInfo(CollectionId: string) {
		const url = `${this.settings.baseUrl}/Collection/${CollectionId}`;
		return this.http.get(url);
	}
}
