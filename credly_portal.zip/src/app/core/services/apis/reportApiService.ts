import { AdminSummaryReport } from '@/core/model/entities';
import BadgesByPeriod from '@/core/model/entities/badgesByPeriod';
import PractitionerSummaryReport from '@/core/model/entities/practitionerSummaryReport';
import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { UrlSerializer } from '@angular/router';
import { Observable } from 'rxjs/internal/Observable';
import { getSettings } from '@/core/infrastructure/settingsLoader';
import { Settings } from '@/core/model/common';

@Injectable({ providedIn: 'root' })
export default class ReportApiService {
	private settings: Settings;

	constructor(protected http: HttpClient) {
		this.settings = getSettings();
	}

	getPractitionerSummaryReport(): Observable<PractitionerSummaryReport> {
		return this.http.get<PractitionerSummaryReport>(`${this.settings.baseUrl}/report/practitioner/summary`);
	}

	getAdminSummary(): Observable<AdminSummaryReport> {
		return this.http.get<AdminSummaryReport>(`${this.settings.baseUrl}/report/admin/summary`);
	}

	getBadgesByPeriod(period: number): Observable<Array<BadgesByPeriod>> {
		return this.http.get<Array<BadgesByPeriod>>(`${this.settings.baseUrl}/report/admin/badgesByPeriod/${period}`);
	}
}
