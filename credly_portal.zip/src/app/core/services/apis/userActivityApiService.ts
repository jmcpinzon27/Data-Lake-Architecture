import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Skill } from '../../model/entities';
import ApiResource from './apiResource';
import BaseApiService from './baseApiService';
import { Response, Settings } from '@/core/model/common';

@Injectable({ providedIn: 'root' })
export default class UserActivityApiService extends BaseApiService<Skill, string> {
	constructor(http: HttpClient) {
		super(http, ApiResource.UserActivity);
	}
	
	getFilterUserActivity(filter: string) {
		return this.http.get(`${this.baseUrl}/UserActivity?${filter}`);
	}
}
