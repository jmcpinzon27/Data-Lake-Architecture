import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Employee } from '../../model/entities';
import ApiResource from './apiResource';
import BaseApiService from './baseApiService';
import { ListResponse } from '@/core/model/common';

@Injectable({ providedIn: 'root' })
export default class EmployeeApiService extends BaseApiService<Employee, string> {
	constructor(http: HttpClient) {
		super(http, ApiResource.Employee);
	}

	getUserSession(): Observable<{ roles: Array<string>; personID: string }> {
		return this.http.get<{ roles: Array<string>; personID: string }>(
			`${this.baseUrl}/${this.apiResource}/userSession`
		);
	}

    getByRoles(request?: any): Observable<ListResponse<any>> {
		const flattenedObj = this.flattenObject (request);
		const params = new HttpParams({ fromObject: flattenedObj });
        const temp = `${this.baseUrl}/${this.apiResource}/${ApiResource.GetEmployeesByRole}`
		
		return this.http.get<ListResponse<any>>(temp, {
			params
		});
	}
}
