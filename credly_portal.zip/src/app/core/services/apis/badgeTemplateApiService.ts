import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { BadgeTemplate, BadgeTemplateQuery } from '../../model/entities';
import ApiResource from './apiResource';
import BaseApiService from './baseApiService';
import { ListResponse } from '@/core/model/common';

@Injectable({ providedIn: 'root' })
export default class BadgeTemplateApiService extends BaseApiService<BadgeTemplate, string> {
	constructor(http: HttpClient) {
		super(http, ApiResource.BadgeTemplate);
	}

	getBadgeTemplatesPractitioner(listRequest: any): Observable<ListResponse<BadgeTemplateQuery>> {
		const flattenedObj = this.flattenObject(listRequest);
		const params = new HttpParams({ fromObject: flattenedObj });

		return this.http.get<ListResponse<BadgeTemplateQuery>>(
			`${this.settings.baseUrl}/badgeTemplate/query/practitioner?`,
			{
				params
			}
		);
	}

	getBadgeTemplatesBusinessRep(listRequest: any): Observable<ListResponse<BadgeTemplateQuery>> {
		const flattenedObj = this.flattenObject(listRequest);
		const params = new HttpParams({ fromObject: flattenedObj });

		return this.http.get<ListResponse<BadgeTemplateQuery>>(
			`${this.settings.baseUrl}/badgeTemplate/query/businessrep?`,
			{
				params
			}
		);
	}

	getBadgesTemplatesAdmin(listRequest: any): Observable<ListResponse<BadgeTemplateQuery>> {
		const flattenedObj = this.flattenObject(listRequest);
		const params = new HttpParams({ fromObject: flattenedObj });

		return this.http.get<ListResponse<BadgeTemplateQuery>>(`${this.settings.baseUrl}/badgeTemplate/query/admin?`, {
			params
		});
	}

	changeBadgeTemplateStatus(body: { id: string; status: string }) {
		return this.http.put(`${this.settings.baseUrl}/BadgeTemplate/query/changestatus`, body);
	}

	changeBadgeTemplateArchiveStatus(body: {
		badgeTemplateId: string;
		status: string;
		archiveDate: any;
		result: boolean;
	}) {
		return this.http.patch(`${this.settings.baseUrl}/BadgeTemplate/admin/ArchivingProcess`, body);
	}

	getCollectionsByName(listRequest: any) {
		const flattenedObj = this.flattenObject(listRequest);

		const params = new HttpParams({ fromObject: flattenedObj });

		const url = `${this.settings.baseUrl}/BadgeTemplate/query/admin?`;
		return this.http.get(url, { params });
	}

	getBadgeTemplateInfo(badgeTemplateId: string): Observable<BadgeTemplate> {
		const url = `${this.settings.baseUrl}/BadgeTemplate/${badgeTemplateId}`;
		return this.http.get<BadgeTemplate>(url);
	}

	getBadgeTemplateCriteriaType() {
		const url = `${this.settings.baseUrl}/BadgeTemplate/BadgeTemplateCriteriaType`;
		return this.http.get(url);
	}

	getBadgeTemplateAll(PageSize: number, filters: any) {
		const getRole = localStorage.getItem('role');
		const listRequest = { PageSize, ...filters };
		const flattenedObj = this.flattenObject(listRequest);
		const params = new HttpParams({ fromObject: flattenedObj });
		const url = `${this.settings.baseUrl}/BadgeTemplate/query/${getRole}`;
		return this.http.get(url, { params });
	}

	changePrivacy(params: { isPublic: boolean; id: string; issuer: string }) {
		const url = `${this.settings.baseUrl}/BadgeTemplate/query/changeprivacy`;
		return this.http.put(url, params);
	}

	getSABACourseById(id: string): Observable<BadgeTemplate> {
		return this.http.get<BadgeTemplate>(`${this.settings.baseUrl}/BadgeTemplate/getsabacoursebyid?courseid=/${id}`);
	}
}
