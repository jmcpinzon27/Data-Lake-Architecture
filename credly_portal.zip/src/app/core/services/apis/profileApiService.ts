import { GraphProfile } from '@/core/model/entities';
import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/internal/Observable';
import ApiResource from './apiResource';
import { getSettings } from '@/core/infrastructure/settingsLoader';
import { Settings } from '@/core/model/common';

@Injectable({ providedIn: 'root' })
export default class ProfileApiService {
	private settings: Settings;

	constructor(protected http: HttpClient) {
		this.settings = getSettings();
	}

	getProfile(): Observable<GraphProfile> {
		return this.http.get<GraphProfile>(this.settings.graphUrl);
	}

	getProfilePhoto() {
		return this.http.get(`${this.settings.graphUrl}/photo/$value`, { responseType: 'blob' });
	}
}
