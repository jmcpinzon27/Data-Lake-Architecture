import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import BaseApiService from './baseApiService';
import ApiResource from './apiResource';

@Injectable({ providedIn: 'root' })
export default class SystemParamsService extends BaseApiService<any, any> {
	backendParams: [{ key: string; value: string }] = [] as unknown as [{ key: string; value: string }];
	constructor(http: HttpClient) {
		super(http, ApiResource.SystemParams);
	}

	getParamsFromBack() {
		const url = `${this.settings.baseUrl}/${this.apiResource}/getparameters`;
		this.http.get<[{ key: string; value: string }]>(url).subscribe((resp) => (this.backendParams = resp));
	}
}
