import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/internal/Observable';
import ApiResource from './apiResource';
import BaseApiService from './baseApiService';

@Injectable({ providedIn: 'root' })
export default class RoleApiService extends BaseApiService<any, string> {
	constructor(http: HttpClient) {
		super(http, ApiResource.BulkTemp);
	}

    changeRole(email: string, role: string) :Observable<any> {
        const params = new HttpParams({ fromObject: { email, role } });

        return this.http.get<any>(
			`${this.baseUrl}/${this.apiResource}/changerole`,
            { params }
		);
    }
}