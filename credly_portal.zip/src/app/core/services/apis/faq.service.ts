import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import ApiResource from './apiResource';
import BaseApiService from './baseApiService';
import { ListResponse } from '@/core/model/common';
import Faq from '@/core/model/entities/faq';
import { Observable, of } from 'rxjs';

@Injectable({ providedIn: 'root' })
export default class FaqService extends BaseApiService<any, any> {
	constructor(http: HttpClient) {
		super(http, ApiResource.Faq);
	}

	getFaqs(): Observable<ListResponse<Faq[]>> {
		const listRequest: any = {
			searchText: '',
			pageSize: 10,
			pageIndex: 1,
			orderBy: {
				column: '',
				desc: false
			},
			roles: ''
		};
		const params = new HttpParams({ fromObject: listRequest });
		return this.http.get<ListResponse<Faq[]>>(`${this.baseUrl}/${this.apiResource}/query/all`);
	}
}
