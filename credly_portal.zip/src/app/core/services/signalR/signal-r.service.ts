import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { HubConnection } from '@microsoft/signalr';
import * as signalR from '@microsoft/signalr';
import { Subject, Observable, of, Subscription } from 'rxjs';
import { map } from 'rxjs/operators';
import { Message } from '../../model/common/message';
import { getSettings } from '@/core/infrastructure/settingsLoader';
import { Settings, Notification } from '@/core/model/common';
import { SignalRConnectionInfo } from './signalr-connection-info.model';
import { SessionStoreService } from '../store';

const retryTime = 5000;
@Injectable({ providedIn: 'root' })
export class SignalRService {
	private readonly connectedWithCredlyNotificationType: string = 'employment.connection.accepted'; // used to detect when the user connect with credly if its not connected
	private settings: Settings;
	private _baseUrlNotification: string;
	private _baseUrl: string;
	private _token: string;
	private hubConnection: HubConnection;
	private messages$: Subject<Notification> = new Subject();
	private retrySubs$: Subscription;
	interval: any = null; // Typescript doesnt have a type for an interval - used to store the interval and once it connect, cancel it.

	get messages(): Observable<Notification> {
		return this.messages$.asObservable();
	}

	constructor(private _http: HttpClient, private sessionStoreService: SessionStoreService) {
		this.settings = getSettings();
		this._baseUrlNotification = this.settings.baseUrlNotification;
		this._baseUrl = this.settings.baseUrl;
	}

	private getConnectionInfo(): Observable<SignalRConnectionInfo> {
		let requestUrl = `${this._baseUrl}/Notification/GetAuthorization`;
		return this._http.get<SignalRConnectionInfo>(requestUrl);
	}

	private startInterval() {
		this.interval = setInterval(() => this.getHubConnectionInfo(), retryTime);
	}

	private stopInterval() {
		clearInterval(this.interval);
		this.interval = null;
	}

	private clearSubs() {
		this.retrySubs$?.unsubscribe();
		this.retrySubs$ = null;
		this.hubConnection.off(this._baseUrlNotification);
		this.hubConnection = null;
	}

	init() {
		this.getHubConnectionInfo();
	}

	private getHubConnectionInfo() {
		if (this.retrySubs$) this.clearSubs();

		this.retrySubs$ = this.getConnectionInfo().subscribe({
			next: (info: any) => {
				if (this.interval) this.stopInterval();
				let options = {
					accessTokenFactory: () => info.accessToken,
					transport: signalR.HttpTransportType.LongPolling
				};
				this.hubConnection = new signalR.HubConnectionBuilder()
					.withUrl(this._baseUrlNotification, options)
					.configureLogging(signalR.LogLevel.Information)
					.withAutomaticReconnect([1000, 5000])
					.build();

				this.hubConnection.start().catch((err) => console.error(err.toString()));
				this.hubConnection.on('ReceiveNotification', (data: Notification) => {
					if (data.type === this.connectedWithCredlyNotificationType)
						this.sessionStoreService.changeCredlyOptIn(true);
					else this.messages$.next(data);
				});

				this.hubConnection.onclose(() => this.startInterval());
			},
			error: (er: any) => console.error(er)
		});
	}
}
