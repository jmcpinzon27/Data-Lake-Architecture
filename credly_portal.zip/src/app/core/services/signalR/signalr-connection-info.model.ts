export class SignalRConnectionInfo {
	endpoint: string;
	accessToken: string;
	url: string;
}
