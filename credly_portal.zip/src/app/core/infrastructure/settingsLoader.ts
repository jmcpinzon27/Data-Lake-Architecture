import { Settings } from '../model/common';

var _settings: Settings;

export const loadSettings = (): Promise<Settings> => {
	const time = new Date().getTime();

	return fetch(`./settings.json?=${time}`)
		.then((response) => response.json())
		.then((settings: Settings) => (_settings = settings));
};

export const getSettings = (): Settings => ({ ..._settings });
