import { MsalGuardConfiguration, MsalInterceptorConfiguration } from '@azure/msal-angular';
import {
	BrowserCacheLocation,
	InteractionType,
	IPublicClientApplication,
	LogLevel,
	PublicClientApplication
} from '@azure/msal-browser';
import { getSettings } from '@/core/infrastructure/settingsLoader';

const isIE = window.navigator.userAgent.indexOf('MSIE ') > -1 || window.navigator.userAgent.indexOf('Trident/') > -1; // Remove this line to use Angular Universal

export function loggerCallback(logLevel: LogLevel, message: string) {}

export function MSALInstanceFactory(): IPublicClientApplication {
	const settings = getSettings();

	return new PublicClientApplication({
		auth: {
			clientId: settings.clientId,
			authority: settings.authority,
			redirectUri: '/',
			postLogoutRedirectUri: '/'
		},
		cache: {
			cacheLocation: BrowserCacheLocation.LocalStorage,
			storeAuthStateInCookie: isIE // set to true for IE 11. Remove this line to use Angular Universal
		},
		system: {
			loggerOptions: {
				loggerCallback,
				logLevel: LogLevel.Verbose,
				piiLoggingEnabled: true
			}
		}
	});
}

export function MSALInterceptorConfigFactory(): MsalInterceptorConfiguration {
	const settings = getSettings();
	const protectedResourceMap = new Map<string, Array<string>>();
	protectedResourceMap.set('https://graph.microsoft.com/v1.0/me', ['user.read']);
	protectedResourceMap.set('https://graph.microsoft.com/v1.0/me/photo/$value', ['Contacts.Read, Contacts.ReadWrite']);
	protectedResourceMap.set(settings.baseUrl, [settings.apiScope]);

	return {
		interactionType: InteractionType.Redirect,
		protectedResourceMap
	};
}

export function MSALGuardConfigFactory(): MsalGuardConfiguration {
	return {
		interactionType: InteractionType.Redirect,
		authRequest: {
			scopes: ['user.read']
		},
		loginFailedRoute: '/login-failed'
	};
}
