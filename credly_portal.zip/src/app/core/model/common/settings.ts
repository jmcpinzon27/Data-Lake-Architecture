export default interface Settings {
	baseUrl: string;
	clientId: string;
	authority: string;
	graphUrl: string;
	apiScope: string;
	baseUrlNotification: string;
	credlyRoute: string;
}
