import Result from './result';

export default interface Response<T> {
    result?: Result,
    data: T
}