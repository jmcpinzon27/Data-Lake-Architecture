export default interface Notification {
	type: string;
	title: string;
	description: string;
}
