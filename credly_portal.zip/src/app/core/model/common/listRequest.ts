export interface OrderBy {
	column: string;
	desc: boolean | undefined;
}

export interface FilterColumn {
	column: string;
	value: string | number | boolean;
	freeText: boolean;
}

export interface ListRequest {
	showExternals?: boolean;
	pageSize?: number;
	pageIndex?: number;
	SearchText?: string;
	orderBy: OrderBy;
	filterColumns: Array<FilterColumn>;
	Roles?: string;
}
