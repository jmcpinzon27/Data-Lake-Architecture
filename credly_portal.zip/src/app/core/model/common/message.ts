export class Message {
	sender: string;
	body: string;
}
