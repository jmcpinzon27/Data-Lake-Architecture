export default interface Result {
    hasErros: boolean
    messages: Array<string>
}