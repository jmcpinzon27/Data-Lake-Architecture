export interface Action {
	label: string;
	disabled: boolean;
	icon?: string;
	modal?: ModalValues;
}

export interface ModalValues {
	title: string;
	hasFooter: boolean;
	showFeedback?: boolean;
	showReleaseNotes?: boolean;
	showUnhideBtnReleaseNotes?: boolean;
	hideCancelBtn?: boolean;
	hideAceptBtn?: boolean;
	contentTitle: string;
	contentText: string[];
	aceptButtonText: string;
	cancelButtonText?: string;
	actionForAceptButton?: Function;
	actionForCancelButton?: Function;
	actionForHiddenButton?: Function;
	alignLeft?: boolean;
}
