export default interface File {
	data: string;
	base64: string;
	name: string;
}
