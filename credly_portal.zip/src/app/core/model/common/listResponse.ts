import Response from './response';

export default interface ListResponse<T> extends Response<Array<T>> {
    count: number
}
