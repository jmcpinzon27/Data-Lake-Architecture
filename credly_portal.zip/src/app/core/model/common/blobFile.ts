export default interface BlobFile {
	idBlob: string;
	uri: string;
	nameFile: string;
	contentType: string;
	contentLength: number;
	lastModified: string;
	createdOn: string;
	content?: {
		canRead: boolean;
		canWrite: boolean;
		canSeek: boolean;
		canTimeout: boolean;
		length: number;
		position: number;
		readTimeout: number;
		writeTimeout: number;
	};
}
