const BadgeTemplateMessages: Record<string, string> = {
	ArchiveWithDate: 'This badge is scheduled to be archived on {date}',
	ArchiveWithoutDate: 'This badge is scheduled to be archived'
};

export default BadgeTemplateMessages;
