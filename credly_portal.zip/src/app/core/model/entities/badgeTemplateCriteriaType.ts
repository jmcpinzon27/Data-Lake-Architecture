export default interface BadgeTemplateCriteriaType {
	id?: string;
	description?: string;
}
