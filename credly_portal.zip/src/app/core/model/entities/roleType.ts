enum RoleType {
	Admin = 'Admin',
	Practitioner = 'Practitioner',
	BusinessRep = 'BusinessRep',
	Report = 'Report'
}

export default RoleType;
