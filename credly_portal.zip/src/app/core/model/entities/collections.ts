export default interface Collections {
	id: string;
	badgeTemplateId?: string;
	description?: string;
	name: string;
	numberOfBadges: number;
	dateCreated: string;
	owner: string;
}
