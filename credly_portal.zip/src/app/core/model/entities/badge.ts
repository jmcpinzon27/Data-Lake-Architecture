import { BadgeTemplateStatus, EducationCriteria, BadgeStatus, EminenceCriteria, ExperienceCriteria } from './index';

export default interface Badge {
	alternativeCriteriaSelected: boolean;
	applyReleaseNotesOnlyInitiated: boolean;
	awardedAt: Date;
	badgeTemplateId: string;
	badgeTemplateLastUpdate: Date;
	badgeTemplateReleaseNotes: string;
	badgeTemplateStatus: BadgeTemplateStatus;
	decisionAt: Date;
	education: EducationCriteria[];
	educationApprovedAt: Date;
	educationStatus?: string;
	eminence: EminenceCriteria[];
	eminenceApprovedAt: Date;
	employeePersonID: string;
	experience: ExperienceCriteria[];
	experienceApprovedAt: Date;
	experienceStatus?: string;
	expiresAt: Date;
	exposureStatus: Date;
	externalId: string;
	id: string;
	badgeTemplateHaveAlternativeCriteria: boolean;
	initiatedAt: Date;
	lastFeedback: Date;
	private: boolean;
	state: string;
	status: BadgeStatus;
	submittedAt: Date;
	exposure?: any;
}
