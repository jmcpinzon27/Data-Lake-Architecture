export default interface BadgesByPeriod {
	period: string;
	badgesCount: number;
}
