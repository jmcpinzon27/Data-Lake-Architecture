enum SkillType {
	Core = 'Core',
	Adjacent = 'Adjacent'
}

export default SkillType;
