enum CriteriaType {
	Education = 'Education',
	Experience = 'Experience',
	Eminence = 'Eminence'
}

export default CriteriaType;
