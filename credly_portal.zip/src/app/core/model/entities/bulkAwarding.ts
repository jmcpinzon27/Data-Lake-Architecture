export default interface BulkAwarding {
	id?: string;
	cohortId?: number;
	title?: string;
	badgeTemplate_Id?: string;
	completionDate?: string;
	status?: string;
	createBy?: string;
	createDate?: string;
	approverEmail?: string;
	approver_Id?: string;
	createdBy?: string;
	csvUrlFileBase64?: EvidenceFile | null;
	zipUrlFileBase64?: EvidenceFile | null;
	csvUrlFile?: string;
	zipUrlFile?: string;
	feedback?: string;
}

interface EvidenceFile {
	fileName: string;
	base64: string;
}
