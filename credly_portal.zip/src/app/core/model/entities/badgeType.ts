enum BadgeType {
	Experience = 'Experience',
	Learning = 'Learning',
	Validation = 'Validation',
	Certification = 'Certification'
}

export default BadgeType;
