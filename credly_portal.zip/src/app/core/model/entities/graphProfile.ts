export default interface GraphProfile {
	jobTitle: string;
	imageUrl: string;
	//TODO: add other props
}
