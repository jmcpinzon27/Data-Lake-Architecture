export default interface AdminSummaryReport {
	badgesApproved: number;
	pendingBadges: number;
	badgesTemplatesReviewed: number;
	badgesTemplatesToReview: number;
	unreadBadgeTemplateNotifications: number;
	unreadBadgeNotifications: number;
}
