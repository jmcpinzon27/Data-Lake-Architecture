enum BadgeStatus {
	Initiated = 'Initiated',
	Withdrawn = 'Withdrawn',
	SubmittedForApproval = 'SubmittedForApproval',
	AwaitingApproval = 'AwaitingApproval',
	AttentionRequired = 'AttentionRequired',
	InProgress = 'InProgress',
	Approved = 'Approved',
	Awarded = 'Awarded',
	Revoked = 'Revoked',
	Expired = 'Expired',
	Deleted = 'Deleted',
	Accepted = 'Accepted',
	Rejected = 'Rejected',
	Archived = 'Archived',
    Archive = 'Archive',
    AddArchiveDate = 'AddArchiveDate',
    Unhide = 'Unhide',
	PrivateBadge = 'PrivateBadge'
}

export default BadgeStatus;
