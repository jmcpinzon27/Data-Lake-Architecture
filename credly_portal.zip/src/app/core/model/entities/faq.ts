export default interface Faq {
	id?: string;
	category?: {
		id?: string;
		description?: string;
		order?: number;
	};
	categoryId?: string;
	question?: string;
	answer?: string;
	order?: number;
}

export interface IFaqResp {
	nameCategory?: string;
	info? : Faq[]
}
