import GraphProfile from './graphProfile';

export default interface Session {
	personID: string;
	email: string;
	name: string;
	roles: Array<string>;
	profile: GraphProfile;
	isAdmin: boolean;
	isBusinessRep: boolean;
	isPractitioner: boolean;
}
