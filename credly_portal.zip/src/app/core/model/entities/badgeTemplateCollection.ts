export default interface BadgeTemplateCollection {
	id?: string;
	description?: string;
	name?: string;
	ownerId?: number;
	listOfBadgeTemplateId: Array<any>;
}
