import BadgeTemplateCriteriaType from './badgeTemplateCriteriaType';
import CriteriaType from './criteriaType';

export default interface BadgeTemplateCriteria {
	id?: string;
	badgeTemplateId?: string;
	type: CriteriaType;
	badgeTemplateCriteriaType?: BadgeTemplateCriteriaType;
	title?: string;
	infoUrl?: string;
	description?: string;
	name?: string;
	businessValidation?: any;
	evidenceExpected?: string;
	sabaValidation?: any;
	sabaCourseID?: string | any;
	sabaCourseName?: string | any;
	sabaCourseValidated?: string | any;
	isAlternative?: boolean;
}
