export default interface RoleManagementUser {
	name: string;
	employeeId: string;
	roleId: string;
	roleCode: string;
	email: string;
	startDate: Date;
}

export interface UserInfo {
	name: string;
	role: string;
	roleId?: string;
	jobTitle: string;
	personId?: string;
	email: string;
	img: string;
}

export interface Role {
	id: string;
	code: string;
	description: string;
}
