import SkillType from './skillType';
export default interface Skill {
	id?: string;
	badgeTemplate_Id?: string;
	name?: string;
	skillType?: SkillType;
	skillName?: string;
	proficiency?: number;
}
