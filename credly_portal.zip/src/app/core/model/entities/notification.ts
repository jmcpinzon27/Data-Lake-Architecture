export default interface Notification {
	id: string;
}
