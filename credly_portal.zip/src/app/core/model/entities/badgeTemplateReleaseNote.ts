export default interface BadgeTemplateReleaseNote {
	id?: string;
	notes?: string;
	applyOnlyInitiated?: boolean;
}
