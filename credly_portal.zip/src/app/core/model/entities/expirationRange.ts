enum ExpirationRange {
	None = 'None',
	_1year = '1 Year',
	_2years = '2 Years',
    _3years = '3 Years',
    _4years = '4 Years',
    _5years = '5 Years',
}

export default ExpirationRange;