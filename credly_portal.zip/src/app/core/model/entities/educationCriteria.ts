export default interface EducationCriteria {
	id: string;
	badgeId: string;
	badgeTemplateCriteriaId?: string;
	title: string;
	hours?: number;
	name?: string;
	url?: string;
	fileName?: string;
	uploadBase64?: base64;
	upload: string;
	isAddedByUser?: boolean;
	courseId?: string;
	sabaCourseValidated?: boolean;
	type?: string;
	completionDate: Date | string;
	vendor?: string;
	isAlternative: boolean;
	infoUrl?: string;
	sabaCourseID? : string;
	criteria? : ICriteria;
}

interface base64 {
	filename: string;
	base64: string;
}

interface ICriteria {
    id?:                        string;
    badgeTemplateId?:           string;
    type?:                      string;
    badgeTemplateCriteriaType?: any;
    name?:                      string;
    description?:               string;
    infoUrl?:                   string;
    evidenceExpected?:          string;
    businessValidation?:        boolean;
    deleted?:                   boolean;
    isAlternative?:             boolean | any;
    sabaValidationNeeded?:      boolean | any;
    sabaCourseID?:              string;
    sabaCourseName?:            string;
}
