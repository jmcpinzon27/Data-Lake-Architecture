export default interface Criteria {
	type?: string;
	title?: string;
	url?: string;
	description?: string;
	upload?: string;
}
