export default interface BadgeManagement {
	id: string;
	feedback?: string;
	status: string;
}
