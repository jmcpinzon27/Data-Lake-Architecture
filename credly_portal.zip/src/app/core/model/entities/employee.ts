export default interface Employee {
	personID: string;
	firstName: string;
	lastName: string;
}

export interface Employees {
	data: Array<Employee>;
}

// [PersonID] [uniqueidentifier] NOT NULL,
// 	[PersonnelNumber] [nvarchar](8) NULL,
// 	[PreferredFirstName] [nvarchar](250) NULL,
// 	[FirstName] [nvarchar](250) NULL,
// 	[MiddleName] [nvarchar](250) NULL,
// 	[LastName] [nvarchar](250) NULL,
// 	[Email] [nvarchar](250) NOT NULL,
// 	[OriginalHireDate] [datetime] NULL,
// 	[MostRecentHireDate] [datetime] NULL,
// 	[TerminationDate] [datetime] NULL,
// 	[JobCode] [nvarchar](250) NULL,
// 	[JobCodeDesc] [nvarchar](250) NULL,
// 	[JobLevelCode] [nvarchar](250) NULL,
// 	[JobLevelCodeDesc] [nvarchar](250) NULL,
// 	[CostCenterNumber] [nvarchar](250) NULL,
// 	[BusinessCode] [nvarchar](250) NULL,
// 	[BusinessDesc] [nvarchar](250) NULL,
// 	[BusinessAreaCode] [nvarchar](250) NULL,
// 	[BusinessAreaDesc] [nvarchar](250) NULL,
// 	[BusinessLineCode] [nvarchar](250) NULL,
// 	[BusinessLineDesc] [nvarchar](250) NULL,
// 	[EmployeePracticeCode] [nvarchar](250) NULL,
// 	[EmployeePracticeDesc] [nvarchar](250) NULL,
// 	[CapabilityCode] [nvarchar](250) NULL,
// 	[CapabilityDesc] [nvarchar](250) NULL,
// 	[SubCapabilityCode] [nvarchar](250) NULL,
// 	[SubCapabilityDesc] [nvarchar](250) NULL,
// 	[SubServiceLineCode] [nvarchar](250) NULL,
// 	[SubServiceLineDesc] [nvarchar](250) NULL,
// 	[IsActive] [bit] NULL,
// 	[IsPPD] [bit] NULL,
// 	[IsFederal] [bit] NULL,
// 	[IsUSI] [bit] NULL,
// 	[LastUpdated] [datetime] NULL,
