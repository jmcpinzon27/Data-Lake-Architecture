enum BadgeTemplateStatus {
	Draft = 'Draft',
	AwaitingApproval = 'AwaitingApproval',
	AttentionRequired = 'AttentionRequired',
	Accepted = 'Accepted',
	Rejected = 'Rejected',
	Hidden = 'Hidden',
	Archived = 'Archived',
	Deleted = 'Deleted',
	Submitted = 'Submitted',
	Awarded = 'Awarded',
	HideForEdit = 'HideForEdit',
	HideForArchive = 'HideForArchive',
	Unhide = 'Unhide'
}

export default BadgeTemplateStatus;
