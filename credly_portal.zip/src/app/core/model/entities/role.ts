export default interface Role {
	id: string;
	code: string;
	description: string;
}