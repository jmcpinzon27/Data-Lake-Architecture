enum BadgeLevel {
	Foundation = 'Foundation',
	Intermediate = 'Intermediate',
	Advanced = 'Advanced',
	Luminary = 'Luminary'
}

export default BadgeLevel;
