export interface ICourseSaba {
    id? : string;
    name? : string;
    validated? : boolean;
    error? : boolean
}