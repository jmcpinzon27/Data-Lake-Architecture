import { ListResponse } from '../common';
import Employee from './employee';

export default interface ExperienceCriteria {
	badgeId: string;
	badgeTemplateCriteriaId: string;
	description: string;
	fileName: string;
	id: string;
	title: string;
	upload: string;
	uploadBase64: UploadBase64;
	wbsCode: string;
	wbsCodeGroup: WbsCode;
	url: string;
	validatorEmail: string;
	isAlternative: boolean;
	type: string;

	hours?: string;
	isAddedByUser?: boolean;
	wbsSelected?: boolean | string;
	showEmailList?: boolean;
	emailList?: ListResponse<Employee>;
}

interface UploadBase64 {
	fileHours: string;
	file: string;
	base64?: string;
	fileName?: string;
}

interface WbsCode {
	code: string;
	hours: string;
}
