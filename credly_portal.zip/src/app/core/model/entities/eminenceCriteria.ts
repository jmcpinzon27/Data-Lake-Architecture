import { ListResponse } from '../common';
import Employee from './employee';

export default interface EminenceCriteria {
	badgeId: string;
	badgeTemplateCriteriaId: string;
	description: string;
	fileName: string;
	hours: string;
	id: string;
	title: string;
	upload: string;
	uploadBase64: string;
	url: string;
	type: string;
	validatorEmail: string;
	isAlternative: boolean;

	isAddedByUser?: boolean;
	showEmailList?: boolean;
	emailList?: ListResponse<Employee>;
}
