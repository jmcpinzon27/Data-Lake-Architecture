export default interface LogoBadge {
	prefix?: string;
	fileName?: string;
	base64?: string;
}
