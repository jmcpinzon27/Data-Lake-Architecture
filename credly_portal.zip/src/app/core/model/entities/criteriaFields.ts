export enum CriteriaFields  {
	Description = 'description',
	EvidenceDescription = 'evidenceDescription'
}
