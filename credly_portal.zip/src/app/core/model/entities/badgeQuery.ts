import BadgeStatus from './badgeStatus';
import BadgeTemplateStatus from './badgeTemplateStatus';

export default interface BadgeQuery {
	id: string;
	externalId: string;
	isExternalCert: boolean;
	employeePersonID: string;
	employeeName: string;
	badgeTemplateId: string;
	badgeTemplateName: string;
	badgeTemplateSubtitle: string;
	badgeTemplateDescription: string;
	badgeTemplateType: string;
	badgeTemplateLevel: string;
	badgeTemplateIssuer: string;
	badgeTemplateCollection: string;
	badgeTemplateApproverID: string;
	badgeTemplateApproverName: string;
	badgeTemplateStatus: BadgeTemplateStatus;
	status: BadgeStatus;
	decisionAt: Date;
	awardedAt: Date;
	expiresAt: Date;
	submittedAt: Date;
	educationStatus: string;
	educationApprovedAt: Date;
	experienceStatus: string;
	experienceApprovedAt: Date;
	exposureStatus: string;
	exposureApprovedAt: Date;
}
