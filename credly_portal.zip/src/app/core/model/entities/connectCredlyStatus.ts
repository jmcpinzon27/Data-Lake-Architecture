enum ConnectCredlyStatus {
	Accepted = 'accepted',
	Created = 'created',
	Pending = 'pending',
	Rejected = 'rejected'
}

export default ConnectCredlyStatus;
