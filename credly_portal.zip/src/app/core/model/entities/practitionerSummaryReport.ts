export default interface PractitionerSummaryReport {
	deloitteBadges: number;
	externalBadges: number;
	unreadNotifications: number;
	badgesInProgress: number;
	badgesExpiringSoon: number;
}
