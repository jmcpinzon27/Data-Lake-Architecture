export enum BulkAwardingProcessStatuses {
	Draft = 'Draft',
	Submitted = 'Submitted',
	Approved = 'Approved',
	AttentionRequired = 'AttentionRequired'
}

export enum ReadableStatuses {
	Draft = 'Draft',
	Submitted = 'Submitted',
	Approved = 'Approved',
	AttentionRequired = 'Attention Required'
}

export enum BulkAwardingProcessStatusesNumeric {
	Draft = 1,
	Submitted,
	Approved,
	AttentionRequired
}

export enum BulkAwardingProcessFormTypes {
	Edit = 'edit',
	Create = 'create'
}
