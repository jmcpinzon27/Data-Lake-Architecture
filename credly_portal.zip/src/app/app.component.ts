import { Component, OnInit } from '@angular/core';
import { MsalService, MsalBroadcastService } from '@azure/msal-angular';
import { AuthenticationResult, InteractionStatus, EventMessage, EventType } from '@azure/msal-browser';
import { filter } from 'rxjs/operators';
import { SignalRService } from '@/core/services/signalR/signal-r.service';
import { ToastOptions, ToastService } from '@usitsdasdesign/dds-ng/toast';
import { Themes } from '@usitsdasdesign/dds-ng/shared';
import { RoleManagmentService, SystemParamsService } from './core/services/apis';
import { GridService, SessionStoreService } from './core/services/store';

@Component({
	selector: 'app-root',
	templateUrl: './app.component.html',
	styleUrls: ['./app.component.scss']
})
export class AppComponent implements OnInit {
	notification: ToastOptions = {
		lifeTime: 7000,
		position: 'top-right',
		closeBtnIcon: 'dds-icon_close',
		isCloseIcon: true,
		customClass: 'notification-toast',
		limit: 5,
		theme: Themes.white
	};

	constructor(
		private authService: MsalService,
		private msalBroadcastService: MsalBroadcastService,
		private sessionService: SessionStoreService,
		private signalRService: SignalRService,
		private toastService: ToastService,
		private roleManagmentService: RoleManagmentService,
		private sysParam: SystemParamsService,
		private gridService: GridService
	) {}

	ngOnInit(): void {
		this.signalRService.init();
		this.signalRService.messages.subscribe({
			next: (msg) => {
				this.detectArchived(msg.title);
				this.notification.title = msg.title;
				this.notification.message = msg.description;
				this.toastService.createToast(this.notification);
			}
		});
		this.msalBroadcastService.msalSubject$
			.pipe(filter((msg: EventMessage) => msg.eventType === EventType.LOGIN_SUCCESS))
			.subscribe((result: EventMessage) => {
				const payload = result.payload as AuthenticationResult;
				this.authService.instance.setActiveAccount(payload.account);
			});

		this.msalBroadcastService.inProgress$
			.pipe(filter((status: InteractionStatus) => status === InteractionStatus.None))
			.subscribe(() => {
				if (this.authService.instance.getAllAccounts().length > 0) {
					this.sessionService.loadSession(this.authService.instance.getAllAccounts()[0]);
				} else {
					this.authService.loginRedirect();
				}
			});
		this.setRoles();
		this.sysParam.getParamsFromBack();
	}

	setRoles() {
		this.roleManagmentService.getRoles();
	}

	detectArchived(message: string) {
		if (message?.toLowerCase().includes('archived')) {
			this.gridService.setUpdateGrid();
		}
	}
}
