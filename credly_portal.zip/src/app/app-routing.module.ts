import { NgModule } from '@angular/core';
import { RouterModule, ROUTES } from '@angular/router';
import { FailedComponent } from './modules/failed/failed.component';
import SessionStoreService from './core/services/store/sessionStoreService';
import { MsalGuard } from '@azure/msal-angular';

enum AppRoutes {
	NotFound = 'not-found',
	Employees = 'employees',
	Admin = 'admin',
	Practitioner = 'practitioner'
}

const routerFactory = (sessionService: SessionStoreService) => {
	return [
		{
			path: '',
			loadChildren: async () => {
				let dataSession: any = await sessionService.UserSession.toPromise();

				if (dataSession.isAdmin) {
					return import('./modules/admin/admin.module').then((m) => m.AdminModule);
				} else if (dataSession.isBusinessRep) {
					return import('./modules/bussiness-rep/bussiness-rep.module').then((m) => m.BussinessRepModule);
				} else {
					return import('./modules/practitioner/practitioner.module').then((m) => m.PractitionerModule);
				}
			},
			canActivate: [MsalGuard]
		},
		{
			path: 'login-failed',
			component: FailedComponent
		},
		{
			path: '**',
			redirectTo: AppRoutes.NotFound
		}
	];
};

@NgModule({
	imports: [RouterModule.forRoot([])],
	providers: [{ provide: ROUTES, useFactory: routerFactory, multi: true, deps: [SessionStoreService] }],
	exports: [RouterModule]
})
export class AppRoutingModule {}
