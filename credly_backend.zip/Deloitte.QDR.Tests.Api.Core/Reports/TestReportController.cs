﻿using Deloitte.QDR.Apis.Core.Controllers;
using Deloitte.QDR.BLL;
using Deloitte.QDR.Contracts;
using Deloitte.QDR.DTO.Common;
using Deloitte.QDR.DTO.Reports;
using Deloitte.QDR.Tests.Mocks;
using Xunit;
using Xunit.Gherkin.Quick;

namespace Deloitte.QDR.Tests.Api.Core.Reports
{
    [FeatureFile("./Reports/Features/TestReport.feature")]
    public sealed class TestReportController : Feature
    {
        private readonly ReportController _reportController;
        private AdminSummaryReport _adminSummaryReport;
        private IList<BadgesByPeriodReportItem> _listBadgesByPeriodReportItem;
        private Interval _interval;
        private PractitionerSummaryReport _practitionerSummaryReport;
        private string _personID;

        public TestReportController()
        {
            MapperBootstrapper.Bootstrap();
            var bl = new ReportBL(
                new SessionServiceMock(),
                DbContextMock.GetContext(),
                new DataCacheMock()
            );

            _reportController = new ReportController(bl);
        }

        [When(@"I Get Admin Summary Report")]
        public void I_Get_Admin_Summary_Report() { }

        [Then(@"the response from Admin Summary Report should contain data")]
        public void Then_the_result_should_be_z_on_the_screen()
        {
            _adminSummaryReport = _reportController.GetAdminSummaryReport();
            Assert.Equal(5, _adminSummaryReport.BadgesApproved);
            Assert.Equal(1, _adminSummaryReport.BadgesTemplatesReviewed);
            Assert.Equal(3, _adminSummaryReport.BadgesTemplatesToReview);
            Assert.Equal(1, _adminSummaryReport.PendingBadges);
            Assert.Equal(2, _adminSummaryReport.UnreadBadgeNotifications);
            Assert.Equal(1, _adminSummaryReport.UnreadBadgeTemplateNotifications);
        }

        [Given(@"the (.*) as interval for Get Badges By Period Report")]
        public void I_Get_Admin_Summary_Report(string interval)
        {
            _interval = (Interval)Enum.Parse(typeof(Interval), interval);
        }

        [Then(@"the response should contain (\d+) result")]
        public void Then_the_result_should_be_contains_results(int result)
        {
            _listBadgesByPeriodReportItem = _reportController.GetBadgesByPeriodReport(_interval);
            Assert.Equal(result, _listBadgesByPeriodReportItem.Count);
        }

        [Given(@"the (.*) as personID for Get Practitioner Summary Report")]
        public void Given_personID_for_Get_Practitioner_Summary_Report(string personID)
        {
            _personID = personID;
        }

        [Then(@"the response from Get Practitioner Summary Report should contain data")]
        public void Then_the_response_from_Get_Practitioner_Summary_Report_should_contain_data()
        {
            _practitionerSummaryReport = _reportController.GetPractitionerSummaryReport();
            //  _practitionerSummaryReport = _reportController.GetAdminSummaryReport(_personID);
            Assert.Equal(2, _practitionerSummaryReport.DeloitteBadges);
            Assert.Equal(1, _practitionerSummaryReport.ExternalBadges);
            Assert.Equal(2, _practitionerSummaryReport.UnreadNotifications);
        }
    }
}
