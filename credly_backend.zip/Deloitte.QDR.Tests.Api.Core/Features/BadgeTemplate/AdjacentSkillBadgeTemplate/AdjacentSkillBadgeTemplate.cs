﻿using Deloitte.QDR.BLL;
using Deloitte.QDR.Contracts;
using Deloitte.QDR.Contracts.BL;
using Deloitte.QDR.Contracts.Services;
using Deloitte.QDR.Services;
using Deloitte.QDR.Tests.Mocks;
using Moq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Deloitte.QDR.DTO.Common;
using Xunit;
using Xunit.Gherkin.Quick;

namespace Deloitte.QDR.Tests.Api.Core.Features.BadgeTemplate.AdjacentSkillBadgeTemplate
{
    [FeatureFile("./Features/BadgeTemplate/AdjacentSkillBadgeTemplate/AdjacentSkills.feature")]
    public sealed class AdjacentSkillBadgeTemplate : Feature
    {
        private readonly BadgeTemplateBL _badgeTemplateBL;
        private readonly Mock<INotificationService> _notificationService;
        private DTO.BadgeTemplate _badgeTemplateDto;
        private DTO.Filters.BadgeTemplateFilter _filterBadgeTemplate;
        public AdjacentSkillBadgeTemplate()
        {
            var mockBlobStorageService = new Mock<IBlobStorageService>();
            var mockCredlyApiService = new Mock<ICredlyAPIService>();
            var mockHubService = new Mock<IHubService>();
            var mockBadgeTemplateStatusFlowService = new Mock<BadgeTemplateStatusFlowService>();
            var mockFeedbackService = new Mock<IFeedbackService>();
            var mockSABAService = new Mock<ISABAService>();
            var mockErrorLog = new Mock<IErrorLogBL>();
            _notificationService = new Mock<INotificationService>();

            MapperBootstrapper.Bootstrap();
            _badgeTemplateBL = new BadgeTemplateBL(
                new SessionServiceMock(),
                DbContextMock.GetContext(),
                new DataCacheMock(),
                mockBlobStorageService.Object,
                mockCredlyApiService.Object,
                mockHubService.Object,
                mockBadgeTemplateStatusFlowService.Object,
                _notificationService.Object,
                mockFeedbackService.Object,
                mockSABAService.Object,
                mockErrorLog.Object
            );

            _badgeTemplateDto = new DTO.BadgeTemplate();
        }

        [Given("I'm a practitioner")]
        public void Step1_Set_As_Practitioner()
        {
            _filterBadgeTemplate = new DTO.Filters.BadgeTemplateFilter();
            _filterBadgeTemplate.PageSize = 10;
            _filterBadgeTemplate.PageIndex = 1;
        }
        [When("I enter to the detail screen of a badge")]
        public void Step2_Want_To_See_The_BadgeTemplate()
        {

        }
        [Then("I should not see the (.*) adjacent skills")]
        public void Step3_I_Will_Not_See_The_AdjacentSkills(string skillType)
        {
            
            var result = _badgeTemplateBL.GetBadgeTemplatesQueryPractitioner(_filterBadgeTemplate);
            foreach (var BTPRactitioner in result.Data)
            {
                foreach (var BTType in BTPRactitioner.Skills)
                {
                    Assert.NotEqual(skillType, BTType.SkillType);
                }
            }
        }
    }
}
