﻿using Deloitte.QDR.BLL;
using Deloitte.QDR.Contracts;
using Deloitte.QDR.Contracts.BL;
using Deloitte.QDR.Contracts.Services;
using Deloitte.QDR.Services;
using Deloitte.QDR.Tests.Mocks;
using Moq;
using Xunit;
using Xunit.Gherkin.Quick;
using BadgeTemplateSkill = Deloitte.QDR.DTO.BadgeTemplateSkill;

namespace Deloitte.QDR.Tests.Api.Core.Features.BadgeTemplate.BadgeTemplateWithProficiency;

[FeatureFile("./Features/BadgeTemplate/BadgeTemplateWithProficiency/BadgeTemplateWithProficiency.feature")]
public sealed class BadgeTemplateWithProficiency : Feature
{
    private BadgeTemplateBL _badgeTemplateBl;
    private readonly Mock<INotificationService> _notificationService;
    private DTO.BadgeTemplate _badgeTemplateDto;

    public BadgeTemplateWithProficiency()
    {
        var mockBlobStorageService = new Mock<IBlobStorageService>();
        var mockCredlyApiService = new Mock<ICredlyAPIService>();
        var mockHubService = new Mock<IHubService>();
        var mockBadgeTemplateStatusFlowService = new Mock<BadgeTemplateStatusFlowService>();
        var mockFeedbackService = new Mock<IFeedbackService>();
        var mockSABAService = new Mock<ISABAService>();
        var mockErrorLog = new Mock<IErrorLogBL>();
        _notificationService = new Mock<INotificationService>();

        MapperBootstrapper.Bootstrap();
        _badgeTemplateBl = new BadgeTemplateBL(
            new SessionServiceMock(),
            DbContextMock.GetContext(),
            new DataCacheMock(),
            mockBlobStorageService.Object,
            mockCredlyApiService.Object,
            mockHubService.Object,
            mockBadgeTemplateStatusFlowService.Object,
            _notificationService.Object,
            mockFeedbackService.Object,
            mockSABAService.Object,
            mockErrorLog.Object
        );

        _badgeTemplateDto = new DTO.BadgeTemplate();
    }

    [Given(@"A badge template DTO to create")]
    public void Given_Badge_Template_DTO()
    {
        _badgeTemplateDto.Name = "Test BT With Skills Proficiendy";
        _badgeTemplateDto.Description = "Test BT With Skills Proficiendy";
        _badgeTemplateDto.Status = "Draft";
        _badgeTemplateDto.Skills = new List<BadgeTemplateSkill>
            {
                new BadgeTemplateSkill { SkillName = "Skill 1", Proficiency = 3, SkillType = "Core" },
                new BadgeTemplateSkill { SkillName = "Skill 2", Proficiency = 1, SkillType = "Core" },
                new BadgeTemplateSkill { SkillName = "Skill 3 ", Proficiency = 4, SkillType = "Core" }
            };
    }

    [Then(@"I save the badge template and return all information related with the badge template")]
    public async Task Set_Badge_Template_As_Private()
    {
        var result = await _badgeTemplateBl.CreateAsync(_badgeTemplateDto);
        Assert.NotNull(result);
        Assert.NotEmpty(result.Skills);
        Assert.Equal(_badgeTemplateDto.Skills.Count, result.Skills.Count);
    }
}
