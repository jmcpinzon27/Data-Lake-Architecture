﻿using Deloitte.QDR.BLL;
using Deloitte.QDR.Contracts.Services;
using Deloitte.QDR.Contracts;
using Deloitte.QDR.Services;
using Deloitte.QDR.Tests.Mocks;
using Moq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xunit.Gherkin.Quick;
using Deloitte.QDR.DTO;
using Deloitte.QDR.Contracts.BL;
using Xunit;

namespace Deloitte.QDR.Tests.Api.Core.Features.BadgeTemplate.SetPublicBadgeTemplate
{
    [FeatureFile("./Features/BadgeTemplate/SetPublicBadgeTemplate/SetPublicBadgeTemplate.feature")]
    public sealed class SetPublicBadgeTemplate : Feature
    {
        private BadgeTemplateBL _badgeTemplateBl;
        private readonly Mock<INotificationService> _notificationService;
        private DTO.BadgeTemplate _badgeTemplateDto;

        public SetPublicBadgeTemplate()
        {
            var mockBlobStorageService = new Mock<IBlobStorageService>();
            var mockCredlyApiService = new Mock<ICredlyAPIService>();
            var mockHubService = new Mock<IHubService>();
            var mockBadgeTemplateStatusFlowService = new Mock<BadgeTemplateStatusFlowService>();
            var mockFeedbackService = new Mock<IFeedbackService>();
            _notificationService = new Mock<INotificationService>();
            var mockSABAService = new Mock<ISABAService>();
            var mockErrorLog = new Mock<IErrorLogBL>();

            MapperBootstrapper.Bootstrap();
            _badgeTemplateBl = new BadgeTemplateBL(
                new SessionServiceMock(),
                DbContextMock.GetContext(),
                new DataCacheMock(),
                mockBlobStorageService.Object,
                mockCredlyApiService.Object,
                mockHubService.Object,
                mockBadgeTemplateStatusFlowService.Object,
                _notificationService.Object,
                mockFeedbackService.Object,
                mockSABAService.Object,
                mockErrorLog.Object
            );

            _badgeTemplateDto = new DTO.BadgeTemplate();
        }

        [Given (@"the badge template to validate with (.*) as Id")]
        public void Validate_BadgeTemplate_Id(string Id)
        {
            _badgeTemplateDto.Id = new Guid(Id);
        }
        [When(@"I set (.*) as IsPublic")]
        public void I_set_the_Approved_status(bool isPublic)
        {            
            _badgeTemplateDto.IsPublic = isPublic;
        }

        [Then(@"I click to make public a badge template only in the action column not on the detail screen and it set (.*) as IsPublic")]
        public void Set_Badge_Template_As_Public(bool isPublic) 
        { 
            var result = _badgeTemplateBl.ChangePrivacyAsync( _badgeTemplateDto );
            Assert.Equal(isPublic, result.Result.IsPublic);
        }
    }
}
