﻿using Deloitte.QDR.BLL;
using Deloitte.QDR.Contracts;
using Deloitte.QDR.Contracts.BL;
using Deloitte.QDR.Contracts.Services;
using Deloitte.QDR.DTO.BadgeTemplateFlow;
using Deloitte.QDR.DTO.Common;
using Deloitte.QDR.Entities;
using Deloitte.QDR.Services;
using Deloitte.QDR.Tests.Mocks;
using Moq;
using Xunit;
using Xunit.Gherkin.Quick;

namespace Deloitte.QDR.Tests.Api.Core.Features.BadgeTemplate.ArchiveAdmin
{
    [FeatureFile("./Features/BadgeTemplate/ArchiveAdmin/ArchiveAdmin.feature")]
    public sealed class ArchiveAdmin : Feature
    {
        private BadgeTemplateBL _badgeTemplateBl;
        private Mock<INotificationService> _notificationService;
        private DTO.BadgeTemplate? _badgeTemplateDto;
        private Mock<IStatusFlowValidator<BadgeTemplateStatus>> _badgeTemplateStatusFlowService;
        private Mock<IBlobStorageService> _blobStorageService;
        private Mock<ICredlyAPIService> _credlyAPIService;
        private Mock<IHubService> _hubService;
        private Mock<IFeedbackService> _feedbackService;
        private Mock<ISABAService> _sabaService;
        private Mock<IErrorLogBL> _errorLogBL;

        private Guid _badgeTemplateId;

        public void InitializeConstructor()
        {
            MapperBootstrapper.Bootstrap();

            var mockBadgeTemplateStatusFlowService = new Mock<BadgeTemplateStatusFlowService>();

            _notificationService = new Mock<INotificationService>();
            _badgeTemplateStatusFlowService = new Mock<IStatusFlowValidator<BadgeTemplateStatus>>();
            _blobStorageService = new Mock<IBlobStorageService>();
            _credlyAPIService = new Mock<ICredlyAPIService>();
            _hubService = new Mock<IHubService>();
            _feedbackService = new Mock<IFeedbackService>();
            _sabaService = new Mock<ISABAService>();
            _errorLogBL = new Mock<IErrorLogBL>();

            _badgeTemplateBl = new BadgeTemplateBL(
                new SessionServiceMock(),
                DbContextMock.GetContext(),
                new DataCacheMock(),
                _blobStorageService.Object,
                _credlyAPIService.Object,
                _hubService.Object,
                mockBadgeTemplateStatusFlowService.Object,
                _notificationService.Object,
                _feedbackService.Object,
                _sabaService.Object,
                _errorLogBL.Object
            );

            _badgeTemplateDto = new DTO.BadgeTemplate();
        }

        #region HideForArchiveNoDate

        [Given(@"I'm an admin step1")]
        public void Step1_HideForArchiveNoDate()
        {
            InitializeConstructor();
        }

        [When(@"I pass the badgetemplate (.*)")]
        public void Step2_HideForArchiveNoDate(string id)
        {
            _badgeTemplateId = new Guid(id);
        }

        [Then(@"the badgetemplate is hide for archive status")]
        public async Task Step3_HideForArchiveNoDate()
        {
            var archivingFlow = new ArchivingFlow { BadgeTemplateId = _badgeTemplateId, Status = "Archived" };

            _badgeTemplateStatusFlowService.Setup(t => t.SetAndValidateStatus(It.IsAny<BadgeTemplateStatus>(), It.IsAny<BadgeTemplateStatus>()))
                .Returns(BadgeTemplateStatus.Archived);

            var blobResult = new DTO.Common.BlobFileInfo
            {
                IdBlob = "testBlobId",
                Content = new System.IO.MemoryStream(),
                ContentType = "application/pdf"
            };
            _blobStorageService.Setup(t => t.DownloadBlobFile(It.IsAny<string>())).Returns(Task.FromResult(blobResult));

            _credlyAPIService.Setup(t => t.UpdateBadgeTemplate(It.IsAny<DTO.CredlyAPI.BadgeTemplate>())).ReturnsAsync(new DTO.CredlyAPI.BadgeTemplate());

            var result = await _badgeTemplateBl.ArchivingProcessAsync(archivingFlow, It.IsAny<CancellationToken>());
            Assert.NotNull(result);
            Assert.Equal(result.Status, archivingFlow.Status);
            Assert.Equal(result.ArchiveDate, archivingFlow.ArchiveDate);
        }

        #endregion HideForArchiveNoDate

        #region HideForArchiveDate

        [Given(@"I'm an admin step2")]
        public void Step1_HideForArchiveDate()
        {
            InitializeConstructor();
        }

        [When(@"I pass the badgetemplate (.*)")]
        public void Step2_HideForArchiveDate(string id)
        {
            _badgeTemplateId = new Guid(id);
        }

        [Then(@"the badgetemplate is hide for archive status")]
        public async Task Step3_HideForArchiveDate()
        {
            var archivingFlow = new ArchivingFlow { BadgeTemplateId = _badgeTemplateId, Status = "Archived", ArchiveDate = DateTime.UtcNow };

            _badgeTemplateStatusFlowService.Setup(t => t.SetAndValidateStatus(It.IsAny<BadgeTemplateStatus>(), It.IsAny<BadgeTemplateStatus>()))
                .Returns(BadgeTemplateStatus.Archived);

            var blobResult = new DTO.Common.BlobFileInfo
            {
                IdBlob = "testBlobId",
                Content = new System.IO.MemoryStream(),
                ContentType = "application/pdf"
            };
            _blobStorageService.Setup(t => t.DownloadBlobFile(It.IsAny<string>())).Returns(Task.FromResult(blobResult));

            _credlyAPIService.Setup(t => t.UpdateBadgeTemplate(It.IsAny<DTO.CredlyAPI.BadgeTemplate>())).ReturnsAsync(new DTO.CredlyAPI.BadgeTemplate());

            var result = await _badgeTemplateBl.ArchivingProcessAsync(archivingFlow, It.IsAny<CancellationToken>());
            Assert.NotNull(result);
            Assert.Equal(result.Status, archivingFlow.Status);
            Assert.Equal(result.ArchiveDate, archivingFlow.ArchiveDate);
        }

        #endregion HideForArchiveDate

        #region HideForArchiveInvalidBadgeTemplate

        [Given(@"I'm an admin step3")]
        public void Step1_HideForArchiveInvalidBadgeTemplate()
        {
            InitializeConstructor();
        }

        [When(@"I pass the badgetemplate (.*)")]
        public void Step2_HideForArchiveInvalidBadgeTemplate(string id)
        {
            _badgeTemplateId = new Guid(id);
        }

        [Then(@"the badgetemplate is invalid")]
        public async Task Step3_HideForArchiveInvalidBadgeTemplate()
        {
            var archivingFlow = new ArchivingFlow { BadgeTemplateId = _badgeTemplateId, Status = "Archived", ArchiveDate = DateTime.UtcNow };

            var result = Assert.ThrowsAsync<ValidationException>(async () => await _badgeTemplateBl.ArchivingProcessAsync(archivingFlow, It.IsAny<CancellationToken>()));
            Assert.NotNull(result);
        }

        #endregion HideForArchiveInvalidBadgeTemplate

        #region HideForArchiveSynchronizeWithThePlatform

        [Given(@"I'm an admin step4")]
        public void Step1_HideForArchiveSynchronizeWithThePlatform()
        {
            InitializeConstructor();
        }

        [When(@"I pass the badgetemplate (.*)")]
        public void Step2_HideForArchiveSynchronizeWithThePlatform(string id)
        {
            _badgeTemplateId = new Guid(id);
        }

        [Then(@"the badgetemplate is hide for archive status and synchronized")]
        public async Task Step3_HideForArchiveSynchronizeWithThePlatform()
        {
            var archivingFlow = new ArchivingFlow { BadgeTemplateId = _badgeTemplateId, Status = "Archived" };

            _badgeTemplateStatusFlowService.Setup(t => t.SetAndValidateStatus(It.IsAny<BadgeTemplateStatus>(), It.IsAny<BadgeTemplateStatus>()))
                .Returns(BadgeTemplateStatus.Archived);

            var blobResult = new DTO.Common.BlobFileInfo
            {
                IdBlob = "testBlobId",
                Content = new System.IO.MemoryStream(),
                ContentType = "application/pdf"
            };
            _blobStorageService.Setup(t => t.DownloadBlobFile(It.IsAny<string>())).Returns(Task.FromResult(blobResult));

            _credlyAPIService.Setup(t => t.CreateBadgeTemplate(It.IsAny<DTO.CredlyAPI.BadgeTemplate>())).ReturnsAsync(new DTO.CredlyAPI.BadgeTemplate { Id = Guid.NewGuid() });

            var btResult = await _badgeTemplateBl.GetByIdAsync(_badgeTemplateId);
            var initialExternalId = btResult.ExternalId;

            var result = await _badgeTemplateBl.ArchivingProcessAsync(archivingFlow, It.IsAny<CancellationToken>());
            Assert.NotNull(result);
            Assert.Equal(result.Result, true);

            btResult = await _badgeTemplateBl.GetByIdAsync(_badgeTemplateId);
            Assert.NotEqual(btResult.ExternalId, initialExternalId);


        }

        #endregion HideForArchiveSynchronizeWithThePlatform
    }
}