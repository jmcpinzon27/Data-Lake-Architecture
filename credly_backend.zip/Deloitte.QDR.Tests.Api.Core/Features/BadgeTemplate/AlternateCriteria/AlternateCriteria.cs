﻿using Deloitte.QDR.BLL;
using Deloitte.QDR.Contracts;
using Deloitte.QDR.Contracts.BL;
using Deloitte.QDR.Contracts.Services;
using Deloitte.QDR.Entities;
using Deloitte.QDR.Services;
using Deloitte.QDR.Tests.Mocks;
using Moq;
using Xunit;
using Xunit.Gherkin.Quick;

namespace Deloitte.QDR.Tests.Api.Core.Features.BadgeTemplate.AlternateCriteria
{
    [FeatureFile("./Features/BadgeTemplate/AlternateCriteria/AlternateCriteria.Feature")]
    public sealed class AlternateCriteria : Feature
    {
        private BadgeTemplateBL _badgeTemplateBl;
        private Mock<INotificationService> _notificationService;
        private DTO.BadgeTemplate? _badgeTemplateDto;
        private Mock<IStatusFlowValidator<BadgeTemplateStatus>> _badgeTemplateStatusFlowService;
        private Mock<IBlobStorageService> _blobStorageService;
        private Mock<ICredlyAPIService> _credlyAPIService;
        private Mock<IHubService> _hubService;
        private Mock<IFeedbackService> _feedbackService;
        private Mock<ISABAService> _sabaService;
        private Mock<IErrorLogBL> _errorLogBL;

        private Guid _badgeTemplateId;

        public void InitializeConstructor()
        {
            MapperBootstrapper.Bootstrap();

            var mockBadgeTemplateStatusFlowService = new Mock<BadgeTemplateStatusFlowService>();

            _notificationService = new Mock<INotificationService>();
            _badgeTemplateStatusFlowService = new Mock<IStatusFlowValidator<BadgeTemplateStatus>>();
            _blobStorageService = new Mock<IBlobStorageService>();
            _credlyAPIService = new Mock<ICredlyAPIService>();
            _hubService = new Mock<IHubService>();
            _feedbackService = new Mock<IFeedbackService>();
            _sabaService = new Mock<ISABAService>();
            _errorLogBL = new Mock<IErrorLogBL>();

            _badgeTemplateBl = new BadgeTemplateBL(
                new SessionServiceMock(),
                DbContextMock.GetContext(),
                new DataCacheMock(),
                _blobStorageService.Object,
                _credlyAPIService.Object,
                _hubService.Object,
                mockBadgeTemplateStatusFlowService.Object,
                _notificationService.Object,
                _feedbackService.Object,
                _sabaService.Object,
                _errorLogBL.Object
            );

            _badgeTemplateDto = new DTO.BadgeTemplate();
        }

        #region CreateBTAlternativeCriteria

        [Given(@"I'm an practitioner step1")]
        public void Step1_CreateBTAlternativeCriteria()
        {
            InitializeConstructor();
        }

        [When(@"I pass the badgetemplate (.*)")]
        public void Step2_CreateBTAlternativeCriteria(string id)
        {
            _badgeTemplateId = new Guid(id);
        }

        [Then(@"the badgetemplate is created with alternate criteria")]
        public async Task Step3_CreateBTAlternativeCriteria()
        {
            var btInformation = await _badgeTemplateBl.GetByIdAsync(_badgeTemplateId, It.IsAny<CancellationToken>());
            Assert.NotNull(btInformation);

            var valueToUpdateAlternateCriteria = true;
            var valueToUpdateAlternativeDescription = "New alternative desc";

            _badgeTemplateDto = btInformation;
            _badgeTemplateDto.Id = default;
            _badgeTemplateDto.HaveAlternativeCriteria = valueToUpdateAlternateCriteria;
            _badgeTemplateDto.AlternativeDescription = valueToUpdateAlternativeDescription;
            _badgeTemplateDto.Name = "My new test bt";
            _badgeTemplateDto.Status = "Draft";

            _badgeTemplateStatusFlowService.Setup(t => t.SetAndValidateStatus(It.IsAny<BadgeTemplateStatus>(), It.IsAny<BadgeTemplateStatus>()))
                .Returns(BadgeTemplateStatus.NotCreated);

            var btResult = await _badgeTemplateBl.CreateAsync(_badgeTemplateDto, It.IsAny<CancellationToken>());
            Assert.NotNull(btResult);
            Assert.True(valueToUpdateAlternateCriteria == btResult.HaveAlternativeCriteria);
            Assert.True(valueToUpdateAlternateCriteria == btResult.HaveAlternativeCriteria);
        }

        #endregion CreateBTAlternativeCriteria

        #region UpdateBTAlternativeCriteria

        [Given(@"I'm an practitioner step2")]
        public void Step1_UpdateBTAlternativeCriteria()
        {
            InitializeConstructor();
        }

        [When(@"I pass the badgetemplate (.*)")]
        public void Step2_UpdateBTAlternativeCriteria(string id)
        {
            _badgeTemplateId = new Guid(id);
        }

        [Then(@"the badgetemplate is updated with alternate criteria")]
        public async Task Step3_UpdateBTAlternativeCriteria()
        {
            var btInformation = await _badgeTemplateBl.GetByIdAsync(_badgeTemplateId, It.IsAny<CancellationToken>());
            Assert.NotNull(btInformation);

            var valueToUpdateAlternateCriteria = btInformation.HaveAlternativeCriteria;

            btInformation.Name = "Alternative test Name";
            btInformation.AlternativeDescription = "Alternative test description";

            var newBtInformation = await _badgeTemplateBl.UpdateAsync(btInformation, It.IsAny<CancellationToken>());
            Assert.NotNull(newBtInformation);
            Assert.True(btInformation.AlternativeDescription == newBtInformation.AlternativeDescription);

            var updatedBtInformation = await _badgeTemplateBl.GetByIdAsync(_badgeTemplateId, It.IsAny<CancellationToken>());
            Assert.NotNull(updatedBtInformation);
            Assert.Equal(valueToUpdateAlternateCriteria, updatedBtInformation.HaveAlternativeCriteria);
        }

        #endregion UpdateBTAlternativeCriteria
    }
}