﻿using Deloitte.QDR.BLL;
using Deloitte.QDR.Contracts;
using Deloitte.QDR.Contracts.BL;
using Deloitte.QDR.Contracts.Services;
using Deloitte.QDR.DTO;
using Deloitte.QDR.DTO.CredlyAPI.Common;
using Deloitte.QDR.Infrastructure.Config;
using Deloitte.QDR.Services;
using Deloitte.QDR.Tests.Mocks;
using Moq;
using Xunit;
using Xunit.Gherkin.Quick;

namespace Deloitte.QDR.Tests.Api.Core.Features.Badge.ValidateStatusFlow
{
    [FeatureFile("./Features/Badge/ValidateStatusFlow/StatusFlow.feature")]
    public sealed class StatusFlow : Feature
    {
        private readonly BadgeBL _badgeBL;
        private readonly Mock<IBlobStorageService> _blobStorageService;
        private readonly Mock<BadgeStatusFlowService> _badgeStatusValidatorHelper;
        private readonly Mock<ICredlyAPIService> _credlyAPIService;
        private readonly Mock<ISABAService> _sabaService;
        private readonly Mock<IHubService> _hubService;
        private readonly Mock<INotificationService> _notificationService;
        private readonly Mock<IEmailValidation> _emailValidation;
        private readonly Mock<IFeedbackService> _feedbackService;
        private readonly Mock<ILoginValidationService> _loginValidationService;
        private readonly Mock<IErrorLogBL> _errorLog;
        private BadgeStatusFlow _statusFlow;

        public StatusFlow()
        {
            MapperBootstrapper.Bootstrap();
            _blobStorageService = new Mock<IBlobStorageService>();
            _badgeStatusValidatorHelper = new Mock<BadgeStatusFlowService>();
            _credlyAPIService = new Mock<ICredlyAPIService>();
            _hubService = new Mock<IHubService>();
            _notificationService = new Mock<INotificationService>();
            _feedbackService = new Mock<IFeedbackService>();
            _emailValidation = new Mock<IEmailValidation>();
            _loginValidationService = new Mock<ILoginValidationService>();
            _errorLog = new Mock<IErrorLogBL>();
            _sabaService = new Mock<ISABAService>();
            _badgeBL = new BadgeBL(
                new SessionServiceMock(),
                DbContextMock.GetContext(),
                new DataCacheMock(),
                _blobStorageService.Object,
                _badgeStatusValidatorHelper.Object,
                _credlyAPIService.Object,
                _hubService.Object,
                _notificationService.Object,
                _feedbackService.Object,
                _emailValidation.Object,
                _loginValidationService.Object,
                _sabaService.Object,
                _errorLog.Object
            );
        }

        #region Test StatusFlow_Approved

        [Given(@"I start a paged list request of employees")]
        public void Step1_StatusFlow_Approved()
        {
            _statusFlow = new BadgeStatusFlow();
        }

        [When(@"I send the (.*), (.*), (.*), (.*)")]
        public void Step2_StatusFlow_Approved(string badgeId, string feedback, bool value, string status)
        {
            _statusFlow.Feedback = feedback;
            _statusFlow.Value = value;
            _statusFlow.Id = new Guid(badgeId);
            _statusFlow.Status = status;
        }

        [Then(@"the response should contain (.*) and (.*)")]
        public void Step10_StatusFlow_Approved(string feedbackExpect, string statusExpect)
        {
            var test = new DTO.CredlyAPI.Badge
            {
                Id = new Guid("880ba2bd-7216-4c19-a91d-50718df1b10b"),
            };
            AppSettings.Settings = new Settings { CredlyUrl = "https://sandbox.credly.com/" };
            _credlyAPIService.Setup(x => x.CreateBadge(It.IsAny<CredlyBadgeCreate>())).ReturnsAsync(test);

            var response = _badgeBL.StatusFlowAsync(_statusFlow);

            Assert.NotNull(response);
            Assert.Equal(statusExpect, response.Result.Status.ToString());
            Assert.Equal(feedbackExpect, response.Result.Feedback.ToString());
        }

        #endregion Test StatusFlow_Approved
    }
}
