﻿using Deloitte.QDR.BLL;
using Deloitte.QDR.Contracts;
using Deloitte.QDR.Contracts.BL;
using Deloitte.QDR.Contracts.Services;
using Deloitte.QDR.Services;
using Deloitte.QDR.Tests.Mocks;
using Moq;
using Xunit;
using Xunit.Gherkin.Quick;
using Deloitte.QDR.Contracts.BL;

namespace Deloitte.QDR.Tests.Api.Core.Features.Badge.AlternateCriteria
{
    [FeatureFile("./Features/Badge/AlternateCriteria/GetAlternateCriteria.feature")]
    public sealed class GetAlternateCriteria : Feature
    {
        private readonly BadgeBL _badgeBL;
        private readonly Mock<IBlobStorageService> _blobStorageService;
        private readonly Mock<BadgeStatusFlowService> _badgeStatusValidatorHelper;
        private readonly Mock<ICredlyAPIService> _credlyAPIService;
        private readonly Mock<IHubService> _hubService;
        private readonly Mock<INotificationService> _notificationService;
        private readonly Mock<IFeedbackService> _feedbackService;
        private readonly Mock<IEmailValidation> _emailValidation;
        private readonly Mock<ISABAService> _sabaService;
        private readonly Mock<ILoginValidationService> _loginValidationService;
        private readonly Mock<IErrorLogBL> _errorLog;
        private Guid _badgeId;

        public GetAlternateCriteria()
        {
            MapperBootstrapper.Bootstrap();

            _blobStorageService = new Mock<IBlobStorageService>();
            _badgeStatusValidatorHelper = new Mock<BadgeStatusFlowService>();
            _credlyAPIService = new Mock<ICredlyAPIService>();
            _hubService = new Mock<IHubService>();
            _notificationService = new Mock<INotificationService>();
            _feedbackService = new Mock<IFeedbackService>();
            _emailValidation = new Mock<IEmailValidation>();
            _sabaService = new Mock<ISABAService>();
            _loginValidationService = new Mock<ILoginValidationService>();
            _errorLog = new Mock<IErrorLogBL>();

            _badgeBL = new BadgeBL(
                new SessionServiceMock(),
                DbContextMock.GetContext(),
                new DataCacheMock(),
                _blobStorageService.Object,
                _badgeStatusValidatorHelper.Object,
                _credlyAPIService.Object,
                _hubService.Object,
                _notificationService.Object,
                _feedbackService.Object,
                _emailValidation.Object,
                _loginValidationService.Object,
                _sabaService.Object,
                _errorLog.Object
            );
        }

        [Given(@"I'm an Admin/BR")]
        public void Step1_()
        {
            _badgeId = default;
        }

        [When(@"I open a submitted for approval request (.*) as badgeId")]
        public void Step2_(string badgeId)
        {
            _badgeId = new Guid(badgeId);
        }

        [Then(@"I open a submitted badge application from a practitioner for approval request and will see (.*) as alternativeCriteriaSelected and (.*) as isAlternativeEducation")]
        public void Step3_(bool alternativeCriteriaSelected, bool isAlternativeEducation)
        {
            var result = _badgeBL.GetById(_badgeId);
            Assert.Equal(alternativeCriteriaSelected, result.AlternativeCriteriaSelected);
            foreach (var education in result.Education)
            {
                Assert.Equal(isAlternativeEducation, education.IsAlternative);
            }
        }
    }
}
