﻿using Deloitte.QDR.BLL;
using Deloitte.QDR.Contracts;
using Deloitte.QDR.Contracts.BL;
using Deloitte.QDR.Contracts.Services;
using Deloitte.QDR.Services;
using Deloitte.QDR.Tests.Mocks;
using Moq;
using Xunit;
using Xunit.Gherkin.Quick;
using Deloitte.QDR.Contracts.BL;

namespace Deloitte.QDR.Tests.Api.Core.Features.Badge.SaveShowFeedback
{
    [FeatureFile("./Features/Badge/SaveShowFeedback/GetFeedback.feature")]
    public sealed class GetFeedback : Feature
    {
        private readonly BadgeBL _badgeBL;
        private readonly Mock<IBlobStorageService> _blobStorageService;
        private readonly Mock<BadgeStatusFlowService> _badgeStatusValidatorHelper;
        private readonly Mock<ICredlyAPIService> _credlyAPIService;
        private readonly Mock<IHubService> _hubService;
        private readonly Mock<INotificationService> _notificationService;
        private readonly Mock<IFeedbackService> _feedbackService;
        private readonly Mock<IEmailValidation> _emailValidation;
        private readonly Mock<ISABAService> _sabaService;
        private readonly Mock<ILoginValidationService> _loginValidationService;
        private readonly Mock<IErrorLogBL> _errorLog;
        private Guid _badgeId;

        public GetFeedback()
        {
            MapperBootstrapper.Bootstrap();

            _blobStorageService = new Mock<IBlobStorageService>();
            _badgeStatusValidatorHelper = new Mock<BadgeStatusFlowService>();
            _credlyAPIService = new Mock<ICredlyAPIService>();
            _hubService = new Mock<IHubService>();
            _notificationService = new Mock<INotificationService>();
            _feedbackService = new Mock<IFeedbackService>();
            _emailValidation = new Mock<IEmailValidation>();
            _sabaService = new Mock<ISABAService>();
            _loginValidationService = new Mock<ILoginValidationService>();
            _errorLog = new Mock<IErrorLogBL>();

            _badgeBL = new BadgeBL(
                new SessionServiceMock(),
                DbContextMock.GetContext(),
                new DataCacheMock(),
                _blobStorageService.Object,
                _badgeStatusValidatorHelper.Object,
                _credlyAPIService.Object,
                _hubService.Object,
                _notificationService.Object,
                _feedbackService.Object,
                _emailValidation.Object,
                _loginValidationService.Object,
                _sabaService.Object,
                _errorLog.Object
            );
        }

        #region NotAvailableFeedback

        [Given(@"I start querying a badge")]
        public void Step1_NotAvailableFeedback()
        {
            _badgeId = default;
        }

        [When(@"I pass the badgeId (.*)")]
        public void Step2_NotAvailableFeedback(string badgeId)
        {
            _badgeId = new Guid(badgeId);
        }

        [Then(@"The feedback badge is not available")]
        public void Step3_NotAvailableFeedback()
        {
            var response = _badgeBL.GetById(_badgeId);
            Assert.Null(response.LastFeedback);
        }

        #endregion NotAvailableFeedback

        #region AvailableFeedback

        [Given(@"I start querying a badge with feedback")]
        public void Step1_AvailableFeedback()
        {
            _badgeId = default;
        }

        [When(@"I pass the badgeId (.*)")]
        public void Step2_AvailableFeedback(string badgeId)
        {
            _badgeId = new Guid(badgeId);
        }

        [Then(@"The feedback badge is available")]
        public void Step3_AvailableFeedback()
        {
            Entities.Feedback feedbackMock = new Entities.Feedback { Detail = "Detail test", Date = DateTime.UtcNow };
            _feedbackService.Setup(x => x.GetLastFeedback(It.IsAny<Guid>(), It.IsAny<Entities.EntityType>()))
                .Returns(feedbackMock);

            var response = _badgeBL.GetById(_badgeId);
            Assert.NotNull(response.LastFeedback);
            Assert.True(response.LastFeedback == feedbackMock.Detail);
        }

        #endregion AvailableFeedback
    }
}
