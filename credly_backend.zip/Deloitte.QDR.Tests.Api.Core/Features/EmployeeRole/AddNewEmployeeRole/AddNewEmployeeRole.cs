﻿using Deloitte.QDR.Apis.Core.Controllers;
using Deloitte.QDR.BLL;
using Deloitte.QDR.Contracts;
using Deloitte.QDR.Contracts.Services;
using Deloitte.QDR.DTO.Common;
using Deloitte.QDR.Tests.Mocks;
using Moq;
using Xunit;
using Xunit.Gherkin.Quick;

namespace Deloitte.QDR.Tests.Api.Core.Features.EmployeeRole.AddNewEmployeeRole
{
    [FeatureFile("./Features/EmployeeRole/AddNewEmployeeRole/AddNewEmployeeRole.feature")]
    public sealed class AddNewEmployeeRole : Feature
    {
        private EmployeeRoleController _employeeRoleController;
        private EmployeeRoleBL _employeeRoleBL;

        private DTO.EmployeeRole _employeeRoleDTO;

        public AddNewEmployeeRole()
        {
            MapperBootstrapper.Bootstrap();
        }

        #region Add a new employee_role

        [Given(@"Im the admin")]
        public void Step1_CreateEmployeeRole()
        {
            InitializeConstructor();
        }

        [When(@"I pass the employeeId (.*) also (.*) as roleId")]
        public void Step2_CreateEmployeeRole(string employeeId, string roleId)
        {
            _employeeRoleDTO = new DTO.EmployeeRole
            {
                Email = string.Empty,
                EmployeeId = employeeId,
                Name = string.Empty,
                RoleCode = string.Empty,
                RoleId = new Guid(roleId),
                StartDate = new DateTime()
            };
        }

        [Then(@"I can create new user")]
        public void Step3_CreateEmployeeRole()
        {
            var result = _employeeRoleBL.Create(_employeeRoleDTO);
            Assert.NotNull(result);

            Assert.Equal(_employeeRoleDTO.RoleId, result.RoleId);
            Assert.Equal(_employeeRoleDTO.EmployeeId, result.EmployeeId);
        }

        #endregion Add a new employee_role

        #region Add a new employee_role exception role exists

        [Given(@"Im the admin")]
        public void Step1_CreateEmployeeRoleExceptionRoleExistis()
        {
            InitializeConstructor();
        }

        [When(@"I pass the employeeId (.*) also (.*) as roleId")]
        public void Step2_CreateEmployeeRoleExceptionRoleExistis(string employeeId, string roleId)
        {
            _employeeRoleDTO = new DTO.EmployeeRole
            {
                Email = string.Empty,
                EmployeeId = employeeId,
                Name = string.Empty,
                RoleCode = string.Empty,
                RoleId = new Guid(roleId),
                StartDate = new DateTime()
            };
        }

        [Then(@"I cannot create new user")]
        public void Step3_CreateEmployeeRoleExceptionRoleExistis()
        {
            Assert.Throws<ValidationException>(() => _employeeRoleBL.Create(_employeeRoleDTO));
        }

        #endregion Add a new employee_role exception role exists

        private void InitializeConstructor()
        {
            var cacheServiceMock = new Mock<ICacheService>();
            _employeeRoleBL = new EmployeeRoleBL(
                new SessionServiceMock(),
                DbContextMock.GetContext(),
                new DataCacheMock(),
                cacheServiceMock.Object
            );
            MapperBootstrapper.Bootstrap();
        }
    }
}