﻿using Deloitte.QDR.BLL;
using Deloitte.QDR.Contracts;
using Deloitte.QDR.Contracts.Services;
using Deloitte.QDR.DTO.Common;
using Deloitte.QDR.Services;
using Deloitte.QDR.Tests.Mocks;
using Microsoft.EntityFrameworkCore;
using Moq;
using Xunit;
using Xunit.Gherkin.Quick;

namespace Deloitte.QDR.Tests.Api.Core.Features.EmployeeRole.UpdateEmployeeRole
{
    [FeatureFile("./Features/EmployeeRole/UpdateEmployeeRole/UpdateEmployeeRole.feature")]
    public class UpdateEmployeeRole : Feature
    {
        private EmployeeRoleBL _employeeRoleBL;
        private DTO.EmployeeRole _employeeRoleDTO;

        public UpdateEmployeeRole()
        {
            MapperBootstrapper.Bootstrap();
        }

        #region Update employee_role not removable

        [Given(@"Im the admin")]
        public void Step1_UpdateEmployeeRoleNotRemovable()
        {
            InitializeConstructor();
        }

        [When(@"I pass the employeeId (.*) also (.*) as roleId")]
        public void Step2_UpdateEmployeeRoleNotRemovable(string employeeId, string roleId)
        {
            _employeeRoleDTO = new DTO.EmployeeRole
            {
                EmployeeId = employeeId,
                RoleId = new Guid(roleId)
            };
        }

        [Then(@"I cannot update employeerole notremovable")]
        public void Step3_UpdateEmployeeRoleNotRemovable()
        {
            var result = Assert.Throws<ValidationException>(() => _employeeRoleBL.Update(_employeeRoleDTO));
            Assert.NotNull(result);
            var errorMessage = result.Result.Messages[0];
            Assert.Equal(GeneralConstants.ErrorMessages.ROLE_CANNOT_REMOVED, errorMessage);
        }

        #endregion Update employee_role not removable

        #region Update employee_role Inconsistent

        [Given(@"Im the admin")]
        public void Step1_UpdateEmployeeRolInconsistent()
        {
            InitializeConstructor();
        }

        [When(@"I pass the employeeId (.*) also (.*) as roleId")]
        public void Step2_UpdateEmployeeRoleInconsistent(string employeeId, string roleId)
        {
            _employeeRoleDTO = new DTO.EmployeeRole
            {
                EmployeeId = employeeId,
                RoleId = new Guid(roleId)
            };
        }

        [Then(@"I cannot update employeerole inconsistent")]
        public void Step3_UpdateEmployeeRoleInconsistent()
        {
            var result = Assert.Throws<ValidationException>(() => _employeeRoleBL.Update(_employeeRoleDTO));
            Assert.NotNull(result);
            var errorMessage = result.Result.Messages[0];
            Assert.Equal(GeneralConstants.ErrorMessages.ROLE_INCONSISTENT, errorMessage);
        }

        #endregion Update employee_role Inconsistent

        #region Update employee_role Alreadyexists

        [Given(@"Im the admin")]
        public void Step1_UpdateEmployeeRolAlreadyexists()
        {
            InitializeConstructor();
        }

        [When(@"I pass the employeeId (.*) also (.*) as roleId")]
        public void Step2_UpdateEmployeeRoleAlreadyexists(string employeeId, string roleId)
        {
            _employeeRoleDTO = new DTO.EmployeeRole
            {
                EmployeeId = employeeId,
                RoleId = new Guid(roleId)
            };
        }

        [Then(@"I cannot update employeerole alreadyexists")]
        public void Step3_UpdateEmployeeRoleAlreadyexists()
        {
            var result = Assert.Throws<ValidationException>(() => _employeeRoleBL.Update(_employeeRoleDTO));
            Assert.NotNull(result);
            var errorMessage = result.Result.Messages[0];
            Assert.Equal(GeneralConstants.ErrorMessages.ROLE_ALREADY_EXISTS, errorMessage);
        }

        #endregion Update employee_role Alreadyexists

        #region Update employee_role Sucess

        [Given(@"Im the admin")]
        public void Step1_UpdateEmployeeRolInconsistentSucess()
        {
            InitializeConstructor();
        }

        [When(@"I pass the employeeId (.*) also (.*) as roleId")]
        public void Step2_UpdateEmployeeRoleInconsistentSucess(string employeeId, string roleId)
        {
            _employeeRoleDTO = new DTO.EmployeeRole
            {
                EmployeeId = employeeId,
                RoleId = new Guid(roleId)
            };
        }

        [Then(@"I can update employeerole sucess")]
        public void Step3_UpdateEmployeeRoleInconsistentSucess()
        {
            var result = _employeeRoleBL.Update(_employeeRoleDTO);
            Assert.NotNull(result);
        }

        #endregion Update employee_role Sucess

        private void InitializeConstructor()
        {
            var cacheServiceMock = new Mock<ICacheService>();
            _employeeRoleBL = new EmployeeRoleBL(
                new SessionServiceMock(),
                DbContextMock.GetContext(),
                new DataCacheMock(),
                cacheServiceMock.Object
            );
            MapperBootstrapper.Bootstrap();
        }
    }
}