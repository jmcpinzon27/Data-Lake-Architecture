﻿using Deloitte.QDR.BLL;
using Deloitte.QDR.Contracts;
using Deloitte.QDR.Contracts.Services;
using Deloitte.QDR.DTO.Common;
using Deloitte.QDR.Tests.Mocks;
using Moq;
using Xunit;
using Xunit.Gherkin.Quick;

namespace Deloitte.QDR.Tests.Api.Core.Features.EmployeeRole.DeleteEmployeeRole
{
    [FeatureFile("./Features/EmployeeRole/DeleteEmployeeRole/DeleteEmployeeRole.feature")]
    public class DeleteEmployeeRole : Feature
    {
        private EmployeeRoleBL _employeeRoleBL;

        private DTO.EmployeeRole _employeeRoleDTO;

        public DeleteEmployeeRole()
        {
            MapperBootstrapper.Bootstrap();
        }

        #region Delete employee_role not removable

        [Given(@"Im the admin")]
        public void Step1_DeleteEmployeeRoleNotRemovable()
        {
            InitializeConstructor();
        }

        [When(@"I pass the employeeId (.*) also (.*) as roleId")]
        public void Step2_DeleteEmployeeRoleNotRemovable(string employeeId, string roleId)
        {
            _employeeRoleDTO = new DTO.EmployeeRole
            {
                EmployeeId = employeeId,
                RoleId = new Guid(roleId)
            };
        }

        [Then(@"I cannot delete employeerole")]
        public void Step3_DeleteEmployeeRoleNotRemovable()
        {
            var result = Assert.Throws<ValidationException>(() => _employeeRoleBL.Delete(_employeeRoleDTO));
            Assert.NotNull(result);
            var errorMessage = result.Result.Messages[0];
            Assert.Equal(GeneralConstants.ErrorMessages.ROLE_CANNOT_REMOVED, errorMessage);
        }

        #endregion Delete employee_role not removable

        #region Delete employee_role not exists

        [Given(@"Im the admin")]
        public void Step1_DeleteEmployee_roleNotExists()
        {
            InitializeConstructor();
        }

        [When(@"I pass the employeeId (.*) also (.*) as roleId")]
        public void Step2_DeleteEmployee_roleNotExists(string employeeId, string roleId)
        {
            _employeeRoleDTO = new DTO.EmployeeRole
            {
                EmployeeId = employeeId,
                RoleId = new Guid(roleId)
            };
        }

        [Then(@"I cannot delete employeerolev1")]
        public void Step3_DeleteEmployee_roleNotExists()
        {
            var result = Assert.Throws<ValidationException>(() => _employeeRoleBL.Delete(_employeeRoleDTO));
            Assert.NotNull(result);

            var errorMessage = result.Result.Messages[0];
            Assert.Equal(GeneralConstants.ErrorMessages.ROLE_NOT_EXISTS, errorMessage);
        }

        #endregion Delete employee_role not exists

        #region Delete employee_role

        [Given(@"Im the admin")]
        public void Step1_DeleteEmployee()
        {
            InitializeConstructor();
        }

        [When(@"I pass the employeeId (.*) also (.*) as roleId")]
        public void Step2_DeleteEmployee(string employeeId, string roleId)
        {
            _employeeRoleDTO = new DTO.EmployeeRole
            {
                EmployeeId = employeeId,
                RoleId = new Guid(roleId)
            };
        }

        [Then(@"I cannot delete employeeroleok")]
        public void Step3_DeleteEmployee()
        {
            var result = _employeeRoleBL.Delete(_employeeRoleDTO);
            Assert.NotNull(result);
        }

        #endregion Delete employee_role

        private void InitializeConstructor()
        {
            var cacheServiceMock = new Mock<ICacheService>();
            _employeeRoleBL = new EmployeeRoleBL(
                new SessionServiceMock(),
                DbContextMock.GetContext(),
                new DataCacheMock(),
                cacheServiceMock.Object
            );
            MapperBootstrapper.Bootstrap();
        }
    }
}