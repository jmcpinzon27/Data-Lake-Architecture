﻿using Deloitte.QDR.Apis.Core.Controllers;
using Deloitte.QDR.BLL;
using Deloitte.QDR.Contracts;
using Deloitte.QDR.Contracts.Services;
using Deloitte.QDR.DTO;
using Deloitte.QDR.DTO.Common;
using Deloitte.QDR.Tests.Mocks;
using Moq;
using Xunit;
using Xunit.Gherkin.Quick;

namespace Deloitte.QDR.Tests.Api.Core.Features.AwardingProcess.GetAllAwardingProcess
{
    [FeatureFile("./Features/AwardingProcess/GetAllAwardingProcess/GetAllAwardingProcess.feature")]
    public sealed class GetAllAwardingProcess : Feature
    {
        private AwardingProcessController _awardingProcessController;
        private DTO.AwardingProcess _awardingProcessDTO;
        private FilterBase _filterBase;
        private ListResponse<Deloitte.QDR.DTO.AwardingProcess> _response;

        public GetAllAwardingProcess()
        {
            var mockBlobStorageService = new Mock<IBlobStorageService>();
            var mockHubService = new Mock<IHubService>();   
            var mockFeedbackService = new Mock<IFeedbackService>(); 
            MapperBootstrapper.Bootstrap();
            var bl = new AwardingProcessBL(
                new SessionServiceMock(),
                DbContextMock.GetContext(),
                new DataCacheMock(),
                mockBlobStorageService.Object,
                mockHubService.Object,
                mockFeedbackService.Object
            );
            _awardingProcessController = new AwardingProcessController(bl);
        }

        [Given(@"I start a paged list request of AwardingProcess")]
        public void The_awarding_process_data()
        {
            _filterBase = new FilterBase();
        }

        [And(@"I set (\d+) as page size")]
        public void I_set_z_as_page_size(int pageSize)
        {
            _filterBase.PageSize = pageSize;
        }

        [And(@"I set (\d+) as page index")]
        public void Set_z_as_page_index(int pageIndex)
        {
            _filterBase.PageIndex = pageIndex;
        }

        [Then(@"the response should contain (.*) awarding process")]
        public void the_response_should_contain_all_registers(int expectedResponse)
        {
            _response = _awardingProcessController.GetBulkAwardingProcessBusinessRep(_filterBase).Value;
            Assert.Equal(expectedResponse, _response.Count);
        }
    }
}
