﻿using Castle.Components.DictionaryAdapter.Xml;
using Deloitte.QDR.Apis.Core.Controllers;
using Deloitte.QDR.BLL;
using Deloitte.QDR.Contracts;
using Deloitte.QDR.Contracts.Services;
using Deloitte.QDR.DTO;
using Deloitte.QDR.DTO.Common;
using Deloitte.QDR.Services;
using Deloitte.QDR.Tests.Mocks;
using Moq;
using Xunit;
using Xunit.Gherkin.Quick;

namespace Deloitte.QDR.Tests.Api.Core.Features.AwardingProcess.UpdateAwardingProcess
{
    [FeatureFile("./Features/AwardingProcess/UpdateAwardingProcess/UpdateAwardingProcess.feature")]
    public sealed class UpdateAwardingProcess : Feature
    {
        private AwardingProcessBL _awardingProcessBL;
        private DTO.AwardingProcess _awardingProcessDTO;
        private FilterBase _awardingProcessFilter;

        public UpdateAwardingProcess()
        {
            var mockBlobStorageService = new Mock<IBlobStorageService>();
            var mockHubService = new Mock<IHubService>();   
            var mockFeedbackService = new Mock<IFeedbackService>();
            MapperBootstrapper.Bootstrap();
            _awardingProcessBL = new AwardingProcessBL(
                new SessionServiceMock(),
                DbContextMock.GetContext(),
                new DataCacheMock(),
                mockBlobStorageService.Object,
                mockHubService.Object,
                mockFeedbackService.Object
            );

            _awardingProcessDTO = new DTO.AwardingProcess();
        }

        [Given(@"the id (.*) as Id")]
        public void The_awarding_process_data(string Id)
        {
            _awardingProcessDTO.Id = new Guid(Id);
        }

        [When(@"I fill the data to update")]
        public void I_fill_the_data_to_update()
        {
            _awardingProcessDTO.Title = "Title";
            _awardingProcessDTO.Approver_Id = "01";
            _awardingProcessDTO.ApproverEmail = "Test@email.com";
            _awardingProcessDTO.BadgeTemplate_Id = new Guid("79d00101-b555-4049-923f-cd7ab464592e");
            _awardingProcessDTO.CompletionDate = DateTime.UtcNow;
            _awardingProcessDTO.Status = "Submitted";
        }

        [Then(@"The record with same CohortId will be updated")]
        public async Task The_record_with_same_CohortId_will_update()
        {
            var result = await _awardingProcessBL.UpdateAsync(_awardingProcessDTO);
            Assert.NotNull(result);
            Assert.Equal(_awardingProcessDTO.Title, result.Title);
        }
    }
}
