﻿using Deloitte.QDR.Apis.Core.Controllers;
using Deloitte.QDR.BLL;
using Deloitte.QDR.Contracts;
using Deloitte.QDR.Contracts.Services;
using Deloitte.QDR.Tests.Mocks;
using Moq;
using Xunit;
using Xunit.Gherkin.Quick;

namespace Deloitte.QDR.Tests.Api.Core.Features.AwardingProcess.CreateAwardingProcess
{
    [FeatureFile("./Features/AwardingProcess/CreateAwardingProcess/CreateAwardingProcess.feature")]
    public sealed class CreateAwardingProcessTest : Feature
    {
        private AwardingProcessBL _awardingProcessBL;

        public CreateAwardingProcessTest()
        {
            var mockBlobStorageService = new Mock<IBlobStorageService>();
            var mockHubService = new Mock<IHubService>(); 
            var mockFeedbackService = new Mock<IFeedbackService>(); 
            MapperBootstrapper.Bootstrap();
            _awardingProcessBL = new AwardingProcessBL(
                new SessionServiceMock(),
                DbContextMock.GetContext(),
                new DataCacheMock(),
                mockBlobStorageService.Object,
                mockHubService.Object,
                mockFeedbackService.Object
            );

        }

        [Given(@"I'm in Bulk Awarding Process list")]
        public void Im_in_Bulk_Awarding_Process_list()
        {

        }

        [When(@"I click in Create New button")]
        public void I_click_in_Create_New_button()
        {

        }

        [Then(@"The record with new CohortId will be created in database")]
        public void The_record_with_new_CohortId_will_be_created_in_database()
        {
            var result = _awardingProcessBL.CreateAwardingProcess();
            Assert.NotNull(result);
            Assert.NotNull(result.CohortId);
        }
    }
}
