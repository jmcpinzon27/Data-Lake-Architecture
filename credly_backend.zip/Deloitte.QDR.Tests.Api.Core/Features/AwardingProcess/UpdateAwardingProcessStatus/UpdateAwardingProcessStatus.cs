﻿using Deloitte.QDR.Apis.Core.Controllers;
using Deloitte.QDR.BLL;
using Deloitte.QDR.Contracts;
using Deloitte.QDR.Contracts.Services;
using Deloitte.QDR.DTO;
using Deloitte.QDR.Entities.Enum;
using Deloitte.QDR.Tests.Mocks;
using Microsoft.AspNetCore.Mvc;
using Moq;
using Xunit;
using Xunit.Gherkin.Quick;

namespace Deloitte.QDR.Tests.Api.Core.Features.AwardingProcess.UpdateAwardingProcessStatus
{
    [FeatureFile("./Features/AwardingProcess/UpdateAwardingProcessStatus/UpdateAwardingProcessStatus.feature")]
    public sealed class UpdateAwardingProcessStatus : Feature
    {
        private AwardingProcessBL _awardingProcessBL;
        private DTO.AwardingProcess _awardingProcessDTO;

        public UpdateAwardingProcessStatus()
        {
            var mockBlobStorageService = new Mock<IBlobStorageService>();
            var mockHubService =  new Mock<IHubService>();
            var mockFeedbackService = new Mock<IFeedbackService>(); 
            MapperBootstrapper.Bootstrap();
            _awardingProcessBL = new AwardingProcessBL(
                new SessionServiceMock(),
                DbContextMock.GetContext(),
                new DataCacheMock(),
                mockBlobStorageService.Object,
                mockHubService.Object,
                mockFeedbackService.Object
            );

            _awardingProcessDTO = new DTO.AwardingProcess();
        }

        [Given(@"the Awarding process to validate with (.*) as Id")]
        public void the_Awarding_process_data_to_validate(string Id)
        {
            _awardingProcessDTO.Id = new Guid(Id);
        }

        [When(@"I set the (.*) as status")]
        public void I_set_the_Approved_status(string status)
        {
            _awardingProcessDTO.Status = status;
        }

        [Then(@"The record will save the (.*) as status")]
        public void The_record_will_save_the_approved_status(string status)
        {
            var result = _awardingProcessBL.ChangeStatus(_awardingProcessDTO);
            var statusAwardingProcess = Assert.IsType<DTO.AwardingProcess>(result);
            Assert.Equal(status, statusAwardingProcess.Status);
        }
    }
}
