﻿using Deloitte.QDR.Apis.Core.Controllers;
using Deloitte.QDR.BLL;
using Deloitte.QDR.Contracts;
using Deloitte.QDR.Contracts.BL;
using Deloitte.QDR.Contracts.Services;
using Deloitte.QDR.DTO.Common;
using Deloitte.QDR.DTO.Filters;
using Deloitte.QDR.Tests.Mocks;
using Moq;
using System.Collections.Generic;
using System.Diagnostics;
using Deloitte.QDR.Entities;
using Xunit;
using Xunit.Gherkin.Quick;
using UserActivity = Deloitte.QDR.DTO.UserActivity;

namespace Deloitte.QDR.Tests.Api.Core.Features.UserActivity.GetAllUserActivity
{
    [FeatureFile("./Features/UserActivity/GetAllUserActivity/GetAllUserActivity.Feature")]
    public sealed class GetAllUserActivity : Feature
    {
        private UserActivityController _userActivityController;
        private UserActivityBL _userActivityBl;
        private DTO.UserActivity _userActivity;
        private UserActivityFilter _userActivityFilter;
        private ListResponse<DTO.UserActivity> _response;

        private void InitializeConstructor()
        {
            MapperBootstrapper.Bootstrap();
            _userActivityBl = new UserActivityBL(
                new SessionServiceMock(),
                DbContextMock.GetContext(),
                new DataCacheMock()
            );
        }

        #region Get all chronologically
        [Given(@"Im the admin")]
        public void Step1_GetAllUseractivityScreen()
        {
            InitializeConstructor();
        }

        [When(@"This list should be order chronologically")]
        public void Step2_GetAllUseractivityScreen()
        {
            _userActivityFilter = new UserActivityFilter();
            _userActivityFilter.OrderBy = new OrderBy()
            {
                Column = "Date"
            };
        }

        [Then(@"I can see a list with name, user role, department, email, activity Type and date by each user.")]
        public void Step3_GetAllUseractivityScreen()
        {
            _response = _userActivityBl.GetByFilter(_userActivityFilter);
            foreach (var userData in _response.Data)
            {
                Assert.NotNull(userData.Employee.FirstName);
                Assert.NotNull(userData.Employee.BusinessDesc);
                Assert.NotNull(userData.Employee.Email);
                Assert.NotNull(userData.Type);
                Assert.NotNull(userData.Date);
            }
        }
        #endregion

        #region Get all chronologically and filteres by avitivity type
        [Given(@"Im the admin")]
        public void Step1_GetAllUseractivityScreenbyActivityType()
        {
            InitializeConstructor();
        }

        [When(@"This list should be order chronologically")]
        public void Step2_GetAllUseractivityScreenbyActivityType()
        {
            _userActivityFilter = new UserActivityFilter();
            _userActivityFilter.OrderBy = new OrderBy()
            {
                Column = "Date"
            };
        }

        [And(@"have a filter to search by activity type")]
        public void Step3_GetAllUseractivityScreenbyActivityType()
        {
            _userActivityFilter.Type = ActivityType.BadgeAttentionRequired;
        }

        [Then(@"I can see a list with name, user role, department, email, activity Type and date by each user.")]
        public void Step4_GetAllUseractivityScreenbyActivityType()
        {
            _response = _userActivityBl.GetByFilter(_userActivityFilter);
            foreach (var userData in _response.Data)
            {
                Assert.NotNull(userData.Employee.FirstName);
                Assert.NotNull(userData.Employee.BusinessDesc);
                Assert.NotNull(userData.Employee.Email);
                Assert.NotNull(userData.Type);
                Assert.NotNull(userData.Date);
                Assert.Equal(_userActivityFilter.Type.ToString(), userData.Type);
            }
        }
        #endregion

        #region Get all chronologically and filteres by role
        [Given(@"Im the admin")]
        public void Step1_GetAllUseractivityScreenbyRole()
        {
            InitializeConstructor();
        }

        [When(@"This list should be order chronologically")]
        public void Step2_GetAllUseractivityScreenbyRole()
        {
            _userActivityFilter = new UserActivityFilter();
            _userActivityFilter.OrderBy = new OrderBy()
            {
                Column = "Date"
            };
        }

        [And(@"have a filter to search by role")]
        public void Step3_GetAllUseractivityScreenbyRole()
        {
            _userActivityFilter.Roles = "Admin";
        }

        [Then(@"I can see a list with name, user role, department, email, activity Type and date by each user.")]
        public void Step4_GetAllUseractivityScreenbyRole()
        {
            _response = _userActivityBl.GetByFilter(_userActivityFilter);
            foreach (var userData in _response.Data)
            {
                Assert.NotNull(userData.Employee.FirstName);
                Assert.NotNull(userData.Employee.BusinessDesc);
                Assert.NotNull(userData.Employee.Email);
                Assert.NotNull(userData.Type);
                Assert.NotNull(userData.Date);
                foreach (var roleData in userData.Employee.Roles)
                {
                    Assert.Equal(_userActivityFilter.Roles, roleData.RoleCode);
                }
            }
        }
        #endregion

        #region Get all chronologically and filteres by date
        [Given(@"Im the admin")]
        public void Step1_GetAllUseractivityScreenbyDate()
        {
            InitializeConstructor();
        }

        [When(@"This list should be order chronologically")]
        public void Step2_GetAllUseractivityScreenbyDate()
        {
            _userActivityFilter = new UserActivityFilter();
            _userActivityFilter.OrderBy = new OrderBy()
            {
                Column = "Date"
            };
        }

        [And(@"have a filter to search by date")]
        public void Step3_GetAllUseractivityScreenbyDate()
        {
            _userActivityFilter.From = new DateTime(2023, 02, 1);
            _userActivityFilter.To = new DateTime(2023, 02, 1);
        }

        [Then(@"I can see a list with name, user role, department, email, activity Type and date by each user.")]
        public void Step4_GetAllUseractivityScreenbyDate()
        {
            _response = _userActivityBl.GetByFilter(_userActivityFilter);
            foreach (var userData in _response.Data)
            {
                Assert.NotNull(userData.Employee.FirstName);
                Assert.NotNull(userData.Employee.BusinessDesc);
                Assert.NotNull(userData.Employee.Email);
                Assert.NotNull(userData.Type);
                Assert.NotNull(userData.Date);
                Assert.InRange(userData.Date.Value, _userActivityFilter.From.Value, _userActivityFilter.To.Value);
            }
        }
        #endregion
    }
}
