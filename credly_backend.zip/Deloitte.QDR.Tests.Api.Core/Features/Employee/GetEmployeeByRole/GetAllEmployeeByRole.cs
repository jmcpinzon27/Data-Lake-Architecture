﻿using Deloitte.QDR.Apis.Core.Controllers;
using Deloitte.QDR.BLL;
using Deloitte.QDR.Contracts;
using Deloitte.QDR.Contracts.Services;
using Deloitte.QDR.DTO.Common;
using Deloitte.QDR.Tests.Mocks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Moq;
using Xunit;
using Xunit.Gherkin.Quick;

namespace Deloitte.QDR.Tests.Api.Core.Features.Employee.GetEmployeeByRole
{
    [FeatureFile("./Features/Employee/GetEmployeeByRole/GetAllEmployeeByRole.feature")]
    public sealed class GetAllEmployeeByRole : Feature
    {
        private EmployeeController _employeeController;
        private FilterBaseWithRoles _filterBase;
        private ListResponse<UserSession> _response;


        private void InitializeConstructor()
        {
            var mockCacheService = new Mock<ICacheService>();
            mockCacheService
                .Setup(x => x.GetEmployeesRoleFromCacheAsync(GeneralConstants.Role.FILTER_EMPLOYEE.ToList()))
                .ReturnsAsync(new CacheServiceResponse<List<UserSession>> { SourceCache = SourceCache.DataBase });

            var bl = new EmployeeBL(
                new SessionServiceMock(),
                DbContextMock.GetContext(),
                new DataCacheMock(),
                mockCacheService.Object
            );
            MapperBootstrapper.Bootstrap();
            _employeeController = new EmployeeController(bl);
            _employeeController.ControllerContext = new ControllerContext { HttpContext = new DefaultHttpContext() };
        }
        public GetAllEmployeeByRole()
        {
            MapperBootstrapper.Bootstrap();
        }

        #region Get Admins
        [Given(@"Im the admin")]
        public void Im_The_Admin()
        {
            InitializeConstructor();
        }

        [When(@"Reach the roles screen lateral menu, (.*) as role")]
        public void Set_Role_To_Search(string role)
        {
            _filterBase = new FilterBaseWithRoles();
            _filterBase.PageIndex = 1;
            _filterBase.PageSize = 10;
            _filterBase.Roles = role;
        }

        [Then(@"I can see an overview of roles and users and when I click it I can execute and specific action")]
        public async Task the_response_should_contain_all_registers()
        {
            var result = await _employeeController.GetEmployeesByRoleAsync(_filterBase);
            _response = result.Value;
            foreach (var employee in _response.Data)
            {
                Assert.NotNull(employee.FirstName);
                Assert.NotNull(employee.LastName);
                Assert.NotNull(employee.Email);
                Assert.NotNull(employee.PersonID);
            }
        }
        #endregion
    }
}
