﻿using Deloitte.QDR.Apis.Core.Controllers;
using Deloitte.QDR.BLL;
using Deloitte.QDR.Contracts;
using Deloitte.QDR.DTO.Common;
using Deloitte.QDR.DTO.Filters;
using Deloitte.QDR.Tests.Mocks;
using Xunit;
using Xunit.Gherkin.Quick;

namespace Deloitte.QDR.Tests.Api.Core.Legacy.Skills
{
    [FeatureFile("./Legacy/Skills/Features/TestSkill.feature")]
    public sealed class TestSkillController : Feature
    {
        private readonly SkillController _SkillController;
        private SkillFilter _filterBase;
        private ListResponse<DTO.Skill> _listSkill;
        private IList<DTO.BadgeTemplateSkill> _allSkill;
        private DTO.BadgeTemplateSkill _responseEmployeeItem;
        private Guid _skillId;

        public TestSkillController()
        {
            MapperBootstrapper.Bootstrap();
            var bl = new SkillBL(
                new SessionServiceMock(),
                DbContextMock.GetContext(),
                new DataCacheMock()
            );

            _SkillController = new SkillController(bl);
        }

        #region Scenario: Get Skills with basic parameters

        [Given(@"I start a paged list request of Skills role")]
        public void I_Start_a_paged_list_request_of_skills()
        {
            _filterBase = new SkillFilter();
        }

        [When(@"I set (\d+) as page size")]
        public void I_set_z_as_page_size(int pageSize)
        {
            _filterBase.PageSize = pageSize;
        }

        [And(@"I set (\d+) as page index")]
        public void Set_z_as_page_index(int pageIndex)
        {
            _filterBase.PageIndex = pageIndex;
        }

        [And(@"I set (.*) as search text")]
        public void Set_z_as_search_text(string searchText)
        {
            _filterBase.SearchText = searchText;
        }

        [Then(@"the response should contain (\d+) Skills")]
        public void Then_the_result_should_be_z_on_the_screen(int expectedResult)
        {
            _listSkill = _SkillController.GetByFilter(_filterBase).Value;
            Assert.Equal(expectedResult, _listSkill.Data.Count);
        }

        #endregion

    }
}
