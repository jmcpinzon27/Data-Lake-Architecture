﻿using Deloitte.QDR.Apis.Core.Controllers;
using Deloitte.QDR.Apis.Core.Controllers.Base;
using Deloitte.QDR.BLL;
using Deloitte.QDR.Contracts;
using Deloitte.QDR.Contracts.BL;
using Deloitte.QDR.DTO.Common;
using Deloitte.QDR.DTO.Filters;
using Deloitte.QDR.Entities;
using Deloitte.QDR.Tests.Mocks;
using Microsoft.IdentityModel.Tokens;
using Moq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xunit;
using Xunit.Gherkin.Quick;

namespace Deloitte.QDR.Tests.Api.Core.BadgesTemplates
{
    [FeatureFile("./BadgesTemplates/Features/BadgeTemplatesAdd.feature")]
    public sealed class TestAddBadgeTemplateController : Feature
    {
        private BadgeTemplateController _badgeTemplate;

        public TestAddBadgeTemplateController()
        {
            var bl = new BadgeTemplateBL(
                new SessionServiceMock(),
                DbContextMock.GetContext(),
                new DataCacheMock()
            );
            MapperBootstrapper.Bootstrap();
            _badgeTemplate = new BadgeTemplateController(bl);
        }
    }
}
