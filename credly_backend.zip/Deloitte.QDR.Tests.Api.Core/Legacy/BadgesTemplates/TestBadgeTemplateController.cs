﻿using Deloitte.QDR.Apis.Core.Controllers;
using Deloitte.QDR.BLL;
using Deloitte.QDR.Contracts;
using Deloitte.QDR.Contracts.BL;
using Deloitte.QDR.Contracts.Services;
using Deloitte.QDR.DTO.Common;
using Deloitte.QDR.Services;
using Deloitte.QDR.Tests.Mocks;
using Moq;
using StackExchange.Redis;
using Xunit;
using Xunit.Gherkin.Quick;

namespace Deloitte.QDR.Tests.Api.Core.Legacy.BadgesTemplates
{
    [FeatureFile("./Legacy/BadgesTemplates/Features/BadgeTemplates.feature")]
    public sealed class TestBadgeTemplateController : Feature
    {
        private DTO.BadgeTemplate _filterBadgeTemplate;
        private readonly BadgeTemplateController _badgeTemplateController;
        private readonly Mock<INotificationService> _notificationService;
        private TransitionStatus _status;

        public TestBadgeTemplateController()
        {
            var mockBlobStorageService = new Mock<IBlobStorageService>();
            var mockCredlyApiService = new Mock<ICredlyAPIService>();
            var mockHubService = new Mock<IHubService>();
            var mockBadgeTemplateStatusFlowService = new Mock<BadgeTemplateStatusFlowService>();
            var mockFeedbackService = new Mock<IFeedbackService>();  
            _notificationService = new Mock<INotificationService>();
            var mockSABAService = new Mock<ISABAService>();
            var mockErrorLog = new Mock<IErrorLogBL>();

            MapperBootstrapper.Bootstrap();
            var bl = new BadgeTemplateBL(
                new SessionServiceMock(),
                DbContextMock.GetContext(),
                new DataCacheMock(),
                mockBlobStorageService.Object,
                mockCredlyApiService.Object,
                mockHubService.Object,
                mockBadgeTemplateStatusFlowService.Object,
                _notificationService.Object,
                mockFeedbackService.Object,
                mockSABAService.Object,
                mockErrorLog.Object
            );
            _badgeTemplateController = new BadgeTemplateController(bl);
        }

        #region HideaBadgeTemplate

        [Given(@"I start a list request of BadgeTemplates by filters")]
        public void I_start_a_list_request_of_badgetemplates_by_filters()
        {
            _filterBadgeTemplate = new DTO.BadgeTemplate();
            _status = new TransitionStatus();
        }

        [When(@"I set the (.*) as badgeTemplate")]
        public void I_set_the_as_badgetemplate(string Id)
        {
            _status.Id = Guid.Parse(Id);
        }

        [And(@"I set the (.*) as Status")]
        public void And_I_set_the_as_status(string status)
        {
            _status.Status = status;
        }

        [Then(@"The response should be the Hidden BadgeTemplate")]
        public void The_response_should_be_the_hidden_badgetemplate()
        {
            var response = _badgeTemplateController.ChangeStatusAsync(_status);
            Assert.NotNull(response);
        }
        #endregion

        #region ArchiveaBadgeTemplate

        [Given(@"I start a list request of BadgeTemplates by filters")]
        public void I_start_list_request_of_badgetemplates_by_filters()
        {
            _filterBadgeTemplate = new DTO.BadgeTemplate();
            _status = new TransitionStatus();
        }

        [When(@"I set the (.*) as badgeTemplate")]
        public void I_set_the_badgetemplate(string Id)
        {
            _status.Id = Guid.Parse(Id);
        }

        [And(@"I set the (.*) as Status")]
        public void And_I_set_the_status(string status)
        {
            _status.Status = status;
        }
        [Then(@"The response should be the Archive BadgeTemplate")]
        public void The_response_should_be_the_archive_badgetemplate()
        {
            var response = _badgeTemplateController.ChangeStatusAsync(_status);
            Assert.NotNull(response);
        }
        #endregion
    }
}

