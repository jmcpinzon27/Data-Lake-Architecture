﻿using AutoMapper;
using Deloitte.QDR.Apis.Core.Controllers;
using Deloitte.QDR.BLL;
using Deloitte.QDR.Contracts;
using Deloitte.QDR.Contracts.Services;
using Deloitte.QDR.DTO.Common;
using Deloitte.QDR.Tests.Mocks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Moq;
using Xunit;
using Xunit.Gherkin.Quick;

namespace Deloitte.QDR.Tests.Api.Core.Legacy.Employees
{
    [FeatureFile("./Legacy/Employees/Features/TestEmployees.feature")]
    public sealed class TestEmployeeController : Feature
    {
        private readonly EmployeeController _employeeController;
        private readonly Mapper Mapper;
        private FilterBaseWithRoles _filterBase;
        private ListResponse<DTO.Common.UserSession> _listEmployee;
        private IList<DTO.Role> _listRoles;
        private DTO.Employee _responseEmployeeItem;
        private DTO.Employee _addEmployeeItem;
        private DTO.Employee _responseEmployeeAdded;
        private DTO.Employee _responseEmployeeUpdated;
        private DTO.Employee _updatedEmployeeItem;
        private ListResponse<DTO.Employee> _listEmployeeFiltered;

        public TestEmployeeController()
        {
            MapperBootstrapper.Bootstrap();
            var cacheServiceMock = new Mock<ICacheService>();
            cacheServiceMock.Setup(x => x.GetEmployeesFromCacheAsync())
                .Returns(Task.FromResult(new CacheServiceResponse<List<UserSession>> { Data = null }));

            var bl = new EmployeeBL(
                new SessionServiceMock(),
                DbContextMock.GetContext(),
                new DataCacheMock(),
                cacheServiceMock.Object
            );
            _employeeController = new EmployeeController(bl);
            _employeeController.ControllerContext = new ControllerContext { HttpContext = new DefaultHttpContext() };
        }

        [Given(@"I start a paged list request of employees")]
        public void I_Start_a_paged_list_request_of_employees()
        {
            _filterBase = new FilterBaseWithRoles();
        }

        [And("I set(.*) as orderBy")]
        public void I_set_z_as_orderby(string field)
        {
            OrderBy order = new OrderBy() { Column = field, Desc = true };
            _filterBase.OrderBy = order;
        }

        [And(@"I set (\d+) as page size")]
        public void I_set_z_as_page_size(int pageSize)
        {
            _filterBase.PageSize = pageSize;
        }

        [And(@"I set (\d+) as page index")]
        public void Set_z_as_page_index(int pageIndex)
        {
            _filterBase.PageIndex = pageIndex;
        }

       [And(@"I set (.*) as columnName and set (.*) as value and set (.*) as freetext")]
        public void I_set_the_filter_columns(string columnName, string value, bool freeText)
        {
            List<FilterColumn> lstFilterColumns = new List<FilterColumn>();

            FilterColumn filterColumn = new FilterColumn()
            {
                Column = columnName,
                Value = value,
                FreeText = freeText
            };
            lstFilterColumns.Add(filterColumn);
            _filterBase.FilterColumns = lstFilterColumns;
        }
      
        [Then(@"the response should contain (\d+) employees")]
        public void Then_the_result_should_be_z_on_the_screen(int expectedResult)
        {
            _listEmployee = _employeeController.GetByFilterAsync(_filterBase).Result.Value;
             Assert.Equal(expectedResult, _listEmployee.Data.Count);
        }
    }
}
