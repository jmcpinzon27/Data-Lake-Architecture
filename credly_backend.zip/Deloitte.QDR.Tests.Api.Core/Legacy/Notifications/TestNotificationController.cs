﻿using Deloitte.QDR.Apis.Core.Controllers;
using Deloitte.QDR.BLL;
using Deloitte.QDR.Contracts;
using Deloitte.QDR.DTO.Common;
using Deloitte.QDR.DTO.Filters;
using Deloitte.QDR.Hubs;
using Deloitte.QDR.Tests.Mocks;
using Microsoft.AspNetCore.SignalR;
using Moq;
using System.Globalization;
using Xunit;
using Xunit.Gherkin.Quick;

namespace Deloitte.QDR.Tests.Api.Core.Legacy.Notifications
{
    [FeatureFile("./Legacy/Notifications/Features/Notifications.feature")]
    public sealed class TestNotificationController : Feature
    {
        private readonly NotificationController _notificationController;
        private NotificationFilter _notificationFilter;
        private ListResponse<DTO.Notification> _notificationList;
        private DTO.Notification _notificationItem;
        private string _messageNotification;
        private const string _groupNotificationHub = "eaguiar@deloitte.com";

        public TestNotificationController()
        {
            MapperBootstrapper.Bootstrap();
            var bl = new NotificationBL(
                new SessionServiceMock(),
                DbContextMock.GetContext(),
                new DataCacheMock()
            );

            Mock<IHubClients> mockClients = new Mock<IHubClients>();
            Mock<IClientProxy> mockClientProxy = new Mock<IClientProxy>();
            mockClients
                .Setup(clients => clients.Group(_groupNotificationHub))
                .Returns(mockClientProxy.Object);
            var hubContext = new Mock<IHubContext<NotificationHub>>();
            hubContext.Setup(x => x.Clients).Returns(() => mockClients.Object);
            _notificationController = new NotificationController(bl, hubContext.Object);
        }

        [Given(@"I start a paged list request of notifications")]
        public void I_Start_a_paged_list_request_of_notifications()
        {
            _notificationFilter = new NotificationFilter();
        }

        [And(@"I set (\d+) as page size")]
        public void I_set_z_as_page_size(int pageSize)
        {
            _notificationFilter.PageSize = pageSize;
        }

        [And(@"I set (.*) as entitytype filter")]
        public void I_set_z_as_entitytpe_filter(string entityType)
        {
            _notificationFilter.EntityType = new List<string>() { entityType };
        }

        [And(@"I set (\d+) as page index")]
        public void Set_z_as_page_index(int pageIndex)
        {
            _notificationFilter.PageIndex = pageIndex;
        }

        [Then(@"the response should contain (\d+) notifications")]
        public void Then_the_result_should_be_z_on_the_screen(int expectedResult)
        {
            _notificationList = _notificationController.GetNotificationsPractitioner(_notificationFilter).Value;
            Assert.Equal(expectedResult, _notificationList.Data.Count);
        }

        [Then(@"The item is displayed on the screen")]
        public void The_item_is_displayed_on_the_screen()
        {
            Assert.NotNull(_notificationItem);
        }

        [And(@"I set (.*) as title filter")]
        public void I_set_title_filter(string title)
        {
            _notificationFilter.Title = title;
        }

        [And(@"I set (.*) as description filter")]
        public void I_set_description_filter(string description)
        {
            _notificationFilter.Description = description;
        }

        [And(@"I set (.*) as read filter")]
        public void I_set_read_filter(string read)
        {
            _notificationFilter.Read = bool.Parse(read);
        }

        [And(@"I set (.*) as startdate filter")]
        public void I_set_startdate_filter(string startdate)
        {
            _notificationFilter.StartDate = DateTime.ParseExact(
                startdate,
                "yyyy-MM-dd",
                CultureInfo.InvariantCulture
            );
        }

        [And(@"I set (.*) as enddate filter")]
        public void I_set_enddate_filter(string enddate)
        {
            _notificationFilter.EndDate = DateTime.ParseExact(
                enddate,
                "yyyy-MM-dd HH:mm",
                CultureInfo.InvariantCulture
            );
        }

        [Then(@"the response should contain notifications for the filters")]
        public void Then_the_result_should_be_contain_because_of_filters()
        {
            _notificationList = _notificationController.GetNotificationsPractitioner(_notificationFilter).Value;
            Assert.NotEmpty(_notificationList.Data);
        }
    }
}
