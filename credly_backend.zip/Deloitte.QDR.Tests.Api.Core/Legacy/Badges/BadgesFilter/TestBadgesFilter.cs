﻿using Deloitte.QDR.Apis.Core.Controllers;
using Deloitte.QDR.BLL;

using Deloitte.QDR.Contracts;
using Deloitte.QDR.Contracts.BL;
using Deloitte.QDR.Contracts.Services;
using Deloitte.QDR.DTO;
using Deloitte.QDR.DTO.Common;
using Deloitte.QDR.Services;
using Deloitte.QDR.Tests.Mocks;
using Moq;
using Xunit;
using Xunit.Gherkin.Quick;

namespace Deloitte.QDR.Tests.Api.Core.Legacy.Badges.BadgesFilter
{
    [FeatureFile("./Legacy/Badges/BadgesFilter/Features/BadgesFilter.feature")]
    public sealed class TestBadgesFilter : Feature
    {
        private BadgeController _badgeController;
        private DTO.Filters.BadgesFilter _filterBadge;
        private ListResponse<Badge> _response;
        private readonly Mock<BadgeStatusFlowService> _badgeStatusValidatorHelper;
        private readonly Mock<ICredlyAPIService> _credlyAPIService;
        private readonly Mock<IHubService> _hubService;
        private readonly Mock<INotificationService> _notificationService;
        private readonly Mock<IEmailValidation> _emailValidation;
        private readonly Mock<IFeedbackService> _feedbackService;
        private readonly Mock<ILoginValidationService> _loginValidationService;
        private readonly Mock<ISABAService> _sabaService;
        private readonly Mock<IErrorLogBL> _errorLog;

        public TestBadgesFilter()
        {
            MapperBootstrapper.Bootstrap();
            var mockBlobStorageService = new Mock<IBlobStorageService>();
            var badgeStatusValidatorHelper = new Mock<BadgeStatusFlowService>();

            _credlyAPIService = new Mock<ICredlyAPIService>();
            _hubService = new Mock<IHubService>();
            _notificationService = new Mock<INotificationService>();
            _emailValidation = new Mock<IEmailValidation>();
            _feedbackService = new Mock<IFeedbackService>();
            _loginValidationService = new Mock<ILoginValidationService>();
            _sabaService = new Mock<ISABAService>();
            _errorLog = new Mock<IErrorLogBL>();

            var bl = new BadgeBL(
                new SessionServiceMock(),
                DbContextMock.GetContext(),
                new DataCacheMock(),
                mockBlobStorageService.Object,
                badgeStatusValidatorHelper.Object,
                _credlyAPIService.Object,
                _hubService.Object,
                _notificationService.Object,
                _feedbackService.Object,
                _emailValidation.Object,
                _loginValidationService.Object,
                _sabaService.Object,
                _errorLog.Object
            );
            _badgeController = new BadgeController(bl);
        }

        [Given(@"I start a paged list request of employees")]
        public void I_Start_a_paged_list_request_of_employees()
        {
            _filterBadge = new DTO.Filters.BadgesFilter();
        }

        [And(@"I set the (.*) as Status")]
        public void I_set_the_Status(string status)
        {
            _filterBadge.Status = new List<string> { status };
        }

        [And(@"I set the (.*) as personid")]
        public void ApprovedDate(string personID)
        {
            _filterBadge.PersonID = personID;
        }

        [And(@"I set (\d+) as page size")]
        public void I_set_z_as_page_size(int pageSize)
        {
            _filterBadge.PageSize = pageSize;
        }

        [And(@"I set (\d+) as page index")]
        public void Set_z_as_page_index(int pageIndex)
        {
            _filterBadge.PageIndex = pageIndex;
        }

        [Then(@"the response should contain (\d+) employees")]
        public void Then_the_result_should_be_z_on_the_screen(int expectedResult)
        {
            _response = _badgeController.GetByFilter(_filterBadge).Value;
            Assert.Equal(expectedResult, _response.Count);
        }
    }
}
