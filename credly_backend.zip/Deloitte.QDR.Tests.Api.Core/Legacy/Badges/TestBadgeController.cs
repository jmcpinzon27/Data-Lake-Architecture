﻿using Deloitte.QDR.Apis.Core.Controllers;
using Deloitte.QDR.BLL;
using Deloitte.QDR.Contracts;
using Deloitte.QDR.Contracts.BL;
using Deloitte.QDR.Contracts.Services;
using Deloitte.QDR.DTO;
using Deloitte.QDR.DTO.Common;
using Deloitte.QDR.Infrastructure.Config;
using Deloitte.QDR.Services;
using Deloitte.QDR.Tests.Mocks;
using Moq;
using Xunit;
using Xunit.Gherkin.Quick;

namespace Deloitte.QDR.Tests.Api.Core.Legacy.Badges
{
    [FeatureFile("./Legacy/Badges/Features/Badges.feature")]
    public sealed class TestBadgeController : Feature
    {
        private BadgeController _badgeController;
        private DTO.Filters.BadgesFilter _filterBadge;
        private ListResponse<Badge> _response;
        private Badge _responseBadgeItem;
        private Badge _badge;
        private Badge _badgeAddItem;
        private Badge _responseBadgeAddItem;
        private Badge _badgeUpdateItem;
        private readonly Mock<ICredlyAPIService> _credlyAPIService;
        private readonly Mock<IHubService> _hubService;
        private readonly Mock<INotificationService> _notificationService;
        private readonly Mock<IEmailValidation> _emailValidation;
        private readonly Mock<IFeedbackService> _feedbackService;
        private readonly Mock<ILoginValidationService> _loginValidationService;
        private readonly Mock<ISABAService> _sabaService;
        private readonly Mock<IErrorLogBL> _errorLog;

        public TestBadgeController()
        {
            MapperBootstrapper.Bootstrap();
            var mockBlobStorageService = new Mock<IBlobStorageService>();
            var badgeStatusValidatorTemplate = new Mock<BadgeStatusFlowService>();
            _credlyAPIService = new Mock<ICredlyAPIService>();
            _hubService = new Mock<IHubService>();
            _notificationService = new Mock<INotificationService>();
            _emailValidation = new Mock<IEmailValidation>();
            _feedbackService = new Mock<IFeedbackService>();
            _loginValidationService = new Mock<ILoginValidationService>();
            _sabaService = new Mock<ISABAService>();
            _errorLog = new Mock<IErrorLogBL>();

            var bl = new BadgeBL(
                new SessionServiceMock(),
                DbContextMock.GetContext(),
                new DataCacheMock(),
                mockBlobStorageService.Object,
                badgeStatusValidatorTemplate.Object,
                _credlyAPIService.Object,
                _hubService.Object,
                _notificationService.Object,
                _feedbackService.Object,
                _emailValidation.Object,
                _loginValidationService.Object,
                _sabaService.Object,
                _errorLog.Object
            );

            _badgeController = new BadgeController(bl);
        }

        [Given(@"I start a paged list request of employees")]
        public void I_Start_a_paged_list_request_of_employees()
        {
            _filterBadge = new DTO.Filters.BadgesFilter();
        }

        [And(@"I set (\d+) as page size")]
        public void I_set_z_as_page_size(int pageSize)
        {
            _filterBadge.PageSize = pageSize;
        }

        [And(@"I set (\d+) as page index")]
        public void Set_z_as_page_index(int pageIndex)
        {
            _filterBadge.PageIndex = pageIndex;
        }

        [Then(@"the response should contain (\d+) employees")]
        public void Then_the_result_should_be_z_on_the_screen(int expectedResult)
        {
            _response = _badgeController.GetByFilter(_filterBadge).Value;
            Assert.Equal(expectedResult, _response.Count);
        }

        [Given(@"I pass the Id (.*)")]
        public void I_pass_the_Id(string id)
        {
            _responseBadgeItem = _badgeController.GetById(Guid.Parse(id)).Value;
        }

        [Then(@"The item is displayed on the screen")]
        public void The_item_is_displayed_on_the_screen()
        {
            Assert.NotNull(_responseBadgeItem);
        }

        [Given(@"I pass the Object")]
        public void I_pass_the_Object()
        {
            _badgeAddItem = new Badge();
        }

        [Then(@"The Badge has been created")]
        public void The_Badge_has_been_created()
        {
            _responseBadgeAddItem = _badgeController.Create(_badgeAddItem);
            Assert.NotNull(_responseBadgeAddItem);
        }

        [Given(@"I pass the Object for updating")]
        public void I_pass_the_Object_for_updating()
        {
            _badgeUpdateItem = new Badge();
        }

        [Then(@"The Bagde has been updated")]
        public async Task The_Bagde_has_been_updated()
        {
            _badgeUpdateItem = await _badgeController.UpdateAsync(_badgeUpdateItem);
            Assert.NotNull(_badgeUpdateItem);
        }

        #region Test for create(post)

        [Given(@"I start creating a new badge")]
        public void Step1_CreateBadge()
        {
            _badge = new Badge();
        }

        [When(@"I pass the Id (.*) also (.*) as Employee")]
        public void Step2_CreateBadge(string badgeTemplateId, string employee)
        {
            _badge.BadgeTemplateId = Guid.Parse(badgeTemplateId);
            _badge.EmployeePersonID = employee;
        }

        [Then(@"The badge was created")]
        public void Step3_CreateBadge()
        {
            _responseBadgeAddItem = _badgeController.Create(_badge);
            Assert.NotNull(_responseBadgeAddItem);
        }

        #endregion Test for create(post)

        #region Test for update(put)

        [Given(@"I start updating a badge")]
        public void Step1_UpdateBadge()
        {
            _badge = new Badge();
        }

        [When(@"I set the badgeTemplateId (.*)")]
        public void Step2_UpdateBadge(string badgeTemplateId)
        {
            _badge.BadgeTemplateId = Guid.Parse(badgeTemplateId);
        }

        [And(@"I set (.*) as Employee")]
        public void Step3_UpdateBadge(string employee)
        {
            _badge.EmployeePersonID = employee;
        }

        [And(@"I set (.*) as Status")]
        public void Step4_UpdateBadge(string status)
        {
            _badge.Status = status;
        }

        [And(@"I set (.*) as BagdeId")]
        public void Step5_UpdateBadge(string bagdeId)
        {
            _badge.Id = Guid.Parse(bagdeId);
        }

        [And(@"I set (.*) as EducationId")]
        public void Step6_UpdateBadge(string educationId)
        {
            _badge.Education = new List<Education>() { new Education { BadgeTemplateCriteriaId = Guid.Parse(educationId) } };
        }

        [And(@"I set (.*) as AwardedAt")]
        public void Step7_UpdateBadge(string awardedAt)
        {
            _badge.AwardedAt = DateTime.Parse(awardedAt);
        }

        [And(@"I set (.*) as Private")]
        public void Step8_UpdateBadge(string privateValue)
        {
            _badge.Private = bool.Parse(privateValue);
        }

        [And(@"I set (.*) as SubmittedAt")]
        public void Step9_UpdateBadge(string SubmittedAt)
        {
            _badge.SubmittedAt = DateTime.Parse(SubmittedAt);
        }

        [Then(@"The badge was updated")]
        public async Task Step10_UpdateBadge()
        {
            AppSettings.Settings = new Settings { CredlyUrl = "https://sandbox.credly.com/" };
            _responseBadgeAddItem = await _badgeController.UpdateAsync(_badge);
            Assert.NotNull(_responseBadgeAddItem);
        }

        #endregion Test for update(put)
    }
}
