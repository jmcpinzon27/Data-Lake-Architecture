﻿
GO
GRANT INSERT TO [qdr_user];

