﻿
GO
GRANT SELECT TO [qdr_user_portal];

