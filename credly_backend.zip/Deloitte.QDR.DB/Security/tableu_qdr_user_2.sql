﻿/****** Object:  User [tableu_qdr_user]    Script Date: 8/1/2023 3:09:04 PM ******/
/****** Object:  User [tableu_qdr_user]    Script Date: 10/5/2023 8:19:55 AM ******/
/****** Object:  User [tableu_qdr_user]    Script Date: 10/5/2023 3:00:04 PM ******/
CREATE USER [tableu_qdr_user] WITHOUT LOGIN;





