﻿CREATE LOGIN [qdr_user]
    WITH PASSWORD = N'kqu{gIh_q`Ed,xk7lp|iRapimsFT7_&#$!~<xaqi!xucoeua';

