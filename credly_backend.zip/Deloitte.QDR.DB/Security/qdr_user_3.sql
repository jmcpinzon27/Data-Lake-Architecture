﻿CREATE LOGIN [qdr_user]
    WITH PASSWORD = N'nIopfJW8sec.J|ytnUicx;ifmsFT7_&#$!~<hcufy{I.mCau';

