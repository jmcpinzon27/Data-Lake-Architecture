﻿
GO
GRANT UPDATE TO [qdr_user_portal];

