﻿
GO
GRANT CREATE TABLE TO [qdr_user];

