﻿
ALTER ROLE [db_datareader] ADD MEMBER [tableu_qdr_user];
GO

ALTER ROLE [db_datareader] ADD MEMBER [qdr_user];
GO

