﻿CREATE USER [tableu_qdr_user] FOR LOGIN [tableu_qdr_user];

