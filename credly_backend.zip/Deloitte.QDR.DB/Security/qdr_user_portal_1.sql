﻿CREATE LOGIN [qdr_user_portal]
    WITH PASSWORD = N'kqu{ohqdxklp|ipixQa2^2qimsFT7_&#$!~<xu4coeuabnEe';

