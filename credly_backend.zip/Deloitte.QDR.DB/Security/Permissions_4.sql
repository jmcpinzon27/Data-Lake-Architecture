﻿
GO
GRANT DELETE TO [qdr_user];

