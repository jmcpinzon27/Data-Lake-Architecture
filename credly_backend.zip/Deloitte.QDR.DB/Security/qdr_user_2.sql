﻿/****** Object:  User [qdr_user]    Script Date: 8/1/2023 3:09:04 PM ******/
/****** Object:  User [qdr_user]    Script Date: 10/5/2023 8:19:55 AM ******/
/****** Object:  User [qdr_user]    Script Date: 10/5/2023 3:00:04 PM ******/
CREATE USER [qdr_user] WITHOUT LOGIN;





