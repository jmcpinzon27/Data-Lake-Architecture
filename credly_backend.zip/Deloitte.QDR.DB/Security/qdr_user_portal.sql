﻿CREATE USER [qdr_user_portal] FOR LOGIN [qdr_user_portal];

