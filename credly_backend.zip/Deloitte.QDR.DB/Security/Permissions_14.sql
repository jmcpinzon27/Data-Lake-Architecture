﻿
GO
GRANT CONNECT TO [tableu_qdr_user];

