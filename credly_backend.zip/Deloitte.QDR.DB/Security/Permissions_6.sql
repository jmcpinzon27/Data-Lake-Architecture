﻿
GO
GRANT REFERENCES TO [qdr_user];

