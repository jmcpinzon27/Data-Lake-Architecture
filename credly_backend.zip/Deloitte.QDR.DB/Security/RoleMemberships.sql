﻿ALTER ROLE [db_datareader] ADD MEMBER [tableu_qdr_user];

