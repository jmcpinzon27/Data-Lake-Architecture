﻿CREATE LOGIN [tableu_qdr_user]
    WITH PASSWORD = N'nfcsecyz#UtIicfAhu?fy{mamsFT7_&#$!~<Z@uxQuwnwj@r';

