﻿CREATE LOGIN [qdr_user_portal]
    WITH PASSWORD = N'nfsecyREtkicf_huf}yXI{mamsFT7_&#$!~<vuxVuwnwjrrg';

