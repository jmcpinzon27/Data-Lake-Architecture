﻿GRANT ALTER TO [qdr_user];


GO
GRANT CONNECT TO [qdr_user];


GO
GRANT CREATE TABLE TO [qdr_user];


GO
GRANT DELETE TO [qdr_user];


GO
GRANT INSERT TO [qdr_user];


GO
GRANT REFERENCES TO [qdr_user];


GO
GRANT SELECT TO [qdr_user];


GO
GRANT UPDATE TO [qdr_user];


GO
GRANT CONNECT TO [qdr_user_portal];


GO
GRANT DELETE TO [qdr_user_portal];


GO
GRANT INSERT TO [qdr_user_portal];


GO
GRANT SELECT TO [qdr_user_portal];


GO
GRANT UPDATE TO [qdr_user_portal];


GO
GRANT CONNECT TO [tableu_qdr_user];

