﻿CREATE USER [qdr_user] FOR LOGIN [qdr_user];

