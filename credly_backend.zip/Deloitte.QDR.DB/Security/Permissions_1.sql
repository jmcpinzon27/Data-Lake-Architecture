﻿
GO
GRANT ALTER TO [qdr_user];

