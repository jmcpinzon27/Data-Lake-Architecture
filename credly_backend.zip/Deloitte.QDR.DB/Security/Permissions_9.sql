﻿
GO
GRANT CONNECT TO [qdr_user_portal];

