﻿CREATE LOGIN [tableu_qdr_user]
    WITH PASSWORD = N'kIqIuf{hhqdxkUlp|tihp2i6msFT7_&#$!~<vx|;aqixHuco';

