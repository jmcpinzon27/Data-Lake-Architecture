﻿CREATE TABLE [dbo].[BadgePathwaySkill](
	[Id] [uniqueidentifier] NOT NULL,
	[BadgePathway_Id] [uniqueidentifier] NOT NULL,
	[Skill_Id] [uniqueidentifier] NOT NULL,
 CONSTRAINT [PK_BadgePathwaySkill] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY],
 CONSTRAINT [UQ_BadgePathwayBadgeTemplate_BadgePathway_Skill] UNIQUE NONCLUSTERED 
(
	[BadgePathway_Id] ASC,
	[Skill_Id] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[BadgePathwaySkill]  WITH CHECK ADD  CONSTRAINT [FK_BadgePathwaySkill_BadgePathway] FOREIGN KEY([BadgePathway_Id])
REFERENCES [dbo].[BadgePathway] ([Id])
GO

ALTER TABLE [dbo].[BadgePathwaySkill] CHECK CONSTRAINT [FK_BadgePathwaySkill_BadgePathway]
GO


GO
ALTER TABLE [dbo].[BadgePathwaySkill]  WITH CHECK ADD  CONSTRAINT [FK_BadgePathwaySkill_Skill] FOREIGN KEY([Skill_Id])
REFERENCES [dbo].[Skill] ([Id])
GO

ALTER TABLE [dbo].[BadgePathwaySkill] CHECK CONSTRAINT [FK_BadgePathwaySkill_Skill]
GO


GO
ALTER TABLE [dbo].[BadgePathwaySkill] ADD  DEFAULT (newid()) FOR [Id]
GO
