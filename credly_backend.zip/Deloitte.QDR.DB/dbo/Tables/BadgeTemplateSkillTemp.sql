﻿CREATE TABLE [dbo].[BadgeTemplateSkillTemp](
	[Id] [uniqueidentifier] NOT NULL,
	[BadgeTemplate_Id] [uniqueidentifier] NULL,
	[SkillName] [varchar](100) NULL,
PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[BadgeTemplateSkillTemp]  WITH NOCHECK ADD  CONSTRAINT [FK_BadgeTemplateSkillTemp_BadgeTemplate_Id] FOREIGN KEY([BadgeTemplate_Id])
REFERENCES [dbo].[BadgeTemplate] ([Id])
GO

ALTER TABLE [dbo].[BadgeTemplateSkillTemp] CHECK CONSTRAINT [FK_BadgeTemplateSkillTemp_BadgeTemplate_Id]
GO


GO


GO


GO
ALTER TABLE [dbo].[BadgeTemplateSkillTemp] ADD  DEFAULT (newid()) FOR [Id]


GO
