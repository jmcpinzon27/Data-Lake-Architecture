﻿CREATE TABLE [dbo].[Faq](
	[Id] [uniqueidentifier] NOT NULL,
	[Question] [varchar](500) NULL,
	[Answer] [varchar](1000) NULL,
	[Category_Id] [uniqueidentifier] NULL,
	[Order] [int] NULL,
PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO

ALTER TABLE [dbo].[Faq]  WITH CHECK ADD  CONSTRAINT [FK_Faq_Category] FOREIGN KEY([Category_Id])
REFERENCES [dbo].[FaqCategory] ([Id])
GO

ALTER TABLE [dbo].[Faq] CHECK CONSTRAINT [FK_Faq_Category]
GO


GO


GO
