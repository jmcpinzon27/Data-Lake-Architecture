﻿CREATE TABLE [dbo].[Role] (
    [Id]          UNIQUEIDENTIFIER DEFAULT (newid()) NOT NULL,
    [Code]        NVARCHAR (50)    NULL,
    [Description] NVARCHAR (100)   NULL,
    PRIMARY KEY CLUSTERED ([Id] ASC)
);

