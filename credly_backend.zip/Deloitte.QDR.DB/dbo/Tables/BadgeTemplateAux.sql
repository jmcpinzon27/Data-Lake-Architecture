﻿CREATE TABLE [dbo].[BadgeTemplateAux] (
    [Id]          UNIQUEIDENTIFIER DEFAULT (newid()) NOT NULL,
    [Issuer]      NVARCHAR (100)   NULL,
    [ExternalId]  VARCHAR (50)     NULL,
    [Name]        NVARCHAR (255)   NULL,
    [Subtitle]    NVARCHAR (255)   NULL,
    [Description] NVARCHAR (500)   NULL,
    [Type]        INT              NULL,
    [Level]       INT              NULL,
    [Status]      INT              NULL,
    [ImageUrl]    NVARCHAR (500)   NULL,
    [InfoUrl]     NVARCHAR (500)   NULL,
    [CreatedAt]   DATETIME         NULL,
    [UpdateAt]    DATETIME         NULL,
    [RetiredAt]   DATETIME         NULL,
    [CreatedBy]   NVARCHAR (20)    NULL,
    [UpdatedBy]   NVARCHAR (20)    NULL,
    [ApprovedAt]  DATETIME         NULL,
    [Approver_Id] NVARCHAR (20)    NULL,
    [Owner_Id]    NVARCHAR (20)    NULL,
    PRIMARY KEY CLUSTERED ([Id] ASC)
);

