﻿CREATE TABLE [dbo].[ErrorLog](
	[Id] [uniqueidentifier] NOT NULL,
	[Date] [datetime] NOT NULL,
	[Source] [varchar](150) NOT NULL,
	[Message] [varchar](max) NOT NULL,
	[Trace] [varchar](max) NOT NULL,
	[UserEmail] [varchar](60) NULL,
	[PersonID] [varchar](20) NULL,
	[StatusCode] [int] NOT NULL,
	[Method] [varchar](20) NOT NULL,
	[URL] [varchar](2064) NOT NULL,
	[Body] [varchar](max) NULL,
 CONSTRAINT [PK_ErrorLog] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]