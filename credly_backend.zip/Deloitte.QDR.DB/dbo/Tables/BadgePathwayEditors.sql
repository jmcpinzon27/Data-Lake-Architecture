﻿CREATE TABLE [dbo].[BadgePathwayEditors](
	[Id] [uniqueidentifier] NOT NULL,
	[BadgePathway_Id] [uniqueidentifier] NOT NULL,
	[Employee_Id] [varchar](20) NOT NULL,
 CONSTRAINT [PK_BadgePathwayEditors] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[BadgePathwayEditors]  WITH CHECK ADD  CONSTRAINT [FK_BadgePathwayEditors_BadgePathway] FOREIGN KEY([BadgePathway_Id])
REFERENCES [dbo].[BadgePathway] ([Id])
GO

ALTER TABLE [dbo].[BadgePathwayEditors] CHECK CONSTRAINT [FK_BadgePathwayEditors_BadgePathway]
GO


GO
ALTER TABLE [dbo].[BadgePathwayEditors]  WITH CHECK ADD  CONSTRAINT [FK_BadgePathwayEditors_Employee] FOREIGN KEY([Employee_Id])
REFERENCES [dbo].[Employee] ([PersonID])
GO

ALTER TABLE [dbo].[BadgePathwayEditors] CHECK CONSTRAINT [FK_BadgePathwayEditors_Employee]
GO

