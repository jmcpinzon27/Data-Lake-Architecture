﻿CREATE TABLE [dbo].[CredlyEvent](
	[Id] [uniqueidentifier] NOT NULL,
	[EventType] [nvarchar](100) NOT NULL,
	[OccurredAt] [datetime] NOT NULL,
	[Status] [smallint] NOT NULL,
	[ProcessedAt] [datetime] NULL,
	[Body] [nvarchar](max) NULL,
	[EntityType] [smallint] NULL,
	[EntityId] [uniqueidentifier] NULL,
 CONSTRAINT [PK_CredlyEvent] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, FILLFACTOR = 80, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

