﻿CREATE TABLE [dbo].[Skill] (
    [Id]          UNIQUEIDENTIFIER DEFAULT (newid()) NOT NULL,
    [Description] NVARCHAR (300)   NULL,
    PRIMARY KEY CLUSTERED ([Id] ASC)
);

