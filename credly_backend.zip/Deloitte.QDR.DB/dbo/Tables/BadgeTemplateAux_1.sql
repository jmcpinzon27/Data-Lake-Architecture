﻿CREATE TABLE [dbo].[BadgeTemplateAux](
	[Id] [uniqueidentifier] NOT NULL,
	[Issuer] [nvarchar](100) NULL,
	[ExternalId] [varchar](50) NULL,
	[Name] [nvarchar](255) NULL,
	[Subtitle] [nvarchar](255) NULL,
	[Description] [nvarchar](500) NULL,
	[Type] [int] NULL,
	[Level] [int] NULL,
	[Status] [int] NULL,
	[ImageUrl] [nvarchar](500) NULL,
	[InfoUrl] [nvarchar](500) NULL,
	[CreatedAt] [datetime] NULL,
	[UpdateAt] [datetime] NULL,
	[RetiredAt] [datetime] NULL,
	[CreatedBy] [nvarchar](20) NULL,
	[UpdatedBy] [nvarchar](20) NULL,
	[ApprovedAt] [datetime] NULL,
	[Approver_Id] [nvarchar](20) NULL,
	[Owner_Id] [nvarchar](20) NULL,
PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]

GO
ALTER TABLE [dbo].[BadgeTemplateAux] ADD  DEFAULT (newid()) FOR [Id]



GO
