﻿CREATE TABLE [dbo].[CredlyEvent] (
    [Id]          UNIQUEIDENTIFIER NOT NULL,
    [EventType]   NVARCHAR (100)   NOT NULL,
    [OccurredAt]  DATETIME         NOT NULL,
    [Status]      SMALLINT         NOT NULL,
    [ProcessedAt] DATETIME         NULL,
    [Body]        NVARCHAR (MAX)   NULL,
    [EntityType]  SMALLINT         NULL,
    [EntityId]    UNIQUEIDENTIFIER NULL,
    CONSTRAINT [PK_CredlyEvent] PRIMARY KEY CLUSTERED ([Id] ASC) WITH (FILLFACTOR = 80)
);

