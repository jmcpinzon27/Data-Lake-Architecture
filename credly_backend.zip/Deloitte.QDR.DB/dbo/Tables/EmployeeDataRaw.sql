﻿CREATE TABLE [dbo].[EmployeeDataRaw] (
    [Id]   INT           IDENTITY (1, 1) NOT NULL,
    [data] VARCHAR (MAX) NULL,
    PRIMARY KEY CLUSTERED ([Id] ASC)
);

