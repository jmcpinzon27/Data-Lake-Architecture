﻿CREATE TABLE [dbo].[CredlyEmployee](
	[CredlyID] [uniqueidentifier] NULL,
	[Status] [smallint] NULL,
	[RecordLastSent] [datetime] NULL,
	[TermLastSent] [datetime] NULL,
	[PersonID] [varchar](20) NOT NULL,
	[EmployeeState] [varchar](30) NULL,
	[Email] [varchar](50) NULL,
	[FirstName] [nvarchar](100) NULL,
	[LastName] [nvarchar](100) NULL,
	[EmployeeLastStateUpdatedAt] [datetime] NULL,
	[PersonnelNumber] [nvarchar](20) NULL,
 CONSTRAINT [PK_CredlyEmployee] PRIMARY KEY CLUSTERED 
(
	[PersonID] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]

