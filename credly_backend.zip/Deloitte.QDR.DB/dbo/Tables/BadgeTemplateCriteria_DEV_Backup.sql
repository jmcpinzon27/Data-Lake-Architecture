﻿CREATE TABLE [dbo].[BadgeTemplateCriteria_DEV_Backup](
	[Id] [nvarchar](50) NULL,
	[Type] [nvarchar](50) NOT NULL,
	[Name] [nvarchar](50) NOT NULL,
	[Description] [nvarchar](400) NULL,
	[BadgeTemplate_Id] [nvarchar](50) NULL,
	[Approver_Id] [nvarchar](50) NULL,
	[InfoUrl] [nvarchar](100) NULL
) ON [PRIMARY]