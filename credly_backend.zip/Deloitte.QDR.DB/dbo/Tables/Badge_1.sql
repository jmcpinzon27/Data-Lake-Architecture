﻿CREATE TABLE [dbo].[Badge] (
    [Id]                          UNIQUEIDENTIFIER DEFAULT (newid()) NOT NULL,
    [ExternalId]                  VARCHAR (50)     NULL,
    [BadgeTemplateId]             UNIQUEIDENTIFIER NOT NULL,
    [PersonID]                    VARCHAR (20)     NULL,
    [Status]                      INT              NULL,
    [DecisionAt]                  DATETIME         NULL,
    [AwardedAt]                   DATETIME         NULL,
    [ExpiresAt]                   DATETIME         NULL,
    [SubmittedAt]                 DATETIME         NULL,
    [EducationStatus]             INT              NULL,
    [EducationApprovedAt]         DATETIME         NULL,
    [ExperienceStatus]            INT              NULL,
    [ExperienceApprovedAt]        DATETIME         NULL,
    [ExposureStatus]              INT              NULL,
    [ExposureApprovedAt]          DATETIME         NULL,
    [Private]                     BIT              DEFAULT ('false') NULL,
    [State]                       VARCHAR (MAX)    NULL,
    [StartAt]                     DATETIME         NULL,
    [DeniedAt]                    DATETIME         NULL,
    [InitiatedAt]                 DATETIME         NULL,
    [ArchiveDate]                 DATETIME         NULL,
    [RejectedAt]                  DATETIME         NULL,
    [AlternativeCriteriaSelected] BIT              NULL,
    [RateFeedback]                NVARCHAR (MAX)   NULL,
    [PersonnelNumber]             NVARCHAR (20)    NULL,
    PRIMARY KEY CLUSTERED ([Id] ASC),
    CONSTRAINT [FK_Badge_BadgeTemplateId] FOREIGN KEY ([BadgeTemplateId]) REFERENCES [dbo].[BadgeTemplate] ([Id]),
    CONSTRAINT [FK_Employee_Badge_PersonID] FOREIGN KEY ([PersonID]) REFERENCES [dbo].[Employee] ([PersonID])
);


GO


GO


GO


GO


GO


GO


GO


GO


GO


GO


GO
