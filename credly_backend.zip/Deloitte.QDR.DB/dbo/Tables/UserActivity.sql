﻿CREATE TABLE [dbo].[UserActivity] (
    [Id]          UNIQUEIDENTIFIER DEFAULT (newid()) NOT NULL,
    [Type]        INT              NOT NULL,
    [EntityId]    NVARCHAR (40)    NULL,
    [Title]       NVARCHAR (100)   NULL,
    [Description] VARCHAR (300)    NULL,
    [Date]        DATETIME         NULL,
    [Employee_Id] VARCHAR (20)     NULL,
    PRIMARY KEY CLUSTERED ([Id] ASC),
    CONSTRAINT [FK_UserActivity_Employee_Id] FOREIGN KEY ([Employee_Id]) REFERENCES [dbo].[Employee] ([PersonID])
);

