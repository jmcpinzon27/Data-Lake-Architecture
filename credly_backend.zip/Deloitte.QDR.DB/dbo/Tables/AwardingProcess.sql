CREATE TABLE [dbo].[AwardingProcess](
	[Id] [uniqueidentifier] NOT NULL,
	[CohortId] [int] IDENTITY(1,1) NOT NULL,
	[Title] [varchar](100) NULL,
	[BadgeTemplate_Id] [uniqueidentifier] NULL,
	[CompletionDate] [datetime] NULL,
	[Approver_Id] [varchar](20) NULL,
	[Status] [int] NULL,
	[CreatedBy] [varchar](20) NULL,
	[Createdate] [datetime] NULL,
	[CsvUrlFile] [varchar](256) NULL,
	[ZipUrlFile] [varchar](256) NULL,
	[Note] [varchar](500) NULL,
PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[AwardingProcess]  WITH CHECK ADD  CONSTRAINT [FK_BadgeTempAwardingProc] FOREIGN KEY([BadgeTemplate_Id])
REFERENCES [dbo].[BadgeTemplate] ([Id])
GO

ALTER TABLE [dbo].[AwardingProcess] CHECK CONSTRAINT [FK_BadgeTempAwardingProc]
GO


GO


GO


GO


GO


GO

GO
ALTER TABLE [dbo].[AwardingProcess] ADD  DEFAULT (newid()) FOR [Id]
GO
ALTER TABLE [dbo].[AwardingProcess]  WITH CHECK ADD  CONSTRAINT [FK_EmployeeAwardingProc] FOREIGN KEY([Approver_Id])
REFERENCES [dbo].[Employee] ([PersonID])
GO

ALTER TABLE [dbo].[AwardingProcess] CHECK CONSTRAINT [FK_EmployeeAwardingProc]
GO


GO
