﻿CREATE TABLE [dbo].[FaqCategory](
	[Id] [uniqueidentifier] NOT NULL,
	[Description] [varchar](100) NULL,
	[Order] [int] NULL,
	[Parent_Id] [uniqueidentifier] NULL,
PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO

ALTER TABLE [dbo].[FaqCategory]  WITH CHECK ADD  CONSTRAINT [FK_Category_Parent] FOREIGN KEY([Parent_Id])
REFERENCES [dbo].[FaqCategory] ([Id])
GO

ALTER TABLE [dbo].[FaqCategory] CHECK CONSTRAINT [FK_Category_Parent]
GO


GO


GO
