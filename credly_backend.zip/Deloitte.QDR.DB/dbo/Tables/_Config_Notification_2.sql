﻿CREATE TABLE [dbo].[_Config_Notification](
	[NotificationId] [varchar](200) NOT NULL,
	[NotificationType] [varchar](20) NOT NULL,
	[EntityType] [varchar](20) NOT NULL,
	[ActivityType] [varchar](30) NOT NULL,
	[Title] [varchar](200) NOT NULL,
	[Description] [varchar](1000) NOT NULL,
	[SendEmail] [bit] NULL,
	[EmailSubject] [varchar](200) NULL,
	[EmailTitle] [varchar](200) NULL,
	[EmailDescription] [varchar](max) NULL,
	[EmailImage] [varchar](1000) NULL,
	[EmailLink] [varchar](1000) NULL,
 CONSTRAINT [PK__Config_Notification_1] PRIMARY KEY CLUSTERED 
(
	[NotificationId] ASC,
	[EntityType] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]