﻿CREATE TABLE [dbo].[BadgePathwayBadgeTemplate](
	[Id] [uniqueidentifier] NOT NULL,
	[BadgePathway_Id] [uniqueidentifier] NOT NULL,
	[BadgeTemplate_Id] [uniqueidentifier] NOT NULL,
 CONSTRAINT [PK_BadgePathwayBadgeTemplate] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY],
 CONSTRAINT [UQ_BadgePathwayBadgeTemplate_BadgePathway_BadgeTemplate] UNIQUE NONCLUSTERED 
(
	[BadgePathway_Id] ASC,
	[BadgeTemplate_Id] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[BadgePathwayBadgeTemplate]  WITH CHECK ADD  CONSTRAINT [FK_BadgePathwayBadgeTemplate_BadgePathway] FOREIGN KEY([BadgePathway_Id])
REFERENCES [dbo].[BadgePathway] ([Id])
GO

ALTER TABLE [dbo].[BadgePathwayBadgeTemplate] CHECK CONSTRAINT [FK_BadgePathwayBadgeTemplate_BadgePathway]
GO


GO


GO
ALTER TABLE [dbo].[BadgePathwayBadgeTemplate]  WITH CHECK ADD  CONSTRAINT [FK_BadgePathwayBadgeTemplate_BadgeTemplate] FOREIGN KEY([BadgeTemplate_Id])
REFERENCES [dbo].[BadgeTemplate] ([Id])
GO

ALTER TABLE [dbo].[BadgePathwayBadgeTemplate] CHECK CONSTRAINT [FK_BadgePathwayBadgeTemplate_BadgeTemplate]
GO


GO


GO
ALTER TABLE [dbo].[BadgePathwayBadgeTemplate] ADD  DEFAULT (newid()) FOR [Id]

GO
