﻿CREATE TABLE [dbo].[Education] (
    [Id]                       UNIQUEIDENTIFIER DEFAULT (newid()) NOT NULL,
    [Title]                    NVARCHAR (MAX)   NULL,
    [Vendor]                   NVARCHAR (200)   NULL,
    [Description]              NVARCHAR (1000)  NULL,
    [CompletionDate]           DATETIME         NULL,
    [Badge_Id]                 UNIQUEIDENTIFIER NULL,
    [BadgeTemplateCriteria_Id] UNIQUEIDENTIFIER NULL,
    [Upload]                   VARCHAR (MAX)    NULL,
    [Url]                      VARCHAR (300)    NULL,
    [BusinessValidation]       BIT              NULL,
    [EvidenceExpected]         VARCHAR (500)    NULL,
    [IsAlternative]            BIT              NULL,
    [SABACourseValidated]      BIT              CONSTRAINT [Default_Education_SABACourseValidated] DEFAULT ((0)) NULL,
    PRIMARY KEY CLUSTERED ([Id] ASC),
    CONSTRAINT [FK_Education_Badge_Id] FOREIGN KEY ([Badge_Id]) REFERENCES [dbo].[Badge] ([Id]),
    CONSTRAINT [FK_Education_BadgeTemplateCriteria_Id] FOREIGN KEY ([BadgeTemplateCriteria_Id]) REFERENCES [dbo].[BadgeTemplateCriteria] ([Id])
);


GO


GO


GO


GO


GO


GO


GO


GO


GO


GO



GO