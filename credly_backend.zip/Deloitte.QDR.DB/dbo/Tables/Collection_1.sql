CREATE TABLE [dbo].[Collection](
	[Id] [uniqueidentifier] NOT NULL,
	[Name] [nvarchar](100) NULL,
	[Description] [nvarchar](300) NULL,
	[DateCreated] [datetime] NULL,
	[Owner] [varchar](20) NULL,
PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]


GO
ALTER TABLE [dbo].[Collection] ADD  DEFAULT (newid()) FOR [Id]
GO
ALTER TABLE [dbo].[Collection]  WITH NOCHECK ADD  CONSTRAINT [FK_Collection_Employee_Owner] FOREIGN KEY([Owner])
REFERENCES [dbo].[Employee] ([PersonID])
GO

ALTER TABLE [dbo].[Collection] CHECK CONSTRAINT [FK_Collection_Employee_Owner]
GO


GO
