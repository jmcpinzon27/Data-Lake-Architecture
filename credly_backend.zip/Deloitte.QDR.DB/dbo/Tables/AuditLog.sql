﻿CREATE TABLE [dbo].[AuditLog] (
    [Id]           UNIQUEIDENTIFIER DEFAULT (newid()) NOT NULL,
    [EntityName]   NVARCHAR (50)    NULL,
    [PropertyName] NVARCHAR (50)    NULL,
    [EntityId]     NVARCHAR (40)    NULL,
    [OldValue]     NVARCHAR (MAX)   NULL,
    [NewValue]     NVARCHAR (MAX)   NULL,
    [Date]         DATETIME         NULL,
    PRIMARY KEY CLUSTERED ([Id] ASC)
);

