﻿CREATE TABLE [dbo].[ProcessLog] (
    [Id]           UNIQUEIDENTIFIER NOT NULL,
    [Date]         DATETIME         NOT NULL,
    [Pipeline]     VARCHAR (255)    NOT NULL,
    [EntityType]   VARCHAR (255)    NULL,
    [EntityId]     VARCHAR (255)    NULL,
    [Step]         VARCHAR (50)     NULL,
    [EventMessage] VARCHAR (MAX)    NULL,
    CONSTRAINT [PK_ProcessLog] PRIMARY KEY CLUSTERED ([Id] ASC)
);

