﻿CREATE TABLE [dbo].[RateBadge](
	[Id] [uniqueidentifier] NOT NULL,
	[BadgeName] [varchar](60) NOT NULL,
	[RememberRate] [bit] NULL,
	[CanceledRate] [bit] NULL,
	[BadgeId] [uniqueidentifier] NOT NULL,
	[PersonId] [varchar](20) NOT NULL,
	[CreatedAt] [datetime] NULL,
	[IsActive] [bit] NULL,
PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]