﻿CREATE TABLE [dbo].[Notification](
	[Id] [uniqueidentifier] NOT NULL,
	[Date] [datetime] NULL,
	[Title] [nvarchar](300) NULL,
	[Description] [nvarchar](1100) NULL,
	[EntityType] [int] NULL,
	[EntityId] [nvarchar](40) NULL,
	[Read] [bit] NULL,
	[ReadDate] [datetime] NULL,
	[Employee_Id] [varchar](20) NULL,
	[Detail] [nvarchar](300) NULL,
	[Status] [varchar](50) NULL,
PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[Notification]  WITH NOCHECK ADD  CONSTRAINT [FK_Notification_Employee_Id] FOREIGN KEY([Employee_Id])
REFERENCES [dbo].[Employee] ([PersonID])
GO

ALTER TABLE [dbo].[Notification] CHECK CONSTRAINT [FK_Notification_Employee_Id]
GO


GO


GO

ALTER TABLE [dbo].[Notification] ADD  DEFAULT (newid()) FOR [Id]
GO
ALTER TABLE [dbo].[Notification] ADD  DEFAULT ((0)) FOR [Read]


GO
