﻿CREATE TABLE [dbo].[BadgeTemplateCollection] (
    [BadgeTemplate_Id] UNIQUEIDENTIFIER NULL,
    [Collection_Id]    UNIQUEIDENTIFIER NULL
);

