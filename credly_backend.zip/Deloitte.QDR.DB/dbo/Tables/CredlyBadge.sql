﻿CREATE TABLE [dbo].[CredlyBadge](
	[Id] [uniqueidentifier] NOT NULL,
	[CredlyId] [varchar](50) NULL,
	[BadgeTemplateCredlyId] [uniqueidentifier] NULL,
	[Issuer] [varchar](30) NULL,
	[BadgeName] [nvarchar](max) NULL,
	[BadgeDescription] [varchar](max) NULL,
	[BadgeUrl] [varchar](max) NULL,
	[BadgeSkills] [nvarchar](max) NULL,
	[PersonID] [nvarchar](20) NULL,
	[FisrtName] [nvarchar](max) NULL,
	[LastName] [nvarchar](max) NULL,
	[State] [varchar](max) NULL,
	[Privacy] [bit] NULL,
	[AwardedAt] [datetime] NULL,
	[ExpiresAt] [datetime] NULL,
PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
ALTER TABLE [dbo].[CredlyBadge] ADD  DEFAULT (newid()) FOR [Id]



GO
