﻿CREATE TABLE [dbo].[Education] (
    [Id]                       UNIQUEIDENTIFIER DEFAULT (newid()) NOT NULL,
    [Title]                    NVARCHAR (100)   NULL,
    [Vendor]                   NVARCHAR (200)   NULL,
    [Description]              NVARCHAR (400)   NULL,
    [Hours]                    INT              NULL,
    [ComplationDate]           DATETIME         NULL,
    [Badge_Id]                 UNIQUEIDENTIFIER NULL,
    [BadgeTemplateCriteria_Id] UNIQUEIDENTIFIER NULL,
    PRIMARY KEY CLUSTERED ([Id] ASC),
    CONSTRAINT [FK_Education_BadgeTemplateCriteria_Id] FOREIGN KEY ([BadgeTemplateCriteria_Id]) REFERENCES [dbo].[BadgeTemplateCriteria] ([Id])
);

