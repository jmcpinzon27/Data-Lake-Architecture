﻿CREATE TABLE [dbo].[CertBadgeMapping](
	[SAPID] [uniqueidentifier] NOT NULL,
	[SAPDesc] [nvarchar](250) NULL,
	[Vendor] [nvarchar](250) NULL,
	[CredlyID] [uniqueidentifier] NOT NULL,
	[CredlyDesc] [nvarchar](250) NULL,
 CONSTRAINT [PK_CertBadgeMapping] PRIMARY KEY CLUSTERED 
(
	[SAPID] ASC,
	[CredlyID] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, FILLFACTOR = 80, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]

