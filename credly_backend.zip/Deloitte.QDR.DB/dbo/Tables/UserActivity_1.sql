﻿CREATE TABLE [dbo].[UserActivity](
	[Id] [uniqueidentifier] NOT NULL,
	[Type] [int] NOT NULL,
	[EntityId] [nvarchar](40) NULL,
	[Title] [nvarchar](100) NULL,
	[Description] [varchar](300) NULL,
	[Date] [datetime] NULL,
	[Employee_Id] [varchar](20) NULL,
PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]


GO
ALTER TABLE [dbo].[UserActivity]  WITH NOCHECK ADD  CONSTRAINT [FK_UserActivity_Employee_Id] FOREIGN KEY([Employee_Id])
REFERENCES [dbo].[Employee] ([PersonID])
GO

ALTER TABLE [dbo].[UserActivity] CHECK CONSTRAINT [FK_UserActivity_Employee_Id]
GO


GO


GO


GO

ALTER TABLE [dbo].[UserActivity] ADD  DEFAULT (newid()) FOR [Id]


GO
