﻿CREATE TABLE [dbo].[RateQuestionBadge](
	[BadgeId] [uniqueidentifier] NOT NULL,
	[QuestionId] [uniqueidentifier] NOT NULL,
	[Rate] [decimal](18, 0) NULL,
	[Id] [uniqueidentifier] NOT NULL,
 CONSTRAINT [PK_RateQuestionBadge] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[RateQuestionBadge]  WITH CHECK ADD  CONSTRAINT [FK_RateQuestionBadge_Badge] FOREIGN KEY([BadgeId])
REFERENCES [dbo].[Badge] ([Id])
GO

ALTER TABLE [dbo].[RateQuestionBadge] CHECK CONSTRAINT [FK_RateQuestionBadge_Badge]
GO


GO
ALTER TABLE [dbo].[RateQuestionBadge]  WITH CHECK ADD  CONSTRAINT [FK_RateQuestionBadge_RateQuestion] FOREIGN KEY([QuestionId])
REFERENCES [dbo].[RateQuestion] ([Id])
GO

ALTER TABLE [dbo].[RateQuestionBadge] CHECK CONSTRAINT [FK_RateQuestionBadge_RateQuestion]
GO

