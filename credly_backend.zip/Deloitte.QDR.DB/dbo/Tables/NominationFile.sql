﻿CREATE TABLE [dbo].[NominationFile](
	[Id] [uniqueidentifier] NOT NULL,
	[NominationId] [uniqueidentifier] NOT NULL,
	[FileUrl] [varchar](256) NULL,
	[CreatedDate] [datetime] NULL,
	[UpdatedDate] [datetime] NULL,
	[Type] [int] NULL,
PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[NominationFile]  WITH CHECK ADD  CONSTRAINT [FK_Nomination] FOREIGN KEY([NominationId])
REFERENCES [dbo].[Nomination] ([Id])
GO

ALTER TABLE [dbo].[NominationFile] CHECK CONSTRAINT [FK_Nomination]
GO


GO
ALTER TABLE [dbo].[NominationFile] ADD  DEFAULT (newid()) FOR [Id]
GO
