﻿CREATE TABLE [dbo].[ProcessLog](
	[Id] [uniqueidentifier] NOT NULL,
	[Date] [datetime] NOT NULL,
	[Pipeline] [varchar](255) NOT NULL,
	[EntityType] [varchar](255) NULL,
	[EntityId] [varchar](255) NULL,
	[Step] [varchar](50) NULL,
	[EventMessage] [varchar](max) NULL,
 CONSTRAINT [PK_ProcessLog] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

