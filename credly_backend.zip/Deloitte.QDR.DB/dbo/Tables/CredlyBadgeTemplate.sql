﻿CREATE TABLE [dbo].[CredlyBadgeTemplate](
	[Id] [uniqueidentifier] NOT NULL,
	[CredlyId] [varchar](50) NULL,
	[BadgeTemplateName] [varchar](50) NULL,
	[BadgeTemplateDescription] [varchar](max) NULL,
	[ImageUrl] [varchar](max) NULL,
	[BadgeSkills] [varchar](max) NULL,
PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
ALTER TABLE [dbo].[CredlyBadgeTemplate] ADD  DEFAULT (newid()) FOR [Id]



GO
