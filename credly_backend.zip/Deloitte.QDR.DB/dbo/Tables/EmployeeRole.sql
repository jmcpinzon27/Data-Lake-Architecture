﻿CREATE TABLE [dbo].[EmployeeRole] (
    [Employee_Id] VARCHAR (20)     NULL,
    [Role_Id]     UNIQUEIDENTIFIER NULL,
    CONSTRAINT [FK_EmployeeRole_Employee_Id] FOREIGN KEY ([Employee_Id]) REFERENCES [dbo].[Employee] ([PersonID])
);

