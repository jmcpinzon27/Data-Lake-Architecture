﻿CREATE TABLE [dbo].[BadgeTemplateSkill] (
    [BadgeTemplate_Id] UNIQUEIDENTIFIER NULL,
    [Skill_Id]         UNIQUEIDENTIFIER NULL,
    [Proficiency]      SMALLINT         NULL
);

