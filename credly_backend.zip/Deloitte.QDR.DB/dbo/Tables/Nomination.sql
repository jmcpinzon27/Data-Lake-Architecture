﻿CREATE TABLE [dbo].[Nomination](
	[Id] [uniqueidentifier] NOT NULL,
	[BadgeTemplateId] [uniqueidentifier] NOT NULL,
	[BadgeId] [uniqueidentifier] NULL,
	[NominatorId] [varchar](20) NOT NULL,
	[NomineeId] [varchar](20) NOT NULL,
	[NomineeRelationship] [varchar](250) NOT NULL,
	[SummaryNomination] [varchar](1000) NOT NULL,
	[CreatedDate] [datetime] NULL,
	[SubmitionDate] [datetime] NULL,
	[UpdatedDate] [datetime] NULL,
	[State] [int] NULL,
PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[Nomination]  WITH CHECK ADD  CONSTRAINT [FK_BadeNomination] FOREIGN KEY([BadgeId])
REFERENCES [dbo].[Badge] ([Id])
GO

ALTER TABLE [dbo].[Nomination] CHECK CONSTRAINT [FK_BadeNomination]
GO


GO
ALTER TABLE [dbo].[Nomination]  WITH CHECK ADD  CONSTRAINT [FK_BadeTemplateNomination] FOREIGN KEY([BadgeTemplateId])
REFERENCES [dbo].[BadgeTemplate] ([Id])
GO

ALTER TABLE [dbo].[Nomination] CHECK CONSTRAINT [FK_BadeTemplateNomination]
GO


GO
ALTER TABLE [dbo].[Nomination]  WITH CHECK ADD  CONSTRAINT [FK_EmployeeNominator] FOREIGN KEY([NominatorId])
REFERENCES [dbo].[Employee] ([PersonID])
GO

ALTER TABLE [dbo].[Nomination] CHECK CONSTRAINT [FK_EmployeeNominator]
GO


GO
ALTER TABLE [dbo].[Nomination]  WITH CHECK ADD  CONSTRAINT [FK_EmployeeNominee] FOREIGN KEY([NomineeId])
REFERENCES [dbo].[Employee] ([PersonID])
GO

ALTER TABLE [dbo].[Nomination] CHECK CONSTRAINT [FK_EmployeeNominee]
GO


GO
ALTER TABLE [dbo].[Nomination] ADD  DEFAULT (newid()) FOR [Id]
GO
