﻿CREATE TABLE [dbo].[Notification] (
    [Id]          UNIQUEIDENTIFIER DEFAULT (newid()) NOT NULL,
    [Date]        DATETIME         NULL,
    [Title]       NVARCHAR (100)   NULL,
    [Description] NVARCHAR (300)   NULL,
    [EntityType]  INT              NULL,
    [EntityId]    NVARCHAR (40)    NULL,
    [Read]        BIT              DEFAULT ((0)) NULL,
    [ReadDate]    DATETIME         NULL,
    [Employee_Id] VARCHAR (20)     NULL,
    [Detail]      NVARCHAR (300)   NULL,
    PRIMARY KEY CLUSTERED ([Id] ASC),
    CONSTRAINT [FK_Notification_Employee_Id] FOREIGN KEY ([Employee_Id]) REFERENCES [dbo].[Employee] ([PersonID])
);

