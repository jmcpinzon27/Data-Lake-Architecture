﻿CREATE TABLE [dbo].[RateQuestion](
	[Id] [uniqueidentifier] NOT NULL,
	[Question] [nvarchar](1000) NOT NULL,
	[IsActive] [bit] NOT NULL,
	[CreatedDate] [datetime] NULL,
	[UpdatedDate] [datetime] NULL,
	[UpdatedByPerson] [varchar](20) NULL,
	[Order] [int] NOT NULL,
 CONSTRAINT [PK_RateQuestion] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]