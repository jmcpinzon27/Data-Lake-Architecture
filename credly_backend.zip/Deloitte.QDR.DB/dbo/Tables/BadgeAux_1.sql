﻿CREATE TABLE [dbo].[BadgeAux](
	[Id] [uniqueidentifier] NOT NULL,
	[ExternalId] [varchar](50) NULL,
	[BadgeTemplateId] [uniqueidentifier] NULL,
	[PersonID] [nvarchar](20) NULL,
	[Status] [int] NULL,
	[DecisionAt] [datetime] NULL,
	[AwardedAt] [datetime] NULL,
	[ExpiresAt] [datetime] NULL,
	[SubmittedAt] [datetime] NULL,
	[EducationStatus] [int] NULL,
	[EducationApprovedAt] [datetime] NULL,
	[ExperienceStatus] [int] NULL,
	[ExperienceApprovedAt] [datetime] NULL,
	[ExposureStatus] [int] NULL,
	[ExposureApprovedAt] [datetime] NULL,
PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]


GO
ALTER TABLE [dbo].[BadgeAux] ADD  DEFAULT (newid()) FOR [Id]



GO
