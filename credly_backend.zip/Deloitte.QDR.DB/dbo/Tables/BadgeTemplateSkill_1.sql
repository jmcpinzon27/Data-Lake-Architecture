﻿CREATE TABLE [dbo].[BadgeTemplateSkill](
	[BadgeTemplate_Id] [uniqueidentifier] NOT NULL,
	[Skill_Id] [uniqueidentifier] NOT NULL,
	[Proficiency] [smallint] NULL,
	[SkillType] [int] NULL,
PRIMARY KEY CLUSTERED 
(
	[BadgeTemplate_Id] ASC,
	[Skill_Id] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]


GO
ALTER TABLE [dbo].[BadgeTemplateSkill]  WITH CHECK ADD  CONSTRAINT [FK_BadgeTemplateSkill_Skill_Id] FOREIGN KEY([Skill_Id])
REFERENCES [dbo].[Skill] ([Id])
GO

ALTER TABLE [dbo].[BadgeTemplateSkill] CHECK CONSTRAINT [FK_BadgeTemplateSkill_Skill_Id]
GO


GO


GO


GO


GO


GO


GO


GO


GO


GO


GO


GO
ALTER TABLE [dbo].[BadgeTemplateSkill]  WITH NOCHECK ADD  CONSTRAINT [FK_BadgeTemplateSkill_BadgeTemplate_Id] FOREIGN KEY([BadgeTemplate_Id])
REFERENCES [dbo].[BadgeTemplate] ([Id])
GO

ALTER TABLE [dbo].[BadgeTemplateSkill] CHECK CONSTRAINT [FK_BadgeTemplateSkill_BadgeTemplate_Id]
GO


GO


GO


GO


GO


GO


GO


GO


GO


GO


GO

