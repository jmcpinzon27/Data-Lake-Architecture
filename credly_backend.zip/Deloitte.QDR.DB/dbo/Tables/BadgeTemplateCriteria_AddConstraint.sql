﻿ALTER TABLE [dbo].[BadgeTemplateCriteria] 
ADD CONSTRAINT [FK_BadgeTemplateCriteria_BadgeTemplateCriteria_Id] FOREIGN KEY([BadgeTemplate_Id])
REFERENCES [dbo].[BadgeTemplate] ([Id])
GO