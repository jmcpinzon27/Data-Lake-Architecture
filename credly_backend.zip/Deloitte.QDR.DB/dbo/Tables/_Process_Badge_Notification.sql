﻿CREATE TABLE [dbo].[_Process_Badge_Notification](
	[ProcessBadgeNotificationId] [int] IDENTITY(1,1) NOT NULL,
	[BadgeTemplateId] [uniqueidentifier] NOT NULL,
	[BadgeId] [uniqueidentifier] NOT NULL,
	[BadgeOldStatus] [int] NULL,
	[BadgeNewStatus] [int] NOT NULL,
	[EmailEmployee] [nvarchar](300) NOT NULL,
	[ProcessStatus] [nvarchar](15) NOT NULL,
	[CreatedDate] [datetime] NOT NULL,
	[UpdatedDate] [datetime] NOT NULL,
PRIMARY KEY CLUSTERED 
(
	[ProcessBadgeNotificationId] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[_Process_Badge_Notification] ADD  DEFAULT ('PENDING') FOR [ProcessStatus]
GO
ALTER TABLE [dbo].[_Process_Badge_Notification] ADD  DEFAULT (getdate()) FOR [CreatedDate]
GO
ALTER TABLE [dbo].[_Process_Badge_Notification] ADD  DEFAULT (getdate()) FOR [UpdatedDate]

GO
