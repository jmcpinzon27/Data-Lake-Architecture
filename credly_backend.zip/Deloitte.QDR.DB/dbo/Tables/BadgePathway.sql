CREATE TABLE [dbo].[BadgePathway](
	[Id] [uniqueidentifier] NOT NULL,
	[Name] [varchar](40) NOT NULL,
	[Owner_Id] [varchar](20) NOT NULL,
	[ImageUrl] [varchar](500) NOT NULL,
	[Description] [varchar](max) NOT NULL,
	[CreatedAt] [datetime] NOT NULL,
	[IsPublic] [bit] NOT NULL DEFAULT 0,
	[Status] [int] NOT NULL DEFAULT 0,
	[Contact_Id] [varchar](20) NULL,
 CONSTRAINT [PK_BadgePathway] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY],
UNIQUE NONCLUSTERED 
(
	[Name] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY],
 CONSTRAINT [UQ_BadgePathway_Name] UNIQUE NONCLUSTERED 
(
	[Name] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
ALTER TABLE [dbo].[BadgePathway]  WITH CHECK ADD  CONSTRAINT [FK_BadgePathway_Owner] FOREIGN KEY([Owner_Id])
REFERENCES [dbo].[Employee] ([PersonID])
GO

ALTER TABLE [dbo].[BadgePathway] CHECK CONSTRAINT [FK_BadgePathway_Owner]
GO


GO


GO
ALTER TABLE [dbo].[BadgePathway] ADD  DEFAULT (newid()) FOR [Id]
GO
ALTER TABLE [dbo].[BadgePathway]  WITH CHECK ADD  CONSTRAINT [FK_BadgePathway_Contact] FOREIGN KEY([Contact_Id])
REFERENCES [dbo].[Employee] ([PersonID])
GO

ALTER TABLE [dbo].[BadgePathway] CHECK CONSTRAINT [FK_BadgePathway_Contact]
GO


GO
