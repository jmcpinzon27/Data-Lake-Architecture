﻿CREATE TABLE [dbo].[BadgeTemplate] (
    [Id]                             UNIQUEIDENTIFIER DEFAULT (newid()) NOT NULL,
    [Issuer]                         NVARCHAR (100)   NULL,
    [ExternalId]                     VARCHAR (50)     NULL,
    [Name]                           NVARCHAR (255)   NULL,
    [Subtitle]                       NVARCHAR (255)   NULL,
    [Description]                    NVARCHAR (500)   NULL,
    [Type]                           INT              NULL,
    [Level]                          INT              NULL,
    [Status]                         INT              NULL,
    [ImageUrl]                       NVARCHAR (500)   NULL,
    [InfoUrl]                        NVARCHAR (500)   NULL,
    [CreatedAt]                      DATETIME         NULL,
    [UpdateAt]                       DATETIME         NULL,
    [RetiredAt]                      DATETIME         NULL,
    [CreatedBy]                      NVARCHAR (20)    NULL,
    [UpdatedBy]                      NVARCHAR (20)    NULL,
    [ApprovedAt]                     DATETIME         NULL,
    [Approver_Id]                    VARCHAR (20)     NULL,
    [Owner_Id]                       VARCHAR (20)     NULL,
    [Sponsor_Id]                     VARCHAR (20)     NULL,
    [ReviewDate]                     DATETIME         NULL,
    [ExpiresAt]                      INT              NULL,
    [ApproverName]                   VARCHAR (50)     NULL,
    [OptionalApprover_Id]            VARCHAR (20)     NULL,
    [State]                          VARCHAR (60)     NULL,
    [BadgeTemplateLevel]             NVARCHAR (60)    NULL,
    [LearningObjectives]             VARCHAR (500)    NULL,
    [IsPublic]                       BIT              NULL,
    [ReleaseNotes]                   VARCHAR (MAX)    NULL,
    [ApplyReleaseNotesOnlyInitiated] BIT              NULL,
    [ArchiveDate]                    DATETIME         NULL,
    [HaveAlternativeCriteria]        BIT              NULL,
    [NominationGuidance]             NVARCHAR (1000)  NULL,
    [AlternativeDescription]         VARCHAR (MAX)    NULL,
    [Privacy]                        BIT              NULL,
    PRIMARY KEY CLUSTERED ([Id] ASC),
    CONSTRAINT [FK_BadgeTemplate_Approver_Id] FOREIGN KEY ([Approver_Id]) REFERENCES [dbo].[Employee] ([PersonID]),
    CONSTRAINT [FK_BadgeTemplate_OptionalApprover_Id] FOREIGN KEY ([OptionalApprover_Id]) REFERENCES [dbo].[Employee] ([PersonID]),
    CONSTRAINT [FK_BadgeTemplate_Owner_Id] FOREIGN KEY ([Owner_Id]) REFERENCES [dbo].[Employee] ([PersonID]),
    CONSTRAINT [FK_BadgeTemplate_Sponsor_Id] FOREIGN KEY ([Sponsor_Id]) REFERENCES [dbo].[Employee] ([PersonID])
);


GO


GO


GO


GO


GO


GO


GO


GO


GO


GO


GO


GO


GO


GO


GO


GO


GO
