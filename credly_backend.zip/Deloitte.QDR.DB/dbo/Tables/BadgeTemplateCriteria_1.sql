﻿CREATE TABLE [dbo].[BadgeTemplateCriteria](
	[Id] [uniqueidentifier] NOT NULL,
	[Type] [int] NULL,
	[Name] [varchar](100) NULL,
	[Description] [varchar](1000) NULL,
	[BadgeTemplate_Id] [uniqueidentifier] NULL,
	[Approver_Id] [varchar](20) NULL,
	[InfoUrl] [nvarchar](500) NULL,
	[BadgeTemplateCriteriaType_Id] [uniqueidentifier] NULL,
	[BusinessValidation] [bit] NULL,
	[EvidenceExpected] [varchar](500) NULL,
	[Deleted] [bit] NULL,
	[IsAlternative] [bit] NULL,
	[SABAValidationNeeded] [bit] NULL,
	[SABACourseID] [varchar](15) NULL,
	[SABACourseName] [varchar](250) NULL,
PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO

ALTER TABLE [dbo].[BadgeTemplateCriteria]  WITH CHECK ADD  CONSTRAINT [FK_BadgeTemplateCriteria_Approver_Id] FOREIGN KEY([Approver_Id])
REFERENCES [dbo].[Employee] ([PersonID])
GO

ALTER TABLE [dbo].[BadgeTemplateCriteria] CHECK CONSTRAINT [FK_BadgeTemplateCriteria_Approver_Id]
GO


GO


GO

ALTER TABLE [dbo].[BadgeTemplateCriteria]  WITH NOCHECK ADD  CONSTRAINT [FK_BadgeTemplateCriteria_BadgeTemplateCriteria_Id] FOREIGN KEY([BadgeTemplate_Id])
REFERENCES [dbo].[BadgeTemplate] ([Id])
GO

ALTER TABLE [dbo].[BadgeTemplateCriteria] CHECK CONSTRAINT [FK_BadgeTemplateCriteria_BadgeTemplateCriteria_Id]
GO


GO


GO

ALTER TABLE [dbo].[BadgeTemplateCriteria]  WITH CHECK ADD  CONSTRAINT [FK_BadgeTemplateCriteria_BadgeTemplateCriteriaType] FOREIGN KEY([BadgeTemplateCriteriaType_Id])
REFERENCES [dbo].[BadgeTemplateCriteriaType] ([Id])
GO

ALTER TABLE [dbo].[BadgeTemplateCriteria] CHECK CONSTRAINT [FK_BadgeTemplateCriteria_BadgeTemplateCriteriaType]
GO


GO


GO

ALTER TABLE [dbo].[BadgeTemplateCriteria] ADD  DEFAULT (newid()) FOR [Id]
GO

ALTER TABLE [dbo].[BadgeTemplateCriteria] ADD  CONSTRAINT [Default_Education_SABAValidationNeeded]  DEFAULT ((0)) FOR [SABAValidationNeeded]
GO
