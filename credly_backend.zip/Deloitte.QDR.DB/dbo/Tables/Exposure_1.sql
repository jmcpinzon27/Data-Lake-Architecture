﻿CREATE TABLE [dbo].[Exposure] (
    [Id]                       UNIQUEIDENTIFIER DEFAULT (newid()) NOT NULL,
    [ValidatorEmail]           NVARCHAR (200)   NULL,
    [Description]              NVARCHAR (1000)  NULL,
    [Hours]                    INT              NULL,
    [Badge_Id]                 UNIQUEIDENTIFIER NULL,
    [BadgeTemplateCriteria_Id] UNIQUEIDENTIFIER NULL,
    [Upload]                   VARCHAR (MAX)    NULL,
    [Title]                    NVARCHAR (MAX)   NULL,
    [Url]                      VARCHAR (300)    NULL,
    [BusinessValidation]       BIT              NULL,
    [EvidenceExpected]         VARCHAR (500)    NULL,
    [IsAlternative]            BIT              NULL,
    PRIMARY KEY CLUSTERED ([Id] ASC),
    CONSTRAINT [FK_Exposure_Badge_Id] FOREIGN KEY ([Badge_Id]) REFERENCES [dbo].[Badge] ([Id]),
    CONSTRAINT [FK_Exposure_BadgeTemplateCriteria_Id] FOREIGN KEY ([BadgeTemplateCriteria_Id]) REFERENCES [dbo].[BadgeTemplateCriteria] ([Id])
);


GO


GO


GO


GO


GO


GO


GO


GO


GO



GO
