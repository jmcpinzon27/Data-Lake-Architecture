﻿CREATE TABLE [dbo].[HanaEmployeeAux](
	[PGEPERSID] [nvarchar](20) NOT NULL,
	[EMPLOYEE_CHAR] [nvarchar](8) NULL,
	[BUSINESS_SUB_LINE] [nvarchar](10) NULL,
	[BUSINESS_SUB_LINE_TXT] [nvarchar](255) NULL,
	[COMP_CODE] [nvarchar](4) NULL,
	[EMP_CAPABILITY] [nvarchar](12) NULL,
	[EMP_CAPABILITY_TXT] [nvarchar](60) NULL,
	[EMP_PRACTICE_ID] [smallint] NULL,
	[EMP_PRACTICE_TXT] [nvarchar](60) NULL,
	[EMP_SUB_CAPABILITY] [nvarchar](12) NULL,
	[EMP_SUB_CAPABILITY_TXT] [nvarchar](60) NULL,
	[IS_ACTIVE] [nvarchar](5) NULL,
	[IS_FEDERAL] [nvarchar](5) NULL,
	[IS_PPD] [nvarchar](5) NULL,
	[IS_USI] [nvarchar](5) NULL,
	[JOB] [nvarchar](8) NULL,
	[JOB_MED_TXT] [nvarchar](40) NULL,
	[MAST_CCTR] [nvarchar](10) NULL,
	[PDTORIHIR] [nvarchar](25) NULL,
	[PDTRECHIR] [nvarchar](25) NULL,
	[PEMAILADD] [nvarchar](60) NULL,
	[PFIRSTNAM] [nvarchar](40) NULL,
	[PFUNCTION] [nvarchar](3) NULL,
	[PFUNCTION_TXT] [nvarchar](30) NULL,
	[PHRSAREA] [nvarchar](3) NULL,
	[PHRSAREA_TXT] [nvarchar](40) NULL,
	[PHRSLINE] [nvarchar](3) NULL,
	[PHRSLINE_TXT] [nvarchar](40) NULL,
	[PLASTNAME] [nvarchar](40) NULL,
	[PLEVEL] [nvarchar](8) NULL,
	[PLEVEL_TXT] [nvarchar](40) NULL,
	[PMIDNAME] [nvarchar](40) NULL,
	[PRFRSTNAM] [nvarchar](40) NULL,
	[TERMINATION_DATE] [nvarchar](25) NULL,
	[TERMINATION_DATE_DATETIME] [datetime] NULL,
	[PDTORIHIR_DATETIME] [datetime] NULL,
	[PDTRECHIR_DATETIME] [datetime] NULL,
	[IsValid] [bit] NOT NULL
) ON [PRIMARY]


GO
ALTER TABLE [dbo].[HanaEmployeeAux] ADD  DEFAULT ((1)) FOR [IsValid]


GO
