﻿CREATE TABLE [dbo].[BadgeTemplateCollection](
	[BadgeTemplate_Id] [uniqueidentifier] NOT NULL,
	[Collection_Id] [uniqueidentifier] NOT NULL,
	[CollectionName] [varchar](50) NULL,
PRIMARY KEY CLUSTERED 
(
	[BadgeTemplate_Id] ASC,
	[Collection_Id] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]


GO
ALTER TABLE [dbo].[BadgeTemplateCollection]  WITH CHECK ADD  CONSTRAINT [FK_BadgeTemplateCollection_Collection_Id] FOREIGN KEY([Collection_Id])
REFERENCES [dbo].[Collection] ([Id])
GO

ALTER TABLE [dbo].[BadgeTemplateCollection] CHECK CONSTRAINT [FK_BadgeTemplateCollection_Collection_Id]
GO


GO


GO


GO


GO


GO


GO


GO


GO


GO


GO


GO
ALTER TABLE [dbo].[BadgeTemplateCollection]  WITH CHECK ADD  CONSTRAINT [FK_BadgeTemplateCollection_BadgeTemplate_Id] FOREIGN KEY([BadgeTemplate_Id])
REFERENCES [dbo].[BadgeTemplate] ([Id])
GO

ALTER TABLE [dbo].[BadgeTemplateCollection] CHECK CONSTRAINT [FK_BadgeTemplateCollection_BadgeTemplate_Id]
GO


GO


GO


GO


GO


GO


GO


GO


GO


GO


GO

