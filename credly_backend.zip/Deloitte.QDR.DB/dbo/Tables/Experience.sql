﻿CREATE TABLE [dbo].[Experience] (
    [Id]                       UNIQUEIDENTIFIER DEFAULT (newid()) NOT NULL,
    [WBSCode]                  NVARCHAR (100)   NULL,
    [ValidatorEmail]           NVARCHAR (200)   NULL,
    [Description]              NVARCHAR (400)   NULL,
    [Hours]                    INT              NULL,
    [Badge_Id]                 UNIQUEIDENTIFIER NULL,
    [BadgeTemplateCriteria_Id] UNIQUEIDENTIFIER NULL,
    PRIMARY KEY CLUSTERED ([Id] ASC),
    CONSTRAINT [FK_Experience_BadgeTemplateCriteria_Id] FOREIGN KEY ([BadgeTemplateCriteria_Id]) REFERENCES [dbo].[BadgeTemplateCriteria] ([Id])
);

