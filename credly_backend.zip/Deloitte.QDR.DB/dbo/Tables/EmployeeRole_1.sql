﻿CREATE TABLE [dbo].[EmployeeRole](
	[Employee_Id] [varchar](20) NULL,
	[Role_Id] [uniqueidentifier] NULL,
	[StartDate] [datetime] NULL,
 CONSTRAINT [uk_employeerole] UNIQUE NONCLUSTERED 
(
	[Employee_Id] ASC,
	[Role_Id] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]


GO
ALTER TABLE [dbo].[EmployeeRole]  WITH CHECK ADD  CONSTRAINT [FK_EmployeeRole_Role_Id] FOREIGN KEY([Role_Id])
REFERENCES [dbo].[Role] ([Id])
GO

ALTER TABLE [dbo].[EmployeeRole] CHECK CONSTRAINT [FK_EmployeeRole_Role_Id]
GO


GO


GO


GO


GO


GO

ALTER TABLE [dbo].[EmployeeRole]  WITH NOCHECK ADD  CONSTRAINT [FK_EmployeeRole_Employee_Id] FOREIGN KEY([Employee_Id])
REFERENCES [dbo].[Employee] ([PersonID])
GO

ALTER TABLE [dbo].[EmployeeRole] CHECK CONSTRAINT [FK_EmployeeRole_Employee_Id]
GO


GO


GO


GO


GO



GO