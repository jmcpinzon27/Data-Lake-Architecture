﻿CREATE TABLE [dbo].[BadgeTemplateCriteria] (
    [Id]               UNIQUEIDENTIFIER DEFAULT (newid()) NOT NULL,
    [Type]             INT              NULL,
    [Name]             NVARCHAR (100)   NULL,
    [Description]      NVARCHAR (400)   NULL,
    [MinEntries]       INT              NULL,
    [MaxEntries]       INT              NULL,
    [Approveer_Id]     VARCHAR (20)     NULL,
    [BadgeTemplate_Id] UNIQUEIDENTIFIER NULL,
    PRIMARY KEY CLUSTERED ([Id] ASC)
);

