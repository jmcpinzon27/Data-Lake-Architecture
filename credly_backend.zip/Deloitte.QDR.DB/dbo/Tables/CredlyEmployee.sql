﻿CREATE TABLE [dbo].[CredlyEmployee] (
    [CredlyID]       UNIQUEIDENTIFIER NULL,
    [Status]         SMALLINT         NULL,
    [RecordLastSent] DATETIME         NULL,
    [TermLastSent]   DATETIME         NULL,
    [PersonID]       VARCHAR (20)     NOT NULL,
    [EmployeeState]  VARCHAR (30)     NULL,
    [Email]          VARCHAR (50)     NULL,
    [FirstName]      VARCHAR (30)     NULL,
    [LastName]       VARCHAR (30)     NULL,
    CONSTRAINT [PK_CredlyEmployee] PRIMARY KEY CLUSTERED ([PersonID] ASC)
);

