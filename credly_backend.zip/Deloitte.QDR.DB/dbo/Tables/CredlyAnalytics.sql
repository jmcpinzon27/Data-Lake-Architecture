﻿
CREATE TABLE [dbo].[CredlyAnalytics] (
    [Id]                      UNIQUEIDENTIFIER DEFAULT (newid()) NOT NULL,
    [BadgeName]               VARCHAR (500)    NULL,
    [BadgeTemplateCredlyId]   UNIQUEIDENTIFIER NULL,
    [Issuer]                  VARCHAR (40)     NULL,
    [EarnerBadgeId]           NVARCHAR (MAX)   NULL,
    [IssuerEarnerId]          NVARCHAR (MAX)   NULL,
    [BadgeUrl]                VARCHAR (MAX)    NULL,
    [FisrtName]               VARCHAR (30)     NULL,
    [LastName]                VARCHAR (30)     NULL,
    [Country]                 VARCHAR (50)     NULL,
    [Region]                  VARCHAR (30)     NULL,
    [SubRegion]               VARCHAR (50)     NULL,
    [AccountStatus]           VARCHAR (50)     NULL,
    [Email]                   VARCHAR (50)     NULL,
    [Status]                  VARCHAR (30)     NULL,
    [Expired]                 VARCHAR (30)     NULL,
    [IssueAt]                 DATETIME         NULL,
    [CreatedAt]               DATETIME         NULL,
    [AcceptedAt]              DATETIME         NULL,
    [ExpiresAt]               DATETIME         NULL,
    [LatestEmailType]         VARCHAR (100)    NULL,
    [LatestEmailStatus]       VARCHAR (50)     NULL,
    [DroppedEmailReason]      VARCHAR (MAX)    NULL,
    [TotalBadgePagesViews]    INT              NOT NULL,
    [TotalBadgeEmbeddedViews] INT              NOT NULL,
    [TotalShares]             INT              NOT NULL,
    [LinkedInNewsfeedShares]  INT              NOT NULL,
    [LinkedInProfileShares]   INT              NOT NULL,
    [TwitterShares]           INT              NOT NULL,
    [FacebookShares]          INT              NOT NULL,
    [FacebookMessengerShares] INT              NOT NULL,
    [EmailShares]             INT              NOT NULL,
    [WhatsAppShares]          INT              NOT NULL,
    [CopyUrlShares]           INT              NOT NULL,
    [EmbedShares]             INT              NOT NULL,
    [WeiboShares]             INT              NOT NULL,
    [DownloadShares]          INT              NOT NULL,
    [PrintShares]             INT              NOT NULL,
    [XingShares]              INT              NOT NULL,
    [WalletShares]            INT              NOT NULL,
    [SEEKShares]              INT              NOT NULL,
    [PublishToBlockchain]     INT              NOT NULL,
    [OBIVerifications]        INT              NOT NULL,
    [BlockchainVerifications] INT              NOT NULL,
    [Clicks]                  INT              NOT NULL,
    [EarnThisBadgeClicks]     INT              NOT NULL,
    [RecommendationClicks]    INT              NOT NULL,
    [LearnMoreClicks]         INT              NOT NULL,
    [EarningCriteriaClicks]   INT              NOT NULL,
    [ClaimBadgeUrl]           VARCHAR (MAX)    NULL,
    [GroupTag]                VARCHAR (50)     NULL,
    [MiddleName]              VARCHAR (50)     NULL,
    [State]                   VARCHAR (50)     NULL,
    [EmailDomain]             VARCHAR (50)     NULL,
    PRIMARY KEY CLUSTERED ([Id] ASC)
);


GO






GO
