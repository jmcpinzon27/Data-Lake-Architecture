﻿CREATE TABLE [dbo].[Badge] (
    [Id]                   UNIQUEIDENTIFIER DEFAULT (newid()) NOT NULL,
    [ExternalId]           VARCHAR (50)     NULL,
    [BadgeTemplateId]      UNIQUEIDENTIFIER NULL,
    [PersonID]             NVARCHAR (20)    NULL,
    [Status]               INT              NULL,
    [DecisionAt]           DATETIME         NULL,
    [AwardedAt]            DATETIME         NULL,
    [ExpiresAt]            DATETIME         NULL,
    [SubmittedAt]          DATETIME         NULL,
    [EducationStatus]      INT              NULL,
    [EducationApprovedAt]  DATETIME         NULL,
    [ExperienceStatus]     INT              NULL,
    [ExperienceApprovedAt] DATETIME         NULL,
    [ExposureStatus]       INT              NULL,
    [ExposureApprovedAt]   DATETIME         NULL,
    PRIMARY KEY CLUSTERED ([Id] ASC),
    CONSTRAINT [FK_Badge_BadgeTemplateId] FOREIGN KEY ([BadgeTemplateId]) REFERENCES [dbo].[BadgeTemplate] ([Id])
);

