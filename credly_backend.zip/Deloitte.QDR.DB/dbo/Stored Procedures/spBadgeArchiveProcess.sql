﻿CREATE PROC [dbo].[spBadgeArchiveProcess]
AS
BEGIN
	
	BEGIN TRANSACTION
		DECLARE  @_newstatus as int = 6
		DECLARE  @_processstatus as nvarchar(15) = 'PENDING'
		BEGIN TRY
			INSERT INTO #_Process_Badge_NotificationTemp
			SELECT bt.Id AS BadgeTemplateId, b.Id AS BadgeId,b.Status AS OldStatus,@_newstatus AS NewStatus,e.Email 
			FROM BadgeTemplate bt 
			INNER JOIN badge b on b.badgetemplateid=bt.id
			INNER JOIN Employee e on e.PersonID=b.PersonID
			WHERE bt.Status=@_newstatus AND bt.ArchiveDate IS NOT NULL AND FORMAT(bt.ArchiveDate,'yyyy-MM-dd','en-US') = FORMAT(GETDATE(),'yyyy-MM-dd','en-US')

			INSERT INTO _Process_Badge_Notification(BadgeTemplateId,BadgeId,BadgeOldStatus,BadgeNewStatus,EmailEmployee)	
			SELECT BadgeTemplateId,BadgeId,OldStatus,NewStatus,Email 
			FROM #_Process_Badge_NotificationTemp

			UPDATE Bagde 
			SET B.Status = @_newstatus, B.ArchiveDate = GETDATE()
			FROM #_Process_Badge_NotificationTemp BadgeArchive
			INNER JOIN Badge B ON B.Id = BadgeArchive.BadgeId

			SELECT COUNT(*) FROM #_Process_Badge_NotificationTemp 

			COMMIT TRAN
		END TRY
		BEGIN CATCH
			IF @@TRANCOUNT > 0
			BEGIN
				ROLLBACK TRANSACTION
			END
		END CATCH
END