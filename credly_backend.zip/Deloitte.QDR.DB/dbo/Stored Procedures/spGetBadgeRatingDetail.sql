﻿CREATE PROCEDURE spGetBadgeRatingDetail @_badgeTemplateId UNIQUEIDENTIFIER, @_levelExecution INT AS
	BEGIN
		BEGIN TRY
			DECLARE @_badgeRatingAVG int = 0, @_completedBadgesNumber int = 0, @_feedbackNumber int = 0, @_awardedApprovedBadgesNumber int = 0

			SELECT @_badgeRatingAVG = ROUND(AVG(rate),0) FROM RateQuestionBadge WHERE BadgeId IN (SELECT id FROM badge WHERE BadgeTemplateId=@_badgeTemplateId) AND Rate IS NOT NULL

			IF(@_levelExecution = 0)
			BEGIN
				SELECT @_completedBadgesNumber = COUNT(DISTINCT(BadgeId)) FROM RateQuestionBadge WHERE Rate IS NOT NULL
				SELECT @_feedbackNumber = COUNT(*) FROM Badge WHERE BadgeTemplateId=@_badgeTemplateId AND RateFeedback IS NOT NULL
				SELECT @_awardedApprovedBadgesNumber = COUNT(Status) from Badge WHERE BadgeTemplateId=@_badgeTemplateId AND Status IN(2,7) --Awarded = 2,Approved = 7
			
				SELECT @_badgeRatingAVG AS BadgeRatingAVG, @_completedBadgesNumber AS CompletedBadgesNumber, @_feedbackNumber AS FeedbackNumber, @_awardedApprovedBadgesNumber AS AwardedApprovedBadgesNumber			

				SELECT a.QuestionId,b.Question,b.[Order],CONVERT(INT, ROUND(AVG(a.Rate),0)) AS Average FROM RateQuestionBadge A INNER JOIN RateQuestion B ON a.QuestionId=B.Id
				WHERE a.BadgeId IN (SELECT id FROM Badge WHERE BadgeTemplateId=@_badgeTemplateId)
				GROUP BY a.questionid,b.Question,b.[order]
				ORDER BY b.[Order]

				SELECT TOP 11 b.RateFeedback, e.FirstName FROM badge b INNER JOIN Employee e ON b.PersonID=e.PersonID 
				WHERE b.BadgeTemplateId=@_badgeTemplateId AND RateFeedback IS NOT NULL
				ORDER BY E.FirstName
			END
			
			IF(@_levelExecution = 1)
			BEGIN
				SELECT @_badgeRatingAVG AS BadgeRatingAVG
			END

			
	
		END TRY
		BEGIN CATCH
			SELECT ERROR_MESSAGE() AS ErrorMessage
		END CATCH
END
/*
NOTES:
	@_levelExecution = 0, FULL RESULT
	@_levelExecution = 1, RETURN @_badgeRatingAVG
*/