﻿CREATE PROC [dbo].[spBadgeDiscardingProcess]
AS
BEGIN	
	--BEGIN TRANSACTION
		DECLARE  @_currentdate as date = CONVERT(date, DATEADD(m, -6, GETDATE()))
		DECLARE @_auxtable TABLE (Id UNIQUEIDENTIFIER)
		
		INSERT INTO @_auxtable
		SELECT Id  FROM Badge 
		WHERE (STATUS IS NOT NULL AND STATUS  = '7' ) 
		AND (RejectedAt IS NOT NULL AND CONVERT(date, RejectedAt) = @_currentdate)

		UPDATE Badge SET Status  = '11'
		FROM Badge B INNER JOIN @_auxtable Aux ON B.Id = Aux.Id
	
		SELECT ID FROM @_auxtable
		
END