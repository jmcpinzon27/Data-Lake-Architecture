﻿CREATE   view [dbo].[BadgeTemplateQuery] as 

SELECT
	bt.Id, 
	bt.ExternalId, 
	bt.Issuer, 
	(CASE WHEN bt.Issuer LIKE '%Deloitte%' THEN cast(0 AS bit) ELSE cast(1 AS bit) END) AS IsExternal, 
	bt.Name, 
	bt.Subtitle, 
	bt.Description, 
	bt.Type, 
	bt.LEVEL,
	(SELECT string_agg(c.Name, ',')
		FROM [Collection] c INNER JOIN
		BadgeTemplateCollection btc ON btc.Collection_Id = c.Id
		WHERE btc.BadgeTemplate_Id = bt.Id) AS Collections, 
	bt.Status, 
	bt.ImageUrl, 
	bt.InfoUrl, 
	bt.CreatedAt, 
	bt.UpdateAt, 
	bt.RetiredAt,
	bt.ArchiveDate,
	bt.CreatedBy AS CreatedByPersonID, 
	CONCAT(ec.FirstName, ' ', ec.LastName) AS CreatedByName, 
	bt.UpdatedBy AS UpdatedByPersonID, bt.ApprovedAt, 
	bt.Approver_Id AS ApproverID, 
	CONCAT(ea.FirstName, ' ', ea.LastName) AS ApproverName, bt.Owner_Id AS OwnerId, 
	CONCAT(eo.FirstName, ' ', eo.LastName) AS OwnerName,
	(SELECT string_agg(btst.SkillName, ',')
		FROM BadgeTemplateSkillTemp btst
		WHERE btst.BadgeTemplate_Id = bt.Id) AS Skills,
	bt.IsPublic AS IsPublic,
	bt.HaveAlternativeCriteria,
	bt.ReleaseNotes
FROM BadgeTemplate bt LEFT JOIN
	Employee ec ON ec.PersonID = bt.CreatedBy LEFT JOIN
	Employee ea ON ea.PersonID = bt.Approver_Id LEFT JOIN
	Employee eo ON eo.PersonID = bt.Owner_Id


GO
