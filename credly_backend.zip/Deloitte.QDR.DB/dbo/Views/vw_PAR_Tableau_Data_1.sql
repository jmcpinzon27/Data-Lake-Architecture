﻿CREATE VIEW [dbo].[vw_PAR_Tableau_Data]
AS
SELECT
b.Id AS 'CertBadgeID'
,ce.PersonID AS 'PersonnelID'
,UPPER(bt.[Name]) AS 'CertName'
,b.ExpiresAt AS 'ExpireDate'
,b.AwardedAt AS 'IssuedEarnedDate'
,UPPER(bt.Issuer) AS 'IssuerVendor'
,UPPER(s.[Description]) AS 'Skills'
,ce.CredlyID
,UPPER(CASE WHEN ce.LastName + ', ' + ce.FirstName IS NULL
THEN e.LastName + ', ' + e.FirstName 
ELSE ce.LastName + ', ' + ce.FirstName END) AS 'Name'
,UPPER(ce.Email) AS 'Email'
,UPPER(CASE WHEN e.BusinessCode IS NULL THEN NULL
WHEN e.BusinessCode IN ('AE','AU','C','T') THEN e.BusinessDesc
ELSE 'ENABLING AREAS' END) AS 'BusinessGroup'
,UPPER(e.BusinessDesc) AS 'Business'
,UPPER(e.BusinessAreaDesc) AS 'BusinessArea'
,UPPER(e.BusinessLineDesc) AS 'BusinessLine'
,UPPER(CASE 
WHEN b.[Status] IS NULL THEN UPPER(ce.EmployeeState)
WHEN b.[Status] = 1 THEN UPPER('Accepted')
WHEN b.[Status] = 0 THEN UPPER('Rejected') END) AS 'QDRStatus'
FROM CredlyEmployee AS ce
LEFT JOIN Badge AS b ON ce.PersonID = b.PersonID
LEFT JOIN BadgeTemplate AS bt ON b.BadgeTemplateId = bt.Id
LEFT JOIN BadgeTemplateSkill AS bts ON b.BadgeTemplateId = bts.BadgeTemplate_Id
LEFT JOIN Skill AS s ON bts.Skill_Id = s.Id
LEFT JOIN Employee AS e ON ce.PersonID = e.PersonID


GO
GRANT SELECT
    ON OBJECT::[dbo].[vw_PAR_Tableau_Data] TO [tableu_qdr_user]
    AS [dbo];

