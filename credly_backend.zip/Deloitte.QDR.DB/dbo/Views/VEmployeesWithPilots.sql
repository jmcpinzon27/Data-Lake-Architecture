﻿
CREATE   VIEW [dbo].[VEmployeesWithPilots] AS

SELECT E.[PersonID] AS 'external_id'
,CE.[Status] AS 'status'
,CE.[CredlyID] AS 'credly_id'
,E.[Email] AS 'email'
,E.[FirstName] AS 'first_name'
,E.[LastName] AS 'last_name'
FROM [dbo].[CredlyEmployee] AS CE 
JOIN [dbo].[Employee] AS E ON E.[PersonID] = CE.[PersonID]
 
--Cyber
WHERE (E.[BusinessCode] = 'AE' AND E.[BusinessLineCode] IN ('983','A52','A55','A56','A57','A58'))

--Salesforce
OR (E.[BusinessCode] = 'C' AND E.[BusinessAreaCode] = '004' AND E.[BusinessLineCode] = '029' AND E.[CapabilityCode] = '51537948' AND E.[EmployeePracticeCode] IN (2,3,4) and IsActive = 1 and JobCode not in ('50233864','50527677'))

--SAP
OR (E.[BusinessCode] = 'C' AND E.[BusinessAreaCode] = '006' AND E.[BusinessLineCode] = '033'  AND E.[EmployeePracticeCode] IN (2,3,4) and IsActive = 1 and JobCode not in ('50233864','50527677'))

--Cloud
OR (E.[BusinessCode] = 'C' AND E.[BusinessAreaCode] = '003' AND E.[BusinessLineCode] = '024'  AND E.[EmployeePracticeCode] IN (2,3,4) and IsActive = 1 and JobCode not in ('50233864','50527677'))

--Audit
OR (E.[CostCenterNumber] IN ('0100007468','0100044014','0100049703','0180001830') and IsActive = 1  and JobCode not in ('50233864','50527677') )
