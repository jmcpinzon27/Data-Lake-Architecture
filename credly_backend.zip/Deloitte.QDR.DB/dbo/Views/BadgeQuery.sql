﻿CREATE VIEW [dbo].[BadgeQuery] as
SELECT 
b.Id, 
b.ExternalId, 
(CASE WHEN bt.Issuer LIKE '%Deloitte%' THEN cast(0 AS bit) ELSE cast(1 AS bit) END) AS IsExternalCert, 
e.PersonID AS EmployeePersonID, 
CONCAT(e.FirstName, ' ', e.LastName) AS EmployeeName, 
bt.Id AS BadgeTemplateId, 
bt.Name AS BadgeTemplateName, 
bt.Subtitle AS BadgeTemplateSubtitle, 
bt.Description AS BadgeTemplateDescription, 
bt.Type AS BadgeTemplateType, 
bt. LEVEL AS BadgeTemplateLevel, 
bt.Issuer AS BadgeTemplateIssuer, 
bt.Approver_Id AS BadgeTemplateApproverID,
CONCAT(ea.FirstName, ' ', ea.LastName) AS BadgeTemplateApproverName, 
bt.OptionalApprover_Id AS BadgeTemplateOptionalApproverID, 
CONCAT(oa.FirstName, ' ', oa.LastName) AS BadgeTemplateOptionalApproverName, 
bt.IsPublic AS BadgeTemplateIsPublic,
(SELECT string_agg(c.Name, ',')
	FROM [Collection] c INNER JOIN
	BadgeTemplateCollection btc ON btc.Collection_Id = c.Id
	WHERE btc.BadgeTemplate_Id = bt.Id) AS BadgeTemplateCollection, 
b.Status, 
b.DecisionAt, 
b.AwardedAt, 
b.ExpiresAt, 
b.SubmittedAt, 
b.EducationStatus, 
b.EducationApprovedAt, 
b.ExperienceStatus, 
b.ExperienceApprovedAt, 
b.ExposureStatus, 
b.ExposureApprovedAt, 
b.InitiatedAt, 
bt.status AS BadgeTemplateStatus,
b.[AlternativeCriteriaSelected]
FROM Badge b INNER JOIN
                         BadgeTemplate bt ON bt.id = b.BadgeTemplateId 
						 INNER JOIN Employee e ON e.PersonID = b.PersonID 
						 LEFT JOIN Employee ea ON ea.PersonID = bt.Approver_Id
						 LEFT JOIN Employee oa ON oa.PersonID = bt.OptionalApprover_Id
GO
