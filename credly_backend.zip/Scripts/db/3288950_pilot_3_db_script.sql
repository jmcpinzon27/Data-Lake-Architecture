create table Role (
	Id uniqueidentifier primary key not null DEFAULT newid(),
	Code nvarchar(50) null,
	Description nvarchar(100) null
)

create table Skill (
	Id uniqueidentifier primary key not null DEFAULT newid(),	
	Description nvarchar(300) null
)

create table Collection (
	Id uniqueidentifier primary key not null DEFAULT newid(),	
	Name nvarchar(100) null,
	Description nvarchar(300) null
)

--drop table Organization (
--	Id uniqueidentifier primary key not null DEFAULT newid(),	
--	Name nvarchar(100) null,
--	[External] bit default 0
--)

create table UserActivity (
	Id uniqueidentifier primary key not null DEFAULT newid(),	
	[Type] int not null,
	EntityId nvarchar(40),
	Title nvarchar(100),
	Description nvarchar(300),
	Date datetime null,
	Employee_Id varchar(20)
)

alter table UserActivity with check add constraint FK_UserActivity_Employee_Id FOREIGN KEY(Employee_Id)
references Employee (PersonID)
go

alter table UserActivity check constraint FK_UserActivity_Employee_Id
go

create table AuditLog (
	Id uniqueidentifier primary key not null DEFAULT newid(),
	EntityName nvarchar(50),
	PropertyName nvarchar(50),
	EntityId nvarchar(40),
	OldValue nvarchar(max),
	NewValue nvarchar(max),
	Date datetime
)

create table Notification (
	Id uniqueidentifier primary key not null DEFAULT newid(),	
	Date datetime,
	Title nvarchar(100),
	Description nvarchar(300),
	Detail nvarchar(300),
	EntityType int,
	EntityId nvarchar(40),
	[Read] bit default 0,
	ReadDate datetime,
	Employee_Id varchar(20)
)

alter table Notification with check add constraint FK_Notification_Employee_Id FOREIGN KEY(Employee_Id)
references Employee (PersonID)
go

alter table Notification check constraint FK_Notification_Employee_Id
go

alter table BadgeTemplateCriteria add Approver_Id varchar(20)
alter table badgeTemplateCriteria drop constraint FK_BadgeTemplateCriteria_Approver_Id

create table BadgeTemplateCriteria (
	Id uniqueidentifier primary key not null DEFAULT newid(),
	Type int,
	Name nvarchar(100),
	Description nvarchar(400),
	MinEntries int,
	MaxEntries int,
	Approver_Id varchar(20),
	BadgeTemplate_Id uniqueidentifier
)



alter table BadgeTemplateCriteria with check add constraint FK_BadgeTemplateCriteria_Approver_Id FOREIGN KEY(Approver_Id)
references Employee (PersonID)
go

alter table BadgeTemplateCriteria check constraint FK_BadgeTemplateCriteria_Approver_Id
go

create table Education (
	Id uniqueidentifier primary key not null DEFAULT newid(),		
	Title nvarchar(100),
	Vendor nvarchar(200),
	Description nvarchar(400),
	Hours int,
	ComplationDate datetime,
	Badge_Id uniqueidentifier,
	BadgeTemplateCriteria_Id uniqueidentifier
)

alter table Education with check add constraint FK_Education_Badge_Id FOREIGN KEY(Badge_Id)
references Badge (Id)
go

alter table Education check constraint FK_Education_Badge_Id
go

alter table Education with check add constraint FK_Education_BadgeTemplateCriteria_Id FOREIGN KEY(BadgeTemplateCriteria_Id)
references BadgeTemplateCriteria (Id)
go

alter table Education check constraint FK_Education_BadgeTemplateCriteria_Id
go
    
create table Experience (
	Id uniqueidentifier primary key not null DEFAULT newid(),		
	WBSCode nvarchar(100),
	ValidatorEmail nvarchar(200),
	Description nvarchar(400),
	Hours int,
	Badge_Id uniqueidentifier,
	BadgeTemplateCriteria_Id uniqueidentifier
)

alter table Experience with check add constraint FK_Experience_Badge_Id FOREIGN KEY(Badge_Id)
references Badge (Id)
go

alter table Experience check constraint FK_Experience_Badge_Id
go

alter table Experience with check add constraint FK_Experience_BadgeTemplateCriteria_Id FOREIGN KEY(BadgeTemplateCriteria_Id)
references BadgeTemplateCriteria (Id)
go

alter table Experience check constraint FK_Experience_BadgeTemplateCriteria_Id
go

create table Exposure (
	Id uniqueidentifier primary key not null DEFAULT newid(),		
	WBSCode nvarchar(100),
	ValidatorEmail nvarchar(200),
	Description nvarchar(400),
	Hours int,
	Badge_Id uniqueidentifier,
	BadgeTemplateCriteria_Id uniqueidentifier
)

alter table Exposure with check add constraint FK_Exposure_Badge_Id FOREIGN KEY(Badge_Id)
references Badge (Id)
go

alter table Exposure check constraint FK_Exposure_Badge_Id
go

alter table Exposure with check add constraint FK_Exposure_BadgeTemplateCriteria_Id FOREIGN KEY(BadgeTemplateCriteria_Id)
references BadgeTemplateCriteria (Id)
go

alter table Exposure check constraint FK_Exposure_BadgeTemplateCriteria_Id
go

alter table BadgeTemplate add [Type] int;
alter table BadgeTemplate add [Level] int;
alter table BadgeTemplate add [Status] int; -- NOTE: lifecycle stutus. Determine if 'state' col is still required
alter table BadgeTemplate add Approver_Id nvarchar(20);
alter table BadgeTemplate add Issuer nvarchar(100);


alter table BadgeTemplate with check add constraint FK_BadgeTemplate_Approver_Id FOREIGN KEY(Approver_Id)
references Employee (PersonID)
go

alter table BadgeTemplate check constraint FK_BadgeTemplate_Approver_Id
go


create table BadgeTemplateSkill (	
	BadgeTemplate_Id uniqueidentifier,
	Skill_Id uniqueidentifier,
	Proficiency smallint
)

alter table BadgeTemplateSkill with check add constraint FK_BadgeTemplateSkill_BadgeTemplate_Id FOREIGN KEY(BadgeTemplate_Id)
references BadgeTemplate (Id)
go

alter table BadgeTemplateSkill check constraint FK_BadgeTemplateSkill_BadgeTemplate_Id
go
  

alter table BadgeTemplateSkill with check add constraint FK_BadgeTemplateSkill_Skill_Id FOREIGN KEY(Skill_Id)
references Skill (Id)
go

alter table BadgeTemplateSkill check constraint FK_BadgeTemplateSkill_Skill_Id
go

create table BadgeTemplateSkillTemp (	
	BadgeTemplate_Id uniqueidentifier,
	SkillName nvarchar(100)
)

alter table BadgeTemplateSkillTemp with check add constraint FK_BadgeTemplateSkillTemp_BadgeTemplate_Id FOREIGN KEY(BadgeTemplate_Id)
references BadgeTemplate (Id)
go

alter table BadgeTemplateSkillTemp check constraint FK_BadgeTemplateSkillTemp_BadgeTemplate_Id
go


create table BadgeTemplateCollection (	
	BadgeTemplate_Id uniqueidentifier,
	Collection_Id uniqueidentifier
)

alter table BadgeTemplateCollection with check add constraint FK_BadgeTemplateCollection_BadgeTemplate_Id FOREIGN KEY(BadgeTemplate_Id)
references BadgeTemplate (Id)
go

alter table BadgeTemplateCollection check constraint FK_BadgeTemplateCollection_BadgeTemplate_Id
go
  

alter table BadgeTemplateCollection with check add constraint FK_BadgeTemplateCollection_Collection_Id FOREIGN KEY(Collection_Id)
references Collection (Id)
go

alter table BadgeTemplateCollection check constraint FK_BadgeTemplateCollection_Collection_Id
go
 

create table EmployeeRole (	
	Employee_Id varchar(20),
	Role_Id uniqueidentifier
)

alter table EmployeeRole with check add constraint FK_EmployeeRole_Employee_Id FOREIGN KEY(Employee_Id)
references Employee (PersonID)
go

alter table EmployeeRole check constraint FK_EmployeeRole_Employee_Id
go
  

alter table EmployeeRole with check add constraint FK_EmployeeRole_Role_Id FOREIGN KEY(Role_Id)
references Role (Id)
go

alter table EmployeeRole check constraint FK_EmployeeRole_Role_Id
go


alter table Badge add Status int;
alter table Badge add ApprovedDate datetime;
alter table Badge add AwardedDate datetime;
alter table Badge add EducationStatus int;
alter table Badge add EducationApprovedDate datetime;
alter table Badge add ExperienceStatus int;
alter table Badge add ExperienceApprovedDate datetime;
alter table Badge add ExposureStatus int;
alter table Badge add ExposureApprovedDate datetime;


alter table Badge with check add constraint FK_Badge_PersonID FOREIGN KEY(PersonID)
references Employee (PersonID)
go

alter table Badge check constraint FK_Badge_PersonID
go

alter table Badge with check add constraint FK_Badge_BadgeTemplateId FOREIGN KEY(BadgeTemplateId)
references BadgeTemplate (Id)
go

alter table Badge check constraint FK_Badge_BadgeTemplateId
go


-- ** BADGE TEMPLATE FINAL DEF **

create table BadgeTemplate (
	Id uniqueidentifier primary key not null DEFAULT newid(),
	Issuer nvarchar(100), -- NOTA: provisoria, valor tal cual se recibe de workforce api. Se utiliza para identificar external / intenal badges
	ExternalId varchar(50), 
	Name nvarchar(255),
    Subtitle nvarchar(255),
	Description nvarchar(500),
    [Type] int, 
    [Level] int, 
    [Status] int, 
	ImageUrl nvarchar(500),
	InfoUrl nvarchar(500),	
	CreatedAt datetime,
	UpdateAt datetime,	
	RetiredAt datetime,
	CreatedBy nvarchar(20),
	UpdatedBy nvarchar(20),
	ApprovedAt datetime,
	Approver_Id varchar(20),
	Owner_Id varchar(20),
	Sponsor_Id varchar(20),
	ReviewDate datetime,
	ExpiresAt int
)



alter table BadgeTemplate with check add constraint FK_BadgeTemplate_Approver_Id FOREIGN KEY(Approver_Id)
references Employee (PersonID)
go

alter table BadgeTemplate check constraint FK_BadgeTemplate_Approver_Id
go

alter table BadgeTemplate with check add constraint FK_BadgeTemplate_Owner_Id FOREIGN KEY(Owner_Id)
references Employee (PersonID)
go

alter table BadgeTemplate check constraint FK_BadgeTemplate_Owner_Id
go

alter table BadgeTemplate with check add constraint FK_BadgeTemplate_Sponsor_Id FOREIGN KEY(Sponsor_Id)
references Employee (PersonID)
go

alter table BadgeTemplate check constraint FK_BadgeTemplate_Sponsor_Id
go


-- ** BADGE FINAL DEF **

create table Badge (
	Id uniqueidentifier primary key not null DEFAULT newid(),
	ExternalId varchar(50),
	BadgeTemplateId uniqueidentifier,
	PersonID nvarchar(20),
    [Status] int,
	DecisionAt datetime,
	AwardedAt datetime,
	ExpiresAt datetime,
	SubmittedAt datetime,
	EducationStatus int,
	EducationApprovedAt datetime,
	ExperienceStatus int,
	ExperienceApprovedAt datetime,
	ExposureStatus int,
	ExposureApprovedAt datetime
);

alter table Badge with check add constraint FK_Badge_PersonID FOREIGN KEY(PersonID)
references Employee (PersonID)
go

alter table Badge check constraint FK_Badge_PersonID
go

alter table Badge with check add constraint FK_Badge_BadgeTemplateId FOREIGN KEY(BadgeTemplateId)
references BadgeTemplate (Id)
go

alter table Badge check constraint FK_Badge_BadgeTemplateId
go