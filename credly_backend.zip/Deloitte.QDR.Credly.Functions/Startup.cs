﻿using Azure.Identity;
using Deloitte.QDR.Credly.Functions;
using Deloitte.QDR.Credly.Functions.Contracts;
using Deloitte.QDR.Credly.Functions.DAL;
using Deloitte.QDR.Credly.Functions.Infrastructure.Config;
using Deloitte.QDR.Credly.Functions.Infrastructure.KeyVault;
using Deloitte.QDR.Credly.Functions.Infrastructure.ServiceBus;
using Deloitte.QDR.Credly.Functions.Infrastructure.Storage;
using Deloitte.QDR.DTO.CredlyAPI.Common;
using Microsoft.Azure.Functions.Extensions.DependencyInjection;
using Microsoft.Azure.WebJobs.Hosting;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Azure;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Net.Http;
using static Deloitte.QDR.DTO.Common.GeneralConstants;

[assembly: WebJobsStartup(typeof(Startup))]

namespace Deloitte.QDR.Credly.Functions
{
    public class Startup : FunctionsStartup
    {
        public override void Configure(IFunctionsHostBuilder builder)
        {
            AppSettings.BindSettings();

            builder.Services.AddDbContext<DefaultDBContext>(
                options =>
                    options
                        .UseSqlServer(AppSettings.Settings.GetSecret(KeyVault.SECRET_SQLDBCONNECTIONSTRING))
                        //ONLY FOR TESTING
                        .EnableSensitiveDataLogging(false)
            );

            builder.Services.AddOptions();
            builder.Services.AddSingleton(x => new CredlyHttpData
            {
                BadgeTemplate = new CredlyOrganizationData
                {
                    Organization = AppSettings.Settings.GetSecret(KeyVault.SECRET_CREDLYORGANIZATION_BADGETEMPLATE),
                    Authorization = AppSettings.Settings.GetSecret(KeyVault.SECRET_CREDLYAUTH_BADGETEMPLATE)
                },
                Badge = new CredlyOrganizationData
                {
                    Organization = AppSettings.Settings.GetSecret(KeyVault.SECRET_CREDLYORGANIZATION_BADGE),
                    Authorization = AppSettings.Settings.GetSecret(KeyVault.SECRET_CREDLYAUTH_BADGE)
                },
                Employment = new CredlyOrganizationData
                {
                    Organization = AppSettings.Settings.GetSecret(KeyVault.SECRET_CREDLYORGANIZATION_EMPLOYMENT),
                    Authorization = AppSettings.Settings.GetSecret(KeyVault.SECRET_CREDLYAUTH_EMPLOYMENT)
                }
            });
            builder.Services.AddHttpClient<ICredlyAPIService, CredlyAPIService>(http =>
            {
                http.BaseAddress = new Uri($"{AppSettings.Settings.GetSecret(KeyVault.SECRET_CREDLYURLBASE)}");
            });


            builder.Services.AddSingleton<IQDRAPIService>(x => new QDRAPIService(InitializeQDRAPIHttpClient()));
            builder.Services.AddSingleton<IQueueService, AZQueue>();
            builder.Services.AddSingleton<IKeyVaultManager, KeyVaultManager>();

            builder.Services.AddAzureClients(azureClient =>
            {
                azureClient.AddSecretClient(new Uri(AppSettings.Settings.VaultUri));

                var credential = new ClientSecretCredential(
                    AppSettings.Settings.GetSecret(KeyVault.SECRET_TENANTID),
                    AppSettings.Settings.GetSecret(KeyVault.SECRET_CLIENTID),
                    AppSettings.Settings.GetSecret(KeyVault.SECRET_CLIENTSECRET));

                azureClient.UseCredential(credential);
            });

            builder.Services.AddSingleton<IBlobStorageService>(
                x =>
                    new BlobStorageService(
                        AppSettings.Settings.GetSecret(KeyVault.SECRET_BLOBSTORAGECONNECTIONSTRING),
                        AppSettings.Settings.BlobStorageUriBase,
                        AppSettings.Settings.BlobStorageContainer
                    )
            );
        }

        private static HttpClient InitializeQDRAPIHttpClient()
        {
            var http = new HttpClient();
            http.BaseAddress = new Uri($"{AppSettings.Settings.QDRAPIUrlBase}");
            return http;
        }
    }
}