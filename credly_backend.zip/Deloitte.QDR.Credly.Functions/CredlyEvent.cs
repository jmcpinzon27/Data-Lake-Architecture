﻿using Azure.Messaging.ServiceBus;
using Deloitte.QDR.Credly.Functions.Infrastructure.Config;
using Deloitte.QDR.DTO.Common;
using Deloitte.QDR.DTO.CredlyAPI;
using Microsoft.Azure.WebJobs;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using System;
using System.IO;
using System.Threading;
using System.Threading.Tasks;

namespace Deloitte.QDR.Credly.Functions
{
    public class CredlyEvent
    {
        private readonly ILogger<CredlyEvent> _logger = null;

        public CredlyEvent(ILogger<CredlyEvent> logger)
        {
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
        }

        [FunctionName("CredlyEvent")]
        public async Task Run(
            [ServiceBusTrigger("%Queue%", Connection = "ServiceBusConnection")]
                ServiceBusReceivedMessage serviceBusReceivedMessage,
                IBinder binder, CancellationToken cancellationToken = default

        )
        {
            string requestBody = await new StreamReader(serviceBusReceivedMessage.Body.ToStream()).ReadToEndAsync();
            var message = JsonConvert.DeserializeObject<Message>(requestBody);
            var event_type = message.EventType;
            var serviceBusConnection = AppSettings.Settings.GetSecret(GeneralConstants.KeyVault.SECRET_SERVICEBUSCONNECTIONSTRING);

            if (event_type == "employment.badges.added")
            {
                var client = new ServiceBusClient(serviceBusConnection);
                var sender = client.CreateSender("badge_created");
                var body = JsonConvert.SerializeObject(message);
                var sbmessage = new ServiceBusMessage(body);
                await sender.SendMessageAsync(sbmessage, cancellationToken);
            }

            if (event_type == "employment.badges.removed")
            {
                var client = new ServiceBusClient(serviceBusConnection);
                var sender = client.CreateSender("badge_deleted");
                var body = JsonConvert.SerializeObject(message);
                var sbmessage = new ServiceBusMessage(body);
                await sender.SendMessageAsync(sbmessage, cancellationToken);
            }

            if (event_type == "employment.badges.privacy_changed")
            {
                var client = new ServiceBusClient(serviceBusConnection);
                var sender = client.CreateSender("badge_privacy_changed");
                var body = JsonConvert.SerializeObject(message);
                var sbmessage = new ServiceBusMessage(body);
                await sender.SendMessageAsync(sbmessage, cancellationToken);
            }

            if (event_type == "employment.badges.state_changed")
            {
                var client = new ServiceBusClient(serviceBusConnection);
                var sender = client.CreateSender("badge_state_changed");
                var body = JsonConvert.SerializeObject(message);
                var sbmessage = new ServiceBusMessage(body);
                await sender.SendMessageAsync(sbmessage, cancellationToken);
            }

            if (event_type == "badge_template.created")
            {                
                var client = new ServiceBusClient(serviceBusConnection);
                var sender = client.CreateSender("badge_template_created");
                var body = JsonConvert.SerializeObject(message);
                var sbmessage = new ServiceBusMessage(body);
                await sender.SendMessageAsync(sbmessage, cancellationToken);
            }

            if (event_type == "badge_template.deleted")
            {
                var client = new ServiceBusClient(serviceBusConnection);
                var sender = client.CreateSender("badge_template_deleted");
                var body = JsonConvert.SerializeObject(message);
                var sbmessage = new ServiceBusMessage(body);
                await sender.SendMessageAsync(sbmessage, cancellationToken);
            }

            if (event_type == "badge_template.changed")
            {
                var client = new ServiceBusClient(serviceBusConnection);
                var sender = client.CreateSender("badge_template_changed");
                var body = JsonConvert.SerializeObject(message);
                var sbmessage = new ServiceBusMessage(body);
                await sender.SendMessageAsync(sbmessage, cancellationToken);
            }

            if (event_type == "employment.connection.accepted")
            {
                var client = new ServiceBusClient(serviceBusConnection);
                var sender = client.CreateSender("employment_connection_accepted");
                var body = JsonConvert.SerializeObject(message);
                var sbmessage = new ServiceBusMessage(body);
                await sender.SendMessageAsync(sbmessage, cancellationToken);
            }

            if (event_type == "employment.connection.rejected")
            {
                var client = new ServiceBusClient(serviceBusConnection);
                var sender = client.CreateSender("employment_connection_rejected");
                var body = JsonConvert.SerializeObject(message);
                var sbmessage = new ServiceBusMessage(body);
                await sender.SendMessageAsync(sbmessage, cancellationToken);
            }

            if (event_type == "employment.connection.pending")
            {
                var client = new ServiceBusClient(serviceBusConnection);
                var sender = client.CreateSender("employment_connection_pending");
                var body = JsonConvert.SerializeObject(message);
                var sbmessage = new ServiceBusMessage(body);
                await sender.SendMessageAsync(sbmessage, cancellationToken);
            }
        }
    }
}