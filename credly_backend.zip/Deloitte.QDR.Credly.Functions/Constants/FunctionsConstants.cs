﻿namespace Deloitte.QDR.Credly.Functions.Constant
{
    public static class FunctionsConstants
    {
        public const string CREDLY_ACCEPTED_STATE = "accepted";
        public const string CREDLY_PENDING_STATE = "pending";
        public const string CREDLY_REVOKE_STATE = "revoked";
        public const string CREDLY_REJECTED_STATE = "rejected";

        public const string QDR_ACCEPTED_STATE = "awarded";
        public const string QDR_PENDING_STATE = "approved";
        public const string QDR_REVOKE_STATE = "revoked";
        public const string QDR_REJECTED_STATE = "rejected";
        public const string QDR_AZUREFUNCTION_CLIENT = "INTERNALFUNCTIONS";
        public const string QDR_AZUREFUNCTION_APIKEY = "APIKEY-INTERNALFUNCTIONS";

        public const string QDR_AZUREFUNCTION_HTTP_IMAGE_SOURCE = "http";
    }
}