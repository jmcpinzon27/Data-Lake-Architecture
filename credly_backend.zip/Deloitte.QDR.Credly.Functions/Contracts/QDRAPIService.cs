﻿using Deloitte.QDR.Credly.Functions.AFBadge;
using Deloitte.QDR.Credly.Functions.Constant;
using Deloitte.QDR.Credly.Functions.Infrastructure.Config;
using Deloitte.QDR.DTO.Notifications;
using Microsoft.Extensions.Logging;
using System;
using System.Net.Http;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Deloitte.QDR.Credly.Functions.Contracts
{
    public class QDRAPIService : IQDRAPIService
    {
        private readonly string _apiUri;
        private readonly HttpClient _httpClient;
        

        public QDRAPIService(HttpClient httpClient)
        {
            _httpClient = httpClient ?? throw new ArgumentNullException(nameof(httpClient));
            _apiUri = AppSettings.Settings.QDRAPIUrlBase;
            
        }

        public async Task SendNotificationAsync(SendNotificationDTO sendNotificationDTO, CancellationToken cancellationToken)
        {
            try
            {
                var apiKeyValue = AppSettings.Settings.GetSecret(FunctionsConstants.QDR_AZUREFUNCTION_APIKEY);
                var jsonPayload = System.Text.Json.JsonSerializer.Serialize<SendNotificationDTO>(sendNotificationDTO);
                var content = new StringContent(jsonPayload, Encoding.UTF8, "application/json");

                _httpClient.DefaultRequestHeaders.Clear();
                _httpClient.DefaultRequestHeaders.Add("apiKey", apiKeyValue);
                _httpClient.DefaultRequestHeaders.Add("inboundsystem", FunctionsConstants.QDR_AZUREFUNCTION_CLIENT);
                var httpResult = await _httpClient.PostAsync(_apiUri, content, cancellationToken);
                httpResult.EnsureSuccessStatusCode();
            }
            catch (Exception ex)
            {
                //TODO: add logging
                Console.WriteLine($"QDRAPIService: error at SendNotificationAsync: {ex.Message}");
                throw ex;
            }
        }
    }
}