﻿using Deloitte.QDR.DTO.CredlyAPI.Common;
using System;
using System.Threading.Tasks;

namespace Deloitte.QDR.Credly.Functions.Contracts
{
    //TODO: Unifique EF versions, to avoid copy duplicate this contract, exist on Deloitte.QDR.Contracts
    public interface ICredlyAPIService
    {
        #region Events

        Task<T> GetEvent<T>(Guid id, OrganizationFor organizationFor);

        #endregion Events
    }
}