﻿using Deloitte.QDR.Credly.Functions.Infrastructure.Config;
using Deloitte.QDR.Credly.Functions.Infrastructure.KeyVault;
using Deloitte.QDR.DTO.Common;
using Deloitte.QDR.DTO.CredlyAPI.Common;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Threading.Tasks;

namespace Deloitte.QDR.Credly.Functions.Contracts
{
    public class CredlyAPIService : ICredlyAPIService
    {
        private readonly HttpClient _httpClient;
        private readonly CredlyHttpData _credlyHttpData;
        private readonly string _credlyVersion;
        private readonly IKeyVaultManager _keyVaultManager;

        public CredlyAPIService(HttpClient httpClient, CredlyHttpData credlyHttpData, IKeyVaultManager keyVaultManager)
        {
            _httpClient = httpClient ?? throw new ArgumentNullException(nameof(httpClient));
            _credlyHttpData = credlyHttpData ?? throw new ArgumentNullException(nameof(credlyHttpData));
            _keyVaultManager = keyVaultManager ?? throw new ArgumentNullException(nameof(keyVaultManager));
            _credlyVersion = AppSettings.Settings.CredlyVersion;
        }

        #region Events

        public async Task<T> GetEvent<T>(Guid id, OrganizationFor organizationFor)
        {
            var organizationUrl = SetHttpAuthorizationAndGetUrlOrganization(organizationFor);

            var httpResult = await _httpClient.GetAsync($"{organizationUrl}/events/{id:D}");
            httpResult.EnsureSuccessStatusCode();
            var jsonResult = await httpResult.Content.ReadAsStringAsync();
            var result = JsonConvert.DeserializeObject<CredlyResponse<T>>(jsonResult);
            return result.Data;
        }

        private string SetHttpAuthorizationAndGetUrlOrganization(OrganizationFor organizationFor)
        {
            switch (organizationFor)
            {
                case OrganizationFor.BadgeTemplate:
                    return AddHeaders(_credlyHttpData.BadgeTemplate);

                case OrganizationFor.Badge:
                    return AddHeaders(_credlyHttpData.Badge);

                case OrganizationFor.Employment:
                    return AddHeaders(_credlyHttpData.Employment);
            }

            throw new ValidationException(new Result
            {
                HasErrors = true,
                Messages = new List<string> { GeneralConstants.ErrorMessages.CREDLY_ORGANIZATION_NOT_SET }
            });
        }

        private string AddHeaders(CredlyOrganizationData data)
        {
            if (string.IsNullOrWhiteSpace(data.Authorization) || string.IsNullOrWhiteSpace(data.Organization))
            {
                throw new ValidationException(new Result
                {
                    HasErrors = true,
                    Messages = new List<string> { GeneralConstants.ErrorMessages.CREDLY_PARAMETRIZATION_MISSING }
                });
            }

            _httpClient.DefaultRequestHeaders.Add("Authorization", data.Authorization);
            return $"/{_credlyVersion}/organizations/{data.Organization}";
        }

        #endregion Events
    }
}