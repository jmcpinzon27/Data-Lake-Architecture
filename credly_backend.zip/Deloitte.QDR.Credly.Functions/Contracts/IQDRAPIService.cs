﻿using Deloitte.QDR.DTO.Notifications;
using System.Threading;
using System.Threading.Tasks;

namespace Deloitte.QDR.Credly.Functions.Contracts
{
    public interface IQDRAPIService
    {
        Task SendNotificationAsync(SendNotificationDTO sendNotificationDTO, CancellationToken cancellationToken = default);
    }
}