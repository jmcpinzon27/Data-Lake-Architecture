﻿using Deloitte.QDR.Credly.Functions.Contracts;
using Deloitte.QDR.Credly.Functions.DAL;
using Deloitte.QDR.Credly.Functions.Infrastructure.Storage;
using Deloitte.QDR.DTO.Azure;
using Microsoft.Azure.WebJobs;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using System;
using System.IO;
using System.Net;
using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;

namespace Deloitte.QDR.Credly.Functions.AFUtils
{
    public class ImageProcessing
    {
        private readonly DefaultDBContext _dbContext = null;
        private readonly ICredlyAPIService _credlyAPIService = null;
        private readonly ILogger<ImageProcessing> _logger = null;
        private static readonly HttpClient _httpClient = new HttpClient();
        private readonly IBlobStorageService _blobStorageService = null;
        private const string _logInfoName = "IMAGE PROCESSING";
        private const string _imageProcessingBadgeTemplate = "imageprocessing_badgetemplate";
        private const string _badgeTemplatePathImage = "badgeTemplates/{0}/Image.png";
        private const String _contentType = "image/jpeg";

        public ImageProcessing(DefaultDBContext dbContext, ICredlyAPIService credlyAPIService,
            ILogger<ImageProcessing> logger, IBlobStorageService blobStorageService)
        {
            _dbContext = dbContext ?? throw new ArgumentNullException(nameof(dbContext));
            _credlyAPIService = credlyAPIService ?? throw new ArgumentNullException(nameof(credlyAPIService));
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
            _blobStorageService = blobStorageService ?? throw new ArgumentNullException(nameof(blobStorageService));
        }

        [FunctionName("ImageProcessing")]
        public async Task Run([ServiceBusTrigger("%ImageProcessingQueue%", Connection = "ServiceBusConnection")] string myQueueItem, CancellationToken cancellationToken = default)
        {
            try
            {
                ImageProcessingDto queueMessage = Newtonsoft.Json.JsonConvert.DeserializeObject<ImageProcessingDto>(myQueueItem);
                _logger.LogInformation($"{_logInfoName} function start to execute at: {DateTime.Now.ToString("HH:mm:ss")}");

                //TargetTable, will let route filtering by domain, ex: badge, employee
                if (queueMessage.TargetTable.Equals(_imageProcessingBadgeTemplate))
                {
                    await BadgeTemplateHandlerAsync(queueMessage, cancellationToken);
                }
                
                _logger.LogInformation($"{_logInfoName} function finisned to execute at: {DateTime.Now.ToString("HH:mm:ss")}");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"{_logInfoName}, it was not possible to complete the process due an internal error.");
            }
        }

        private async Task BadgeTemplateHandlerAsync(ImageProcessingDto queueMessage, CancellationToken cancellationToken)
        {
            
            var badgeTemplateQDR = await _dbContext.BadgeTemplates.FirstOrDefaultAsync(t => t.Id == queueMessage.Id, cancellationToken);
            if (badgeTemplateQDR is null)
            {
                _logger.LogInformation($"{_logInfoName} - badge template id not found in qdr, executed at: {DateTime.Now.ToString("HH:mm:ss")}");
                return;
            }
            bool isHttpImageSource = badgeTemplateQDR.ImageUrl.ToLower().StartsWith(Constant.FunctionsConstants.QDR_AZUREFUNCTION_HTTP_IMAGE_SOURCE);
            if (isHttpImageSource)
            {
                string imagePath = string.Format(_badgeTemplatePathImage, badgeTemplateQDR.Id);
                var imageContent = GetImage(badgeTemplateQDR.ImageUrl);
                _logger.LogInformation($"{_logInfoName}/imageprocessing_badgetemplate image downloaded sucess at: {DateTime.Now.ToString("HH:mm:ss")}");
                var resultUpload = await _blobStorageService.UploadBlobFile(imageContent, imagePath, _contentType);
                _logger.LogInformation($"{_logInfoName}/imageprocessing_badgetemplate image uploaded sucess at: {DateTime.Now.ToString("HH:mm:ss")}");
                badgeTemplateQDR.ImageUrl = resultUpload.IdBlob;
                await _dbContext.SaveChangesAsync(cancellationToken);
                _logger.LogInformation($"{_logInfoName}/imageprocessing_badgetemplate record updated sucess at: {DateTime.Now.ToString("HH:mm:ss")}");
            }
            _logger.LogInformation($"{_logInfoName}/imageprocessing_badgetemplate execute completed at: {DateTime.Now.ToString("HH:mm:ss")}");
        }

        private MemoryStream GetImage(string imageUri)
        {
            try
            {
                WebClient client = new WebClient();
                var uri = new Uri(imageUri);
                MemoryStream result = new MemoryStream(client.DownloadData(uri));
                return result;
            }
            catch (Exception ex)
            {
                throw new Exception($"It was not possible download the requested image: {imageUri}", ex);
            }
        }
    }
}