using System;
using System.IO;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Threading;
using Deloitte.QDR.Credly.Functions.Contracts;
using Deloitte.QDR.Credly.Functions.DAL;
using Deloitte.QDR.Credly.Functions.Infrastructure.Storage;
using Deloitte.QDR.DTO.Azure;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Host;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using System.Linq;
using System.Security.Cryptography.Xml;
using System.Collections.Generic;
using Microsoft.WindowsAzure.Storage.Queue.Protocol;
using Deloitte.QDR.DTO.Common;

namespace Deloitte.QDR.Credly.Functions.AFUtils
{
    public class ImageProcessingLegacyData
    {
        private readonly DefaultDBContext _dbContext = null;
        private readonly ICredlyAPIService _credlyAPIService = null;
        private readonly ILogger<ImageProcessing> _logger = null;
        private static readonly HttpClient _httpClient = new HttpClient();
        private readonly IBlobStorageService _blobStorageService = null;
        private const string _logInfoName = "IMAGE PROCESSING";
        private const string _imageProcessingBadgeTemplate = "imageprocessing_badgetemplate";
        private const string _badgeTemplatePathImage = "badgeTemplates/{0}/Image.png";
        private const String _contentType = "image/jpeg";

        public ImageProcessingLegacyData(DefaultDBContext dbContext, ICredlyAPIService credlyAPIService,
            ILogger<ImageProcessing> logger, IBlobStorageService blobStorageService)
        {
            _dbContext = dbContext ?? throw new ArgumentNullException(nameof(dbContext));
            _credlyAPIService = credlyAPIService ?? throw new ArgumentNullException(nameof(credlyAPIService));
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
            _blobStorageService = blobStorageService ?? throw new ArgumentNullException(nameof(blobStorageService));
        }

        [FunctionName("ImageProcessingLegacyData")]
        public async Task Run([TimerTrigger("0 */1 * * * *")]TimerInfo myTimer, ILogger log, CancellationToken cancellationToken = default)
        {
            log.LogInformation($"C# Timer trigger function { nameof(ImageProcessingLegacyData) } executed at: {DateTime.Now}");
            try
            {
                var numberRegisters = 10;
                var templates = await (from t in _dbContext.BadgeTemplates
                                 where t.ImageUrl.StartsWith("http")
                                 select new string[] { t.Id.ToString(), t.ImageUrl }).Take(numberRegisters).ToListAsync();

                foreach (var item in templates)
                {
                    await BadgeTemplateHandlerAsync(item, cancellationToken);
                }
               
                _logger.LogInformation($"{_logInfoName} function finisned to execute at: {DateTime.Now.ToString("HH:mm:ss")}");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"{_logInfoName}, it was not possible to complete the process due an internal error.");
            }
        }

        private async Task BadgeTemplateHandlerAsync(string[] template, CancellationToken cancellationToken)
        {
            _logger.LogInformation($"IdTemplate: {template[0]} - badge template image: {template[1]}: {DateTime.Now.ToString("HH:mm:ss")}");
            var badgeTemplateQDR = await _dbContext.BadgeTemplates.FirstOrDefaultAsync(t => t.Id == Guid.Parse(template[0]), cancellationToken);
            if (badgeTemplateQDR is null)
            {
                _logger.LogInformation($"{_logInfoName} - badge template id not found in qdr, executed at: {DateTime.Now.ToString("HH:mm:ss")}");
                return;
            }

            string imagePath = string.Format(_badgeTemplatePathImage, badgeTemplateQDR.Id);
            _logger.LogInformation($"({_logInfoName} imagePath = {imagePath} ");
            var imageContent = GetImage(badgeTemplateQDR.ImageUrl);
            if (imageContent != null)
            {
                _logger.LogInformation($"{_logInfoName}/imageprocessing_badgetemplate image was downloaded success at: {DateTime.Now.ToString("HH:mm:ss")}");           
                var resultUpload = await _blobStorageService.UploadBlobFile(imageContent, imagePath, _contentType);
                _logger.LogInformation($"{_logInfoName}/imageprocessing_badgetemplate image was uploaded success at: {DateTime.Now.ToString("HH:mm:ss")}");
                badgeTemplateQDR.ImageUrl = resultUpload.IdBlob;
                await _dbContext.SaveChangesAsync(cancellationToken);
                _logger.LogInformation($"{_logInfoName}/imageprocessing_badgetemplate record updated sucess at: {DateTime.Now.ToString("HH:mm:ss")}");
            }

            _logger.LogInformation($"{_logInfoName}/imageprocessing_badgetemplate execute completed at: {DateTime.Now.ToString("HH:mm:ss")}");
        }

        private MemoryStream GetImage(string imageUri)
        {
            MemoryStream result = null;
            try
            {
                WebClient client = new WebClient();
                var uri = new Uri(imageUri);
                result = new MemoryStream(client.DownloadData(uri));
                return result;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"It was not possible download the requested image: {imageUri}");
            }

            return result;
        }
    }
}
