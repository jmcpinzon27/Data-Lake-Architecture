﻿using Azure.Messaging.ServiceBus;
using Deloitte.QDR.Credly.Functions.Contracts;
using Deloitte.QDR.Credly.Functions.DAL;
using Deloitte.QDR.DTO.CredlyAPI;
using Deloitte.QDR.DTO.Notifications;
using Deloitte.QDR.Entities;
using Microsoft.Azure.WebJobs;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Threading;
using System.Threading.Tasks;
using Deloitte.QDR.DTO.CredlyAPI.Common;

namespace Deloitte.QDR.Credly.Functions.AFEmployment
{
    public class EmploymentConnectionAccepted
    {
        private readonly DefaultDBContext _dbContext;
        private readonly ICredlyAPIService _credlyAPIService;
        private readonly ILogger<EmploymentConnectionAccepted> _logger;
        private readonly IQDRAPIService _qDRAPIService;
        private const string _acceptedConnectionText = "employment.connection.accepted";
        private List<ProcessLog> _processLogTrace;
        private Guid _employmentId;

        public EmploymentConnectionAccepted(DefaultDBContext dbContext, ICredlyAPIService credlyAPIService
            , ILogger<EmploymentConnectionAccepted> logger, IQDRAPIService qDRAPIService)
        {
            _dbContext = dbContext ?? throw new ArgumentNullException(nameof(dbContext));
            _credlyAPIService = credlyAPIService ?? throw new ArgumentNullException(nameof(credlyAPIService));
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
            _qDRAPIService = qDRAPIService ?? throw new ArgumentNullException(nameof(qDRAPIService));
            _processLogTrace = new List<ProcessLog>();
        }

        [FunctionName("EmploymentConnectionAccepted")]
        public async Task Run(
            [ServiceBusTrigger("employment_connection_accepted", "ea_subscription", Connection = "ServiceBusConnection")]
                ServiceBusReceivedMessage serviceBusReceivedMessage,
                IBinder binder, CancellationToken cancellationToken = default
        )
        {
            try
            {
                string requestTopicMessage = await new StreamReader(serviceBusReceivedMessage.Body.ToStream()).ReadToEndAsync();
                var topicMessage = JsonConvert.DeserializeObject<Message>(requestTopicMessage);
                var event_type = topicMessage.EventType;
                AddLogTrace(topicMessage.Id, topicMessage.EventType, "Read incoming message", "Start to execute");

                if (event_type == _acceptedConnectionText)
                {
                    //TODO: Send organization for badge template because are validate what is the organization for employees.
                    var data = await _credlyAPIService.GetEvent<EmployeeConnectionAcceptedEvent>(topicMessage.Id, OrganizationFor.Employment);
                    var employment = data.Employment;
                    _employmentId = employment.Id;
                    AddLogTrace(_employmentId, "Employment", "Obtained event from credly", "Start to reading credly information");

                    var employee = await _dbContext.CredlyEmployees.FirstOrDefaultAsync(e => e.CredlyID == _employmentId, cancellationToken);

                    if (employee != null)
                    {
                        AddLogTrace(_employmentId, "Employment", $"It found employee: {employee.PersonID}", "Employee was found");
                        employee.EmployeeState = employment.EmployeeState;
                        employee.EmployeeLastStateUpdatedAt = DateTime.Now;

                        await _dbContext.SaveChangesAsync(cancellationToken);
                        AddLogTrace(_employmentId, "Employment", $"It found employee: {employee.PersonID}", "Employee was found");

                        var newNotification = GenerateAcceptedNotification(employee);
                        await _qDRAPIService.SendNotificationAsync(newNotification, cancellationToken);
                        var jsonNotification = System.Text.Json.JsonSerializer.Serialize<SendNotificationDTO>(newNotification);
                        AddLogTrace(_employmentId, "Employment", $"Notificaction was send to API, payload: [{jsonNotification}]", "Employee was found");
                    }
                    else
                    {
                        AddLogTrace(_employmentId, "Employment", $"It not found employee: {_employmentId}", "Employee was not found");
                    }
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "EmploymentConnectionAccepted.Error", DateTime.Now.ToString("HH:mm:ss"));
                var jsonException = System.Text.Json.JsonSerializer.Serialize<Exception>(ex);
                AddLogTrace(_employmentId, "Employment", $"Error: [{jsonException}]", "Error was catched");
            }
            finally
            {
                AddLogTrace(_employmentId, "Employment", "", "Finished to execute");
                await SaveLogTraceAsync(cancellationToken);
            }
        }

        private DTO.Notifications.SendNotificationDTO GenerateAcceptedNotification(Entities.CredlyEmployee employee)
        {
            var newNotification = new DTO.Notifications.SendNotificationDTO
            {
                EmailGroup = new System.Collections.Generic.List<string>() { employee.Email },
                NotificacionHub = new DTO.Common.NotificacionHub
                {
                    Title = "User connection accepted",//Not needed, pending to define
                    Description = "User connection accepted", //Not needed, pending to define
                    ActivityType = _acceptedConnectionText,
                    EntityId = employee.CredlyID.ToString(),
                    EntityType = "CredlyEmployee",
                    NotificationId = employee.EmployeeState,
                    Type = _acceptedConnectionText
                }
            };
            return newNotification;
        }

        private async Task SaveLogTraceAsync(CancellationToken cancellationToken)
        {
            await _dbContext.ProcessLogs.AddRangeAsync(_processLogTrace, cancellationToken);
            await _dbContext.SaveChangesAsync(cancellationToken);
        }

        private void AddLogTrace(Guid entityId, string entityType, string eventMessage, string step)
        {
            var log = new ProcessLog
            {
                Date = DateTime.Now,
                EntityId = entityId.ToString(),
                EntityType = entityType,
                EventMessage = eventMessage,
                Pipeline = _acceptedConnectionText.ToUpper(),
                Step = step
            };
            _processLogTrace.Add(log);
            _logger.LogInformation($"EmploymentConnectionAccepted: {eventMessage}");
        }
    }
}