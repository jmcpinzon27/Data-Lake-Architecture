﻿using Azure.Messaging.ServiceBus;
using Deloitte.QDR.Credly.Functions.Contracts;
using Deloitte.QDR.Credly.Functions.DAL;
using Deloitte.QDR.DTO.CredlyAPI;
using Microsoft.Azure.WebJobs;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using System;
using System.IO;
using System.Threading;
using System.Threading.Tasks;
using Deloitte.QDR.DTO.CredlyAPI.Common;

namespace Deloitte.QDR.Credly.Functions.AFEmployment
{
    public class EmploymentconnectionRejected
    {
        private readonly DefaultDBContext _dbContext;
        private readonly ICredlyAPIService _credlyAPIService;
        private readonly ILogger<EmploymentconnectionRejected> _logger;

        public EmploymentconnectionRejected(DefaultDBContext dbContext, ICredlyAPIService credlyAPIService, ILogger<EmploymentconnectionRejected> logger)
        {
            _dbContext = dbContext ?? throw new ArgumentNullException(nameof(dbContext));
            _credlyAPIService = credlyAPIService ?? throw new ArgumentNullException(nameof(credlyAPIService));
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
        }

        [FunctionName("EmploymentConnectionRejected")]
        public async Task Run(
            [ServiceBusTrigger("employment_connection_rejected", "er_subscription", Connection = "ServiceBusConnection")]
                ServiceBusReceivedMessage serviceBusReceivedMessage,
                IBinder binder, CancellationToken cancellationToken = default
        )
        {
            string requestTopicMessage = await new StreamReader(serviceBusReceivedMessage.Body.ToStream()).ReadToEndAsync();
            var topicMessage = JsonConvert.DeserializeObject<Message>(requestTopicMessage);
            var event_type = topicMessage.EventType;

            if (event_type == "employment.connection.rejected")
            {
                //TODO: Send organization for badge template because are validate what is the organization for employees.
                var data = await _credlyAPIService.GetEvent<EmployeeConnectionRejectedEvent>(topicMessage.Id, OrganizationFor.Employment);
                var employment = data.Employment;

                var employee = await _dbContext.CredlyEmployees.SingleOrDefaultAsync(e => e.CredlyID == employment.Id, cancellationToken);

                if (employee != null)
                {
                    employee.EmployeeState = employment.EmployeeState;
                    employee.EmployeeLastStateUpdatedAt = DateTime.Now;

                    await _dbContext.SaveChangesAsync(cancellationToken);
                }
            }
        }
    }
}