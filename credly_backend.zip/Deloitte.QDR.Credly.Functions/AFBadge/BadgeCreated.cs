using Azure.Messaging.ServiceBus;
using Deloitte.QDR.Credly.Functions.Constant;
using Deloitte.QDR.Credly.Functions.Contracts;
using Deloitte.QDR.Credly.Functions.DAL;
using Deloitte.QDR.DTO.CredlyAPI;
using Deloitte.QDR.DTO.CredlyAPI.Common;
using Deloitte.QDR.Entities;
using Microsoft.Azure.WebJobs;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using NPOI.OpenXmlFormats;
using System;
using System.IO;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace Deloitte.QDR.Credly.Functions.AFBadge
{
    public class BadgeCreated
    {
        private readonly DefaultDBContext _dbContext = null;
        private readonly ICredlyAPIService _credlyAPIService = null;
        private readonly ILogger<BadgeCreated> _logger = null;
        private const string _logInfoName = "Badge created";

        public BadgeCreated(DefaultDBContext dbContext, ICredlyAPIService credlyAPIService, ILogger<BadgeCreated> logger)
        {
            _dbContext = dbContext ?? throw new ArgumentNullException(nameof(dbContext));
            _credlyAPIService = credlyAPIService ?? throw new ArgumentNullException(nameof(credlyAPIService));
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
        }

        [FunctionName("BadgeCreated")]
        public async Task Run(
            [ServiceBusTrigger(
                "badge_created",
                "bc_subscription",
                Connection = "ServiceBusConnection"
            )]
                ServiceBusReceivedMessage serviceBusReceivedMessage,
                IBinder binder, CancellationToken cancellationToken = default
        )
        {
            try
            {
                _logger.LogTrace($"{_logInfoName}: function start to execute at: {DateTime.UtcNow.ToString("HH:mm:ss")}");
                string requestTopicMessage = await new StreamReader(serviceBusReceivedMessage.Body.ToStream()).ReadToEndAsync();
                var topicMessage = JsonConvert.DeserializeObject<Message>(requestTopicMessage);
                var data = await _credlyAPIService.GetEvent<BadgeCreatedEvent>(topicMessage.Id, OrganizationFor.Badge);
                _logger.LogTrace($"{_logInfoName}: received information from credly event");
                var badge_collection = data.Badge;
                var employment = data.EmploymentInfo;
                var issuer = badge_collection.Issuer;
                var badgetemplate_collection = badge_collection.BadgeTemplate;
                _logger.LogTrace($"{_logInfoName}: readed data from credly-badge-->user: {employment}, issuer: {issuer}, badgetemplate: {badgetemplate_collection}");

                var personnelNumber = _dbContext.CredlyEmployees.Where(e => e.CredlyID == employment.Id).Select(e => e.PersonnelNumber).FirstOrDefault();
                var personID = _dbContext.Employees.Where(e => e.PersonnelNumber == employment.PersonnelNumber).Select(e => e.PersonID).FirstOrDefault();

                if (personnelNumber == null)
                {
                    _logger.LogTrace($"{_logInfoName}: not found credlyemployee with credlyid={employment.Id}");
                }
                else
                {
                    _logger.LogTrace($"{_logInfoName}: found credlyemployee with credlyid={employment.Id} and personid={personnelNumber}");
                }
                var badgeTemplate = await _dbContext.BadgeTemplates.FirstOrDefaultAsync(e => e.ExternalId == badgetemplate_collection.Id.ToString(), cancellationToken);

                if (badgeTemplate == null)
                {
                    _logger.LogTrace($"{_logInfoName}: badge template was not found with externalid={badgetemplate_collection.Id.ToString()}");
                    badgeTemplate = new Entities.BadgeTemplate
                    {
                        Issuer = issuer.Name,
                        ExternalId = badgetemplate_collection.Id.ToString(),
                        Name = badgetemplate_collection.Name,
                        Description = badgetemplate_collection.Description,
                        CreatedAt = badge_collection.IssuedAt
                    };

                    _dbContext.BadgeTemplates.Add(badgeTemplate);
                }

                var entity = await _dbContext.Badges.FirstOrDefaultAsync(e => e.BadgeTemplateId == badgeTemplate.Id && e.PersonID == personID, cancellationToken);

                var isNew = true;
                if (entity == null)
                {

                    entity = new Entities.Badge
                    {
                        ExternalId = badge_collection.Id.ToString(),
                        AwardedAt = badge_collection.IssuedAt,
                        BadgeTemplate = badgeTemplate,
                        DecisionAt = badge_collection.IssuedAt,
                        PersonID = personID,
                        PersonnelNumber = personnelNumber,
                        Private = badge_collection.IsPrivateBadge,
                    };
                    _logger.LogTrace($"{_logInfoName}: new badge created with personid={personnelNumber}");
                }
                else
                {
                    isNew = false;
                    entity.AwardedAt = badge_collection.IssuedAt;
                    entity.DecisionAt = badge_collection.IssuedAt;
                    entity.PersonnelNumber = personnelNumber;
                    _logger.LogTrace($"{_logInfoName}: badge updated with personid={personnelNumber}");
                }

                switch (badge_collection.State)
                {
                    case FunctionsConstants.CREDLY_ACCEPTED_STATE:
                        entity.State = FunctionsConstants.QDR_ACCEPTED_STATE;
                        entity.Status = BadgeStatus.Awarded;
                        break;

                    case FunctionsConstants.CREDLY_PENDING_STATE:
                        entity.State = FunctionsConstants.QDR_PENDING_STATE;
                        entity.Status = BadgeStatus.Approved;
                        break;

                    case FunctionsConstants.CREDLY_REVOKE_STATE:
                        entity.State = FunctionsConstants.QDR_REVOKE_STATE;
                        entity.Status = BadgeStatus.Rejected;
                        break;

                    case FunctionsConstants.CREDLY_REJECTED_STATE:
                        entity.State = FunctionsConstants.QDR_REJECTED_STATE;
                        entity.Status = BadgeStatus.Rejected;
                        break;

                    default:
                        break;
                }

                if (isNew) { _dbContext.Badges.Add(entity); }
                await _dbContext.SaveChangesAsync(cancellationToken);
                _logger.LogTrace($"{_logInfoName}: function finished to execute at: {DateTime.UtcNow.ToString("HH:mm:ss")}");
            }
            catch (Exception ex)
            {
                _logger.LogTrace($"{_logInfoName}: an exception was caugth: {ex.Message} executed at: {DateTime.UtcNow.ToString("HH:mm:ss")}");
                _logger.LogError(ex, "BadgeCreated.Error", DateTime.Now.ToString("HH:mm:ss"));
            }
        }
    }
}