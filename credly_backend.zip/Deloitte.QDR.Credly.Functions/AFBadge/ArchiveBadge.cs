using Deloitte.QDR.Credly.Functions.Contracts;
using Deloitte.QDR.Credly.Functions.DAL;
using Deloitte.QDR.Credly.Functions.Infrastructure.Config;
using Deloitte.QDR.DTO.Common;
using Deloitte.QDR.DTO.Notifications;
using Deloitte.QDR.Entities;
using Microsoft.Azure.WebJobs;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace Deloitte.QDR.Credly.Functions.AFBadge
{
    public class ArchiveBadge
    {
        private readonly DefaultDBContext _dbContext;
        private readonly IQDRAPIService _qDRAPIService;

        private const string _entityType = "Badge";
        private const string _logInfoName = "ARCHIVE_BADGE_PROCESS:";
        private int _batchQuantity = 0;
        private List<string> _awardedEmailList = null;
        private List<string> _commonEmailList = null;
        private readonly ILogger<ArchiveBadge> _logger = null;

        public ArchiveBadge(DefaultDBContext dbContext, IQDRAPIService qDRAPIService, ILogger<ArchiveBadge> logger)
        {
            _dbContext = dbContext ?? throw new ArgumentNullException(nameof(dbContext));
            _qDRAPIService = qDRAPIService ?? throw new ArgumentNullException(nameof(qDRAPIService));
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
            _logger.LogInformation($"{_logInfoName} function constructor execute at: {DateTime.Now.ToString("HH:mm:ss")}");

            bool checkArchiveBadgeCapacityToProcess = int.TryParse(AppSettings.Settings.ArchiveBadgeCapacityToProcess, out _batchQuantity);
            if (!(!string.IsNullOrEmpty(AppSettings.Settings.ArchiveBadgeCapacityToProcess) && checkArchiveBadgeCapacityToProcess))
            {
                throw new ArgumentException("Invalid parameter value to ArchiveBadgeCapacityToProcess");
            }
            _logger.LogInformation($"{_logInfoName} function constructor executed at: {DateTime.Now.ToString("HH:mm:ss")}");
        }

        [FunctionName("ArchiveBadge")]
        public async Task Run([TimerTrigger("0 */1 * * * *")] TimerInfo myTimer, CancellationToken cancellationToken = default)
        {
            _logger.LogInformation($"{_logInfoName} function start to execute at: {DateTime.Now.ToString("HH:mm:ss")}");
            await CollectBadgeToBeArchiveAsync(cancellationToken);
            _logger.LogInformation($"{_logInfoName} function finished to executed at: {DateTime.Now.ToString("HH:mm:ss")}");
        }

        private async Task CollectBadgeToBeArchiveAsync(CancellationToken cancellationToken)
        {
            try
            {
                var recordsToArchive = await GetRecordsToArchiveAsync(cancellationToken);

                if (recordsToArchive.Any())
                {
                    var batchList = recordsToArchive.Chunk<BadgeToArchiveDTO>(_batchQuantity);
                    foreach (var records in batchList)
                    {
                        _commonEmailList = _awardedEmailList = new List<string>();

                        for (int i = 0; i <= records.Length - 1; i++)
                        {
                            try
                            {
                                var badge = _dbContext.Badges.Find(records[i].BadgeId);
                                SortNotification(badge.Status, records[i].EmailEmployee);
                                //TODO: check a valid status change.
                                badge.Status = Entities.BadgeStatus.Archived;
                                badge.ArchiveDate = DateTime.UtcNow;

                                _dbContext.Badges.Update(badge);
                            }
                            catch (Exception ex)
                            {
                                _logger.LogError(ex, $"{_logInfoName} archivebadge timer trigger function failure at badgeid: {records[i].BadgeId}");
                            }
                        }

                        await _dbContext.SaveChangesAsync(cancellationToken);
                        await SendNotificationAsync(cancellationToken);
                    }
                }
            }
            catch (Exception generalException)
            {
                _logger.LogError(generalException, $"{_logInfoName} it was not possible to execute the function due an internal error.");
                throw;
            }
        }

        private void SortNotification(BadgeStatus? badgeStatus, string employeeEmail)
        {
            if (badgeStatus == BadgeStatus.Awarded)
            {
                _awardedEmailList.Add(employeeEmail);
            }
            else
            {
                _commonEmailList.Add(employeeEmail);
            }
        }

        private async Task SendNotificationAsync(CancellationToken cancellationToken)
        {
            NotificacionHub awardedNotification = await GetConfigNotificationAsync(GeneralConstants.Badge.BADGE_AWARDEDTOBEARCHIVED_STATUS, _entityType, cancellationToken);
            NotificacionHub commonNotification = await GetConfigNotificationAsync(GeneralConstants.Badge.BADGE_HASBEENARCHIVED_STATUS, _entityType, cancellationToken);

            try
            {
                _logger.LogTrace($"{_logInfoName} trying to send a notification.", _awardedEmailList, awardedNotification);
                await _qDRAPIService.SendNotificationAsync(new SendNotificationDTO
                {
                    EmailGroup = _awardedEmailList,
                    NotificacionHub = awardedNotification
                }, cancellationToken);

                _logger.LogTrace($"{_logInfoName} trying to send a notification.", _commonEmailList, commonNotification);
                await _qDRAPIService.SendNotificationAsync(new SendNotificationDTO
                {
                    EmailGroup = _commonEmailList,
                    NotificacionHub = commonNotification
                }, cancellationToken);
            }
            catch (Exception ex)
            {
                _logger.LogWarning(ex, "{_logInfoName} handled exception because the current authentication to qdr api is not available.");
            }
        }

        private async Task<IEnumerable<BadgeToArchiveDTO>> GetRecordsToArchiveAsync(CancellationToken cancellationToken)
        {
            _logger.LogInformation($"{_logInfoName} getting available records to process, executed at: {DateTime.UtcNow.ToString("HH:mm:ss")}");
            var result = await (from bt in _dbContext.BadgeTemplates
                                join b in _dbContext.Badges on bt.Id equals b.BadgeTemplateId
                                join emp in _dbContext.Employees on b.Employee.PersonID equals emp.PersonID
                                where bt.Status == Entities.BadgeTemplateStatus.Archived && bt.ArchiveDate != null
                                && bt.ArchiveDate.Value.Date == DateTime.UtcNow.Date
                                && (b.Status != BadgeStatus.Archived && b.ArchiveDate == null)
                                select new BadgeToArchiveDTO { EmailEmployee = emp.Email, BadgeId = b.Id }
                                  ).ToListAsync(cancellationToken);
            if (!result.Any())
            {
                _logger.LogInformation($"{_logInfoName} not records found, executed at: {DateTime.UtcNow.ToString("HH:mm:ss")}");
            }
            else
            {
                var recordCount = result.Count();
                _logger.LogInformation($"{_logInfoName} records found:{recordCount}, executed at: {DateTime.UtcNow.ToString("HH:mm:ss")}");
            }
            return result;
        }

        private async Task<NotificacionHub> GetConfigNotificationAsync(string id, string entityType, CancellationToken cancellationToken)
        {
            var notificationEntity = await _dbContext.ConfigNotifications.FirstOrDefaultAsync
                (t => t.NotificationId == id && t.EntityType == entityType, cancellationToken);

            if (notificationEntity == null)
            {
                throw new ValidationException(
                     new Result { HasErrors = true, Messages = new List<string> { GeneralConstants.ErrorMessages.NOTIFICATIONS_CONFIG } });
            }

            NotificacionHub notificacionHub = new NotificacionHub
            {
                ActivityType = notificationEntity.ActivityType,
                Description = notificationEntity.Description,
                EntityType = notificationEntity.EntityType,
                Title = notificationEntity.Title,
                Type = notificationEntity.NotificationType,
                EntityId = entityType,
                NotificationId = id
            };

            return notificacionHub;
        }
    }
}