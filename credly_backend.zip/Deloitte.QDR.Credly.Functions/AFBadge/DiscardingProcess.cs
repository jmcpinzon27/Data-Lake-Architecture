﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Threading;
using Microsoft.Azure.WebJobs;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using Deloitte.QDR.Credly.Functions.DAL;
using System.Linq;
using Microsoft.EntityFrameworkCore;
using Deloitte.QDR.Entities.StoredProcedures;

namespace Deloitte.QDR.Credly.Functions.AFBadge
{
    public class DiscardingProcess
    {
        private const string _logInfoName = "Discarding badge process";
        private readonly DefaultDBContext _dbContext;
        private readonly ILogger<DiscardingProcess> _logger = null;

        public DiscardingProcess(DefaultDBContext dbContext, ILogger<DiscardingProcess> logger)
        {
            _dbContext = dbContext ?? throw new ArgumentNullException(nameof(dbContext));
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
        }

        [FunctionName("DiscardingProcess")]
        public async Task Run([TimerTrigger("%DiscardingProcessCron%")] TimerInfo myTimer, CancellationToken cancellationToken = default)
        {
            _logger.LogInformation($"{_logInfoName} function start to execute at: {DateTime.Now.ToString("HH:mm:ss")}");
            await CollectBadgeToBeArchiveAsync(cancellationToken);
            _logger.LogInformation($"{_logInfoName} function finished to executed at: {DateTime.Now.ToString("HH:mm:ss")}");
        }

        private async Task CollectBadgeToBeArchiveAsync(CancellationToken cancellationToken)
        {
            try
            {
                var recordsToDiscard = await GetRecordsToDiscardAsync(cancellationToken);

                if (recordsToDiscard.Any())
                {
                    recordsToDiscard.ToList().ForEach
                        (t =>
                        _logger.LogInformation($"{_logInfoName}: {t.Id} has been discarded, executed at: {DateTime.UtcNow.ToString("HH:mm:ss")}")
                        );
                }
            }
            catch (Exception generalException)
            {
                _logger.LogError(generalException, $"{_logInfoName} it was not possible to execute the function due an internal error.");
                throw;
            }
        }

        private async Task<IEnumerable<spBadgeDiscardingProcess>> GetRecordsToDiscardAsync(CancellationToken cancellationToken)
        {
            try
            {
                var result = await _dbContext.spBadgeDiscardingProcessResult.FromSqlRaw("EXECUTE spBadgeDiscardingProcess").ToListAsync(cancellationToken);
                if (!result.Any())
                {
                    _logger.LogInformation($"{_logInfoName} not records found, executed at: {DateTime.UtcNow.ToString("HH:mm:ss")}");
                }
                else
                {
                    var recordCount = result.Count();
                    _logger.LogInformation($"{_logInfoName} records found:{recordCount}, executed at: {DateTime.UtcNow.ToString("HH:mm:ss")}");
                }

                return result;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}