﻿using Azure.Messaging.ServiceBus;
using Deloitte.QDR.Credly.Functions.Constant;
using Deloitte.QDR.Credly.Functions.Contracts;
using Deloitte.QDR.Credly.Functions.DAL;
using Deloitte.QDR.DTO.CredlyAPI;
using Microsoft.Azure.WebJobs;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using System;
using System.IO;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using Deloitte.QDR.DTO.CredlyAPI.Common;
using Deloitte.QDR.Entities;
using Microsoft.EntityFrameworkCore;

namespace Deloitte.QDR.Credly.Functions.AFBadge
{
    public class BadgeStateChanged
    {
        private readonly DefaultDBContext _dbContext = null;
        private readonly ICredlyAPIService _credlyAPIService = null;
        private readonly ILogger<BadgeStateChanged> _logger = null;
        private const string _logInfoName = "Badge_State_Changed";

        public BadgeStateChanged(DefaultDBContext dbContext, ICredlyAPIService credlyAPIService, ILogger<BadgeStateChanged> logger)
        {
            _dbContext = dbContext ?? throw new ArgumentNullException(nameof(dbContext));
            _credlyAPIService = credlyAPIService ?? throw new ArgumentNullException(nameof(credlyAPIService));
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
        }

        [FunctionName("BadgeStateChanged")]
        public async Task Run(
            [ServiceBusTrigger("badge_state_changed", "bsc_subscription", Connection = "ServiceBusConnection")]
                ServiceBusReceivedMessage serviceBusReceivedMessage,
                IBinder binder, CancellationToken cancellationToken = default

        )
        {
            _logger.LogTrace($"{_logInfoName}: function start to execute at: {DateTime.UtcNow.ToString("HH:mm:ss")}");
            string requestTopicMessage = await new StreamReader(serviceBusReceivedMessage.Body.ToStream()).ReadToEndAsync();
            var topicMessage = JsonConvert.DeserializeObject<Message>(requestTopicMessage);
            var event_type = topicMessage.EventType;

            if (event_type == "employment.badges.state_changed")
            {
                try
                {
                    _logger.LogInformation($"{_logInfoName} GET request to Credly API. executed at: {DateTime.Now.ToString("HH:mm:ss")}");
                    var data = await _credlyAPIService.GetEvent<BadgeStateChangedEvent>(topicMessage.Id, OrganizationFor.Badge);
                    _logger.LogTrace($"{_logInfoName}: Data received from credly event");
                    var badge_collection = data.Badge;
                    var employment = data.EmploymentInfo;
                    var user = badge_collection.User;
                    var badgeState = badge_collection.State;
                    var externalId = badge_collection.Id.ToString();

                    if (badgeState != null)
                    {
                        bool saveChanges = await BadgeHandlerAsync(externalId, badgeState, cancellationToken);

                        if (saveChanges)
                        {
                            _logger.LogInformation($"{_logInfoName} trying to save changes in dqr. executed at: {DateTime.Now.ToString("HH:mm:ss")}");
                            await _dbContext.SaveChangesAsync(cancellationToken);
                            _logger.LogInformation($"{_logInfoName} qdr changes were saved sucessful. executed at: {DateTime.Now.ToString("HH:mm:ss")}");
                        }

                    }                       
                }
                catch (Exception ex)
                {
                    _logger.LogError(ex, $"{_logInfoName} it was not possible to execute the function due an internal error.");
                    throw;
                }

                _logger.LogInformation($"{_logInfoName} function finished to executed at: {DateTime.Now.ToString("HH:mm:ss")}");

            }
        }

        private async Task<bool> BadgeHandlerAsync(string externalId, string badgeState, CancellationToken cancellationToken)
        {
            bool saveChanges = false;
            var qdrBadgeToUpdate = await _dbContext.Badges.SingleOrDefaultAsync(e => e.ExternalId == externalId
                                                                                        && e.Status != null && (e.Status != BadgeStatus.Awarded  || e.Status != BadgeStatus.Rejected || e.Status != BadgeStatus.Revoked),
                                                                                        cancellationToken);
            if (qdrBadgeToUpdate != null) 
            {
                _logger.LogInformation($"{_logInfoName} badge data found in qdr. executed at: {DateTime.Now.ToString("HH:mm:ss")}");
                switch (badgeState)
                {
                    case FunctionsConstants.CREDLY_ACCEPTED_STATE:
                        qdrBadgeToUpdate.State = FunctionsConstants.QDR_ACCEPTED_STATE;
                        qdrBadgeToUpdate.Status = BadgeStatus.Awarded;
                        break;

                    case FunctionsConstants.CREDLY_PENDING_STATE:
                        qdrBadgeToUpdate.State = FunctionsConstants.QDR_PENDING_STATE;
                        qdrBadgeToUpdate.Status = BadgeStatus.Approved;
                        break;

                    case FunctionsConstants.CREDLY_REVOKE_STATE:
                        qdrBadgeToUpdate.State = FunctionsConstants.QDR_REVOKE_STATE;
                        qdrBadgeToUpdate.Status = BadgeStatus.Revoked;
                        break;

                    case FunctionsConstants.CREDLY_REJECTED_STATE:
                        qdrBadgeToUpdate.State = FunctionsConstants.QDR_REJECTED_STATE;
                        qdrBadgeToUpdate.Status = BadgeStatus.Rejected;
                        break;

                    default:
                        break;
                }
                _dbContext.Badges.Update(qdrBadgeToUpdate);
                _logger.LogInformation($"{_logInfoName} badge had been updated. executed at: {DateTime.Now.ToString("HH:mm:ss")}");

                var userActivity = new UserActivity
                {
                    Date = DateTime.UtcNow,
                    Description = ActivityType.BadgeStateUpdatedByAutomaticProcess.ToString(),
                    EntityId = qdrBadgeToUpdate.Id.ToString(),
                    Title = qdrBadgeToUpdate.State,
                    Type = ActivityType.BadgeStateUpdatedByAutomaticProcess
                };
                await _dbContext.UserActivities.AddAsync(userActivity, cancellationToken);
                saveChanges = true;
                _logger.LogInformation($"{_logInfoName} added user activity trace. executed at: {DateTime.Now.ToString("HH:mm:ss")}");
            }
            else
            {
                _logger.LogInformation($"{_logInfoName} not badge data found: (externalid){externalId} in qdr. executed at: {DateTime.Now.ToString("HH:mm:ss")}");
            }

            return saveChanges;
        }

    }
}