﻿using Azure.Messaging.ServiceBus;
using Deloitte.QDR.Credly.Functions.Contracts;
using Deloitte.QDR.Credly.Functions.DAL;
using Deloitte.QDR.DTO.CredlyAPI;
using Microsoft.Azure.WebJobs;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using System;
using System.IO;
using System.Threading;
using System.Threading.Tasks;
using Deloitte.QDR.DTO.CredlyAPI.Common;

namespace Deloitte.QDR.Credly.Functions.AFBadge
{
    internal class BadgePrivacyChanged
    {
        private readonly DefaultDBContext _dbContext;
        private readonly ICredlyAPIService _credlyAPIService;
        private readonly ILogger<BadgePrivacyChanged> _logger = null;

        public BadgePrivacyChanged(DefaultDBContext dbContext, ICredlyAPIService credlyAPIService, ILogger<BadgePrivacyChanged> logger)
        {
            _dbContext = dbContext ?? throw new ArgumentNullException(nameof(dbContext));
            _credlyAPIService = credlyAPIService ?? throw new ArgumentNullException(nameof(credlyAPIService));
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
        }

        [FunctionName("BadgePrivacyChanged")]
        public async Task Run(
            [ServiceBusTrigger("badge_privacy_changed", "bpc_subscription", Connection = "ServiceBusConnection")]
                ServiceBusReceivedMessage serviceBusReceivedMessage,
                IBinder binder, CancellationToken cancellationToken = default

        )
        {
            string requestTopicMessage = await new StreamReader(serviceBusReceivedMessage.Body.ToStream()).ReadToEndAsync();
            var topicMessage = JsonConvert.DeserializeObject<Message>(requestTopicMessage);
            var event_type = topicMessage.EventType;

            if (event_type == "employment.badges.privacy_changed")
            {
                var data = await _credlyAPIService.GetEvent<BadgePrivacyChangedEvent>(topicMessage.Id, OrganizationFor.Badge);
                var badge_collection = data.Badge;
                var user = badge_collection.User;
                var issuer = badge_collection.Issuer;
                var badgetemplate = badge_collection.BadgeTemplate;
                var image = badge_collection.Image;
                var createdby = badge_collection.CreatedBy;

                var badge = await _dbContext.Badges.FirstOrDefaultAsync(e => e.ExternalId == badge_collection.Id.ToString(), cancellationToken);

                if (badge != null)
                {
                    badge.Private = !badge_collection.Private;

                    await _dbContext.SaveChangesAsync(cancellationToken);
                }
            }
        }
    }
}