﻿using Azure.Messaging.ServiceBus;
using Microsoft.Azure.WebJobs;
using Newtonsoft.Json;
using System;
using System.IO;
using System.Threading.Tasks;

namespace Credly.Functions.Gateway
{

    public class Message
    {
        public Guid id { get; set; }
        public string organization_id { get; set; }
        public string event_type { get; set; }
        public string ocurred_at { get; set; }
    }

    public class Gateway
    {
        [FunctionName("Gateway")]
        public async Task Run([ServiceBusTrigger("%Queue%", Connection = "ServiceBusConnection")] ServiceBusReceivedMessage serviceBusReceivedMessage, IBinder binder)
        {
            var requestBody = await new StreamReader(
                 serviceBusReceivedMessage.Body.ToStream()
             ).ReadToEndAsync();
            var message = JsonConvert.DeserializeObject<Message>(requestBody); ;

            //log.LogInformation($"C# ServiceBus queue trigger function processed message: ");

            var asyncCollector = await binder.BindAsync<IAsyncCollector<string>>(new ServiceBusAttribute(message.event_type)
            {
                Connection = "ServiceBusConnection",
                EntityType = Microsoft.Azure.WebJobs.ServiceBus.ServiceBusEntityType.Topic,

            });

            await asyncCollector.AddAsync(requestBody);
        }
    }
}
