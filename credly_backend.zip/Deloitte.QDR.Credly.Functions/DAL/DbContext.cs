﻿using Deloitte.QDR.Entities;
using Deloitte.QDR.Entities.StoredProcedures;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.ChangeTracking;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace Deloitte.QDR.Credly.Functions.DAL
{
    public class DefaultDBContext : DbContext
    {
        public DefaultDBContext()
        { }

        public DefaultDBContext(DbContextOptions<DefaultDBContext> options)
            : base(options) { }

        public DefaultDBContext(DbContextOptions options)
            : base(options) { }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            base.OnConfiguring(optionsBuilder);
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            foreach (var entityType in modelBuilder.Model.GetEntityTypes())
            {
                modelBuilder.Entity(entityType.ClrType).ToTable(entityType.ClrType.Name);
            }

            modelBuilder
               .Entity<BadgeTemplate>()
               .HasOne(e => e.Approver)
               .WithMany()
               .HasForeignKey(e => e.ApproverId);

            modelBuilder
                .Entity<BadgeTemplate>()
                .HasOne(e => e.Owner)
                .WithMany()
                .HasForeignKey(e => e.OwnerId);

            modelBuilder
                .Entity<BadgeTemplate>()
                .HasOne(e => e.Sponsor)
                .WithMany()
                .HasForeignKey(e => e.SponsorId);

            modelBuilder
                .Entity<BadgeTemplate>()
                .HasOne(e => e.OptionalApprover)
                .WithMany()
                .HasForeignKey(e => e.OptionalApproverId);

            modelBuilder
                .Entity<Badge>()
                .HasOne(e => e.BadgeTemplate)
                .WithMany()
                .HasForeignKey(e => e.BadgeTemplateId);

            modelBuilder
                .Entity<Badge>()
                .HasOne(e => e.Employee)
                .WithMany()
                .HasForeignKey(e => e.PersonID);

            modelBuilder
                .Entity<Notification>()
                .HasOne(e => e.Employee)
                .WithMany()
                .HasForeignKey(x => x.EmployeeId);

            modelBuilder.Entity<EmployeeRole>().HasKey(k => new { k.EmployeeId, k.RoleId });

            modelBuilder
                .Entity<EmployeeRole>()
                .HasOne(e => e.Employee)
                .WithMany(e => e.EmployeeRoles)
                .HasForeignKey(e => e.EmployeeId);

            modelBuilder
                .Entity<EmployeeRole>()
                .HasOne(e => e.Role)
                .WithMany(e => e.EmployeeRoles)
                .HasForeignKey(e => e.RoleId);

            modelBuilder
                .Entity<BadgeTemplateSkill>()
                .HasKey(k => new { k.BadgeTemplateId, k.SkillId });

            modelBuilder
                .Entity<BadgeTemplateSkill>()
                .HasOne(e => e.BadgeTemplate)
                .WithMany()
                .HasForeignKey(e => e.BadgeTemplateId);

            modelBuilder
                .Entity<BadgeTemplateSkill>()
                .HasOne(e => e.Skill)
                .WithMany()
                .HasForeignKey(e => e.SkillId);

            modelBuilder
                .Entity<BadgeTemplateCriteria>()
                .HasOne(e => e.Approver)
                .WithMany()
                .HasForeignKey("Approver_Id");

            modelBuilder
                .Entity<BadgeTemplateCriteria>()
                .HasOne(e => e.BadgeTemplate)
                .WithMany(e => e.Criterias)
                .HasForeignKey("BadgeTemplate_Id");

            modelBuilder
                .Entity<BadgeTemplateSkill>()
                .HasOne(x => x.BadgeTemplate)
                .WithMany(x => x.Skills)
                .HasForeignKey(x => x.BadgeTemplateId);

            modelBuilder
                .Entity<UserActivity>()
                .HasOne(e => e.Employee)
                .WithMany()
                .HasForeignKey(x => x.EmployeeId);

            modelBuilder
                .Entity<Education>()
                .HasOne(e => e.Badge)
                .WithMany(e => e.Education)
                .HasForeignKey(x => x.BadgeId);

            modelBuilder
                .Entity<Education>()
                .HasOne(e => e.Criteria)
                .WithMany()
                .HasForeignKey(x => x.BadgeTemplateCriteriaId);

            modelBuilder
                .Entity<Experience>()
                .HasOne(e => e.Badge)
                .WithMany(e => e.Experience)
                .HasForeignKey(x => x.BadgeId);

            modelBuilder
                .Entity<Experience>()
                .HasOne(e => e.Criteria)
                .WithMany()
                .HasForeignKey(x => x.BadgeTemplateCriteriaId);

            modelBuilder
                .Entity<Exposure>()
                .HasOne(e => e.Badge)
                .WithMany(e => e.Exposure)
                .HasForeignKey(x => x.BadgeId);

            modelBuilder
                .Entity<Exposure>()
                .HasOne(e => e.Criteria)
                .WithMany()
                .HasForeignKey(x => x.BadgeTemplateCriteriaId);

            modelBuilder
                .Entity<BadgeTemplateCriteria>()
                .HasOne(e => e.Approver)
                .WithMany()
                .HasForeignKey("Approver_Id");

            modelBuilder
                .Entity<AwardingProcess>()
                .HasOne(e => e.BadgeTemplate)
                .WithMany()
                .HasForeignKey(e => e.BadgeTemplate_Id);

            modelBuilder
                .Entity<AwardingProcess>()
                .HasOne(e => e.Approver)
                .WithMany()
                .HasForeignKey(e => e.Approver_Id);

            modelBuilder.Entity<BadgeTemplateCollection>().HasKey(k => new { k.CollectionId, k.BadgeTemplateId });

            modelBuilder
               .Entity<BadgeTemplateCollection>()
               .HasOne(e => e.BadgeTemplate)
               .WithMany(e => e.Collections)
               .HasForeignKey(e => e.BadgeTemplateId);

            modelBuilder
               .Entity<BadgeTemplateCollection>()
               .HasOne(e => e.Collection)
               .WithMany(e => e.BadgeTemplatesCollections)
               .HasForeignKey(e => e.CollectionId);

            modelBuilder
                .Entity<FaqCategory>()
                .HasMany(e => e.Faq)
                .WithOne(e => e.Category)
                .HasForeignKey(e => e.CategoryId);

            modelBuilder
                .Entity<Collection>()
                .HasOne(e => e.Owner)
                .WithMany(e => e.Collections)
                .HasForeignKey(e => e.OwnerId);

            modelBuilder.Entity<Badge>().Property<BadgeStatus?>("Status");
            modelBuilder.Entity<Badge>().HasQueryFilter(t => EF.Property<BadgeStatus?>(t, "Status") != BadgeStatus.Deleted);

            modelBuilder.Entity<BadgeTemplate>().Property<BadgeTemplateStatus?>("Status");
            modelBuilder.Entity<BadgeTemplate>().HasQueryFilter(t => EF.Property<BadgeTemplateStatus?>(t, "Status") != BadgeTemplateStatus.Deleted);
            modelBuilder.Entity<_Config_Notification>().HasKey(k => new { k.NotificationId, k.EntityType });
            modelBuilder.Entity<spBadgeDiscardingProcess>(t => t.HasNoKey());
        }

        #region DbSets

        public virtual DbSet<Employee> Employees { get; set; }
        public virtual DbSet<CredlyEmployee> CredlyEmployees { get; set; }
        public virtual DbSet<Badge> Badges { get; set; }
        public virtual DbSet<BadgeTemplate> BadgeTemplates { get; set; }
        public virtual DbSet<AuditLog> AuditLogs { get; set; }
        public virtual DbSet<Skill> Skills { get; set; }
        public virtual DbSet<Notification> Notifications { get; set; }
        public virtual DbSet<Role> Role { get; set; }
        public virtual DbSet<EmployeeRole> EmployeeRole { get; set; }
        public virtual DbSet<_Config_Notification> ConfigNotifications { get; set; }
        public virtual DbSet<spBadgeDiscardingProcess> spBadgeDiscardingProcessResult { get; set; }
        public virtual DbSet<ProcessLog> ProcessLogs { get; set; }
        public virtual DbSet<UserActivity> UserActivities { get; set; }
        public virtual DbSet<CredlyBadge> CredlyBadges { get; set; }

        #endregion DbSets

        public override int SaveChanges()
        {
            SoftDelete();
            return base.SaveChanges();
        }

        public override Task<int> SaveChangesAsync(CancellationToken cancellation = default)
        {
            SoftDelete();
            return base.SaveChangesAsync(cancellation);
        }

        private void SoftDelete()
        {
            var recordAsDeleted = ChangeTracker.Entries()
                .Where(e => e.Entity.GetType().GetInterfaces()
                .Any(i => i.IsGenericType && i.GetGenericTypeDefinition() == typeof(ISoftDeletable<>)) && e.State == EntityState.Deleted);

            foreach (var entry in recordAsDeleted)
            {
                var entity = (dynamic)entry.Entity;
                entity.Delete();
                entry.State = EntityState.Modified;
            }
        }
    }
}