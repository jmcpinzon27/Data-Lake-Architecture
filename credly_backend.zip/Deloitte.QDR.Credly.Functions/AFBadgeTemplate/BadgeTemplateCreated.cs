﻿using Azure.Messaging.ServiceBus;
using Deloitte.QDR.Credly.Functions.Contracts;
using Deloitte.QDR.Credly.Functions.DAL;
using Deloitte.QDR.Credly.Functions.Infrastructure.ServiceBus;
using Deloitte.QDR.DTO.Azure;
using Deloitte.QDR.DTO.CredlyAPI;

//using Deloitte.QDR.Infrastructure.ServiceBus;
using Microsoft.Azure.WebJobs;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using System;
using System.IO;
using System.Threading;
using System.Threading.Tasks;
using Deloitte.QDR.DTO.CredlyAPI.Common;

namespace Deloitte.QDR.Credly.Functions.AFBadgeTemplate
{
    public class BadgeTemplateCreated
    {
        private readonly DefaultDBContext _dbContext;
        private readonly ICredlyAPIService _credlyAPIService;
        private readonly ILogger<BadgeTemplateCreated> _logger = null;
        private readonly IQueueService _queueService = null;
        private const string _logInfoName = "BADGE TEMPLATE CREATE";

        public BadgeTemplateCreated(DefaultDBContext dbContext, ICredlyAPIService credlyAPIService, ILogger<BadgeTemplateCreated> logger, IQueueService queueService)
        {
            _dbContext = dbContext ?? throw new ArgumentNullException(nameof(dbContext));
            _credlyAPIService = credlyAPIService ?? throw new ArgumentNullException(nameof(credlyAPIService));
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
            _queueService = queueService ?? throw new ArgumentNullException(nameof(queueService));
        }

        [FunctionName("BadgeTemplateCreated")]
        public async Task Run(
                [ServiceBusTrigger("badge_template_created","btc_subscription",Connection = "ServiceBusConnection")]
                ServiceBusReceivedMessage serviceBusReceivedMessage, IBinder binder, CancellationToken cancellationToken = default
        )
        {
            try
            {
                string requestTopicMessage = await new StreamReader(serviceBusReceivedMessage.Body.ToStream()).ReadToEndAsync();
                var topicMessage = JsonConvert.DeserializeObject<Message>(requestTopicMessage);

                _logger.LogInformation($"{_logInfoName} function start to execute at: {DateTime.Now.ToString("HH:mm:ss")}");

                var data = await _credlyAPIService.GetEvent<BadgeTemplateCreatedEvent>(topicMessage.Id, OrganizationFor.BadgeTemplate);
                var badge_template_created = data.BadgeTemplate;
                var bt_owner_collection = badge_template_created.Owner;
                var credlyExternalId = badge_template_created.Id.ToString();
                var existQDRBadgeTemplate = await _dbContext.BadgeTemplates.FirstOrDefaultAsync(t => t.ExternalId == credlyExternalId, cancellationToken);

                if (existQDRBadgeTemplate is null)
                {
                    var entity = new Entities.BadgeTemplate
                    {
                        Issuer = bt_owner_collection.Name,
                        ExternalId = badge_template_created.Id.ToString(),
                        Name = badge_template_created.Name,
                        Description = badge_template_created.Description,
                        CreatedAt = badge_template_created.CreatedAt
                    };

                    _dbContext.BadgeTemplates.Add(entity);
                }
                else
                {
                    existQDRBadgeTemplate.Issuer = existQDRBadgeTemplate.Issuer.Equals(bt_owner_collection.Name) ? existQDRBadgeTemplate.Issuer : existQDRBadgeTemplate.Issuer;
                    existQDRBadgeTemplate.Name = existQDRBadgeTemplate.Name.Equals(badge_template_created.Name) ? existQDRBadgeTemplate.Name : badge_template_created.Name;
                    existQDRBadgeTemplate.Description = existQDRBadgeTemplate.Description.Equals(badge_template_created.Description) ? existQDRBadgeTemplate.Description : badge_template_created.Description;
                    existQDRBadgeTemplate.CreatedAt = existQDRBadgeTemplate.CreatedAt.Equals(badge_template_created.CreatedAt) ? existQDRBadgeTemplate.CreatedAt : badge_template_created.CreatedAt;

                    _dbContext.BadgeTemplates.Update(existQDRBadgeTemplate);
                }

                await _dbContext.SaveChangesAsync(cancellationToken);

                await SendMessageToQueueAsync(existQDRBadgeTemplate.Id, existQDRBadgeTemplate.ImageUrl, badge_template_created.Image.RemoteUploadUrl);
                _logger.LogInformation($"{_logInfoName} function finished to execute at: {DateTime.Now.ToString("HH:mm:ss")}");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"{_logInfoName}, it was not possible to complete the process due an internal error.");
            }
        }

        private async Task SendMessageToQueueAsync(Guid badgeTemplateId, string imageUrlQDR, string imageUrlCredly)
        {
            var newMessage = new ImageProcessingDto
            {
                TargetTable = "imageprocessing_badgetemplate",
                Id = badgeTemplateId,
                ImageUrlQDR = imageUrlQDR,
                ImageUrlCredly = imageUrlCredly
            };

            var jsonPayload = System.Text.Json.JsonSerializer.Serialize<ImageProcessingDto>(newMessage);
            await _queueService.SendAsync(jsonPayload);
        }
    }
}