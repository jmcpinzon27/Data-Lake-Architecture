﻿using Azure.Messaging.ServiceBus;
using Deloitte.QDR.Credly.Functions.Contracts;
using Deloitte.QDR.Credly.Functions.DAL;
using Deloitte.QDR.DTO.CredlyAPI;
using Deloitte.QDR.Entities;
using Microsoft.Azure.WebJobs;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using System;
using System.IO;
using System.Threading;
using System.Threading.Tasks;
using Deloitte.QDR.DTO.CredlyAPI.Common;

namespace Deloitte.QDR.Credly.Functions.AFBadgeTemplate
{
    public class BadgeTemplateDeleted
    {
        private readonly DefaultDBContext _dbContext;
        private readonly ICredlyAPIService _credlyAPIService;
        private readonly ILogger<BadgeTemplateDeleted> _logger;

        public BadgeTemplateDeleted(DefaultDBContext dbContext, ICredlyAPIService credlyAPIService, ILogger<BadgeTemplateDeleted> logger)
        {
            _dbContext = dbContext ?? throw new ArgumentNullException(nameof(dbContext));
            _credlyAPIService = credlyAPIService ?? throw new ArgumentNullException(nameof(credlyAPIService));
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
        }

        [FunctionName("BadgeTemplateDeleted")]
        public async Task Run(
            [ServiceBusTrigger("badge_template_deleted", "btd_subscription", Connection = "ServiceBusConnection")]
                ServiceBusReceivedMessage serviceBusReceivedMessage,
                IBinder binder, CancellationToken cancellationToken = default
        )
        {
            string requestTopicMessage = await new StreamReader(serviceBusReceivedMessage.Body.ToStream()).ReadToEndAsync();
            var topicMessage = JsonConvert.DeserializeObject<Message>(requestTopicMessage);
            var event_type = topicMessage.EventType;

            if (event_type == "badge_template.deleted")
            {
                var data = await _credlyAPIService.GetEvent<BadgeTemplateDeletedEvent>(topicMessage.Id, OrganizationFor.BadgeTemplate);
                var badge_template_created = data.BadgeTemplate;

                var badgetemplatedeleted = await _dbContext.BadgeTemplates
                    .SingleOrDefaultAsync(e => e.ExternalId == badge_template_created.Id.ToString() && e.Status != BadgeTemplateStatus.Deleted, cancellationToken);

                if (badgetemplatedeleted != null)
                {
                    badgetemplatedeleted.ExternalId = badge_template_created.Id.ToString();

                    _dbContext.Remove(badgetemplatedeleted);
                    await _dbContext.SaveChangesAsync(cancellationToken);
                }
            }
        }
    }
}