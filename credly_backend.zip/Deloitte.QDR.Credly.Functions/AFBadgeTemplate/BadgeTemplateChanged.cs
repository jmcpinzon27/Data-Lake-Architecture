﻿using Azure.Messaging.ServiceBus;
using Deloitte.QDR.Credly.Functions.Contracts;
using Deloitte.QDR.Credly.Functions.DAL;
using Deloitte.QDR.DTO.CredlyAPI;
using Microsoft.Azure.WebJobs;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using System;
using System.IO;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using Deloitte.QDR.DTO.CredlyAPI.Common;

namespace Deloitte.QDR.Credly.Functions.AFBadgeTemplate
{
    internal class BadgeTemplateChanged
    {
        private readonly DefaultDBContext _dbContext;
        private readonly ICredlyAPIService _credlyAPIService;
        private readonly ILogger<BadgeTemplateChanged> _logger = null;

        public BadgeTemplateChanged(DefaultDBContext dbContext, ICredlyAPIService credlyAPIService, ILogger<BadgeTemplateChanged> logger)
        {
            _dbContext = dbContext ?? throw new ArgumentNullException(nameof(dbContext));
            _credlyAPIService = credlyAPIService ?? throw new ArgumentNullException(nameof(credlyAPIService));
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
        }
        [FunctionName("BadgeTemplateChanged")]
        public async Task Run(
            [ServiceBusTrigger("badge_template_changed", "btch_subscription", Connection = "ServiceBusConnection")]
                ServiceBusReceivedMessage serviceBusReceivedMessage,
                IBinder binder, CancellationToken cancellationToken = default
        )
        {
            string requestTopicMessage = await new StreamReader(serviceBusReceivedMessage.Body.ToStream()).ReadToEndAsync();
            var topicMessage = JsonConvert.DeserializeObject<Message>(requestTopicMessage);
            var event_type = topicMessage.EventType;

            if (event_type == "badge_template.changed")
            {
                var data = await _credlyAPIService.GetEvent<BadgeTemplateChangedEvent>(topicMessage.Id, OrganizationFor.BadgeTemplate);
                var badge_template_created = data.BadgeTemplate;
                var owner = badge_template_created.Owner;

                var badgetemplateupdated = await _dbContext.BadgeTemplates.SingleOrDefaultAsync(e => e.ExternalId == badge_template_created.Id.ToString(), cancellationToken);

                if (badgetemplateupdated != null)
                {
                    badgetemplateupdated.Issuer = owner.Name;
                    badgetemplateupdated.ExternalId = badge_template_created.Id.ToString();
                    badgetemplateupdated.Name = badge_template_created.Name;
                    badgetemplateupdated.Description = badge_template_created.Description;
                    badgetemplateupdated.CreatedAt = badge_template_created.CreatedAt;
                    await _dbContext.SaveChangesAsync(cancellationToken);
                }
            }
        }
    }
}
