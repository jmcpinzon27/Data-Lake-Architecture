﻿using Azure.Messaging.ServiceBus;
using Deloitte.QDR.Credly.Functions.Contracts;
using Deloitte.QDR.Credly.Functions.DAL;
using Deloitte.QDR.DTO.CredlyAPI;
using Microsoft.Azure.WebJobs;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using System;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;
using Azure.Storage.Blobs;

namespace Deloitte.QDR.Credly.Functions.AFBadgeTemplate
{
    public class ImageProcessing
    {
        private readonly DefaultDBContext _dbContext;
        private readonly ICredlyAPIService _credlyAPIService;
        private readonly ILogger<ImageProcessing> _logger = null;


        public ImageProcessing(DefaultDBContext dbContext, ICredlyAPIService credlyAPIService, ILogger<ImageProcessing> logger)
        {
            _dbContext = dbContext ?? throw new ArgumentNullException(nameof(dbContext));
            _credlyAPIService = credlyAPIService ?? throw new ArgumentNullException(nameof(credlyAPIService));
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
        }

        private static readonly HttpClient _httpClient = new HttpClient();
        private static readonly string _storageConnectionString = "hrTzjj3VO5xQda8hypq4hnVGHZvdjRvGNuYDJwrOwJMV8j5HS7ttzOGCM9i/NLF7DvvwZ6lS1wxj+AStOS+0Kg==";
        private static readonly string _containerName = "qdr-docs/badgeTemplates";

        [FunctionName("ProcessBadgeImage")]
        public async Task Run(
            [ServiceBusTrigger("badge-events", Connection = "ServiceBusConnection")] string message)
        {
            var badgeRecords = await _dbContext.Badges.ToListAsync();

            BlobServiceClient blobServiceClient = new BlobServiceClient(_storageConnectionString);
            BlobContainerClient containerClient = blobServiceClient.GetBlobContainerClient(_containerName);

            foreach (var record in badgeRecords)
            {
                string imagePath = $"badgeTemplates/{record.Id}/Image.png";
                BlobClient blobClient = containerClient.GetBlobClient(imagePath);

                // Download the image using HttpClient
                //HttpResponseMessage response = await _httpClient.GetAsync(record.ImageUrl);
                //response.EnsureSuccessStatusCode();
                //using (var imageStream = await response.Content.ReadAsStreamAsync())
                /***
                {
                    // Upload the image to Azure Blob Storage
                    await blobClient.UploadAsync(imageStream, true);
                }
                **/

                //log.LogInformation($"Image saved to: {imagePath}");
            }
        }
    }
}
