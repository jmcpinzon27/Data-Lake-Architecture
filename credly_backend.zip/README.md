# Introduction 
QDR API 

# Getting Started
TODO: install the following dependencies from command line:
- dotnet tool install -g csharpier
- dotnet tool install husky
- dotnet husky install
