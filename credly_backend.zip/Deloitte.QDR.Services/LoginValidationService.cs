﻿using Deloitte.QDR.Contracts;
using Deloitte.QDR.Contracts.Services;
using Deloitte.QDR.DTO.Common;
using Deloitte.QDR.Entities;
using Deloitte.QDR.Infrastructure;

namespace Deloitte.QDR.Services
{
    public class LoginValidationService : ILoginValidationService
    {
        private readonly IDataCache _dataCache;
        private readonly IDBContext _dbContext;
        private readonly INotificationService _notificationService;

        public LoginValidationService(IDataCache dataCache, IDBContext dBContext, INotificationService notificationService)
        {
            _dataCache = dataCache;
            _dbContext = dBContext;
            _notificationService = notificationService;
        }

        public async Task FirstLoginValidateAsync(string personId)
        {
            UserActivity? result = _dataCache.Get<UserActivity>(personId);

            if (result == null)
            {
                result = _dbContext.UserActivity
                    .Where(x => x.EmployeeId == personId && x.Type == ActivityType.FirstLogin)
                    .FirstOrDefault();

                if (result == null)
                {
                    var employee = _dbContext.Employees.Single(t => t.PersonID == personId);

                    if (employee != null)
                    {
                        await BuildAndSendNotification(employee, ActivityType.FirstLogin);

                        result = AddUserActivity(employee);

                        _dataCache.InsertOrUpdate(personId, result);

                        await _dbContext.SaveChangesAsync();
                    }
                }
                else
                {
                    _dataCache.InsertOrUpdate(personId, result);
                }
            }
        }

        private UserActivity AddUserActivity(Employee employee)
        {
            var userActivity = new UserActivity
            {
                Type = ActivityType.FirstLogin,
                Date = DateTime.UtcNow,
                Employee = employee,
                Title = GeneralConstants.UserActivity.USER_FIRST_TIME_LOGIN_TITLE,
                Description = GeneralConstants.UserActivity.USER_FIRST_TIME_LOGIN_DESC
            };

            _dbContext.UserActivity.Add(userActivity);
            return userActivity;
        }

        private async Task BuildAndSendNotification(Employee employee, ActivityType activityType)
        {
            DTO.Common.NotificacionHub notificationHub = await _notificationService
                .SendNotificationToHubAsync(new List<string> { employee.Email ?? string.Empty }, activityType.ToString(), EntityType.Employee.ToString());

            var notificationEntity = new Entities.Notification
            {
                Id = Guid.NewGuid(),
                Date = DateTime.UtcNow,
                Title = notificationHub.Title,
                Description = notificationHub.Description,
                EntityType = notificationHub.EntityType.ResolveEnum<EntityType>(),
                EntityId = null,
                ReadDate = null,
                Read = false,
                Employee = employee,
                Detail = null
            };

            _dbContext.Notifications.Add(notificationEntity);
        }
    }
}