﻿using Deloitte.QDR.Contracts.Services;
using Deloitte.QDR.DTO.SABA;
using Deloitte.QDR.Infrastructure.Config;

namespace Deloitte.QDR.Services;

public class SABAService : ISABAService
{
    private readonly HttpClient _httpClient;
    private readonly string _organization;

    public SABAService(HttpClient httpClient)
    {
        _httpClient = httpClient ?? throw new ArgumentNullException(nameof(httpClient));
        _organization = AppSettings.Settings.CredlyOrganization;
    }

    private List<string> _courses = new List<string>
        {
            "Azure Cloud Architect",
            "Cyber SecurityAssessment",
            "Udemy Cyber Course 101",
            "LinkedIn Learning Cloud Course",
            "Machine Learning Intermediate Course",
            "Cyber Security 301",
            "Udemy Science course",
            "Artificial intelligence: Implications for business strategy",
            "Introduction to Generative AI"
        };
    public async Task<Course> GetCourseById(string courseId)
    {
        var index = new Random().Next(0, _courses.Count - 1);
        return new Course { Id = courseId, Validated = true, Name = _courses[index] };
    }

    public bool ValidateCourse(string employeeInfoPersonId, string? criteriaSabaCourseId)
    {
        if (criteriaSabaCourseId.Contains("D"))
        {
            return true;
        }

        return false;
    }

}

