﻿using Deloitte.QDR.Contracts.Services;
using Deloitte.QDR.DTO.Common;
using Deloitte.QDR.Entities;

namespace Deloitte.QDR.Services

{
    public class BadgeTemplateStatusFlowService : IStatusFlowValidator<BadgeTemplateStatus>
    {
        public BadgeTemplateStatus SetAndValidateStatus(BadgeTemplateStatus? currentStatus, BadgeTemplateStatus statusToPass)
        {
            if (!currentStatus.HasValue)
            {
                throw new ValidationException(new Result { HasErrors = true, Messages = new List<string> { GeneralConstants.ErrorMessages.BADGE_TEMPLATE_STATUS_CURRENT_EMPTY } });
            }

            switch (statusToPass)
            {
                case BadgeTemplateStatus.Draft:
                    var statusForDraft = new List<BadgeTemplateStatus>
                    {
                        BadgeTemplateStatus.Draft,
                        BadgeTemplateStatus.NotCreated,
                        BadgeTemplateStatus.AttentionRequired
                    };
                    if (statusForDraft.Contains(currentStatus.Value))
                    {
                        return statusToPass;
                    }
                    break;

                case BadgeTemplateStatus.Submitted:
                    if (currentStatus == BadgeTemplateStatus.Draft
                        || currentStatus == BadgeTemplateStatus.AttentionRequired
                        || currentStatus == BadgeTemplateStatus.HideForEdit)
                    {
                        return statusToPass;
                    }
                    break;

                case BadgeTemplateStatus.Rejected:
                case BadgeTemplateStatus.AttentionRequired:
                    if (currentStatus == BadgeTemplateStatus.Submitted)
                    {
                        return statusToPass;
                    }
                    break;
                case BadgeTemplateStatus.Accepted:
                    if (currentStatus == BadgeTemplateStatus.Submitted 
                        || currentStatus == BadgeTemplateStatus.HideForEdit
                        || currentStatus == BadgeTemplateStatus.HideForArchive
                        || currentStatus == BadgeTemplateStatus.Draft)
                    {
                        return statusToPass;
                    }
                    break;
                case BadgeTemplateStatus.HideForEdit:
                    if (currentStatus == BadgeTemplateStatus.Accepted || currentStatus == BadgeTemplateStatus.HideForEdit)
                    {
                        return statusToPass;
                    }
                    break;
                case BadgeTemplateStatus.Archived:
                    if (currentStatus == BadgeTemplateStatus.HideForEdit
                        || currentStatus == BadgeTemplateStatus.HideForArchive )
                    {
                        return statusToPass;
                    }
                    break;
                case BadgeTemplateStatus.Deleted:
                    var statusForDeleted = new List<BadgeTemplateStatus>
                    {
                        BadgeTemplateStatus.Draft,
                        BadgeTemplateStatus.Submitted,
                        BadgeTemplateStatus.Rejected,
                        BadgeTemplateStatus.AttentionRequired
                    };
                    if (statusForDeleted.Contains(currentStatus.Value))
                    {
                        return statusToPass;
                    }
                    break;

                case BadgeTemplateStatus.HideForArchive:
                    if (currentStatus == BadgeTemplateStatus.Accepted || currentStatus == BadgeTemplateStatus.HideForArchive)
                    {
                        return statusToPass;
                    }
                    break;

                default:
                    throw ThrowValidationException(currentStatus, statusToPass);
            }
            throw ThrowValidationException(currentStatus, statusToPass);
        }

        public ValidationException ThrowValidationException(BadgeTemplateStatus? currentStatus, BadgeTemplateStatus statusToPass)
        {
            string stringCurrent = currentStatus.Value.ToString();
            string stringToPass = statusToPass.ToString();
            return new ValidationException(new Result { HasErrors = true, Messages = new List<string> { string.Format(GeneralConstants.ErrorMessages.BADGE_TEMPLATE_WRONG_STATUS_FLOW, stringCurrent, stringToPass) } });
        }
    }
}