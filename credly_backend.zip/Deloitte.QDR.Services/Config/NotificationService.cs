﻿using Deloitte.QDR.Contracts;
using Deloitte.QDR.Contracts.Services;
using Deloitte.QDR.DTO.Common;
using Deloitte.QDR.Entities;

namespace Deloitte.QDR.Services.Config
{
    public class NotificationService : INotificationService
    {
        private readonly IDBContext _dBContext;
        private readonly IHubService _hubService;
        private readonly IEmailService _emailService;

        public NotificationService(IDBContext dBContext, IHubService hubService, IEmailService emailService)
        {
            _dBContext = dBContext ?? throw new ArgumentNullException(nameof(dBContext));
            _hubService = hubService ?? throw new ArgumentNullException(nameof(hubService));
            _emailService = emailService ?? throw new ArgumentNullException(nameof(emailService));
        }

        public async Task<NotificacionHub> SendNotificationToHubAsync(List<string> emailEmployee, string notificationId, string entityType, string[] contentParams, bool isAdmin = false)
        {
            var configNotification = Get(notificationId, entityType);

            //Definig new instance to avoid persisiting in DB
            var modifiedNotification = new _Config_Notification
            {
                EmailSubject = configNotification.EmailSubject,
                EmailImage = configNotification.EmailImage,
                EmailLink = configNotification.EmailLink,
                EmailTitle = configNotification.EmailTitle,
                EmailDescription = configNotification.EmailDescription,
                EntityType = configNotification.EntityType,
                NotificationId = configNotification.NotificationId,
                Title = configNotification.Title,
                Description = configNotification.Description
            };

            if (contentParams != null)
            {
                var title = string.Format(configNotification.Title, contentParams.Select(t => t.ToString()).ToArray());
                modifiedNotification.Title = title;

                var description = string.Format(configNotification.Description, contentParams.Select(t => t.ToString()).ToArray());
                modifiedNotification.Description = description;

                var emailTitle = string.Format(configNotification.EmailTitle ?? string.Empty, contentParams.Select(t => t.ToString()).ToArray());
                modifiedNotification.EmailTitle = emailTitle;

                var emailDescription = string.Format(configNotification.EmailDescription ?? string.Empty, contentParams.Select(t => t.ToString()).ToArray());
                modifiedNotification.EmailDescription = emailDescription;
            }

            if (configNotification.SendEmail.HasValue && configNotification.SendEmail.Value && emailEmployee.Any())
            {
                await _emailService.SendEmailAsync(emailEmployee, modifiedNotification, isAdmin);
            }

            NotificacionHub notificacionHub = new NotificacionHub
            {
                ActivityType = configNotification.ActivityType,
                Description = modifiedNotification.Description,
                EntityType = configNotification.EntityType,
                Title = modifiedNotification.Title,
                Type = configNotification.NotificationType
            };

            await _hubService.ReceiveNotification(notificacionHub, emailEmployee);

            return notificacionHub;
        }

        private _Config_Notification Get(string id, string entityType)
        {
            var notificationEntity = _dBContext.ConfigNotifications.FirstOrDefault(t => t.NotificationId == id
                                        && t.EntityType == entityType);

            if (notificationEntity == null)
            {
                throw new ValidationException(
                    new Result { HasErrors = true, Messages = new List<string> { GeneralConstants.ErrorMessages.NOTIFICATIONS_CONFIG } });
            }

            return notificationEntity;
        }

        public bool IsAllowedNotification(string notificationId, string entityType)
        {
            var notificationEntity = _dBContext.ConfigNotifications.FirstOrDefault(t => t.NotificationId == notificationId
                                        && t.EntityType == entityType);

            return notificationEntity == null ? false : true;
        }
    }
}
