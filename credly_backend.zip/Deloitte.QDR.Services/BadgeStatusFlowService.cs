﻿using Deloitte.QDR.Contracts.Services;
using Deloitte.QDR.DTO.Common;
using Deloitte.QDR.Entities;

namespace Deloitte.QDR.Services
{
    public class BadgeStatusFlowService : IStatusFlowValidator<BadgeStatus>
    {
        public BadgeStatus SetAndValidateStatus(BadgeStatus? currentStatus, BadgeStatus statusToPass)
        {
            if (currentStatus == null)
            {
                throw new ValidationException(new Result { HasErrors = true, Messages = new List<string> { GeneralConstants.ErrorMessages.BADGE_STATUS_CURRENT_EMPTY } });
            }

            switch (currentStatus)
            {
                case BadgeStatus.Initiated:
                    if (statusToPass == BadgeStatus.InProgress || statusToPass == BadgeStatus.SubmittedForApproval || statusToPass == BadgeStatus.Withdrawn)
                        return statusToPass;
                    break;
                case BadgeStatus.InProgress:
                    if (statusToPass == BadgeStatus.SubmittedForApproval || statusToPass == BadgeStatus.InProgress || statusToPass == BadgeStatus.Withdrawn)
                        return statusToPass;
                    break;
                case BadgeStatus.SubmittedForApproval:
                    if (statusToPass == BadgeStatus.Rejected || statusToPass == BadgeStatus.AttentionRequired || statusToPass == BadgeStatus.Approved)
                        return statusToPass;
                    break;
                case BadgeStatus.AttentionRequired:
                    if (statusToPass == BadgeStatus.InProgress || statusToPass == BadgeStatus.SubmittedForApproval)
                        return statusToPass;
                    break;
                case BadgeStatus.Approved:
                    if (statusToPass == BadgeStatus.Awarded || statusToPass == BadgeStatus.ToBeArchived)
                        return statusToPass;
                    break;
                case BadgeStatus.Awarded:
                    if (statusToPass == BadgeStatus.Archived || statusToPass == BadgeStatus.Expired)
                        return statusToPass;
                    break;
                default:
                    throw ThrowValidationException(currentStatus, statusToPass); 
            }
            throw ThrowValidationException(currentStatus, statusToPass);
        }

        public ValidationException ThrowValidationException(BadgeStatus? currentStatus, BadgeStatus statusToPass)
        {
            string stringCurrent = currentStatus.Value.ToString();
            string stringToPass = statusToPass.ToString();
            return new ValidationException(new Result { HasErrors = true, Messages = new List<string> { string.Format(GeneralConstants.ErrorMessages.BADGE_STATUS_WRONG_STATUS_FLOW, stringCurrent, stringToPass) } });
        }               
        
    }
}
