﻿using Deloitte.QDR.Contracts.Services;
using Deloitte.QDR.DTO.Common;
using Deloitte.QDR.Hubs;
using Microsoft.AspNetCore.SignalR;

namespace Deloitte.QDR.Services
{
    public class HubService : IHubService
    {
        private readonly IHubContext<NotificationHub> _notificationHub;

        public HubService(IHubContext<NotificationHub> notificationHub)
        {
            _notificationHub = notificationHub;
        }

        public async Task ReceiveNotification(NotificacionHub notification, string email)
        {
            if (string.IsNullOrWhiteSpace(email))
            {
                throw new ValidationException(
                    new Result { HasErrors = true, Messages = new List<string> { GeneralConstants.ErrorMessages.NOTIFICATIONS_NOT_EMAIL } });
            }
            await _notificationHub.Clients
                .Group(email)
                .SendAsync("ReceiveNotification", notification);
        }

        public async Task ReceiveNotification(NotificacionHub notification, List<string> emails)
        {
            if (emails == null || !emails.Any())
            {
                throw new ValidationException(
                    new Result { HasErrors = true, Messages = new List<string> { GeneralConstants.ErrorMessages.NOTIFICATIONS_NOT_EMAIL } });
            }
            await _notificationHub.Clients
                .Groups(emails)
                .SendAsync("ReceiveNotification", notification);
        }
    }
}
