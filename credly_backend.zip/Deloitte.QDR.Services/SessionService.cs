﻿using Deloitte.QDR.Contracts.Services;
using Deloitte.QDR.DTO;
using Deloitte.QDR.DTO.Common;
using Microsoft.AspNetCore.Http;
using System.Net;
using System.Text;

namespace Deloitte.QDR.Services
{
    public class SessionService : ISessionService
    {
        private readonly IHttpContextAccessor _contextAccessor;
        private readonly ICacheService _cacheService;

        public SessionService(
            IHttpContextAccessor contextAccessor,
            ICacheService cacheService
        )
        {
            _contextAccessor = contextAccessor ?? throw new ArgumentNullException(nameof(contextAccessor));
            _cacheService = cacheService ?? throw new ArgumentNullException(nameof(cacheService));
        }

        public UserSession GetSession(string email = null)
        {
            if (string.IsNullOrWhiteSpace(email))
            {
                email = _contextAccessor.HttpContext.User.Identity.Name;
            }

            //Ensure the client has sent data for email parameter.
            if(string.IsNullOrEmpty(email))
            {
                throw new ValidationException
                (
                new Result { HasErrors = true, Messages = new List<string>() {GeneralConstants.ErrorMessages.EMPLOYEE_NOT_USER_EMAIL } }
                );
            }

            return _cacheService.GetUserSession(email).GetAwaiter().GetResult();
        }

        public async Task<UserSession> GetSessionAsync(string email = null)
        {
            if (string.IsNullOrWhiteSpace(email))
            {
                email = _contextAccessor.HttpContext.User.Identity.Name;
            }

            return await _cacheService.GetUserSession(email);
        }

        public async Task<ErrorLog> GetContextErrorLog()
        {
            var request = _contextAccessor.HttpContext.Request;

            var url = string.Empty;
            var method = string.Empty;
            string? body = null;
            if (request != null)
            {
                url = WebUtility.UrlDecode($"{request.Path}{request.QueryString.Value}");
                method = request.Method;
                body = await GetRawBodyAsync(request);
            }

            return new ErrorLog
            {
                StatusCode = (int)HttpStatusCode.InternalServerError,
                Method = method,
                URL = url,
                Body = body
            };
        }

        private async Task<string?> GetRawBodyAsync(HttpRequest request)
        {
            if (request.ContentLength == null || request.ContentLength <= 0)
            {
                return null;
            }

            if (!request.Body.CanSeek)
            {
                request.EnableBuffering();
            }

            request.Body.Position = 0;
            var reader = new StreamReader(request.Body, Encoding.UTF8);
            var body = await reader.ReadToEndAsync();
            body = body.Replace(Environment.NewLine, string.Empty);
            request.Body.Position = 0;
            return body;
        }

        
    }
}
