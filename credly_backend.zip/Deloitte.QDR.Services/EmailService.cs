﻿using Deloitte.QDR.Contracts;
using Deloitte.QDR.Contracts.Services;
using Deloitte.QDR.DTO.Common;
using Deloitte.QDR.Entities;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Hosting;
using System.Text;
using System.Text.RegularExpressions;

namespace Deloitte.QDR.Services
{
    public class EmailService : IEmailService
    {
        private readonly ISMTPEmailHandler _SMTPEmailHandler;
        private readonly IHostingEnvironment _hostingEnvironment;
        private readonly IHttpContextAccessor _contextAccessor;

        public EmailService(ISMTPEmailHandler SMTPEmailHandler, IHostingEnvironment hostingEnvironment, IHttpContextAccessor contextAccessor)
        {
            _SMTPEmailHandler = SMTPEmailHandler;
            _hostingEnvironment = hostingEnvironment;
            _contextAccessor = contextAccessor;
        }

        public async Task SendEmailAsync(List<string> emailEmployee, _Config_Notification emailConfig, bool isAdmin = false)
        {
            string emailBody = BuildEmailBody(emailConfig, isAdmin);

            var mailData = new MailData
            {
                EmailToId = emailEmployee,
                EmailSubject = emailConfig.EmailSubject,
                EmailBody = emailBody
            };

            await _SMTPEmailHandler.SendEmailAsync(mailData);
        }

        public async Task<bool> SendEmailAsync(string emailEmployee, string htmlString, _Config_Notification emailConfig)
        {
            string emailBody;

            if (string.IsNullOrEmpty(htmlString))
            {
                emailBody = BuildEmailBody(emailConfig);
            }
            else
            {
                emailBody= htmlString;
            }           


            var mailData = new MailData
            {
                EmailToId = new List<string>() { emailEmployee },
                EmailSubject = emailConfig.EmailSubject,
                EmailBody = emailBody
            };

            return await _SMTPEmailHandler.SendEmailAsync(mailData);
        }

        private string BuildEmailBody(_Config_Notification emailConfig, bool isAdmin = false)
        {
            try
            {
                string path = Path.Combine(Path.GetDirectoryName(AppContext.BaseDirectory), @"Files\template-email-notification.html");

                string bodyContent;
                using (StreamReader streamReader = new StreamReader(path, Encoding.UTF8))
                {
                    bodyContent = streamReader.ReadToEnd();
                    if (string.IsNullOrEmpty(bodyContent))
                    {
                        throw new ValidationException(new Result
                        {
                            HasErrors = true,
                            Messages = new List<string>() { GeneralConstants.ErrorMessages.EMAIL_VALIDATION_NOT_BODYCONTENT }
                        });
                    }
                }

                bool isCredlyLink = false;
                if (emailConfig.EntityType == "Badge" && emailConfig.NotificationId == BadgeStatus.Approved.ToString())
                {
                    isCredlyLink = true;
                    bodyContent = Regex.Replace(bodyContent, "##ButtonLabel##", GeneralConstants.Badge.EMAIL_BUTTON_LABEL_ON_APPROVED_BADGE);
                }
                else
                {
                    bodyContent = Regex.Replace(bodyContent, "##ButtonLabel##", GeneralConstants.Badge.EMAIL_BUTTON_LABEL_OTHER_CASES);
                }

                bool isTemplatesLink = false;
                if (emailConfig.EntityType == GeneralConstants.BadgeTemplate.BADGE_TEMPLATE_CONSTANT &&
                    (emailConfig.NotificationId == BadgeTemplateStatus.AttentionRequired.ToString() ||
                    emailConfig.NotificationId == BadgeTemplateStatus.Submitted.ToString()))
                {
                    isTemplatesLink = true;
                }


                if (!isAdmin && isTemplatesLink)
                {
                    bodyContent = Regex.Replace(bodyContent, "##Link##", BuildLink("templates"));
                }
                else
                {
                    bodyContent = Regex.Replace(bodyContent, "##Link##", isCredlyLink ? emailConfig.EmailLink ?? string.Empty : BuildLink(emailConfig.EmailLink ?? string.Empty));
                }
            

                bodyContent = Regex.Replace(bodyContent, "##Title##", emailConfig.EmailTitle ?? string.Empty);
                bodyContent = Regex.Replace(bodyContent, "##Description##", emailConfig.EmailDescription ?? string.Empty);
                bodyContent = Regex.Replace(bodyContent, "##BodyImage##", BuildLink(emailConfig.EmailImage ?? string.Empty));
                bodyContent = Regex.Replace(bodyContent, "##LogoImage##", BuildLink(GeneralConstants.Email.LOGO_IMAGE_LINK));

                return bodyContent;
            }
            catch (FileNotFoundException fileEx)
            {
                throw new ValidationException(new Result { Messages = new List<string>() { GeneralConstants.ErrorMessages.EMAIL_VALIDATION_FILE_NOTFOUND }, HasErrors = true });
            }
            catch (ValidationException valEx)
            {
                throw new ValidationException(new Result { Messages = new List<string>() { valEx.Message }, HasErrors = true });
            }
        }

        private string BuildLink(string relativeLink)
        {
            HttpRequest currentRequest = _contextAccessor.HttpContext.Request;

            var baseEnvironmentUrl = $"{currentRequest.Scheme}://{currentRequest.Host}{currentRequest.PathBase}";

            int index = baseEnvironmentUrl.IndexOf(GeneralConstants.Email.API_BASE_URL);
            string cleanPath = (index < 0)
                ? baseEnvironmentUrl
                : baseEnvironmentUrl.Remove(index, GeneralConstants.Email.API_BASE_URL.Length);

            return $"{cleanPath}/{relativeLink}";
        }
    }
}
