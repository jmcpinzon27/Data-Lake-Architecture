﻿using Deloitte.QDR.Contracts;
using Deloitte.QDR.Contracts.Services;
using Deloitte.QDR.Entities;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Deloitte.QDR.Services
{
    public class FeedbackService : IFeedbackService
    {
        private IDBContext _dbContext;
        
        public FeedbackService(IDBContext dBContext)
        {
            _dbContext = dBContext; 
        }

        public Feedback? GetLastFeedback(Guid id, EntityType entityType)
        {
            return _dbContext.Feedback.OrderByDescending(x => x.Date)
                .FirstOrDefault(x => x.EntityId == id.ToString() && x.EntityType == entityType);
        }
    }
}
