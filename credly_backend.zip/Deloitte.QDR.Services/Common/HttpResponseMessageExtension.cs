﻿using System.Net;
using Deloitte.QDR.DTO.Common;
using Deloitte.QDR.DTO.CredlyAPI.Common;
using Newtonsoft.Json;

namespace Deloitte.QDR.Services.Common;

public static class HttpResponseMessageExtension
{
    public static async Task ValidateCredlyResponse(this HttpResponseMessage httpResult)
    {
        if (httpResult.IsSuccessStatusCode)
        {
            return;
        }

        if (httpResult.StatusCode >= HttpStatusCode.BadRequest && httpResult.StatusCode < HttpStatusCode.UnavailableForLegalReasons)
        {
            var jsonResult = await httpResult.Content.ReadAsStringAsync();
            var result = JsonConvert.DeserializeObject<CredlyResponse<CredlyError>>(jsonResult);
            throw new ValidationException(new Result
            {
                HasErrors = true,
                Messages = result.Data.GetFullErrors()
            });
        }
        else
        {
            var jsonResult = await httpResult.Content.ReadAsStringAsync();
            var error = $"Credly's service error: StatusCode {httpResult.StatusCode}, Content: {jsonResult}";
            throw new Exception(error);
        }
    }
}