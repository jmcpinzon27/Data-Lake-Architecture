﻿using Deloitte.QDR.Contracts.Services;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;

namespace Deloitte.QDR.Services
{
    public class RefresherService : BackgroundService
    {
        private readonly IServiceScopeFactory _serviceScopeFactory;

        public RefresherService(
            IServiceScopeFactory serviceScopeFactory
        )
        {
            _serviceScopeFactory = serviceScopeFactory ?? throw new ArgumentNullException(nameof(serviceScopeFactory));
        }

        protected override async Task ExecuteAsync(CancellationToken stoppingToken)
        {
            while (!stoppingToken.IsCancellationRequested)
            {
                using (var scope = _serviceScopeFactory.CreateScope())
                {
                    var cacheService = scope.ServiceProvider.GetRequiredService<ICacheService>();
                    await cacheService.LoadDataEmployeeToCache();
                }

                await Task.Delay(TimeSpan.FromHours(12), stoppingToken);
            }

        }
    }
}
