﻿using System.Runtime.InteropServices.ComTypes;
using Deloitte.QDR.Contracts;
using Deloitte.QDR.Contracts.Services;
using Deloitte.QDR.DTO.Common;

namespace Deloitte.QDR.Services.CustomValidaiton
{
    public class EmailValidation : IEmailValidation
    {
        private readonly IDBContext _context;
        public EmailValidation(IDBContext dbContext)
        {
            _context = dbContext ?? throw new ArgumentNullException(nameof(dbContext));
        }

        public async Task<bool> ValidateQDREmail(string email)
        {
            var mailExist = _context.Employees.Any(x => string.Equals(x.Email.ToLower(), email.ToLower()));
            return mailExist;
        }
    }
}
