﻿using Deloitte.QDR.Contracts.Services;
using Deloitte.QDR.DTO.Common;
using Deloitte.QDR.DTO.CredlyAPI;
using Deloitte.QDR.DTO.CredlyAPI.Common;
using Deloitte.QDR.Infrastructure.Config;
using Deloitte.QDR.Services.Common;
using Newtonsoft.Json;

namespace Deloitte.QDR.Services
{
    public class CredlyAPIService : ICredlyAPIService
    {
        private readonly HttpClient _httpClient;
        private readonly CredlyHttpData _credlyHttpData;
        private readonly string _credlyVersion;

        public CredlyAPIService(HttpClient httpClient, CredlyHttpData credlyHttpData)
        {
            _httpClient = httpClient ?? throw new ArgumentNullException(nameof(httpClient));
            _credlyHttpData = credlyHttpData ?? throw new ArgumentNullException(nameof(credlyHttpData));
            _credlyVersion = AppSettings.Settings.CredlyVersion;
        }

        #region BadgeTemplates

        public async Task<List<BadgeTemplate>> GetAllBadgeTemplates()
        {
            return await GetAllData<BadgeTemplate>("badge_templates", OrganizationFor.BadgeTemplate);
        }

        public async Task<BadgeTemplate> GetSingleBadgeTemplate(Guid id)
        {
            return await GetSingleData<BadgeTemplate>($"badge_templates/{id:D}", OrganizationFor.BadgeTemplate);
        }

        public async Task<BadgeTemplate> CreateBadgeTemplate(BadgeTemplate dto)
        {
            return await PostData<BadgeTemplate, BadgeTemplate>(dto, $"badge_templates", OrganizationFor.BadgeTemplate);
        }

        public async Task<BadgeTemplate> UpdateBadgeTemplate(BadgeTemplate dto)
        {
            return await PutData<BadgeTemplate, BadgeTemplate>(dto, $"badge_templates/{dto.Id:D}", OrganizationFor.BadgeTemplate);
        }

        public async Task<BadgeTemplate> ArchiveBadgeTemplate(Guid id)
        {
            var organizationUrl = SetHttpAuthorizationAndGetUrlOrganization(OrganizationFor.BadgeTemplate);
            var httpResult = await _httpClient.PutAsync(
                $"{organizationUrl}/badge_templates/{id:D}/archive",
                null
            );
            await httpResult.ValidateCredlyResponse();
            var jsonResult = await httpResult.Content.ReadAsStringAsync();
            var result = JsonConvert.DeserializeObject<CredlyResponse<BadgeTemplate>>(jsonResult);
            return result.Data;
        }

        public async Task<BadgeTemplate> UnarchiveBadgeTemplate(Guid id)
        {
            var organizationUrl = SetHttpAuthorizationAndGetUrlOrganization(OrganizationFor.BadgeTemplate);
            var httpResult = await _httpClient.PutAsync(
                $"{organizationUrl}/badge_templates/{id:D}/unarchive",
                null
            );
            await httpResult.ValidateCredlyResponse();
            var jsonResult = await httpResult.Content.ReadAsStringAsync();
            var result = JsonConvert.DeserializeObject<CredlyResponse<BadgeTemplate>>(jsonResult);
            return result.Data;
        }

        public async Task DeleteBadgeTemplate(Guid id)
        {
            var organizationUrl = SetHttpAuthorizationAndGetUrlOrganization(OrganizationFor.BadgeTemplate);
            var httpResult = await _httpClient.DeleteAsync(
                $"{organizationUrl}/badge_templates/{id:D}"
            );
            await httpResult.ValidateCredlyResponse();
        }

        #endregion

        #region Badges

        public async Task<List<Badge>> GetAllBadges()
        {
            return await GetAllData<Badge>("badges", OrganizationFor.Badge);
        }

        public async Task<Badge> GetSingleBadge(Guid id)
        {
            return await GetSingleData<Badge>($"badges/{id:D}", OrganizationFor.Badge);
        }

        public async Task<Badge> CreateBadge(CredlyBadgeCreate dto)
        {
            return await PostData<Badge, CredlyBadgeCreate>(dto, $"badges", OrganizationFor.Badge);
        }

        public async Task<Badge> ReplaceBadge(CredlyBadgeReplace dto)
        {
            return await PostData<Badge, CredlyBadgeReplace>(
                dto,
                $"badges/{dto.BadgeId:D}/replace",
                OrganizationFor.Badge
            );
        }

        public async Task<Badge> RevokeBadge(CredlyBadgeRevoke dto)
        {
            return await PutData<Badge, CredlyBadgeRevoke>(dto, $"badges/{dto.BadgeId:D}/revoke", OrganizationFor.Badge);
        }

        public async Task DeleteBadge(Guid id)
        {
            var organizationUrl = SetHttpAuthorizationAndGetUrlOrganization(OrganizationFor.Badge);
            var httpResult = await _httpClient.DeleteAsync(
                $"{organizationUrl}/badges/{id:D}"
            );
            await httpResult.ValidateCredlyResponse();
        }

        #endregion

        #region Employees

        //Waiting to validation

        //public async Task<List<Employment>> GetAllEmployees()
        //{
        //    return await GetAllData<Employment>("employees");
        //}

        //public async Task<Employment> GetSingleEmployee(Guid id)
        //{
        //    return await GetSingleData<Employment>($"employees/{id:D}");
        //}

        //public async Task<Employment> UpdateEmployee(Employment dto)
        //{
        //    return await PutData<Employment, Employment>(dto, $"employees/{dto.Id:D}");
        //}

        #endregion

        #region Events

        public async Task<T> GetEvent<T>(Guid id, OrganizationFor organizationFor)
        {
            var organizationUrl = SetHttpAuthorizationAndGetUrlOrganization(organizationFor);
            var httpResult = await _httpClient.GetAsync($"{organizationUrl}/events/{id:D}");
            await httpResult.ValidateCredlyResponse();
            var jsonResult = await httpResult.Content.ReadAsStringAsync();
            var result = JsonConvert.DeserializeObject<CredlyResponse<T>>(jsonResult);
            return result.Data;
        }

        #endregion

        #region Generics

        private async Task<List<T>> GetAllData<T>(string endpoint, OrganizationFor organizationFor)
        {
            var organizationUrl = SetHttpAuthorizationAndGetUrlOrganization(organizationFor);
            List<T> dataResult = new List<T>();
            var httpResult = await _httpClient.GetAsync($"{organizationUrl}/{endpoint}");
            await httpResult.ValidateCredlyResponse();
            var jsonResult = await httpResult.Content.ReadAsStringAsync();
            var result = JsonConvert.DeserializeObject<CredlyResponse<List<T>>>(jsonResult);
            dataResult.AddRange(result.Data);
            while (result != null && !string.IsNullOrWhiteSpace(result.Metadata.NextPageUrl))
            {
                httpResult = await _httpClient.GetAsync(result.Metadata.NextPageUrl);
                await httpResult.ValidateCredlyResponse();
                jsonResult = await httpResult.Content.ReadAsStringAsync();
                result = JsonConvert.DeserializeObject<CredlyResponse<List<T>>>(jsonResult);
                dataResult.AddRange(result.Data);
            }

            return dataResult;
        }

        private async Task<T> GetSingleData<T>(string endpoint, OrganizationFor organizationFor)
        {
            var organizationUrl = SetHttpAuthorizationAndGetUrlOrganization(organizationFor);
            T dataResult = default;
            var httpResult = await _httpClient.GetAsync($"{organizationUrl}/{endpoint}");
            await httpResult.ValidateCredlyResponse();
            var jsonResult = await httpResult.Content.ReadAsStringAsync();
            var result = JsonConvert.DeserializeObject<CredlyResponse<T>>(jsonResult);
            dataResult = result.Data;
            return dataResult;
        }

        private async Task<T1> PostData<T1, T2>(T2 dto, string endpoint, OrganizationFor organizationFor)
        {
            var organizationUrl = SetHttpAuthorizationAndGetUrlOrganization(organizationFor);
            var content = new StringContent(
                JsonConvert.SerializeObject(dto, Formatting.Indented, new JsonSerializerSettings { NullValueHandling = NullValueHandling.Ignore, DateFormatString = GeneralConstants.Common.CREDLY_DATETIME_FORMAT }),
                System.Text.Encoding.UTF8,
                "application/json"
            );
            var httpResult = await _httpClient.PostAsync($"{organizationUrl}/{endpoint}", content);
            await httpResult.ValidateCredlyResponse();
            var jsonResult = await httpResult.Content.ReadAsStringAsync();
            var result = JsonConvert.DeserializeObject<CredlyResponse<T1>>(jsonResult);
            return result.Data;
        }

        private async Task<T1> PutData<T1, T2>(T2 dto, string endpoint, OrganizationFor organizationFor)
        {
            var organizationUrl = SetHttpAuthorizationAndGetUrlOrganization(organizationFor);
            var content = new StringContent(
                JsonConvert.SerializeObject(dto, Formatting.Indented, new JsonSerializerSettings { NullValueHandling = NullValueHandling.Ignore, DateFormatString = GeneralConstants.Common.CREDLY_DATETIME_FORMAT }),
                System.Text.Encoding.UTF8,
                "application/json"
            );
            var httpResult = await _httpClient.PutAsync($"{organizationUrl}/{endpoint}", content);
            await httpResult.ValidateCredlyResponse();
            var jsonResult = await httpResult.Content.ReadAsStringAsync();
            var result = JsonConvert.DeserializeObject<CredlyResponse<T1>>(jsonResult);
            return result.Data;
        }

        #endregion

        private string SetHttpAuthorizationAndGetUrlOrganization(OrganizationFor organizationFor)
        {
            if (string.IsNullOrWhiteSpace(_credlyHttpData.BadgeTemplate.Authorization) ||
                string.IsNullOrWhiteSpace(_credlyHttpData.BadgeTemplate.Organization) ||
                string.IsNullOrWhiteSpace(_credlyHttpData.Badge.Authorization) ||
                string.IsNullOrWhiteSpace(_credlyHttpData.Badge.Organization))
            {
                throw new ValidationException(new Result
                {
                    HasErrors = true,
                    Messages = new List<string> { GeneralConstants.ErrorMessages.CREDLY_PARAMETRIZATION_MISSING }
                });
            }

            if (organizationFor == OrganizationFor.BadgeTemplate)
            {
                _httpClient.DefaultRequestHeaders.Add("Authorization", _credlyHttpData.BadgeTemplate.Authorization);
                return $"/{_credlyVersion}/organizations/{_credlyHttpData.BadgeTemplate.Organization}";
            }
            if (organizationFor == OrganizationFor.Badge)
            {
                _httpClient.DefaultRequestHeaders.Add("Authorization", _credlyHttpData.Badge.Authorization);
                return $"/{_credlyVersion}/organizations/{_credlyHttpData.Badge.Organization}";
            }

            throw new ValidationException(new Result
            {
                HasErrors = true,
                Messages = new List<string> { GeneralConstants.ErrorMessages.CREDLY_ORGANIZATION_NOT_SET }
            });
        }

    }
}
