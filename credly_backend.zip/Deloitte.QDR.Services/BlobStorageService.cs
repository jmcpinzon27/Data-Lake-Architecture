﻿using Azure;
using Azure.Storage.Blobs;
using Azure.Storage.Blobs.Models;
using Deloitte.QDR.Contracts.Services;
using Deloitte.QDR.DTO.Common;

namespace Deloitte.QDR.Services
{
    public class BlobStorageService : IBlobStorageService
    {
        private readonly string _blobStorageConnectionString;
        private readonly string _blobStorageUriBase;
        private readonly string _container;

        public BlobStorageService(
            string blobStorageConnectionString,
            string blobStorageUriBase,
            string container
        )
        {
            _blobStorageConnectionString = blobStorageConnectionString;
            _blobStorageUriBase = blobStorageUriBase;
            _container = container;
        }

        public async Task<BlobFileInfo> UploadBlobFile(
            MemoryStream file,
            string idBlobFile,
            string ContentType
        )
        {
            file.Position = 0;
            var blobContainerClient = new BlobContainerClient(
                _blobStorageConnectionString,
                _container
            );
            BlobClient blob = blobContainerClient.GetBlobClient(idBlobFile);
            var response = await blob.UploadAsync(
                file,
                new BlobHttpHeaders { ContentType = ContentType }
            );
            return new BlobFileInfo
            {
                IdBlob = idBlobFile,
                NameFile = idBlobFile.Substring(idBlobFile.LastIndexOf("/") + 1),
                Uri = $"{_blobStorageUriBase}/{_container}/{idBlobFile}",
                ContentType = ContentType,
                ContentLength = response.Value.ContentHash.Length,
                LastModified = response.Value.LastModified,
                CreatedOn = response.Value.LastModified,
            };
        }

        public async Task<BlobFileInfo> DownloadBlobFile(string idBlobFile)
        {
            var blobContainerClient = new BlobContainerClient(
                _blobStorageConnectionString,
                _container
            );

            var blob = blobContainerClient.GetBlobClient(idBlobFile);

            var contentExist = await blob.ExistsAsync();

            if (!contentExist.Value) { return null; }

            var name = blob.Uri.Segments?.Last();
            var result = await blob.DownloadAsync();

            return new BlobFileInfo
            {
                IdBlob = idBlobFile,
                NameFile = string.IsNullOrWhiteSpace(name) ? Guid.NewGuid().ToString() : name,
                Uri = $"{_blobStorageUriBase}/{_container}/{idBlobFile}",
                ContentType = result.Value.ContentType,
                ContentLength = result.Value.ContentLength,
                Content = result.Value.Content
            };
        }

        public async Task DeleteBlobFile(string nameFile)
        {
            var blobContainerClient = new BlobContainerClient(
                _blobStorageConnectionString,
                _container
            );
            await blobContainerClient.DeleteBlobAsync(nameFile);
        }

        public async Task<List<BlobFileInfo>> GetListOFBlobs(string prefix)
        {
            List<BlobFileInfo> blobs = new List<BlobFileInfo>();
            var blobContainerClient = new BlobContainerClient(
                _blobStorageConnectionString,
                _container
            );
            var result = blobContainerClient
                .GetBlobsAsync(BlobTraits.None, BlobStates.All, prefix)
                .AsPages(default, 10);
            await foreach (Page<BlobItem> blobPage in result)
            {
                foreach (BlobItem blobItem in blobPage.Values)
                {
                    blobs.Add(
                        new DTO.Common.BlobFileInfo
                        {
                            IdBlob = blobItem.Name,
                            NameFile = blobItem.Name.Substring(blobItem.Name.LastIndexOf("/") + 1),
                            Uri = $"{_blobStorageUriBase}/{_container}/{blobItem.Name}",
                            ContentType = blobItem.Properties.ContentType,
                            ContentLength = blobItem.Properties.ContentLength,
                            LastModified = blobItem.Properties.LastModified,
                            CreatedOn = blobItem.Properties.CreatedOn,
                        }
                    );
                }
            }

            return blobs;
        }

        public async Task<string> SendFileToStorageAsync(MemoryStream fileContent, Guid entityId,
            string contentType, string storagePrefix, string storageFileName)
        {
            var storageResult = await UploadBlobFile(
                fileContent,
                $"{storagePrefix}/{entityId}/{storageFileName}",
                contentType);

            return storageResult.IdBlob;
        }
    }
}