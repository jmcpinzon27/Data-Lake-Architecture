﻿using AutoMapper;
using Deloitte.QDR.Contracts;
using Deloitte.QDR.Contracts.Services;
using Deloitte.QDR.DTO.Common;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Caching.Memory;

namespace Deloitte.QDR.Services;

public class CacheService : ICacheService
{
    private readonly IDBContext _dbContext;
    private readonly IMemoryCache _memoryCache;
    private readonly IDataCache _redisCache;
    private readonly Mapper Mapper;
    private const int ExpirationHours = 12;
    private readonly MemoryCacheEntryOptions _memoryCacheOptions;

    public CacheService(
        IDataCache dataCache,
        IMemoryCache memoryCache,
        IDBContext dbContext
    )
    {
        _redisCache = dataCache ?? throw new ArgumentNullException(nameof(dataCache));
        _memoryCache = memoryCache ?? throw new ArgumentNullException(nameof(memoryCache));
        _dbContext = dbContext ?? throw new ArgumentNullException(nameof(dbContext));
        Mapper = new Mapper(MapperBootstrapper.MapperConfiguration);
        _memoryCacheOptions = new MemoryCacheEntryOptions().SetAbsoluteExpiration(TimeSpan.FromHours(ExpirationHours));
    }

    public async Task LoadDataEmployeeToCache()
    {
        var temporaryData = new List<UserSession>();
        var pageNumber = 1;
        var pageSize = 10000;

        while (true)
        {
            var dataEmployee = await _dbContext.Employees
                .Include(x => x.EmployeeRoles).ThenInclude(x => x.Role)
                .Where(x => x.IsActive == true)
                .OrderBy(x => x.PersonID)
                .Skip((pageNumber - 1) * pageSize)
                .Take(pageSize)
                .ToListAsync();

            if (dataEmployee == null || !dataEmployee.Any())
            {
                //memory cache //Commented for test in DEV and QA env.
                _memoryCache.Set(nameof(UserSession), temporaryData, _memoryCacheOptions);

                //redis cache
                _redisCache.InsertOrUpdate(nameof(UserSession), temporaryData, ExpirationHours);

                break;
            }
            //map in memory is faster
            var mapEmployees = dataEmployee.Select(x => Mapper.Map<Entities.Employee, UserSession>(x)).ToList();
            temporaryData.AddRange(mapEmployees);
            pageNumber++;
        }
    }

    public async Task<UserSession> GetUserSession(string email)
    {
        UserSession? result = null;

        var dataEmployee = await GetEmployeesFromMemoryCache(); //Find the employee on memory cache data.
        if (dataEmployee != null)
        {
            result = dataEmployee.FirstOrDefault(x => string.Equals(x.Email, email, StringComparison.OrdinalIgnoreCase));
            if (result is not null)
            {
                result.CredlyEmployeeState = await GetCredlyEmployeeState(result.PersonID); //Get current credly employee state
                return result;
            }
        }

        dataEmployee = await GetEmployeesFromRedisCacheAsync(); //Find the employee on redis cache data
        result = dataEmployee.FirstOrDefault(x => string.Equals(x.Email, email, StringComparison.OrdinalIgnoreCase));
        if (result is not null)
        {
            result.CredlyEmployeeState = await GetCredlyEmployeeState(result.PersonID); //Get current credly employee state
            return result;
        }

        UpdateCache(result.Email);

        return result;
    }

    public void UpdateCache(string personId)
    {
        IList<UserSession> dataEmployee = new List<UserSession>();

        if (!_memoryCache.TryGetValue(nameof(UserSession), out dataEmployee))
        {
            try
            {
                dataEmployee = _redisCache.Get<List<UserSession>>(nameof(UserSession));
            }
            catch (Exception e)
            {
                //TODO: We can log this
            }
        }

        if (dataEmployee == null || !dataEmployee.Any())
        { //If no cache, nothing to do
            return;
        }

        var toUpdate = dataEmployee.FirstOrDefault(o => o.PersonID == personId);

        //get new data
        var person = _dbContext.Employees
            .Include(x => x.EmployeeRoles)
            .ThenInclude(x => x.Role)
            .Where(x => x.PersonID == personId)
            .Select(x => Mapper.Map<QDR.Entities.Employee, UserSession>(x))
            .First();

        //update index or add new
        int index = dataEmployee.IndexOf(toUpdate);
        if (index > -1)
        {
            dataEmployee[index] = person;
        }
        else
        {
            dataEmployee.Add(person);
        }

        //memory cache  with default options (24 hs)
        _memoryCache.Set(nameof(UserSession), dataEmployee, _memoryCacheOptions);

        //redis cache with default options (24 hs)
        _redisCache.InsertOrUpdate(nameof(UserSession), dataEmployee);
    }

    public async Task DeleteEmployeeFromCache(string email)
    {
        var dataEmployee = await GetEmployeesFromMemoryCache();
        int index = dataEmployee.FindIndex(x => x.Email == email);
        if (index > -1)
        {
            dataEmployee.RemoveAt(index);
        }

        dataEmployee = await GetEmployeesFromRedisCacheAsync();
        index = dataEmployee.FindIndex(x => x.Email == email);
        if (index > -1)
        {
            dataEmployee.RemoveAt(index);
        }

        //memory cache  with default options (24 hs)
        _memoryCache.Set(nameof(UserSession), dataEmployee, _memoryCacheOptions);

        //redis cache with default options (24 hs)
        _redisCache.InsertOrUpdate(nameof(UserSession), dataEmployee);
    }

    public async Task<CacheServiceResponse<List<UserSession>>> GetEmployeesFromCacheAsync()
    {
        CacheServiceResponse<List<UserSession>> cacheServiceResponse = new CacheServiceResponse<List<UserSession>>();
        cacheServiceResponse.Data = await GetEmployeesFromMemoryCache();
        cacheServiceResponse.SourceCache = SourceCache.Memory;
        if (cacheServiceResponse.Data is null || !cacheServiceResponse.Data.Any())
        {
            cacheServiceResponse.Data = await GetEmployeesFromRedisCacheAsync();
            cacheServiceResponse.SourceCache = SourceCache.Redis;
        }

        return cacheServiceResponse;
    }

    public async Task<CacheServiceResponse<List<UserSession>>> GetEmployeesRoleFromCacheAsync(List<string> roles)
    {
        CacheServiceResponse<List<UserSession>> cacheServiceResponse = new CacheServiceResponse<List<UserSession>>();
        cacheServiceResponse.Data = await GetEmployeesFromMemoryCache();
        cacheServiceResponse.SourceCache = SourceCache.Memory;
        if (cacheServiceResponse.Data is null || !cacheServiceResponse.Data.Any())
        {
            cacheServiceResponse.Data = await GetEmployeesFromRedisCacheAsync();
            cacheServiceResponse.SourceCache = SourceCache.Redis;
        }

        if (cacheServiceResponse.Data is not null)
        {
            cacheServiceResponse.Data = cacheServiceResponse.Data.Where(x => x.Roles.Any(j => roles.Contains(j))).ToList();
        }

        return cacheServiceResponse;
    }

    private async Task<List<UserSession>>? GetEmployeesFromMemoryCache()
    {
        List<UserSession> dataEmployee = new List<UserSession>();
        _memoryCache.TryGetValue(nameof(UserSession), out dataEmployee);
        return dataEmployee;
    }

    private async Task<List<UserSession>>? GetEmployeesFromRedisCacheAsync()
    {
        return await _redisCache.GetAsync<List<UserSession>>(nameof(UserSession));
    }

    private async Task<string?> GetCredlyEmployeeState(string personId)
    {
        var credlyEmployee = await _dbContext.CredlyEmployees.FirstOrDefaultAsync(t => t.PersonID == personId);
        string? result = string.Empty;
        if (credlyEmployee is not null)
        {
            result = credlyEmployee.EmployeeState;
        }
        return result;
    }
}