﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Deloitte.QDR.Contracts.Services
{
    public interface IEmailValidation
    {
        Task<bool> ValidateQDREmail(string email);
    }
}
