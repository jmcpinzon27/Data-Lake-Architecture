﻿using Deloitte.QDR.DTO.SABA;

namespace Deloitte.QDR.Contracts.Services;

public interface ISABAService
{
    Task<Course> GetCourseById(string courseId);
    bool ValidateCourse(string employeeInfoPersonId, string? criteriaSabaCourseId);
}