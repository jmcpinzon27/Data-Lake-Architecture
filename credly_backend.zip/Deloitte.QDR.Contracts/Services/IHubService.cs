﻿using Deloitte.QDR.DTO.Common;

namespace Deloitte.QDR.Contracts.Services;

public interface IHubService
{
    Task ReceiveNotification(NotificacionHub notification, string email);
    Task ReceiveNotification(NotificacionHub notification, List<string> emails);
}