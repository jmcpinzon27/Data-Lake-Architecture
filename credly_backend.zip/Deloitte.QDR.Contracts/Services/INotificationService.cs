﻿namespace Deloitte.QDR.Contracts.Services
{
    public interface INotificationService
    {        
        Task<DTO.Common.NotificacionHub> SendNotificationToHubAsync(List<string> emailEmployee, string notificationId, string entityType, string[]contentParams = default, bool isAdmin = false);
        bool IsAllowedNotification(string notificationId, string entityType);
    }
}