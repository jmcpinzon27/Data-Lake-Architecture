﻿using Deloitte.QDR.DTO;
using Deloitte.QDR.DTO.Common;

namespace Deloitte.QDR.Contracts.Services
{
    public interface ISessionService
    {
        UserSession GetSession(string email = null);
        Task<UserSession> GetSessionAsync(string email = null);
        Task<ErrorLog> GetContextErrorLog();
    }
}