﻿using Deloitte.QDR.DTO.Common;

namespace Deloitte.QDR.Contracts.Services
{
    public interface IStatusFlowValidator<T> where T : struct
    {
        T SetAndValidateStatus(T? currentStatus, T statusToPass);
        ValidationException ThrowValidationException(T? currentStatus, T statusToPass);
    }
}
