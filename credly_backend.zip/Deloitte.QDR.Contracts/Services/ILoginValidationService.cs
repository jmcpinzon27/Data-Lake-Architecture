﻿namespace Deloitte.QDR.Contracts.Services
{
    public interface ILoginValidationService
    {
        Task FirstLoginValidateAsync(string personId);
    }
}