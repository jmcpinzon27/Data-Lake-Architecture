﻿using Deloitte.QDR.DTO.CredlyAPI;
using Deloitte.QDR.DTO.CredlyAPI.Common;

namespace Deloitte.QDR.Contracts.Services
{
    public interface ICredlyAPIService
    {
        #region BadgeTemplates

        Task<List<BadgeTemplate>> GetAllBadgeTemplates();
        Task<BadgeTemplate> GetSingleBadgeTemplate(Guid id);
        Task<BadgeTemplate> CreateBadgeTemplate(BadgeTemplate dto);
        Task<BadgeTemplate> UpdateBadgeTemplate(BadgeTemplate dto);
        Task<BadgeTemplate> ArchiveBadgeTemplate(Guid id);
        Task<BadgeTemplate> UnarchiveBadgeTemplate(Guid id);
        Task DeleteBadgeTemplate(Guid id);

        #endregion

        #region Badges

        Task<List<Badge>> GetAllBadges();
        Task<Badge> CreateBadge(CredlyBadgeCreate dto);
        Task<Badge> ReplaceBadge(CredlyBadgeReplace dto);
        Task<Badge> RevokeBadge(CredlyBadgeRevoke dto);

        #endregion

        #region Employees

        //Task<List<Employment>> GetAllEmployees();
        //Task<Employment> GetSingleEmployee(Guid id);
        //Task<Employment> UpdateEmployee(Employment dto);

        #endregion

        #region Events

        Task<T> GetEvent<T>(Guid id, OrganizationFor organizationFor);

        #endregion
    }
}
