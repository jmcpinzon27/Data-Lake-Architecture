﻿using Deloitte.QDR.Entities;

namespace Deloitte.QDR.Contracts.Services
{
    public interface IEmailService
    {
        Task<bool> SendEmailAsync(string emailEmployee, string htmlString, _Config_Notification emailConfig);
        Task SendEmailAsync(List<string> emailEmployee, _Config_Notification configNotification, bool isAdmin = false);
    }
}
