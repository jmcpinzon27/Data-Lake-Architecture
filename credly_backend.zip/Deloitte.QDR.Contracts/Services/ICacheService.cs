﻿using Deloitte.QDR.DTO;
using Deloitte.QDR.DTO.Common;

namespace Deloitte.QDR.Contracts.Services;

public interface ICacheService
{
    Task LoadDataEmployeeToCache();
    void UpdateCache(string employeeInfoPersonId);
    //TODO ADD updateCacheAsync when all interfaces supports that
    Task DeleteEmployeeFromCache(string email);
    Task<UserSession> GetUserSession(string email);
    Task<CacheServiceResponse<List<UserSession>>> GetEmployeesFromCacheAsync();
    Task<CacheServiceResponse<List<UserSession>>> GetEmployeesRoleFromCacheAsync(List<string> roles);
}