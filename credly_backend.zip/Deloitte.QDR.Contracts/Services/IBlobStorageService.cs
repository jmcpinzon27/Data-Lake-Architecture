﻿using Deloitte.QDR.DTO.Common;

namespace Deloitte.QDR.Contracts.Services
{
    public interface IBlobStorageService
    {
        Task<BlobFileInfo> UploadBlobFile(MemoryStream file, string idBlobFile, string ContentType);

        Task<BlobFileInfo> DownloadBlobFile(string idBlobFile);

        Task DeleteBlobFile(string idBlobFile);

        Task<List<BlobFileInfo>> GetListOFBlobs(string prefix);

        Task<string> SendFileToStorageAsync(MemoryStream fileContent, Guid entityId,
            string contentType, string storagePrefix, string storageFileName);
    }
}
