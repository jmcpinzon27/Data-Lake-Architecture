﻿using Deloitte.QDR.Contracts.BL.Base;
using Deloitte.QDR.DTO;
using Deloitte.QDR.DTO.Common;

namespace Deloitte.QDR.Contracts.BL
{
    public interface IAwardingProcessBL :
        IGetByIdBL<Guid, DTO.AwardingProcess>,
        IGetByFilterBL<DTO.AwardingProcess, FilterBase>,
        IUpdateAsyncBL<DTO.AwardingProcess>,
        IDeleteBL<Guid>
    {
        public DTO.AwardingProcess CreateAwardingProcess();
        public DTO.AwardingProcess ChangeStatus(AwardingProcess bulkAwardingProcessDto);
    }
}
