﻿using Deloitte.QDR.Contracts.BL.Base;
using Deloitte.QDR.DTO.BadgeTemplateFlow;
using Deloitte.QDR.DTO.Common;
using Deloitte.QDR.DTO.Filters;
using Deloitte.QDR.DTO.SABA;

namespace Deloitte.QDR.Contracts.BL
{
    public interface IBadgeTemplateBL :
        IGetByIdAsyncBL<Guid, DTO.BadgeTemplate>,
        IGetByFilterBL<DTO.BadgeTemplate, BadgeTemplateFilter>,
        ICreateAsyncBL<DTO.BadgeTemplate>,
        IUpdateAsyncBL<DTO.BadgeTemplate>,
        IDeleteAsyncBL<Guid>
    {
        ListResponse<DTO.Queries.BadgeTemplateQuery> GetBadgeTemplatesBusinessRep(
            DTO.Filters.BadgeTemplateFilter filter
        );
        ListResponse<DTO.Queries.BadgeTemplateQuery> GetBadgesTemplatesAdmin(
            DTO.Filters.BadgeTemplateFilter filter
        );
        ListResponse<DTO.BadgeTemplate> GetBadgeTemplatesQueryPractitioner(
            BadgeTemplateFilter filter
        );
        Task<DTO.BadgeTemplate> ChangeStatusAsync(TransitionStatus statusDto, CancellationToken cancellationToken = default);
        Task<DTO.BadgeTemplate> ChangePrivacyAsync(DTO.BadgeTemplate badgeTemplate);
        List<DTO.BadgeTemplateCriteriaType> GetBadgeTemplateCriteriaTypes();
        DTO.BadgeTemplate SetReleaseNotes(ReleaseNotes releaseNotesDto);
        Task<ArchivingFlow> ArchivingProcessAsync(ArchivingFlow archivingFlow, CancellationToken cancellationToken);
        Task<Course> GetSABACourseByIdAsync(string courseId, CancellationToken cancellationToken = default);
    }
}
