﻿using Deloitte.QDR.Contracts.BL.Base;
using Deloitte.QDR.DTO;
using Deloitte.QDR.DTO.Common;
using Deloitte.QDR.DTO.Filters;

namespace Deloitte.QDR.Contracts.BL
{
    public interface IUserActivityBL : ICrudBL<Guid, UserActivity, UserActivityFilter>
    {
    }
}
