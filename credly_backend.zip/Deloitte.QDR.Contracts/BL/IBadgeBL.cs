﻿using Deloitte.QDR.Contracts.BL.Base;
using Deloitte.QDR.DTO.Common;

namespace Deloitte.QDR.Contracts.BL
{
    public interface IBadgeBL :
        IGetByIdBL<Guid, DTO.Badge>,
        IGetByFilterBL<DTO.Badge, DTO.Filters.BadgesFilter>,
        ICreateBL<DTO.Badge>,
        IUpdateAsyncBL<DTO.Badge>,
        IDeleteBL<Guid>
    {
        ListResponse<DTO.Queries.BadgeQuery> GetBadgesPractitioner(DTO.Filters.BadgesFilter filter);

        Task<ListResponse<DTO.Queries.BadgeQuery>> GetBadgesBusinessRepAsync(DTO.Filters.BadgesFilter filter);

        ListResponse<DTO.Queries.BadgeQuery> GetBadgesAdmin(DTO.Filters.BadgesFilter filter);

        Task<DTO.BadgeStatusFlow> StatusFlowAsync(DTO.BadgeStatusFlow badgeStatusFlow);

        Task<DTO.Badge> ReInitiatedBadgeAsync(Guid badgeId, CancellationToken cancellationToken = default);

    }
}