﻿namespace Deloitte.QDR.Contracts.BL
{
    public interface IRoleBL
    {
        IEnumerable<DTO.Role> GetRoles();
    }
}