﻿using Deloitte.QDR.Contracts.BL.Base;
using Deloitte.QDR.DTO;
using Deloitte.QDR.DTO.Common;
using Deloitte.QDR.DTO.Filters;

namespace Deloitte.QDR.Contracts.BL
{
    public interface IEmployeeBL
    {
        Task<CacheResponse<ListResponse<UserSession>>> GetByFilterAsync(FilterBaseWithRoles filter, CancellationToken cancellationToken = default);
        UserSession GetUserSession();
        Task<CacheResponse<ListResponse<UserSession>>> GetEmployeesByRoleAsync(FilterBaseWithRoles filter, CancellationToken cancellationToken = default);
    }
}
