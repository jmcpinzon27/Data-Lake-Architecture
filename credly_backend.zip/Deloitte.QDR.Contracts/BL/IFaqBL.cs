﻿using Deloitte.QDR.Contracts.BL.Base;
using Deloitte.QDR.DTO.Common;
using Deloitte.QDR.DTO.Filters;
using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
namespace Deloitte.QDR.Contracts.BL
{
    public interface IFaqBL : ICrudBL<Guid, DTO.Faq, FaqFilter>
    {
        ListResponse<DTO.Faq> GetByCategory(FaqFilter filterById);
        ListResponse<DTO.Faq> GetAll(FaqFilter filterById);

    }
}
