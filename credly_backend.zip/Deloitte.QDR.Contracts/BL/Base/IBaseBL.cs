﻿using AutoMapper;
using Deloitte.QDR.Contracts.Services;

namespace Deloitte.QDR.Contracts.BL.Base
{
    public interface IBaseBL
    {
        ISessionService SessionService { get; }
        IDBContext DbContext { get; }
        IDataCache DataCache { get; }
        Mapper Mapper { get; }
    }
}
