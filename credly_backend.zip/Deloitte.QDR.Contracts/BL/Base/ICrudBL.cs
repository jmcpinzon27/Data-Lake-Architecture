﻿using Deloitte.QDR.DTO.Common;

namespace Deloitte.QDR.Contracts.BL.Base
{
    public interface ICrudBL<TID, TD, TF> :
        IGetByIdBL<TID, TD>,
        IGetByFilterBL<TD, TF>,
        ICreateBL<TD>,
        IUpdateBL<TD>,
        IDeleteBL<TID>
    {
    }

    public interface ICrudAsyncBL<TID, TD, TF> :
        IGetByIdAsyncBL<TID, TD>,
        IGetByFilterAsyncBL<TD, TF> where TF : FilterBase,
        ICreateAsyncBL<TD>,
        IUpdateAsyncBL<TD>,
        IDeleteAsyncBL<TID>
    {
    }

    public interface IGetByIdBL<TID, TD> : IBaseBL
    {
        TD GetById(TID id);
    }

    public interface IGetByIdAsyncBL<TID, TD> : IBaseBL
    {
        Task<TD> GetByIdAsync(TID id, CancellationToken cancellationToken = default);
    }

    public interface IGetByFilterBL<TD, TF> : IBaseBL
    {
        ListResponse<TD> GetByFilter(TF filter);
    }

    public interface IGetByFilterAsyncBL<TD, TF> : IBaseBL
    {
        Task<ListResponse<TD>> GetByFilterAsync(TF filter, CancellationToken cancellationToken = default);
    }

    public interface ICreateBL<TD> : IBaseBL
    {
        TD Create(TD DTO);
    }

    public interface ICreateAsyncBL<TD> : IBaseBL
    {
        Task<TD> CreateAsync(TD DTO, CancellationToken cancellationToken = default);
    }

    public interface IUpdateBL<TD> : IBaseBL
    {
        TD Update(TD DTO);
    }

    public interface IUpdateAsyncBL<TD> : IBaseBL
    {
        Task<TD> UpdateAsync(TD DTO, CancellationToken cancellationToken = default);
    }

    public interface IDeleteBL<TID> : IBaseBL
    {
        void Delete(TID id);
    }

    public interface IDeleteAsyncBL<TID> : IBaseBL
    {
        Task DeleteAsync(TID id, CancellationToken cancellationToken = default);
    }
}
