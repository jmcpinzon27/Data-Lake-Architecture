﻿using Deloitte.QDR.Contracts.BL.Base;
using Deloitte.QDR.DTO.Common;

namespace Deloitte.QDR.Contracts.BL;

public interface IBlobFileBL : IBaseBL
{
    Task<BlobFileInfo> UploadBadgeFile(Base64File file);
    Task<BlobFileInfo> DownloadBadgeFile(string idBlobFile);
    Task DeleteBadgeFile(string idBlobFile);
    Task<List<BlobFileInfo>> GetListBadgeFile(string prefix);
}
