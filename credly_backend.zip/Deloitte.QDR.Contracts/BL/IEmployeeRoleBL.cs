﻿using Deloitte.QDR.Contracts.BL.Base;
using Deloitte.QDR.DTO;

namespace Deloitte.QDR.Contracts.BL
{
    public interface IEmployeeRoleBL : ICrudBL<Guid, DTO.EmployeeRole, DTO.Filters.EmployeeRoleFilter>
    {
        bool Delete(EmployeeRole employeeRoleDTO);
        List<EmployeeRole> GetByGuid(Guid id);
        DTO.EmployeeRole Create(DTO.EmployeeRole employeeRoleDTO);
    }
}