﻿using Deloitte.QDR.Contracts.BL.Base;
using Deloitte.QDR.DTO.Common;

namespace Deloitte.QDR.Contracts.BL
{
    public interface IBulkTempBL : IBaseBL
    {
        bool BulkEmployeeData(string email, RoleType role, bool? isActive);
        bool ChangeRole(string email, RoleType role);
        Task RefreshEmployeesCache();
        Task<bool> SendMailAsync(NotificationEmailData emailData);
        Task<bool> SendMailTestAsync(NotificationEmailData mailData);
    }
}
