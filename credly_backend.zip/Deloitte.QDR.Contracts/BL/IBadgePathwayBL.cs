﻿using Deloitte.QDR.Contracts.BL.Base;
using Deloitte.QDR.DTO;
using Deloitte.QDR.DTO.Common;

namespace Deloitte.QDR.Contracts.BL;

public interface IBadgePathwayBL :
    IGetByIdAsyncBL<Guid, BadgePathway>,
    ICreateAsyncBL<BadgePathway>,
    IUpdateAsyncBL<BadgePathway>
{
    Task<ListResponse<BadgePathway>> GetBadgePathwaysBusinessRepAndAdminAsync(FilterBase filter, CancellationToken cancellationToken = default);
    List<string> GetSkillsFromBadgeTemplates(List<Guid> idBadgeTemplates);
}