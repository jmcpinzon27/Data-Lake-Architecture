﻿namespace Deloitte.QDR.Contracts.BL;

public interface ISystemBL
{
    List<KeyValuePair<string, string>> GetParameters();
}