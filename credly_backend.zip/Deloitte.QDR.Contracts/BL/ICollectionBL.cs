﻿using Deloitte.QDR.Contracts.BL.Base;
using Deloitte.QDR.DTO.Common;

namespace Deloitte.QDR.Contracts.BL;

public interface ICollectionBL : ICrudBL<Guid, DTO.Collection, FilterBase>
{
}