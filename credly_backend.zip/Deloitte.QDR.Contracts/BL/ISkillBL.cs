﻿using Deloitte.QDR.Contracts.BL.Base;
using Deloitte.QDR.DTO.Filters;

namespace Deloitte.QDR.Contracts.BL
{
    public interface ISkillBL :
        IGetByIdBL<Guid, DTO.Skill>,
        IGetByFilterBL<DTO.Skill, SkillFilter>
    {
        public List<string> GetSkillsDistinctByName();
        List<string> GetSkillsByBadgeTemplateStatus(SkillFilter filter);
    }
}