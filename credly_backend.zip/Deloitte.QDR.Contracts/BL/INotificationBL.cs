﻿using Deloitte.QDR.Contracts.BL.Base;
using Deloitte.QDR.DTO.Common;

namespace Deloitte.QDR.Contracts.BL
{
    public interface INotificationBL : IBaseBL
    {
        ListResponse<DTO.Notification> GetNotificationsPractitioner(DTO.Filters.NotificationFilter filter);
        ListResponse<DTO.Notification> GetNotificationsBusinessRep(DTO.Filters.NotificationFilter filter);
        ListResponse<DTO.Notification> GetNotificationsAdmin(DTO.Filters.NotificationFilter filter);
    }
}
