﻿using Deloitte.QDR.Contracts.BL.Base;
using Deloitte.QDR.DTO.Common;
using Deloitte.QDR.DTO.Reports;

namespace Deloitte.QDR.Contracts.BL
{
    public interface IReportBL : IBaseBL
    {
        Task<AdminSummaryReport> GetAdminSummaryReportAsync();
        IList<BadgesByPeriodReportItem> GetBadgesByPeriodReport(Interval interval);
        Task<PractitionerSummaryReport> GetPractitionerSummaryReportAsync();
    }
}
