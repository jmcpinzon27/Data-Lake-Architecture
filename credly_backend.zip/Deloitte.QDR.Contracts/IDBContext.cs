﻿using Deloitte.QDR.Entities;
using Deloitte.QDR.Entities.Queries;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Infrastructure;

namespace Deloitte.QDR.Contracts
{
    public interface IDBContext
    {
        int SaveChanges();
        Task<int> SaveChangesAsync(CancellationToken cancellationToken = default);

        DbSet<T> Set<T>()
            where T : class;

        DatabaseFacade Database { get; }

        DbSet<Feedback> Feedback { get; }
        DbSet<Employee> Employees { get; }
        DbSet<Badge> Badges { get; }
        DbSet<BadgeQuery> BadgeQueries { get; }
        DbSet<BadgeTemplate> BadgeTemplates { get; }
        DbSet<BadgeTemplateQuery> BadgeTemplateQueries { get; }
        DbSet<AuditLog> AuditLogs { get; }
        DbSet<Skill> Skills { get; }
        DbSet<Notification> Notifications { get; }
        DbSet<Role> Role { get; }
        DbSet<EmployeeRole> EmployeeRole { get; }
        DbSet<BadgeTemplateSkill> BadgeTemplateSkills { get; }
        DbSet<BadgeTemplateCriteria> BadgeTemplateCriteria { get; }
        DbSet<BadgeTemplateCriteriaType> BadgeTemplateCriteriaType { get; }
        DbSet<UserActivity> UserActivity { get; }
        DbSet<Education> Educations { get; }
        DbSet<Experience> Experiencies { get; }
        DbSet<Exposure> Exposures { get; }
        DbSet<AwardingProcess> AwardingProcess { get; }
        DbSet<BadgeTemplateCollection> BadgeTemplateCollections { get; }
        DbSet<Collection> Collections { get; }
        DbSet<FaqCategory> Categories { get; }
        DbSet<Faq> Faq { get; }
        DbSet<_Config_Notification> ConfigNotifications { get; }
	DbSet<CredlyEmployee> CredlyEmployees { get; }
        DbSet<BadgePathwayBadgeTemplate> BadgePathwayBadgeTemplate { get; set; }
        DbSet<BadgePathwaySkill> BadgePathwaySkill { get; set; }
        DbSet<BadgePathway> BadgePathway { get; set; }
        DbSet<ErrorLog> ErrorLog { get; }
    }
}
