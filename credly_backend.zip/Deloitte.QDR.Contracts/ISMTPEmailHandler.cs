﻿using Deloitte.QDR.DTO.Common;

namespace Deloitte.QDR.Contracts
{
    public interface ISMTPEmailHandler
    {
        Task<bool> SendEmailAsync(MailData mailData);
    }
}
