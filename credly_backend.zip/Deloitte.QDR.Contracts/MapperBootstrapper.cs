﻿using AutoMapper;
using Deloitte.QDR.DTO;
using Deloitte.QDR.DTO.Common;

namespace Deloitte.QDR.Contracts
{
    public static class MapperBootstrapper
    {
        public static MapperConfiguration MapperConfiguration { get; private set; }

        public static void Bootstrap()
        {
            MapperConfiguration = new MapperConfiguration(cfg =>
            {
                cfg.CreateMap<Entities.Employee, Employee>()
                    .ForMember(dest => dest.Roles,
                        opt =>
                            opt.MapFrom(src => src.EmployeeRoles)
                    )
                    ;
                cfg.CreateMap<Employee, Entities.Employee>();

                cfg.CreateMap<Entities.EmployeeRole, EmployeeRole>()
                .ForMember(dest => dest.Name, opt => opt.MapFrom(src => src.Employee.LastName + ", " + src.Employee.FirstName))
                .ForMember(dest => dest.Email, opt => opt.MapFrom(src => src.Employee.Email));

                cfg.CreateMap<EmployeeRole, Entities.EmployeeRole>();

                cfg.CreateMap<Entities.Role, Role>();
                cfg.CreateMap<Role, Entities.Role>();

                cfg.CreateMap<Entities.UserActivity, UserActivity>();
                cfg.CreateMap<UserActivity, Entities.UserActivity>();

                cfg.CreateMap<Entities.BadgeTemplate, BadgeTemplate>();
                cfg.CreateMap<BadgeTemplate, Entities.BadgeTemplate>();
                cfg.CreateMap<
                    Entities.Queries.BadgeTemplateQuery,
                    DTO.Queries.BadgeTemplateQuery
                >();

                cfg.CreateMap<Entities.Badge, Badge>()
                    .ForMember(d => d.Eminence,opt => opt.MapFrom(src => src.Exposure))
                    .ForMember(d => d.EminenceApprovedAt,opt => opt.MapFrom(src => src.ExposureApprovedAt))
                    .ForMember(d => d.BadgeTemplateStatus,opt => opt.MapFrom(src => src.BadgeTemplate.Status));
                cfg.CreateMap<Badge, Entities.Badge>()
                    .ForMember(d => d.Exposure,opt => opt.MapFrom(src => src.Eminence))
                    .ForMember(d => d.ExposureApprovedAt,opt => opt.MapFrom(src => src.EminenceApprovedAt));

                cfg.CreateMap<Entities.Queries.BadgeQuery, DTO.Queries.BadgeQuery>();

                cfg.CreateMap<Entities.Skill, Skill>();
                cfg.CreateMap<Skill, Entities.Skill>();

                cfg.CreateMap<Entities.Notification, Notification>();
                cfg.CreateMap<Notification, Entities.Notification>();

                cfg.CreateMap<Entities.BadgeTemplateSkill, BadgeTemplateSkill>()
                    .ForMember(d => d.Proficiency,
                        opt => opt.MapFrom(src => src.Proficiency))
                    .ForMember(d => d.SkillName,
                        opt => opt.MapFrom(src => src.Skill.Description));

                cfg.CreateMap<Entities.BadgeTemplateCriteria, BadgeTemplateCriteria>();

                cfg.CreateMap<Entities.Education, Education>()
                    .ForMember(d => d.FileName,
                        opt => opt.MapFrom(src => src.Upload.Substring(src.Upload.LastIndexOf("/") + 1))
                    );
                cfg.CreateMap<Education, Entities.Education>();

                cfg.CreateMap<Entities.Experience, Experience>()
                    .ForMember(d => d.FileName,
                        opt => opt.MapFrom(src => src.Upload.Substring(src.Upload.LastIndexOf("/") + 1))
                    );
                cfg.CreateMap<Experience, Entities.Experience>();

                cfg.CreateMap<Entities.Exposure, Exposure>()
                    .ForMember(d => d.FileName,
                        opt => opt.MapFrom(src => src.Upload.Substring(src.Upload.LastIndexOf("/") + 1))
                    );
                cfg.CreateMap<Exposure, Entities.Exposure>();

                cfg.CreateMap<Entities.AwardingProcess, AwardingProcess>();
                cfg.CreateMap<AwardingProcess, Entities.AwardingProcess>();

                cfg.CreateMap<Entities.BadgeTemplateCollection, BadgeTemplateCollection>()
                    .ForMember(d => d.Name,
                        opt => opt.MapFrom(src => src.Collection.Name)
                    )
                    .ForMember(d => d.Description,
                        opt => opt.MapFrom(src => src.Collection.Description)
                    )
                    .ForMember(d => d.OwnerId,
                        opt => opt.MapFrom(src => src.Collection.Owner.PersonID)
                    );

                cfg.CreateMap<Entities.Faq, Faq>();
                cfg.CreateMap<Faq, Entities.Faq>();
                cfg.CreateMap<Entities.FaqCategory, Category>();
                cfg.CreateMap<Category, Entities.FaqCategory>();

                cfg.CreateMap<Entities.Collection, Collection>()
                    .ForMember(d => d.NumberOfBadges,
                        opt => opt.MapFrom(src => src.BadgeTemplatesCollections.Count())
                    )
                    .ForMember(d => d.BadgeTemplates,
                        opt => opt.MapFrom(src => src.BadgeTemplatesCollections.Select(x => x.BadgeTemplate).ToList())
                    );
                cfg.CreateMap<Collection, Entities.Collection>();

                cfg.CreateMap<Entities.BadgeTemplateCriteriaType, BadgeTemplateCriteriaType>();
                cfg.CreateMap<BadgeTemplateCriteriaType, Entities.BadgeTemplateCriteriaType>();

                cfg.CreateMap<Entities.Employee, UserSession>()
                    .ForMember(d => d.Roles,
                        opt => opt.MapFrom(src => src.EmployeeRoles.Select(x=>x.Role.Code).ToList())
                    );

                cfg.CreateMap<Entities.BadgePathway, BadgePathway>()
                    .ForMember(d => d.BadgeTemplatesData,
                        opt => opt.MapFrom(src => src.BadgeTemplates.Select(x => x.BadgeTemplate)))
                    .ForMember(d => d.Skills,
                        opt => opt.MapFrom(src => src.Skills.Select(x => x.Skill.Description)));

                cfg.CreateMap<Entities.ErrorLog, ErrorLog>();
                cfg.CreateMap<ErrorLog, Entities.ErrorLog>();
            });
        }
    }
}
