﻿namespace Deloitte.QDR.Contracts
{
    public interface IDataCache
    {
        T Get<T>(string key);
        Task<T> GetAsync<T>(string key);
        IList<T> GetAll<T>();
        void InsertOrUpdate<T>(string key, T value, int expirationHours = 24);
        void Delete<T>(string key);
        void Bulk<T>(IList<T> values);
    }
}
