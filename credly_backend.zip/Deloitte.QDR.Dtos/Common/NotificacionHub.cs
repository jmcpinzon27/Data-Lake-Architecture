﻿namespace Deloitte.QDR.DTO.Common;

public class NotificacionHub
{
    public string? Type { get; set; }
    public string? Title { get; set; }
    public string? Description { get; set; }
    public string? EntityType { get; set; }
    public string? ActivityType { get; set; }
    public string? EntityId { get; set; }
    public string NotificationId { get; set; }
}