﻿namespace Deloitte.QDR.DTO.Common
{
    public class ValidationException : Exception
    {
        public Result Result { get; set; }

        public ValidationException(Result result)
            : base("Validation exception")
        {
            Result = result;
        }
    }
}
