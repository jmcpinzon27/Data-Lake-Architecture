﻿using Microsoft.AspNetCore.Mvc;

namespace Deloitte.QDR.DTO.Common
{
    [Bind("Id","Status","Feedback")]
    public class TransitionStatus
    {
        public Guid Id { get; set; }
        public string Status { get; set; }
        public string Feedback { get; set; } = string.Empty;
    }
}
