﻿using Deloitte.QDR.Entities;

namespace Deloitte.QDR.DTO.Common
{
    public static class GeneralConstants
    {
        public static class ErrorMessages
        {
            #region BADGE

            public const string BADGE_INVALID = "The badge provided not exists, or some information is not valid. Suggestion solution: verify the submmited badge id exist and have correct information and try again.";
            public const string BADGE_STATUS_WRONG_STATUS_FLOW = "The transition is not allowed: The current status of badge is {0} and can not be changed for {1}.";
            public const string BADGE_STATUS_CURRENT_EMPTY = "The transition is not allowed: The current status is empty.";
            public const string BADGE_ALREADY_EXIST = "This badge is already assigned to your user.";
            public const string BADGE_EDUCATIONS_REQUIRED = "This Badge must have at least {0} educations.";
            public const string BADGE_EXPERIENCE_REQUIRED = "This Badge must have at least {0} experience.";
            public const string BADGE_EMINENCE_REQUIRED = "This Badge must have at least {0} eminence.";
            public const string BADGE_EDUCATIONS_FIELDS_REQUIRED = "The education with title '{0}' is missing required fields.";
            public const string BADGE_EXPERIENCE_FIELDS_REQUIRED = "The experience with title '{0}' is missing required fields.";
            public const string BADGE_EMINENCE_FIELDS_REQUIRED = "The eminence with title '{0}' is missing required fields.";
            public const string BADGE_EXPERIENCE_HANDLER_FAILED = "The experience handler can't be procesed";
            public const string CONTENT_UPLOADFILE_CONVERT_FAILED = "The content file could not be procesed. Suggestion: check file structure and make sure it contains valid data.";
            public const string BADGE_EDUCATION_SABA_COURSEID_EMPTY = "The course id is required.";
            public const string BADGE_INCONSISTENT_DATA_FOR_BADGETEMPLATE = "The badge does not have approvers assigned.";
            #endregion BADGE

            #region BADGE-TEMPLATE

            public const string BADGE_TEMPLATE_WITH_OUT_EXTERNALID = "The badge template not have an external id.";
            public const string BADGE_TEMPLATE_STATUS_NOT_VALID = "The badge template not have a correctly status for credly portal.";
            public const string BADGE_TEMPLATE_WRONG_STATUS_FLOW = "The transition is not allowed: The current status of badge template is {0} and can not be changed for {1}.";
            public const string BADGE_TEMPLATE_STATUS_CURRENT_EMPTY = "The transition is not allowed: The current status is empty.";
            public const string BADGE_TEMPLATE_CRITERIAS_EMPTY = "Badge template must have at least 1 criteria.";
            public const string BADGE_TEMPLATE_CRITERIAS_WITHOUT_NAME = "There are criteria without name.";
            public const string BADGE_TEMPLATE_CRITERIAS_WITHOUT_TYPE = "There are criteria without criteria type.";
            public const string BADGE_TEMPLATE_SKILLS_MINIMUM = "Badge template must have at least 3 core skills.";
            public const string BADGE_TEMPLATE_LOGO_EMPTY = "The badge template logo is required.";
            public const string BADGE_TEMPLATE_LOGO_BAD_RESULT = "The badge template logo can´t be proccess. Error: {0}";
            public const string BADGE_TEMPLATE_INVALID = "The badge template provided not exists. Suggestion solution: verify the submmited badge template id and try again.";
            public const string BADGE_TEMPLATE_DELETION_FAILED = "The badge template has not an Id releated in credly";
            public const string BADGE_TEMPLATE_SKILLS_DUPLICATED = "The badge template must have all its skill names with different values.";
            public const string BADGE_TEMPLATE_ALREADY_EXIST = "The badge template with the name '{0}' already exist, please check.";
            public const string BADGE_TEMPLATE_STATUS_NOT_RELEASENOTES = "Can't set the release notes because the status is not hide for edit.";
            public const string BADGE_TEMPLATE_WITH_OUT_OWNERID = "The badge template has no owner id.";
            public const string BADGE_TEMPLATE_FAILED_SAVE_SKILL = "This Skill {0} has an error while be created. Error: {1} "; 
            public const string BADGE_TEMPLATE_DELETE_CRITERIAS_NOT_ALLOWED = "You cannot delete these criterias due to badge template current status";
            public const string BADGE_TEMPLATE_INVLID_ACTION = "Sorry, the badge template couldn't be approved due to an internal error. Please try again and if the problem persist contact your administrator";
            public const string BADGE_TEMPLATE_FAILED_CREATE_IN_CREDLY = "Sorry, the badge template couldn't be created in Credly. Please try again and if the problem persist contact your administrator";
            public const string BADGE_TEMPLATE_REQUIERED_NO_ALTERNATIVE_CRITERIA = "To create the badge template you need to enter at least one standard criteria. Please review the information entered and try again.";
            public const string BADGE_TEMPLATE_HAVE_CRITERIA_TYPE = "To create the badge template please select a Criteria type for all the criteria entered";
            public const string BADGE_TEMPLATE_CRITERIA_NAME_NULL = "This badge template can't be unhide because it has at least one criteria name empty. Please fill all the criteria names and try again";
            public const string BADGE_TEMPLATE_CRITERIA_INVALID_DATA = "To create the badge template, please select a criteria type for all the criteria entered.";
            public const string BADGE_TEMPLATE_CRITERIA_BROKEN_LOGO = "This badge template couldn't be unhidden because the logo file can't be processed. Please update the logo file and try again. If the problem persists, contact your administrator";
            #endregion BADGE-TEMPLATE

            #region EMPLOYEE

            public const string EMPLOYEE_FILTER_WITHOUT_ROLE = "No role was sent to filter.";
            public const string EMPLOYEE_FILTER_PRACTITIONER_NOT_ALLOWED = "The practitioner role is not allowed on the filter.";
            public const string EMPLOYEE_NOT_USER_EMAIL = "The system can not get the user email, check if you have a valid Credly connection.";

            #endregion EMPLOYEE

            #region EMPLOYEE-ROLE

            public const string ROLE_ALREADY_EXISTS = "This person has already been assigned this role";
            public const string ROLE_CANNOT_REMOVED = "The action cannot be completed due the practitioner role cannot be removed from the user.";
            public const string ROLE_NOT_EXISTS = "The action cannot be completed due the role has not been assigned this user.";
            public const string ROLE_INCONSISTENT = "The user information roles is incorrect. Suggested solution: clean the role information for this user.";
            public const string ROLE_EMPLOYEE_ROLE_EMPTY = "The user has not a default role. Suggested solution: add the role practitioner to this user.";
            public const string ROLE_INVALID = "The role provided not exists. Suggestion solution: verify the submmited role id and try again.";
            public const string ROLE_EMPLOYEE = "This Person has been removed.";

            #endregion EMPLOYEE-ROLE

            #region NOTIFICATIONS-CONFIG

            public const string NOTIFICATIONS_CONFIG = "System cannot find an valid entry for notification service. Suggested solution: Check basic parametrization for notifications.";
            public const string NOTIFICATIONS_NOT_EMAIL = "Not exists any email to send the notification.";


            #endregion NOTIFICATIONS-CONFIG

            #region AWARDING-PROCESS

            public const string AWARDING_PROCESS_INVALID = "The awarding process provided not exists. Suggestion solution: verify the submmited awarding process id and try again.";
            public const string UPLOAD_EMPTY_FILE = "The content file is empty. Suggestion: Please upload a different file.";

            #endregion AWARDING-PROCESS

            #region BULKTEMP

            public const string USER_CREATE_IS_ACTIVE_NULL = "This user can't be created, you need to specify if is active or not";

            #endregion BULKTEMP

            #region EmailValidation

            public const string EMAIL_VALIDATION_NOT_EXIST = "The email must be a valid Deloitte email. Suggestion solution: check the email and replace it with a valid Deloitte email.";
            public const string EMAIL_VALIDATION_NOT_BODYCONTENT = "The email template has no a valid content. Suggestion solution: check the html email content for the registered file template.";
            public const string EMAIL_VALIDATION_FILE_NOTFOUND = "The email file template was not found. Suggestion solution: check the email html file template exists.";

            #endregion EmailValidation

            #region FEEDBACK

            public const string MAX_FEEDBACK_LENGTH = "The feedback text exceeds maximum limit";
            public const string FEEDBACK_REQUIRED = "The feedback is required.";
            public const string FEEDBACK_SANITIZER = "The feedback content is not valid.";

            #endregion FEEDBACK

            #region BLOBSTORAGE

            public const string IDBLOB_IS_REQUIRED = "The Id Blob is required.";

            #endregion BLOBSTORAGE

            #region BADGE_PATHWAY

            public const string BADGE_PATHWAY_ALREADY_EXISTS = "The Badge Pathway with the name '{0}' already exists.";
            public const string BADGE_PATHWAY_LOGO_REQUIRED = "The Badge Pathway logo is required.";
            public const string BADGE_PATHWAY_INVALID = "The badge pathway provided not exists. Suggestion solution: verify the submmited badge pathway id and try again.";

            #endregion

            #region WEBHOOKS

            public const string WEBHOOKS_INVALID_PAYLOAD = "The submitted payload is not a valid json object. Suggestion solution: check the payload message";

            #endregion WEBHOOKS

            #region AUTHORIZATION

            public const string AUTHORIZATION_APIKEY_MISSING = "The apikey is missing. Suggestion solution: check the apikey value.";

            #endregion AUTHORIZATION

            #region CREDLY

            public const string CREDLY_PARAMETRIZATION_MISSING = "The parametrization for the organizations is missing.";
            public const string CREDLY_ORGANIZATION_NOT_SET = "The organization is not setted.";
            public const string CREDLY_ORGANIZATION_FOR_EMPLOYMENT_VAULT_ERROR = "There is an issue getting data from vault.";

            #endregion

            #region EMAIL

            public const string EMAIL_ERROR_METHOD_NAME = "SendEmail";

            #endregion
        }

        public static class Badge
        {
            public const string BADGE_NOT_HAVE_EMPLOYEE = "The badge not have an employee associated.";
            public const string BADGE_EMPLOYEE_INVALID_EMAIL = "The employee associated have a invalid email.";
            public const string BADGE_BADGETEMPLATE_INVALID_EXTERNALID = "The badge template associated have a invalid credly id.";
            public const string BADGE_TOBEARCHIVEDATE_STATUS = "ToBeArchiveDate";
            public const string BADGE_TOBEARCHIVENODATE_STATUS = "ToBeArchiveNoDate";
            public const string BADGE_HASBEENARCHIVED_STATUS = "HasBeenArchived";
            public const string BADGE_AWARDEDTOBEARCHIVED_STATUS = "AwardedToArchived";
            public const string EMAIL_BUTTON_LABEL_ON_APPROVED_BADGE = "Go to Credly!";
            public const string EMAIL_BUTTON_LABEL_OTHER_CASES = "Go to the <br> Deloitte Certified Platform";
        }

        public static class Feedback
        {
            public const int MAX_FEEDBACK_LENGHT = 500;
        }

        public static class UserActivity
        {
            public const string BADGE_TEMPLATE_CHANGE_STATUS_TITLE = "Change Status";
            public const string BADGE_TEMPLATE_CHANGE_STATUS_DESC = "The badge template status change for {0}.";
            public const string BADGE_TEMPLATE_CREATE_TITLE = "Badge template created";
            public const string BADGE_TEMPLATE_CREATE_DESC = "A badge template was created.";
            public const string BADGE_TEMPLATE_UPDATE_TITLE = "Badge template updated";
            public const string BADGE_TEMPLATE_UPDATE_DESC = "A badge template was updated.";
            public const string BADGE_TEMPLATE_DELETE_TITLE = "Badge template deleted";
            public const string BADGE_TEMPLATE_DELETE_DESC = "A badge template was deleted.";
            public const string USER_FIRST_TIME_LOGIN_TITLE = "User First Login";
            public const string USER_FIRST_TIME_LOGIN_DESC = "The user has logged in for the first time";
            public const string BADGE_TEMPLATE_CHANGE_PRIVACY = "The badge template has been changed his privacy";
            public const string BADGE_TEMPLATE_CHANGE_PRIVACY_DESC = "The badge template privacy change for {0}.";
        }

        public static class Common
        {
            public const string FORMAT_GUID_TO_STRING = "D";
            public const string CREDLY_DATETIME_FORMAT = "yyyy-MM-dd HH:mm:ss zzz";
            public const string HEADER_DATA_IS_FROM_CACHE = "DataFromCache";
            public const string HEADER_DATA_SOURCE_CACHE = "SourceCache";
        }

        public static class Education
        {
            public const string STORAGE_PREFIX = "education";
        }

        public static class Experience
        {
            public const string STORAGE_PREFIX = "experience";
        }

        public static class Exposure
        {
            public const string STORAGE_PREFIX = "exposure";
        }

        public static class AwardingProcess
        {
            public const string STORAGE_PREFIX = "awardingprocess";
            public const string ZIP_NAME = "awardingprocesszip";
            public const string CSV_NAME = "awardingprocesscsv";
        }

        public static class Role
        {
            public const string DEFAULT_CODE_ROLE = "Practitioner";
            public static string ADMIN_ROLE = "Admin";
            public static string BUSINES_REP_ROLE = "BusinessRep";
            public static IEnumerable<string> FILTER_EMPLOYEE = new List<string>() { ADMIN_ROLE, BUSINES_REP_ROLE };

            public static Dictionary<string, string> FILTER_DICTIONARY = new Dictionary<string, string>()
            {
                { "name", "Employee.LastName" },
                { "email", "Employee.Email" }
            };
        }

        public static class Collection
        {
            public const string FILTER_NUMBER_BADGESTEMPLATES = "numberOfBadges";
            public const string FILTER_ORDERBY_COLLECTION_TEXT = "collectionsText";
            public const string FILTER_COLUMN_COLLECTION_TEXT = "Collections";
        }

        public static class Notification
        {
            #region BADGE_TEMPLATE

            public const string SUCCESSFUL_SAVED = "SuccessfullySaved";
            public const string SUBMITTED_FOR_APPROVAL = "SubmittedForApproval";

            public static NotificacionHub BADGE_TEMPLATE_INPROGRESS_TO_ARCHIVED = new NotificacionHub
            {
                Type = NotificationType.Info.ToString(),
                Title = "A badge has been archived.",
                Description = "A Badge that you have been working on, has been archived by a Business Representative. This badge is no longer active, but can find similar badges like this one to start completing.",
                EntityType = EntityType.BadgeTemplate.ToString(),
                ActivityType = ActivityType.BadgeTemplateArchived.ToString()
            };

            public static NotificacionHub BADGE_TEMPLATE_AWARDED_TO_ARCHIVED = new NotificacionHub
            {
                Type = NotificationType.Info.ToString(),
                Title = "A badge awarded has been archived.",
                Description = "A Badge that you have been awarded, has been archived by a Business Representative. This badge is no longer active, but can find similar badges like this one to start completing on the Catalog.",
                EntityType = EntityType.BadgeTemplate.ToString(),
                ActivityType = ActivityType.BadgeTemplateArchived.ToString()
            };

            #endregion BADGE_TEMPLATE

            #region AWARDING_PROCESS

            public static NotificacionHub BULK_AWARD_SUBMITTED = new NotificacionHub
            {
                Type = NotificationType.Info.ToString(),
                Title = "Bulk award submitted",
                Description = "The Cohort ID {0} has been submitted for approval.",
                EntityType = EntityType.AwardingProcess.ToString(),
                ActivityType = ActivityType.AwardingProcessSubmitted.ToString()
            };

            #endregion AWARDING_PROCESS
        }

        public static class KeyVault
        {
            public const string SECRET_BLOBSTORAGECONNECTIONSTRING = "BlobStorageConnectionString";
            public const string SECRET_CLIENTID = "Clientid";
            public const string SECRET_CLIENTSECRET = "ClientSecret";
            public const string SECRET_CREDLYURLBASE = "CredlyUrlBase";
            public const string SECRET_DOMAINNAME = "DomainName";
            public const string SECRET_REDISCONNECTIONSTRING = "RedisConnectionString";
            public const string SECRET_SQLDBCONNECTIONSTRING = "SqlDbConnectionString";
            public const string SECRET_TENANTID = "Tenantid";
            public const string SECRET_SENDER_EMAIL = "SenderEmail";
            public const string SECRET_SENDER_NAME = "SenderName";
            public const string SECRET_SERVER = "Server";
            public const string SECRET_PORT = "Port";
            public const string SECRET_SERVICEBUSCONNECTIONSTRING = "ServiceBusConnString";
            public const string SECRET_SERVICEBUSQUEUENAME = "ServiceBusQueue";
            public const string SECRET_CREDLYORGANIZATION_BADGETEMPLATE = "CredlyOrganizationBadgeTemplate";
            public const string SECRET_CREDLYAUTH_BADGETEMPLATE = "CredlyAuthorizationBadgeTemplate";
            public const string SECRET_CREDLYORGANIZATION_BADGE = "CredlyOrganizationBadge";
            public const string SECRET_CREDLYAUTH_BADGE = "CredlyAuthorizationBadge";
            public const string SECRET_CREDLYAUTH_EMPLOYMENT = "EmployeeWebhooksToken";
            public const string SECRET_CREDLYORGANIZATION_EMPLOYMENT = "EmployeeWebhooksOrg";
        }

        public static class BadgeTemplateCriteriaType
        {
            public const string TYPE_FOR_EDUCATION = "Education Experience";
            public const string TYPE_FOR_EXPERIENCE = "Professional Experience";
            public const string TYPE_FOR_EMINENCE = "Other";
        }

        public static class BadgeTemplate
        {
            public const string BADGETEMPLATE_TOBEARCHIVEDATE_STATUS = "ToBeArchiveDate";
            public const string BADGETEMPLATE_TOBEARCHIVENODATE_STATUS = "ToBeArchiveNoDate";
            public const string BADGE_TEMPLATE_CONSTANT = "BadgeTemplate";
        }

        public static class Email
        {
            public const string LOGO_IMAGE_LINK = "assets/images/ImagesEmail/Logo/Logo.png";
            public const string API_BASE_URL = "api";
        }
    }
}
