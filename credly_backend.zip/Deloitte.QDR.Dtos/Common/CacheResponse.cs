﻿namespace Deloitte.QDR.DTO.Common;

public class CacheResponse<T>
{
    public bool IsCache { get; set; }
    public SourceCache SourceCache { get; set; }
    public T Data { get; set; }
}

public class CacheServiceResponse<T>
{
    public SourceCache SourceCache { get; set; }
    public T Data { get; set; }
}

public enum SourceCache
{
    DataBase = 0,
    Redis = 1,
    Memory = 2
}