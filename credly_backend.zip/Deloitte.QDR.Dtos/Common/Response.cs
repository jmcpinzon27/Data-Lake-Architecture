﻿namespace Deloitte.QDR.DTO.Common
{
    public class Response<T>
    {
        public Result Result { get; set; } = new Result();
        public T Data { get; set; }
    }
}
