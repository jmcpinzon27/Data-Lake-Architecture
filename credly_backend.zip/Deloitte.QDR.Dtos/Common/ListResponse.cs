﻿namespace Deloitte.QDR.DTO.Common
{
    public class ListResponse<T> : Response<IList<T>>
    {
        public int Count { get; set; }
    }
}
