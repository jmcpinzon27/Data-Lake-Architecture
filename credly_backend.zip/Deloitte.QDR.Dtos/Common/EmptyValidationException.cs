﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Deloitte.QDR.DTO.Common
{
    public class EmptyValidationException : Exception
    {
        public Result Result { get; set; }
        public EmptyValidationException(Result result)
                : base("Empty Validation exception")
        {
            Result = result;
        }
    }

}
