﻿namespace Deloitte.QDR.DTO.Common
{
    public class BlobFileInfo
    {
        public string IdBlob { get; set; } = string.Empty;
        public string Uri { get; set; } = string.Empty;
        public string NameFile { get; set; } = string.Empty;
        public string ContentType { get; set; } = string.Empty;
        public long? ContentLength { get; set; }
        public DateTimeOffset? LastModified { get; set; }
        public DateTimeOffset? CreatedOn { get; set; }
        public Stream Content { get; set; }
    }
}
