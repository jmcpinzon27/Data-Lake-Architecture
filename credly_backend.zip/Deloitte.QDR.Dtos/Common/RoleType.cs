﻿using System.ComponentModel;

namespace Deloitte.QDR.DTO.Common
{
    public enum RoleType
    {
        [Description("Admin")]
        Admin = 1,

        [Description("BusinessRep")]
        BusinessRep = 2,

        [Description("Practitioner")]
        Practitioner = 3
    }
}
