﻿namespace Deloitte.QDR.DTO.Common
{
    public class UserSession
    {
        public string? Email { get; set; }
        public string? PersonID { get; set; }
        public string? FirstName { get; set; }
        public string? LastName { get; set; }
        public List<string> Roles { get; set; } = new List<string>();
        public string? CredlyEmployeeState { get; set; }

        public bool IsAdmin
        {
            get { return Roles != null && Roles.Any(e => string.Equals(e.ToLower(), RoleType.Admin.ToString().ToLower())); }
        }

        public bool IsBusinnesRep
        {
            get { return Roles != null && Roles.Any(e => string.Equals(e.ToLower(), RoleType.BusinessRep.ToString().ToLower())); }
        }

        public bool IsPractitioner
        {
            get { return Roles != null && Roles.Any(e => string.Equals(e.ToLower(), RoleType.Practitioner.ToString().ToLower())); }
        }
    }
}