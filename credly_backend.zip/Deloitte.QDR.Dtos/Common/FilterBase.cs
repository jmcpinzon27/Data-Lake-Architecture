﻿using Microsoft.AspNetCore.Mvc;

namespace Deloitte.QDR.DTO.Common
{
    [Bind("SearchText", "PageSize", "PageIndex", "OrderBy", "FilterColumns")]
    public class FilterBase
    {
        public string? SearchText { get; set; }
        public int? PageSize { get; set; }
        public int? PageIndex { get; set; }
        public OrderBy? OrderBy { get; set; }
        public IList<FilterColumn> FilterColumns { get; set; } = new List<FilterColumn>();

    }

    [Bind("Roles", "SearchText", "PageSize", "PageIndex", "OrderBy", "FilterColumns")]
    public class FilterBaseWithRoles : FilterBase
    {
        public string? Roles { get; set; }
    }

    public class OrderBy
    {
        public string Column { get; set; }
        public bool Desc { get; set; }
        public bool NestedOrUnforced { get; set; } = false;
    }

    public class FilterColumn
    {
        public string Column { get; set; }
        public string Value { get; set; }
        public bool FreeText { get; set; }
        public bool Exclude { get; set; }
        public bool NestedOrUnforced { get; set; }
    }
}
