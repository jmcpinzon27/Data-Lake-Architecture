﻿using Microsoft.AspNetCore.Mvc;

namespace Deloitte.QDR.DTO.Common
{
    [Bind("Subject", "To", "BodyDescription", "BodyTitle", "ImagePath",
        "Link", "UseHtmlTemplate", "HtmlString")]
    public class NotificationEmailData
    {
        public string Subject { get; set; }
        public string To { get; set; }
        public string BodyDescription { get; set; }
        public string BodyTitle { get; set; }
        public string ImagePath { get; set; }
        public string Link { get; set; }
        public bool UseHtmlTemplate { get; set; }
        public string HtmlString { get; set; }
    }
}