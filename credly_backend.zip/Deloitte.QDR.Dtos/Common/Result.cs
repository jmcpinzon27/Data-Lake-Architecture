﻿namespace Deloitte.QDR.DTO.Common
{
    public class Result
    {
        public bool HasErrors { get; set; }
        public IList<string> Messages { get; set; } = new List<string>();
    }
}
