﻿namespace Deloitte.QDR.DTO.Common
{
    public enum Interval
    {
        Week = 1,
        Month,
        Quarter
    }
}
