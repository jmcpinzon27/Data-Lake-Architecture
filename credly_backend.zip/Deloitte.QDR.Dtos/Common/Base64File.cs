﻿using System.Text.Json.Serialization;
using System.Text.RegularExpressions;

namespace Deloitte.QDR.DTO.Common;

public class Base64File
{
    public string FileName { get; set; }
    public string Base64 { get; set; }

    [JsonIgnore]
    public string Extension
    {
        get
        {
            return Path.GetExtension(FileName);
        }
    }

    [JsonIgnore]
    public MemoryStream File
    {
        get
        {
            try
            {
                var onlyBase64Data = Base64.Substring(Base64.IndexOf(",") + 1);
                if (string.Equals(onlyBase64Data, "data:"))
                {
                    throw new EmptyValidationException(new Result());
                }
                                   
                return new MemoryStream(Convert.FromBase64String(onlyBase64Data));
            }
            catch (EmptyValidationException ex)
            {
                throw new ValidationException(new Result { Messages = new List<string>() { GeneralConstants.ErrorMessages.UPLOAD_EMPTY_FILE }, HasErrors = true });
            }
            catch (Exception ex)
            {                
                throw new ValidationException(new Result { Messages = new List<string>() { GeneralConstants.ErrorMessages.CONTENT_UPLOADFILE_CONVERT_FAILED }, HasErrors = true });
            }
        }
    }

    [JsonIgnore]
    public string ContentType
    {
        get
        {
            Regex rg = new Regex("^data:([a-zA-Z0-9]+/[a-zA-Z0-9]+).*,.*");
            return rg.Split(Base64)[1];
        }
    }

    [JsonIgnore]
    public bool HaveFile
    {
        get { return !string.IsNullOrWhiteSpace(Base64) && !string.IsNullOrWhiteSpace(FileName); }
    }
}
