﻿using System.ComponentModel.DataAnnotations;

namespace Deloitte.QDR.DTO.Common;

public class ReleaseNotes
{
    public Guid Id { get; set; }
    public bool ApplyOnlyInitiated { get; set; }
    [Required]
    public string Notes { get; set; }
}