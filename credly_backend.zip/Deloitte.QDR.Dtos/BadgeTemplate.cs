﻿using Deloitte.QDR.DTO.Common;
using Microsoft.AspNetCore.Mvc;

namespace Deloitte.QDR.DTO
{
    [Bind("Id", "Issuer", "ExternalId", "Name", "Subtitle", "Description", "LearningObjectives",
        "Type", "Level", "Status", "ImageUrl", "InfoUrl", "CreatedAt", "UpdateAt", "RetiredAt",
        "CreatedBy", "UpdatedBy", "ApprovedAt", "ApproverPersonID", "OwnerPersonID", "SponsorPersonID",
        "OptionalApproverPersonID", "LastFeedback", "Approver", "Owner", "Sponsor", "OptionalApprover",
        "ReviewDate", "ExpiresAt", "BadgeStatusForCurrentUser", "BadgeIdForCurrentUser", "Criterias",
        "Skills", "Collections", "Logo")]
    public class BadgeTemplate
    {
        public Guid? Id { get; set; }
        public string Issuer { get; set; }
        public string? ExternalId { get; set; }
        public string? Name { get; set; }
        public string? Subtitle { get; set; }
        public string? Description { get; set; }
        public string? LearningObjectives { get; set; }
        public string? Type { get; set; }
        public string? Level { get; set; }
        public string? Status { get; set; }
        public string? ImageUrl { get; set; }
        public string? InfoUrl { get; set; }
        public DateTime? CreatedAt { get; set; }
        public DateTime? UpdateAt { get; set; }
        public DateTime? RetiredAt { get; set; }
        public string? CreatedBy { get; set; }
        public string? UpdatedBy { get; set; }
        public DateTime? ApprovedAt { get; set; }
        public string? ApproverPersonID { get; set; }
        public string? OwnerPersonID { get; set; }
        public string? SponsorPersonID { get; set; }
        public string? OptionalApproverPersonID { get; set; }
        public string? LastFeedback { get; set; }
        public bool? IsPublic { get; set; }
        public bool? HaveAlternativeCriteria { get; set; }
        public string? AlternativeDescription { get; set; }

        public string? ReleaseNotes { get; set; }
        public bool? ApplyReleaseNotesOnlyInitiated { get; set; }

        public Employee? Approver { get; set; }
        public Employee? Owner { get; set; }
        public Employee? Sponsor { get; set; }
        public Employee? OptionalApprover { get; set; }

        public DateTime? ReviewDate { get; set; }
        public string? ExpiresAt { get; set; }
        public string? BadgeStatusForCurrentUser { get; set; }
        public Guid? BadgeIdForCurrentUser { get; set; }
        public DateTime? ArchiveDate { get; set; }

        public IList<DTO.BadgeTemplateCriteria> Criterias { get; set; } =
            new List<DTO.BadgeTemplateCriteria>();

        public IList<BadgeTemplateSkill> Skills { get; set; } =
            new List<BadgeTemplateSkill>();

        public IList<BadgeTemplateCollection> Collections { get; set; } =
            new List<BadgeTemplateCollection>();

        public Base64File? Logo { get; set; }
    }
}