﻿namespace Deloitte.QDR.DTO.Reports
{
    public class BadgesByPeriodReportItem
    {
        public DateTime Period { get; set; }
        public int BadgesCount { get; set; }
    }
}
