﻿namespace Deloitte.QDR.DTO.Reports
{
    public class AdminSummaryReport
    {
        public int BadgesApproved { get; set; }
        public int PendingBadges { get; set; }
        public int BadgesTemplatesReviewed { get; set; }
        public int BadgesTemplatesToReview { get; set; }
        public int UnreadBadgeTemplateNotifications { get; set; }
        public int UnreadBadgeNotifications { get; set; }
    }
}
