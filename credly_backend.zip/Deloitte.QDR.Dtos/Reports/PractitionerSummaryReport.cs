﻿namespace Deloitte.QDR.DTO.Reports
{
    public class PractitionerSummaryReport
    {
        public int DeloitteBadges { get; set; }
        public int ExternalBadges { get; set; }
        public int UnreadNotifications { get; set; }
        public int BadgesInProgress { get; set; }
        public int BadgesExpiringSoon { get; set; }
    }
}
