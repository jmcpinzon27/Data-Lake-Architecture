﻿namespace Deloitte.QDR.DTO.Queries
{
    public class BadgeTemplateQuery
    {
        public Guid Id { get; set; }
        public string? ExternalId { get; set; }
        public string? Issuer { get; set; }
        public bool IsExternal { get; set; }
        public string? Name { get; set; }
        public string? Subtitle { get; set; }
        public string? Description { get; set; }
        public string? Type { get; set; }
        public string? Level { get; set; }
        public string? Collections { get; set; }
        public string? Status { get; set; }
        public string? ImageUrl { get; set; }
        public string? InfoUrl { get; set; }
        public DateTime? CreatedAt { get; set; }
        public DateTime? UpdateAt { get; set; }
        public DateTime? RetiredAt { get; set; }
        public DateTime? ArchiveDate { get; set; }
        public string? CreatedByPersonID { get; set; }
        public string? CreatedByName { get; set; }
        public string? UpdatedByPersonID { get; set; }
        public DateTime? ApprovedAt { get; set; }
        public string? ApproverID { get; set; }
        public string? ApproverName { get; set; }
        public string? OwnerId { get; set; }
        public string? OwnerName { get; set; }
        public string? Skills { get; set; }
        public string? BadgeStatusForCurrentUser { get; set; }
        public Guid? BadgeIdForCurrentUser { get; set; }
        public bool? IsPublic { get; set; }
        public bool? HaveAlternativeCriteria { get; set; }
	public string? ReleaseNotes { get; set; }
    }
}
