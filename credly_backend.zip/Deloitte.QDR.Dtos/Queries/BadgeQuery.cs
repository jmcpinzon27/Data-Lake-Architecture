﻿namespace Deloitte.QDR.DTO.Queries
{
    public class BadgeQuery
    {
        public Guid Id { get; set; }
        public string? ExternalId { get; set; }
        public bool IsExternalCert { get; set; }
        public string? EmployeePersonID { get; set; }
        public string? EmployeeName { get; set; }
        public Guid? BadgeTemplateId { get; set; }
        public string? BadgeTemplateStatus { get; set; }
        public string? BadgeTemplateName { get; set; }
        public string? BadgeTemplateSubtitle { get; set; }
        public string? BadgeTemplateDescription { get; set; }
        public string? BadgeTemplateType { get; set; }
        public string? BadgeTemplateLevel { get; set; }
        public string? BadgeTemplateIssuer { get; set; }
        public string? BadgeTemplateCollection { get; set; }

        public string? BadgeTemplateApproverID { get; set; }
        public string? BadgeTemplateApproverName { get; set; }
        public bool? BadgeTemplateIsPublic { get; set; }

        public string? Status { get; set; }
        public DateTime? DecisionAt { get; set; }
        public DateTime? InitiatedAt { get; set; }
        public DateTime? AwardedAt { get; set; }
        public DateTime? ExpiresAt { get; set; }
        public DateTime? SubmittedAt { get; set; }
        public string? EducationStatus { get; set; }
        public DateTime? EducationApprovedAt { get; set; }
        public string? ExperienceStatus { get; set; }
        public DateTime? ExperienceApprovedAt { get; set; }
        public string? ExposureStatus { get; set; }
        public DateTime? ExposureApprovedAt { get; set; }
        public bool? AlternativeCriteriaSelected { get; set; }
    }
}
