﻿using System.ComponentModel.DataAnnotations;
using Deloitte.QDR.DTO.Common;
using Microsoft.AspNetCore.Mvc;

namespace Deloitte.QDR.DTO;

[Bind("Id", "Name", "OwnerId", "Image", "Description", "BadgeTemplatesIds", "Skills")]
public class BadgePathway
{
    public Guid? Id { get; set; }

    [StringLength(40)]
    [Required]
    public string Name { get; set; } = string.Empty;

    [StringLength(20)]
    [Required]
    public string OwnerId { get; set; } = string.Empty;
    public virtual Employee? Owner { get; set; }

    public string? ImageUrl { get; set; } = string.Empty;
    public Base64File? Logo { get; set; }

    [Required]
    public string Description { get; set; } = string.Empty;
    public DateTime? CreatedAt { get; set; }

    public IList<Guid>? BadgeTemplatesIds { get; set; }
    public IList<BadgeTemplate>? BadgeTemplatesData { get; set; }
    public IList<string>? Skills { get; set; }
}