﻿namespace Deloitte.QDR.DTO;

public class Category
{
    public Guid Id { get; set; }
    public string Description { get; set; }
    public int? Order { get; set; }
}