﻿using Deloitte.QDR.DTO.Common;
using System.ComponentModel.DataAnnotations;

namespace Deloitte.QDR.DTO
{
    public class Education
    {
        public Guid? Id { get; set; }
        public Guid? BadgeId { get; set; }
        public Guid? BadgeTemplateCriteriaId { get; set; }
        public BadgeTemplateCriteria? Criteria { get; set; }
        [StringLength(100)]
        public string? Title { get; set; }
        public DateTime? CompletionDate { get; set; }
        [StringLength(200)]
        public string? Vendor { get; set; }
        [StringLength(500)]
        public string? Description { get; set; }
        public string? Upload { get; set; }
        public string? FileName { get; set; }
        public Base64File? UploadBase64 { get; set; }
        [StringLength(300)]
        public String? Url { get; set; }
        public bool? IsAlternative { get; set; }
        public bool? SABACourseValidated { get; set; }
    }
}