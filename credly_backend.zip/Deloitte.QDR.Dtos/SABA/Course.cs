﻿using Newtonsoft.Json;

namespace Deloitte.QDR.DTO.SABA;

public class Course
{
    [JsonProperty("id")]
    public string Id { get; set; }
    [JsonProperty("name")]
    public string Name { get; set; }
    [JsonProperty("validate")]
    public bool Validated { get; set; }
}

