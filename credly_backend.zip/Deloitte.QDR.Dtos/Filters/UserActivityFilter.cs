using Deloitte.QDR.DTO.Common;
using Deloitte.QDR.Entities;
using Microsoft.AspNetCore.Mvc;

namespace Deloitte.QDR.DTO.Filters;

[Bind("Type", "From", "To", "PersonID", "BadgeTemplateId", "SearchText", "PageSize", "PageIndex", "OrderBy", "FilterColumns", "Roles")]
public class UserActivityFilter : FilterBaseWithRoles
{
    public ActivityType? Type { get; set; }
    public DateTime? From { get; set; }
    public DateTime? To { get; set; }
    public string? PersonID { get; set; }
    public Guid? BadgeTemplateId { get; set; }
}