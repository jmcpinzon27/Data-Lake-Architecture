using Deloitte.QDR.DTO.Common;
using Microsoft.AspNetCore.Mvc;

namespace Deloitte.QDR.DTO.Filters
{
    [Bind("Status", "Levels", "Skills", "ShowExternals", "SearchText", "PageSize", "PageIndex", "OrderBy", "FilterColumns")]
    public class BadgeTemplateFilter : FilterBase
    {
        public List<string> Status { get; set; } = new List<string>();
        public List<string> Levels { get; set; } = new List<string>();
        public List<string> Skills { get; set; } = new List<string>();
        public bool ShowExternals { get; set; }
    }
}
