using Deloitte.QDR.DTO.Common;
using Microsoft.AspNetCore.Mvc;

namespace Deloitte.QDR.DTO.Filters
{
    [Bind("PersonID", "RoleId", "SearchText", "PageSize", "PageIndex", "OrderBy", "FilterColumns", "Roles")]
    public class EmployeeRoleFilter : FilterBaseWithRoles
    {
        public string? PersonID { get; set; }
        public Guid? RoleId { get; set; }
    }
}
