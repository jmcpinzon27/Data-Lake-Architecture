using Deloitte.QDR.DTO.Common;
using Microsoft.AspNetCore.Mvc;

namespace Deloitte.QDR.DTO.Filters;

[Bind("From", "To", "PersonID", "Email", "Method"
    , "SearchText", "PageSize", "PageIndex", "OrderBy", "FilterColumns")]
public class ErrorLogFilter : FilterBase
{
    public DateTime? From { get; set; }
    public DateTime? To { get; set; }
    public string? PersonID { get; set; }
    public string? Email { get; set; }
    public Method? Method { get; set; }
}

public enum Method
{
    GET = 1,
    POST = 2,
    PUT = 3,
    DELETE = 4,
    PATCH = 5
}