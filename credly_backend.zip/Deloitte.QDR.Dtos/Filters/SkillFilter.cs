using Deloitte.QDR.DTO.Common;
using Microsoft.AspNetCore.Mvc;

namespace Deloitte.QDR.DTO.Filters;

[Bind("Status", "SearchText", "PageSize", "PageIndex", "OrderBy", "FilterColumns")]
public class SkillFilter : FilterBase
{
    public List<string> Status { get; set; } = new List<string>();
}