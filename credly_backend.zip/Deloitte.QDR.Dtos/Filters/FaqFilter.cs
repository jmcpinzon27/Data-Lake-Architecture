using Deloitte.QDR.DTO.Common;
using Microsoft.AspNetCore.Mvc;

namespace Deloitte.QDR.DTO.Filters;

[Bind("CategoryId", "SearchText", "PageSize", "PageIndex", "OrderBy", "FilterColumns")]
public class FaqFilter : FilterBase
{
    public Guid? CategoryId { get; set; }
}