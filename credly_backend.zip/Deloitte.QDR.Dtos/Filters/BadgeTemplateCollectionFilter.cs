using Deloitte.QDR.DTO.Common;
using Microsoft.AspNetCore.Mvc;

namespace Deloitte.QDR.DTO.Filters;

[Bind("BadgeTemplateId", "CollectionId", "SearchText", "PageSize", "PageIndex", "OrderBy", "FilterColumns")]
public class BadgeTemplateCollectionFilter : FilterBase
{
    public Guid? BadgeTemplateId { get; set; }
    public Guid? CollectionId { get; set; }
}