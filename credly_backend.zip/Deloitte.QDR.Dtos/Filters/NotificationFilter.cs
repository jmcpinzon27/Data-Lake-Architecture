using Deloitte.QDR.DTO.Common;
using Microsoft.AspNetCore.Mvc;

namespace Deloitte.QDR.DTO.Filters
{
    [Bind("Title", "Description", "StartDate", "EndDate", "Read", "PersonID", "EntityType", "SearchText", "PageSize", "PageIndex", "OrderBy", "FilterColumns")]
    public class NotificationFilter : FilterBase
    {
        public string? Title { get; set; }
        public string? Description { get; set; }
        public DateTime? StartDate { get; set; }
        public DateTime? EndDate { get; set; }
        public bool? Read { get; set; }
        public string? PersonID { get; set; }
        public IList<string> EntityType { get; set; } = new List<string>();
    }
}
