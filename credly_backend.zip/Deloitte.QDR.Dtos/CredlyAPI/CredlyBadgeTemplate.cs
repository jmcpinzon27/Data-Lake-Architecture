﻿using Newtonsoft.Json;

namespace Deloitte.QDR.DTO.CredlyAPI
{
    public class CredlyBadgeTemplate { }

    public class Message
    {
        [JsonProperty("id")]
        public Guid Id { get; set; }

        [JsonProperty("organization_id")]
        public string OrganizationId { get; set; }

        [JsonProperty("event_type")]
        public string EventType { get; set; }

        [JsonProperty("ocurred_at")]
        public string OcurredAt { get; set; }
    }

    public class BadgeTemplateCreatedEvent
    {
        [JsonProperty("id")]
        public Guid? Id { get; set; }

        [JsonProperty("organization_id")]
        public string? OrganizationId { get; set; }

        [JsonProperty("event_type")]
        public string? EventType { get; set; }

        [JsonProperty("ocurred_at")]
        public string? OcurredAt { get; set; }

        [JsonProperty("badge_template")]
        public BadgeTemplate BadgeTemplate { get; set; }
    }

    public class BadgeTemplate
    {
        [JsonProperty("id")]
        public Guid? Id { get; set; }

        [JsonProperty("description")]
        public string? Description { get; set; }

        [JsonProperty("level")]
        public string? Level { get; set; }

        [JsonProperty("name")]
        public string? Name { get; set; }

        [JsonProperty("state")]
        public string? State { get; set; }

        [JsonProperty("type_category")]
        public string? TypeCategory { get; set; }

        [JsonProperty("badge_template_activities")]
        public List<BadgeTemplateActivity> BadgeTemplateActivities { get; set; }

        [JsonProperty("skills")]
        public List<string> Skills { get; set; }

        [JsonProperty("image")]
        public BadgeTemplateImage Image { get; set; }

        [JsonProperty("owner")]
        public Owner Owner { get; set; }

        [JsonProperty("created_at")]
        public DateTime? CreatedAt;
    }

    public class BadgeTemplateActivity
    {
        [JsonProperty("title")]
        public string Title { get; set; }

        [JsonProperty("activity_type")]
        public string ActivityType { get; set; }
    }

    public class BadgeTemplateImage
    {
        [JsonProperty("remote_upload_url")]
        public string RemoteUploadUrl { get; set; }
    }

    public class BadgeTemplateChangedEvent
    {
        [JsonProperty("id")]
        public Guid Id { get; set; }

        [JsonProperty("organization_id")]
        public string OrganizationId { get; set; }

        [JsonProperty("event_type")]
        public string EventType { get; set; }

        [JsonProperty("ocurred_at")]
        public string OcurredAt { get; set; }

        [JsonProperty("badge_template")]
        public BadgeTemplate BadgeTemplate { get; set; }
    }

    public class BadgeTemplateDeletedEvent
    {
        [JsonProperty("id")]
        public Guid Id { get; set; }

        [JsonProperty("organization_id")]
        public string OrganizationId { get; set; }

        [JsonProperty("event_type")]
        public string EventType { get; set; }

        [JsonProperty("ocurred_at")]
        public string OcurredAt { get; set; }

        [JsonProperty("badge_template")]
        public BadgeTemplate BadgeTemplate { get; set; }
    }
}
