﻿using Newtonsoft.Json;

namespace Deloitte.QDR.DTO.CredlyAPI
{
    public class CredlyEmployee { }

    public class EmployeeConnectionRejectedEvent
    {
        [JsonProperty("id")]
        public Guid Id { get; set; }

        [JsonProperty("organization_id")]
        public string OrganizationId { get; set; }

        [JsonProperty("event_type")]
        public string EventType { get; set; }

        [JsonProperty("ocurred_at")]
        public string OcurredAt { get; set; }

        [JsonProperty("employment")]
        public Employment Employment { get; set; }
    }

    public class EmployeeConnectionAcceptedEvent
    {
        [JsonProperty("id")]
        public Guid Id { get; set; }

        [JsonProperty("organization_id")]
        public string OrganizationId { get; set; }

        [JsonProperty("event_type")]
        public string EventType { get; set; }

        [JsonProperty("ocurred_at")]
        public string OcurredAt { get; set; }

        [JsonProperty("employment")]
        public Employment Employment { get; set; }
    }

    public class EmployeeConnectionPendingEvent
    {
        [JsonProperty("id")]
        public Guid Id { get; set; }

        [JsonProperty("organization_id")]
        public string OrganizationId { get; set; }

        [JsonProperty("event_type")]
        public string EventType { get; set; }

        [JsonProperty("ocurred_at")]
        public string OcurredAt { get; set; }

        [JsonProperty("employment")]
        public Employment Employment { get; set; }
    }

    public class Employment
    {
        [JsonProperty("id")]
        public Guid Id { get; set; }

        [JsonProperty("email")]
        public string Email { get; set; }

        [JsonProperty("created_at")]
        public DateTime CreatedAt { get; set; }

        [JsonProperty("employee_state")]
        public string EmployeeState { get; set; }

        [JsonProperty("first_name")]
        public string FirstName { get; set; }

        [JsonProperty("last_name")]
        public string LastName { get; set; }
    }
}
