﻿using Newtonsoft.Json;
using System.Text.Json;

namespace Deloitte.QDR.DTO.CredlyAPI
{
    public class CredlyBadge { }

    public class BadgeCreatedEvent
    {
        [JsonProperty("id")]
        public Guid Id { get; set; }

        [JsonProperty("organization_id")]
        public string OrganizationId { get; set; }

        [JsonProperty("event_type")]
        public string EventType { get; set; }

        [JsonProperty("ocurred_at")]
        public string OcurredAt { get; set; }

        [JsonProperty("badge")]
        public Badge Badge { get; set; }
        [JsonProperty("employment")]
        public EmploymentInfo EmploymentInfo { get; set; }
    }

    public class BadgeDeletedEvent
    {
        [JsonProperty("id")]
        public Guid Id { get; set; }

        [JsonProperty("organization_id")]
        public string OrganizationId { get; set; }

        [JsonProperty("event_type")]
        public string EventType { get; set; }

        [JsonProperty("ocurred_at")]
        public string OcurredAt { get; set; }

        [JsonProperty("badge")]
        public Badge Badge { get; set; }
        [JsonProperty("employment")]
        public EmploymentInfo EmploymentInfo { get; set; }
    }

    public class BadgeStateChangedEvent
    {
        [JsonProperty("id")]
        public Guid Id { get; set; }

        [JsonProperty("organization_id")]
        public string OrganizationId { get; set; }

        [JsonProperty("event_type")]
        public string EventType { get; set; }

        [JsonProperty("ocurred_at")]
        public string OcurredAt { get; set; }

        [JsonProperty("badge")]
        public Badge Badge { get; set; }
        [JsonProperty("employment")]
        public EmploymentInfo EmploymentInfo { get; set; }
    }

    public class BadgePrivacyChangedEvent
    {
        [JsonProperty("id")]
        public Guid Id { get; set; }

        [JsonProperty("organization_id")]
        public string OrganizationId { get; set; }

        [JsonProperty("event_type")]
        public string EventType { get; set; }

        [JsonProperty("ocurred_at")]
        public string OcurredAt { get; set; }

        [JsonProperty("badge")]
        public Badge Badge { get; set; }
        [JsonProperty("employment")]
        public EmploymentInfo EmploymentInfo { get; set; }
    }

    public class Badge
    {
        [JsonProperty("id")]
        public Guid Id { get; set; }

        [JsonProperty("user")]
        public User User { get; set; }

        [JsonProperty("created_by")]
        public CreatedBy CreatedBy { get; set; }

        [JsonProperty("issuer")]
        public Issuer Issuer { get; set; }

        [JsonProperty("badge_template")]
        public NewBadgeTemplate BadgeTemplate { get; set; }

        [JsonProperty("image")]
        public Image Image { get; set; }

        [JsonProperty("is_private_badge")]
        public bool IsPrivateBadge { get; set; }

        [JsonProperty("state")]
        public string? State { get; set; }

        [JsonProperty("issued_at")]
        public DateTime? IssuedAt { get; set; }
        [JsonProperty("public")]
        public bool Private { get; set; }

    }

    public class EmploymentInfo
    {
        [JsonProperty("id")]
        public Guid? Id { get; set; }

        [JsonProperty("email")]
        public string? Email { get; set; }

        [JsonProperty("first_name")]
        public string? FirstName { get; set; }

        [JsonProperty("last_name")]
        public string? LastName { get; set; }
        [JsonProperty("external_id")]
        public string? PersonnelNumber { get; set; }
    }

    public class User
    {
        [JsonProperty("id")]
        public Guid? Id { get; set; }

        [JsonProperty("email")]
        public string? Email { get; set; }

        [JsonProperty("first_name")]
        public string? FirstName { get; set; }

        [JsonProperty("last_name")]
        public string? LastName { get; set; }
    }

    public class CreatedBy
    {
        [JsonProperty("type")]
        public string? Type { get; set; }

        [JsonProperty("id")]
        public Guid? Id { get; set; }

        [JsonProperty("name")]
        public string? Name { get; set; }
    }

    public class BadgeBadgeTemplate
    {
        [JsonProperty("id")]
        public Guid? Id { get; set; }

        [JsonProperty("description")]
        public string? Description { get; set; }

        [JsonProperty("level")]
        public string? Level { get; set; }

        [JsonProperty("name")]
        public string? Name { get; set; }

        [JsonProperty("Status")]
        public string? Status { get; set; }

        [JsonProperty("type_category")]
        public string? Type_Category { get; set; }

        [JsonProperty("created_at")]
        public DateTime? CreatedAt;
    }

    public class NewBadgeTemplate
    {
        [JsonProperty("id")]
        public Guid? Id { get; set; }
        [JsonProperty("image_url")]
        public string? ImageUrl {  get; set; }
        [JsonProperty("name")]
        public string? Name { get; set; }
        [JsonProperty("description")]
        public string? Description { get; set; }
    }

    public class Owner
    {
        [JsonProperty("id")]
        public Guid id { get; set; }

        [JsonProperty("name")]
        public string? Name { get; set; }
    }

    public class Image
    {
        [JsonProperty("id")]
        public Guid? Id { get; set; }

        [JsonProperty("url")]
        public string? Url { get; set; }
    }

    public class Issuer
    {
        [JsonProperty("type")]
        public string? Type { get; set; }

        [JsonProperty("id")]
        public Guid? Id { get; set; }

        [JsonProperty("name")]
        public string? Name { get; set; }
    }

    public class BadgePrivacyChanged
    {
        [JsonProperty("id")]
        public Guid Id { get; set; }

        [JsonProperty("organization_id")]
        public string OrganizationId { get; set; }

        [JsonProperty("event_type")]
        public string EventType { get; set; }

        [JsonProperty("ocurred_at")]
        public string OcurredAt { get; set; }

        [JsonProperty("badge")]
        public JsonDocument Badge { get; set; }
    }

    public class BadgeStateChanged
    {
        [JsonProperty("id")]
        public Guid Id { get; set; }

        [JsonProperty("organization_id")]
        public string OrganizationId { get; set; }

        [JsonProperty("event_type")]
        public string EventType { get; set; }

        [JsonProperty("ocurred_at")]
        public string OcurredAt { get; set; }

        [JsonProperty("badge")]
        public JsonDocument Badge { get; set; }
    }

    public class JsonDocument
    {
        [JsonProperty("primary_badge_template_id")]
        public Guid PrimaryBadgeTemplateId { get; set; }

        [JsonProperty("id")]
        public Guid Id { get; set; }

        [JsonProperty("description")]
        public string Description { get; set; }

        [JsonProperty("name")]
        public string Name { get; set; }

        [JsonProperty("state")]
        public string State { get; set; }

        [JsonProperty("variant_type")]
        public string VariantType { get; set; }
    }
}
