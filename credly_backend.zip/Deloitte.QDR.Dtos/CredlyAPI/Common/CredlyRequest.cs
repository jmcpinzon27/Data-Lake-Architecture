﻿namespace Deloitte.QDR.DTO.CredlyAPI.Common
{
    public class CredlyRequest { }
}
