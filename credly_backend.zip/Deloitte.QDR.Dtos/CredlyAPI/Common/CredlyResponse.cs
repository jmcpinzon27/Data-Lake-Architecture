﻿namespace Deloitte.QDR.DTO.CredlyAPI.Common
{
    public class CredlyResponse<T>
    {
        public T Data { get; set; }
        public CredlyMetadata Metadata { get; set; }
    }
}
