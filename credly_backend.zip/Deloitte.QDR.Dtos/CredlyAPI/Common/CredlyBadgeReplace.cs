﻿using Newtonsoft.Json;

namespace Deloitte.QDR.DTO.CredlyAPI.Common
{
    public class CredlyBadgeReplace
    {
        [JsonProperty("badge_id")]
        public Guid BadgeId { get; set; }

        [JsonProperty("badge_template_id")]
        public Guid BadgeTemplateId { get; set; }

        [JsonProperty("issued_at")]
        public DateTime IssuedAt { get; set; }

        [JsonProperty("issued_to")]
        public string IssuedTo { get; set; }

        [JsonProperty("issued_to_first_name")]
        public string IssuedToFirstName { get; set; }

        [JsonProperty("issued_to_last_name")]
        public string IssuedToLastName { get; set; }

        [JsonProperty("issuer_earner_id")]
        public string IssuerEarnerId { get; set; }

        [JsonProperty("expires_at")]
        public bool ExpiresAt { get; set; }

        [JsonProperty("country_name")]
        public string CountryName { get; set; }

        [JsonProperty("state_or_province")]
        public string StateOrProvince { get; set; }

        [JsonProperty("evidence")]
        public List<Evidence> Evidence { get; set; }

        [JsonProperty("notification_message")]
        public string NotificationMessage { get; set; }
    }

    public class Evidence
    {
        [JsonProperty("type")]
        public string Type { get; set; }

        [JsonProperty("value")]
        public string Value { get; set; }

        [JsonProperty("description")]
        public string Description { get; set; }

        [JsonProperty("name")]
        public string Name { get; set; }
    }
}
