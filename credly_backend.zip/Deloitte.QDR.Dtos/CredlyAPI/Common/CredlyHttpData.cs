﻿namespace Deloitte.QDR.DTO.CredlyAPI.Common;

public class CredlyHttpData
{
    public CredlyOrganizationData BadgeTemplate { get; set; }
    public CredlyOrganizationData Badge { get; set; }
    public CredlyOrganizationData Employment { get; set; }

}

public class CredlyOrganizationData
{
    public string Organization { get; set; }
    public string Authorization { get; set; }
}

public enum OrganizationFor
{
    BadgeTemplate = 1,
    Badge = 2,
    Employment = 3
}

