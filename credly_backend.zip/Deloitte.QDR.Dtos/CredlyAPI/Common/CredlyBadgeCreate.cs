﻿using Newtonsoft.Json;

namespace Deloitte.QDR.DTO.CredlyAPI.Common;

public class CredlyBadgeCreate
{
    [JsonProperty("recipient_email")]
    public string RecipientEmail { get; set; }

    [JsonProperty("badge_template_id")]
    public string BadgeTemplateId { get; set; }

    [JsonProperty("issued_at")]
    public DateTime IssuedAt { get; set; }

    [JsonProperty("issued_to_first_name")]
    public string? IssuedToFirstName { get; set; }

    [JsonProperty("issued_to_last_name")]
    public string? IssuedToLastName { get; set; }

    [JsonProperty("expires_at")]
    public DateTime? ExpiresAt { get; set; }

    [JsonProperty("issuer_earner_id")]
    public string? IssuerEarnerId { get; set; }

    [JsonProperty("locale")]
    public string? Locale { get; set; }

    [JsonProperty("suppress_badge_notification_email")]
    public bool SuppressBadgeNotificationEmail { get; set; }
}