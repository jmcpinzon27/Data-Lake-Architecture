﻿using Newtonsoft.Json;

namespace Deloitte.QDR.DTO.CredlyAPI.Common
{
    public class CredlyMetadata
    {
        [JsonProperty("count")]
        public int Count { get; set; }

        [JsonProperty("current_page")]
        public int CurrentPage { get; set; }

        [JsonProperty("total_count")]
        public int TotalCount { get; set; }

        [JsonProperty("total_pages")]
        public int TotalPages { get; set; }

        [JsonProperty("badgpere_id")]
        public int Per { get; set; }

        [JsonProperty("previous_page_url")]
        public string PreviousPageUrl { get; set; }

        [JsonProperty("next_page_url")]
        public string NextPageUrl { get; set; }
    }
}
