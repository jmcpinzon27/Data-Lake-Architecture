﻿using Newtonsoft.Json;

namespace Deloitte.QDR.DTO.CredlyAPI.Common;

public class CredlyError
{
    [JsonProperty("message")]
    public string Message { get; set; }
    [JsonProperty("errors")]
    public List<CredlyAttributeErrors> Errors { get; set; }

    public List<string> GetFullErrors()
    {
        var errors = new List<string>();
        if (Errors != null && Errors.Any())
        {
            errors.Add($"Credly's service have {Errors.Count} errors:");
            foreach (var error in Errors)
            {
                errors.Add($"Attribute: {error.Attribute}, Message: {string.Join(". ", error.Messages)}");
            }
        }
        else
        {
            errors.Add($"Credly's service error: {Message}");
        }

        return errors;
    }
}

public class CredlyAttributeErrors
{
    [JsonProperty("attribute")]
    public string Attribute { get; set; }
    [JsonProperty("messages")]
    public List<string> Messages { get; set; }
}