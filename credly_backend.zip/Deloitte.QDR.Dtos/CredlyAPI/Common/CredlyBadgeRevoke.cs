﻿using Newtonsoft.Json;

namespace Deloitte.QDR.DTO.CredlyAPI.Common;

public class CredlyBadgeRevoke
{
    [JsonProperty("badge_id")]
    public Guid BadgeId { get; set; }

    [JsonProperty("reason")]
    public string Reason { get; set; }

    [JsonProperty("suppress_revoke_notification_email")]
    public bool SuppressRevokeNotificationEmail { get; set; }
}
