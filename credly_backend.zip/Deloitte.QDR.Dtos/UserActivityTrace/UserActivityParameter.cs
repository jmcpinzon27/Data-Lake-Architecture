﻿using Deloitte.QDR.Entities;

namespace Deloitte.QDR.DTO.UserActivityTrace
{
    public class UserActivityParameter
    {
        public string Description { get; set; }
        public ActivityType ActivityType { get; set; }
        public EntityType EntityType { get; set; }
        public string EntityStatus { get; set; }
    }
}