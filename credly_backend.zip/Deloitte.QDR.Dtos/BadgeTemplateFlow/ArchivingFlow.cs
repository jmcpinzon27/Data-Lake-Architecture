﻿namespace Deloitte.QDR.DTO.BadgeTemplateFlow
{
    public class ArchivingFlow
    {
        public Guid BadgeTemplateId { get; set; }
        public string Status { get; set; }
        public DateTime? ArchiveDate { get; set; }
        public bool? Result { get; set; }
    }
}