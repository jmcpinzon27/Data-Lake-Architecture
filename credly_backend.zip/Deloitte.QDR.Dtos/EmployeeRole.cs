﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.ModelBinding;

namespace Deloitte.QDR.DTO
{
    [Bind("Name", "Email", "StartDate")]
    public class EmployeeRole : EmployeeRoleBase
    {
        public string? Name { get; set; }
        public string? Email { get; set; }

        [BindRequired]
        public string? RoleCode { get; set; }

        public DateTime? StartDate { get; set; }

        [BindNever]
        public virtual Role? Role { get; set; }
    }
}