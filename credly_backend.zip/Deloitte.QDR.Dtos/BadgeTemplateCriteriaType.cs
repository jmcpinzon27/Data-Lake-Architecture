﻿namespace Deloitte.QDR.DTO;

public class BadgeTemplateCriteriaType
{
    public Guid? Id { get; set; }
    public string? Description { get; set; }
}