﻿namespace Deloitte.QDR.DTO;

    public class Skill
    {
        public Guid? Id { get; set; }
        public string Description { get; set; }
    }