﻿using Deloitte.QDR.DTO.Common;
using System.ComponentModel.DataAnnotations;

namespace Deloitte.QDR.DTO
{
    public class Experience
    {
        public Guid? Id { get; set; }
        public Guid? BadgeId { get; set; }
        public Guid? BadgeTemplateCriteriaId { get; set; }
        public string? WBSCode { get; set; }
        public int? Hours { get; set; }
        [DataType(DataType.EmailAddress)]
        [EmailAddress]
        [StringLength(200)]
        public string? ValidatorEmail { get; set; }
        [StringLength(500)]
        public string? Description { get; set; }
        [StringLength(100)]
        public string? Title { get; set; }
        public string? Upload { get; set; }
        public string? FileName { get; set; }
        public Base64File? UploadBase64 { get; set; }
        public String? Url { get; set; }
        public bool? IsAlternative { get; set; }
    }
}