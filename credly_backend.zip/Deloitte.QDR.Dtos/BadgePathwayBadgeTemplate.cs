﻿namespace Deloitte.QDR.DTO;

public class BadgePathwayBadgeTemplate
{
    public Guid Id { get; set; }
    
    public Guid BadgePathwayId { get; set; }
    public virtual BadgePathway BadgePathway { get; set; }

    public Guid BadgeTemplateId { get; set; }
    public virtual BadgeTemplate BadgeTemplate { get; set; }
}