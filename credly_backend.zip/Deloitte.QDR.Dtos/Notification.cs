﻿namespace Deloitte.QDR.DTO
{
    public class Notification
    {
        public Guid Id { get; set; }
        public DateTime? Date { get; set; }
        public string? Title { get; set; }
        public string? Description { get; set; }
        public string? Detail { get; set; }
        public string? EntityType { get; set; }
        public string? EntityId { get; set; }
        public string? EmployeePersonID { get; set; }
        public Employee? Employee { get; set; }
        public bool? Read { get; set; }
        public DateTime? ReadDate { get; set; }
        public string? Status { get; set; }
    }
}
