﻿using Newtonsoft.Json;
using System.ComponentModel.DataAnnotations;
using Microsoft.AspNetCore.Mvc.ModelBinding;

namespace Deloitte.QDR.DTO
{
    public class Employee
    {
        public string? PersonID { get; set; }
        public string? PersonnelNumber { get; set; }
        public string? PreferredFirstName { get; set; }
        public string? BusinessDesc { get; set; }
        public string? BusinessAreaDesc { get; set; }
        public string? FirstName { get; set; }
        public string? MiddleName { get; set; }
        public string? LastName { get; set; }

        [DataType(DataType.EmailAddress)]
        [EmailAddress]
        public string? Email { get; set; }

        public bool? IsActive { get; set; }
        [BindRequired]
        public List<EmployeeRole>? Roles { get; set; }

        //TODO: add pending props
    }
}
