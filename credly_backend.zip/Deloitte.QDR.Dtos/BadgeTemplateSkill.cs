﻿namespace Deloitte.QDR.DTO
{
    public class BadgeTemplateSkill
    {
        public Guid? BadgeTemplateId { get; set; }
        public Guid? SkillId { get; set; }
        public Int16? Proficiency { get; set; }
        public string? SkillType { get; set; }
        public string? SkillName { get; set; }
    }
}
