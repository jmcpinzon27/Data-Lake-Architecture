﻿namespace Deloitte.QDR.DTO;

public class PrimaryDataEmployee
{
    public string? PersonID { get; set; }
    public string? FirstName { get; set; }
    public string? LastName { get; set; }
    public string? Email { get; set; }
}
