﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Deloitte.QDR.DTO
{
    public class Faq
    {
        public Guid Id { get; set; }
        public string Question { get; set; }
        public string Answer { get; set; }
        public Guid CategoryId { get; set; }
        public int? Order { get; set; }
        public Category Category { get; set; }
    }
}
