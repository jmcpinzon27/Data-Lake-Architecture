﻿using Deloitte.QDR.DTO.Common;

namespace Deloitte.QDR.DTO.Notifications
{
    public class SendNotificationDTO
    {
        public NotificacionHub NotificacionHub { get; set; }
        public List<string> EmailGroup { get; set; }
    }
}
