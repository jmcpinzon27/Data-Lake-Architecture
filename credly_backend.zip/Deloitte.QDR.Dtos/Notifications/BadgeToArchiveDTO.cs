﻿namespace Deloitte.QDR.DTO.Notifications
{
    public class BadgeToArchiveDTO
    {
        public Guid BadgeId { get; set; }
        public string EmailEmployee { set; get; }
    }
}