﻿using Deloitte.QDR.Entities;

namespace Deloitte.QDR.DTO.SendNotification
{
    public class NotificationInformation
    {
        public Guid EntityId { get; set; }
        public Entities.Employee Employee { get; set; }
        public EntityType? EntityType { get; set; }
        public string? Detail { get; set; }
    }
}