﻿namespace Deloitte.QDR.DTO
{
    public class BadgeStatusToArchive
    {
        public string EmailOwner { get; set; }
        public Guid EntityId { get; set; }
        public string Status { get; set; }
        public Entities.Employee Owner { get; set; }
    }
}