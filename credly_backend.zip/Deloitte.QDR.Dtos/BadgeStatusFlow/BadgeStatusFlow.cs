﻿using Microsoft.AspNetCore.Mvc;

namespace Deloitte.QDR.DTO
{
    [Bind("Id", "Feedback", "Status", "Value")]
    public class BadgeStatusFlow
    {
        public Guid Id { get; set; }
        public string? Feedback { get; set; }
        public string? Status { get; set; }
        public bool Value { get; set; }
        public DateTime? ArchiveDate { get; set; }
    }
}