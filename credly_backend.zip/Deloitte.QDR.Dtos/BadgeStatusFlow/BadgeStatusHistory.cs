﻿namespace Deloitte.QDR.DTO
{
    public class BadgeStatusHistory
    {
        public string Feedback { get; set; }
        public DateTime? Timestamp { get; set; }
        public string ActionValue { get; set; }
    }
}