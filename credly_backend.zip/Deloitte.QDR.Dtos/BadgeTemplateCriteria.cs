﻿using System.ComponentModel.DataAnnotations;

namespace Deloitte.QDR.DTO
{
    public class BadgeTemplateCriteria
    {
        public Guid? Id { get; set; }
        public Guid? BadgeTemplateId { get; set; }
        public string? Type { get; set; }
        public BadgeTemplateCriteriaType? BadgeTemplateCriteriaType { get; set; }
        public string? Name { get; set; }
        public string? Description { get; set; }
        public string? InfoUrl { get; set; }
        public String? EvidenceExpected { get; set; }
        public bool? BusinessValidation { get; set; }
        public bool? Deleted { get; set; }
        public bool? IsAlternative { get; set; }
        public bool? SABAValidationNeeded { get; set; }
        [StringLength(15)]
        public string? SABACourseID { get; set; }
        [StringLength(250)]
        public string? SABACourseName { get; set; }
    }
}
