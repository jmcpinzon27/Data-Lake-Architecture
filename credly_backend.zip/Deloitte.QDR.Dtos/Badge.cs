﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.ModelBinding;

namespace Deloitte.QDR.DTO
{
    [Bind("Id", "ExternalId", "BadgeTemplateId", "EmployeePersonID", "Status", "InitiatedAt", "DecisionAt", "AwardedAt", 
        "ExpiresAt", "SubmittedAt", "EducationStatus", "EducationApprovedAt", "ExperienceStatus", "ExperienceApprovedAt",
        "ExposureStatus", "EminenceApprovedAt", "State", "LastFeedback", "Education", "Experience", "Eminence", "Private", "AlternativeCriteriaSelected")]
    public class Badge
    {
        public Guid? Id { get; set; }
        public string? ExternalId { get; set; }
        public Guid? BadgeTemplateId { get; set; }
        public string? EmployeePersonID { get; set; }
        public string? Status { get; set; }
        public DateTime? InitiatedAt { get; set; }
        public DateTime? DecisionAt { get; set; }
        public DateTime? AwardedAt { get; set; }
        public DateTime? ExpiresAt { get; set; }
        public DateTime? SubmittedAt { get; set; }
        public string? EducationStatus { get; set; }
        public DateTime? EducationApprovedAt { get; set; }
        public string? ExperienceStatus { get; set; }
        public DateTime? ExperienceApprovedAt { get; set; }
        public string? ExposureStatus { get; set; }
        public DateTime? EminenceApprovedAt { get; set; }

        [BindRequired]
        public bool Private { get; set; }
        public bool AlternativeCriteriaSelected { get; set; }
        public string? State { get; set; }
        public string? LastFeedback { get; set; }
        public bool? BadgeTemplateHaveAlternativeCriteria { get; set; }
        public string? BadgeTemplateStatus { get; set; }
        public string? BadgeTemplateReleaseNotes { get; set; }
        public bool? ApplyReleaseNotesOnlyInitiated { get; set; }
        public DateTime? BadgeTemplateLastUpdate { get; set; }
        public IList<DTO.Education> Education { get; set; } = new List<DTO.Education>();
        public IList<DTO.Experience> Experience { get; set; } = new List<DTO.Experience>();
        public IList<DTO.Exposure> Eminence { get; set; } = new List<DTO.Exposure>();
    }
}