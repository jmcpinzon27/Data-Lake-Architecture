﻿using Deloitte.QDR.DTO.Common;
using Microsoft.AspNetCore.Mvc.ModelBinding;

namespace Deloitte.QDR.DTO
{
    [BindRequired]
    public class AwardingProcess
    {
        public Guid? Id { get; set; }
        public int? CohortId { get; set; }
        public string? Title { get; set; }
        public DateTime? CompletionDate { get; set; }
        public string? CreatedById { get; set; }
        public string? CreatedBy { get; set; }
        public DateTime? Createdate { get; set; }
        public string? Status { get; set; }
        public Guid? BadgeTemplate_Id { get; set; }
        public string? Approver_Id { get; set; }
        public string? ApproverEmail { get; set; }
        public string? CsvUrlFile { get; set; }
        public string? ZipUrlFile { get; set; }
        public Base64File? CsvUrlFileBase64 { get; set; }
        public Base64File? ZipUrlFileBase64 { get; set; }
        public string? LastFeedback { get; set; }
    }
}
