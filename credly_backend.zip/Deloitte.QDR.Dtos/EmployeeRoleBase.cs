﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.ModelBinding;

namespace Deloitte.QDR.DTO
{
    [Bind("EmployeeId", "RoleId")]
    public class EmployeeRoleBase
    {
        /// <summary>
        /// The employeeId value
        /// </summary>
        public string EmployeeId { get; set; }

        /// <summary>
        /// The roleId value
        /// </summary>
        [BindRequired]
        public Guid RoleId { get; set; }
    }
}