﻿namespace Deloitte.QDR.DTO.Azure
{
    public class ImageProcessingDto
    {
        public Guid Id { get; set; }
        public string ImageUrlQDR { get; set; }
        public string ImageUrlCredly { get; set; }
        public string TargetTable { get; set; }
    }
}