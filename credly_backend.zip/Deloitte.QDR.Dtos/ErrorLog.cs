﻿using System.ComponentModel.DataAnnotations;

namespace Deloitte.QDR.DTO;

public class ErrorLog
{
    public Guid Id { get; set; }
    public DateTime Date { get; set; }
    [StringLength(150)]
    public string Source { get; set; }
    public string Message { get; set; }
    public string Trace { get; set; }
    [StringLength(60)]
    public string? UserEmail { get; set; }
    [StringLength(20)]
    public string? PersonID { get; set; }
    public int StatusCode { get; set; }
    [StringLength(20)]
    public string Method { get; set; }
    [StringLength(20)]
    public string URL { get; set; }
    public string? Body { get; set; }
}