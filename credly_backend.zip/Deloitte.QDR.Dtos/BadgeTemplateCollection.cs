﻿namespace Deloitte.QDR.DTO
{
    public class BadgeTemplateCollection
    {
        public Guid? CollectionId { get; set; }
        public Guid? BadgeTemplateId { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
        public string OwnerId { get; set; }
        public IList<Guid> ListOfBadgeTemplateId { get; set; }
    }
}