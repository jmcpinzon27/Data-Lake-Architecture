﻿namespace Deloitte.QDR.DTO;

public class Collection
{
    public Guid? Id { get; set; }
    public string? Name { get; set; }
    public string? Description { get; set; }
    public int NumberOfBadges { get; set; }
    public DateTime DateCreated { get; set; }
    public Employee Owner { get; set; }
    public List<BadgeTemplate> BadgeTemplates { get; set; } = new List<BadgeTemplate>();
}