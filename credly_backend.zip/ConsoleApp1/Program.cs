﻿using Deloitte.QDR.Apis.Core.Controllers;
using Deloitte.QDR.BLL;
using Deloitte.QDR.DTO;
using Deloitte.QDR.DTO.Common;
using Deloitte.QDR.Tests.Mocks;

MapperBootstrapper.Bootstrap();
var _badgeController = new BadgeController(
    DbContextMock.GetContext(),
    new HttpContextAccessorMock(),
    new DataCacheMock()
);
var _badgeModel = new Badge();
var _filterBase = new FilterBase { PageIndex = 1, PageSize = 5 };

//var _response = _badgeController.Get(_filterBase).Value;
var badgeResult = _badgeController.Post(_badgeModel);

var _badgeTemplateController = new BadgeTemplateController(
    DbContextMock.GetContext(),
    new HttpContextAccessorMock(),
    new DataCacheMock()
);

//var result = _badgeTemplateController.Get(1).Value;

var _responseBadgeTemplateItem = new BadgeTemplate();
var _badgeTemplate = new BadgeTemplate();
_responseBadgeTemplateItem = _badgeTemplateController.Post(_badgeTemplate);

var _employee = new EmployeeController(
    DbContextMock.GetContext(),
    new HttpContextAccessorMock(),
    new DataCacheMock()
);

//var res = _employee.Get(Guid.Parse("79d10101-b555-4049-923f-cd7ab464592e")).Value;
Console.ReadLine();
