﻿using Azure.Security.KeyVault.Secrets;

namespace Deloitte.QDR.Infrastructure.KeyVault
{
    public class KeyVaultManager : IKeyVaultManager
    {
        private readonly SecretClient _secretClient;

        public KeyVaultManager(SecretClient secretClient)
        {
            _secretClient = secretClient ?? throw new ArgumentNullException(nameof(secretClient));
        }

        public async Task<string> GetSecretAsync(string secretName, string version = default, CancellationToken cancellationToken = default)
        {
            try
            {
                KeyVaultSecret keyVaultSecret = await _secretClient.GetSecretAsync(secretName, version, cancellationToken);
                return keyVaultSecret.Value;
            }
            catch (Exception ex)
            {
                //TODO: report to log
                throw ex;
            }
        }

        public string GetSecret(string secretName)
        {
            try
            {
                KeyVaultSecret keyVaultSecret = _secretClient.GetSecret(secretName);
                return keyVaultSecret.Value;
            }
            catch (Exception ex)
            {
                //TODO: report to log
                throw ex;
            }
        }
    }
}