﻿using Deloitte.QDR.DTO.Common;
using Deloitte.QDR.DTO.UserActivityTrace;
using Deloitte.QDR.Entities;
using Ganss.Xss;
using System.ComponentModel.DataAnnotations;
using System.Reflection;

namespace Deloitte.QDR.Infrastructure
{
    public static class Utils
    {
        public static string Sanitizer(string data)
        {
            var sanitizer = new HtmlSanitizer();
            return sanitizer.Sanitize(data);
        }

        public static string ConvertToBase64(this Stream stream, string contentType)
        {
            try
            {
                byte[] bytes;
                using (var memoryStream = new MemoryStream())
                {
                    stream.CopyTo(memoryStream);
                    bytes = memoryStream.ToArray();
                }

                string base64 = Convert.ToBase64String(bytes);
                return $"data:{contentType};base64,{base64}";
            }
            catch (Exception ex)
            {
                throw new Exception("Error converting file to base 64.", ex);
            }
        }

        public static string? GetEntityIdName<T>()
        {
            return typeof(T)
                .GetProperties()
                .Where(
                    p =>
                        p.CustomAttributes.Any(
                            a => string.Equals(a.AttributeType.Name, "KeyAttribute")
                        )
                )
                .Select(p => p.Name)
                .FirstOrDefault();//Fixed .Single when there are many records
        }

        public static string GetEntityIdValue<T>(T entity)
        {
            return entity
                .GetType()
                .GetProperties()
                .Where(
                    p =>
                        p.CustomAttributes.Any(
                            a => string.Equals(a.AttributeType.Name, "KeyAttribute")
                        )
                )
                .Select(p => p.GetValue(entity).ToString())
                .Single();
        }

        public static bool IsType<T>(Type ot)
        {
            return typeof(T).GetInterfaces().Any(e => e.GetTypeInfo() == ot);
        }

        public static T? ResolveEnum<T>(this string value)
        {
            return string.IsNullOrEmpty(value) ? default(T) : (T)Enum.Parse(typeof(T), value, true);
        }

        public static void CheckValidEmail(string emailParam)
        {
            var email = new EmailAddressAttribute();

            var trimmedEmail = emailParam.Trim();

            if (!email.IsValid(trimmedEmail) || trimmedEmail.EndsWith("."))
            {
                var result = new Result
                {
                    HasErrors = true,
                    Messages = new List<string>
                    {
                        "'email' should be valid"
                    }
                };

                throw new DTO.Common.ValidationException(result);
            }
        }
    }

    public class UserActivityHelper
    {
        //TODO: this is a first approach, but must be migrated as a service.
        private static List<UserActivityParameter> _userActivityParameters;

        public static UserActivityParameter GetActivityType(EntityType entityType, string entityStatus)
        {
            LoadUserActivities();

            var userActivityParameter = _userActivityParameters.FirstOrDefault(t => t.EntityType == entityType && t.EntityStatus == entityStatus);
            if (userActivityParameter == null)
            {
                return _userActivityParameters.FirstOrDefault(t => t.ActivityType == ActivityType.ActivityTypeNoIdentified);
            }

            return userActivityParameter;
        }

        private static void LoadUserActivities()
        {
            //TODO: this is a first approach, but must be migrated to database and cache service
            _userActivityParameters = new List<UserActivityParameter>();
            _userActivityParameters.Add(new UserActivityParameter
            {
                EntityType = EntityType.Badge,
                EntityStatus = BadgeStatus.ActivityTypeNoIdentified.ToString(),
                ActivityType = ActivityType.ActivityTypeNoIdentified,
                Description = ActivityType.ActivityTypeNoIdentified.ToString()
            });
            _userActivityParameters.Add(new UserActivityParameter
            {
                EntityType = EntityType.Badge,
                EntityStatus = BadgeStatus.Withdrawn.ToString(),
                ActivityType = ActivityType.BadgeWithdrawn,
                Description = ActivityType.BadgeWithdrawn.ToString()
            });
            _userActivityParameters.Add(new UserActivityParameter
            {
                EntityType = EntityType.Badge,
                EntityStatus = BadgeStatus.Initiated.ToString(),
                ActivityType = ActivityType.BadgeInitiated,
                Description = ActivityType.BadgeInitiated.ToString()
            });

            _userActivityParameters.Add(new UserActivityParameter
            {
                EntityType = EntityType.Badge,
                EntityStatus = BadgeStatus.Approved.ToString(),
                ActivityType = ActivityType.BadgeApproved,
                Description = ActivityType.BadgeApproved.ToString()
            });
            _userActivityParameters.Add(new UserActivityParameter
            {
                EntityType = EntityType.Badge,
                EntityStatus = BadgeStatus.AttentionRequired.ToString(),
                ActivityType = ActivityType.BadgeAttentionRequired,
                Description = ActivityType.BadgeAttentionRequired.ToString()
            });
            _userActivityParameters.Add(new UserActivityParameter
            {
                EntityType = EntityType.Badge,
                EntityStatus = BadgeStatus.Deleted.ToString(),
                ActivityType = ActivityType.BadgeDeleted,
                Description = ActivityType.BadgeDeleted.ToString()
            });
            _userActivityParameters.Add(new UserActivityParameter
            {
                EntityType = EntityType.Badge,
                EntityStatus = BadgeStatus.Rejected.ToString(),
                ActivityType = ActivityType.BadgeRejected,
                Description = ActivityType.BadgeRejected.ToString()
            });
            _userActivityParameters.Add(new UserActivityParameter
            {
                EntityType = EntityType.Badge,
                EntityStatus = BadgeStatus.Revoked.ToString(),
                ActivityType = ActivityType.BadgeRevoked,
                Description = ActivityType.BadgeRevoked.ToString()
            });
        }
    }
}