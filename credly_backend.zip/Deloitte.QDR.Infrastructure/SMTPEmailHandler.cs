﻿using AngleSharp.Dom;
using Deloitte.QDR.Contracts;
using Deloitte.QDR.Contracts.BL;
using Deloitte.QDR.DTO;
using Deloitte.QDR.DTO.Common;
using Deloitte.QDR.Infrastructure.Config;
using Microsoft.AspNetCore.Http;
using System.Net;
using System.Net.Mail;
using System.Web;

namespace Deloitte.QDR.Infrastructure
{
    public class SMTPEmailHandler : ISMTPEmailHandler
    {
        private readonly IErrorLogBL _errorLogBL;

        public SMTPEmailHandler(IErrorLogBL errorLogBL)
        {
            _errorLogBL = errorLogBL; 
        }
        public async Task<bool> SendEmailAsync(MailData mailData)
        {
            try
            {
                var fromAddress = new MailAddress(AppSettings.Settings.GetSecret(GeneralConstants.KeyVault.SECRET_SENDER_EMAIL), AppSettings.Settings.GetSecret(GeneralConstants.KeyVault.SECRET_SENDER_NAME));

                var smtp = new SmtpClient
                {
                    Host = AppSettings.Settings.GetSecret(GeneralConstants.KeyVault.SECRET_SERVER),
                    Port = Convert.ToInt32(AppSettings.Settings.GetSecret(GeneralConstants.KeyVault.SECRET_PORT)),
                    EnableSsl = true,
                    DeliveryMethod = SmtpDeliveryMethod.Network,
                    UseDefaultCredentials = false
                };
                using (var message = new MailMessage()
                {
                    Subject = mailData.EmailSubject,
                    Body = mailData.EmailBody,
                    IsBodyHtml = true
                })
                {
                    foreach (var item in mailData.EmailToId)
                    {
                        message.To.Add(item);
                    }
                    message.From = fromAddress;

                    smtp.Send(message);
                }               
            }catch (Exception ex)
            {
                var errorLog = new ErrorLog
                {
                    Source = ex.Source,
                    Message = ex.GetFullMessage(),
                    Trace = ex.StackTrace,
                    StatusCode = (int)HttpStatusCode.InternalServerError,
                    Method = GeneralConstants.ErrorMessages.EMAIL_ERROR_METHOD_NAME,
                    URL = mailData?.EmailSubject ?? string.Empty
                };

                await _errorLogBL.SaveErrorLogAsync(errorLog);

                return false;
            }
            return true;
        }
    }
}
