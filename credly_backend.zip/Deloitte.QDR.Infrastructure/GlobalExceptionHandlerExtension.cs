﻿using Deloitte.QDR.Contracts.BL;
using Deloitte.QDR.DTO.Common;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Diagnostics;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using System.Net;
using System.Text;
using System.Text.Json;
using Deloitte.QDR.DTO;
using System;
using System.Text.Json.Serialization;
using Microsoft.Extensions.DependencyInjection;

namespace Deloitte.QDR.Infrastructure
{
    public static class GlobalExceptionHandlerExtension
    {

        public static void UseGlobalExeptionHandler(this IApplicationBuilder app, IWebHostEnvironment host)
        {
            app.UseExceptionHandler(appBuilder =>
            {
                appBuilder.Run(async context =>
                {
                    var exception = context.Features.Get<IExceptionHandlerFeature>().Error;
                    var options = new JsonSerializerOptions
                    {
                        PropertyNamingPolicy = JsonNamingPolicy.CamelCase,
                        WriteIndented = true,
                        DefaultIgnoreCondition = JsonIgnoreCondition.WhenWritingNull
                    };

                    context.Response.StatusCode = (int)HttpStatusCode.BadRequest;
                    context.Response.ContentType = "application/json; charset=utf-8";

                    if (exception is ValidationException)
                    {
                        var responseDetail = new Response<object>();
                        responseDetail.Result.HasErrors = true;
                        responseDetail.Result = (exception as ValidationException).Result;
                        await context.Response.WriteAsync(JsonSerializer.Serialize(responseDetail, options), Encoding.UTF8);
                    }
                    else if (exception is Azure.RequestFailedException)
                    {
                        var authorizationException = (exception as Azure.RequestFailedException);
                        var responseDetail = new Response<object>();
                        responseDetail.Result.HasErrors = true;
                        responseDetail.Result.Messages = new List<string>() { authorizationException.ErrorCode };
                        context.Response.StatusCode = (int)HttpStatusCode.Unauthorized;
                        await context.Response.WriteAsync(JsonSerializer.Serialize(responseDetail, options), Encoding.UTF8);
                    }
                    else
                    {
                        var errorLog = await GetErrorLogAsync(exception, context.Request);
                        using (var scope = app.ApplicationServices.CreateScope())
                        {
                            var errorLogBL = scope.ServiceProvider.GetRequiredService<IErrorLogBL>();
                            await errorLogBL.SaveErrorLogAsync(errorLog);
                        }

                        const string _invalidDNS = "deloittecertified";

                        if (!context.Request.Host.Value.StartsWith(_invalidDNS))
                        {
                            await context.Response.WriteAsync(JsonSerializer.Serialize(errorLog, options), Encoding.UTF8);
                        }
                    }
                });
            });
        }

        private static async Task<ErrorLog> GetErrorLogAsync(Exception ex, HttpRequest? request)
        {
            var url = string.Empty;
            var method = string.Empty;
            string? body = null;
            if (request != null)
            {
                url = WebUtility.UrlDecode($"{request.Path}{request.QueryString.Value}");
                method = request.Method;
                body = await GetRawBodyAsync(request);
            }

            return new ErrorLog
            {
                Source = ex.Source,
                Message = ex.GetFullMessage(),
                Trace = ex.StackTrace,
                StatusCode = (int)HttpStatusCode.InternalServerError,
                Method = method,
                URL = url,
                Body = body
            };
        }

        private static async Task<string?> GetRawBodyAsync(HttpRequest request)
        {
            if (request.ContentLength == null || request.ContentLength <= 0)
            {
                return null;
            }

            if (!request.Body.CanSeek)
            {
                request.EnableBuffering();
            }

            request.Body.Position = 0;
            var reader = new StreamReader(request.Body, Encoding.UTF8);
            var body = await reader.ReadToEndAsync();
            body = body.Replace(Environment.NewLine, string.Empty);
            request.Body.Position = 0;
            return body;
        }

        public static string GetFullMessage(this Exception ex)
        {
            string message = $"{ex.Message}.";
            while (ex.InnerException != null)
            {
                ex = ex.InnerException;
                message += $" {ex.Message}.";
            }

            return message;
        }
    }
}
