﻿namespace Deloitte.QDR.Infrastructure.ServiceBus
{
    public interface IQueueService
    {
        Task SendAsync(string payload);
    }
}