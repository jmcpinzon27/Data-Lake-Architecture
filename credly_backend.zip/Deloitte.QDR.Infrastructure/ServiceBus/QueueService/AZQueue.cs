﻿using Deloitte.QDR.DTO.Common;
using Deloitte.QDR.Infrastructure.KeyVault;
using Microsoft.Azure.ServiceBus;
using Microsoft.Extensions.Configuration;
using System.Text;

namespace Deloitte.QDR.Infrastructure.ServiceBus
{
    public class AZQueue : IQueueService
    {
        private IQueueClient _queueClient;
        private readonly IKeyVaultManager _keyVaultManager;

        public AZQueue(IKeyVaultManager keyVaultManager, IConfiguration conf)
        {
            _keyVaultManager = keyVaultManager ?? throw new ArgumentNullException(nameof(keyVaultManager));

            bool isLocalEnv = false;
            bool.TryParse(conf["app:IsLocalEnv"], out isLocalEnv);

            var serviceBusConnection = string.Empty;
            var queueName = string.Empty;

            if (isLocalEnv)
            {
                serviceBusConnection = conf["app:ServiceBusConnectionString"];
                queueName = conf["app:ServiceBusQueueName"];
            }
            else
            {
                serviceBusConnection = _keyVaultManager.GetSecret(GeneralConstants.KeyVault.SECRET_SERVICEBUSCONNECTIONSTRING);
                queueName = _keyVaultManager.GetSecret(GeneralConstants.KeyVault.SECRET_SERVICEBUSQUEUENAME);
            }

            _queueClient = new QueueClient(serviceBusConnection, queueName);
        }

        public async Task SendAsync(string payload)
        {
            var payloadMessage = new Message(Encoding.UTF8.GetBytes(payload));
            await _queueClient.SendAsync(payloadMessage);
        }
    }
}