﻿using Azure.Identity;
using Azure.Security.KeyVault.Secrets;

namespace Deloitte.QDR.Infrastructure.Config
{
    public class Settings
    {
        public string BlobStorageUriBase { get; set; }
        public string BlobStorageContainer { get; set; }
        public string CredlyUrlBase { get; set; }
        public string CredlyOrganization { get; set; }
        public string CredlyVersion { get; set; }
        public string SABAUrlBase { get; set; }
        public string[] AllowedOrigins { get; set; }
        public string VaultUri { get; set; }
        public bool IsLocalEnv { get; set; }
        public string ClientSecret { get; set; }
        public string ClientId { get; set; }
        public string TenantId { get; set; }
        public string MailServer { get; set; }
        public int MailPort { get; set; }
        public string MailSenderName { get; set; }
        public string MailSenderEmail { get; set; }
        public string CredlyUrl { get; set; }


        public string GetSecret(string secretName)
        {
            if (IsLocalEnv)
            {
                return GetLocalSecret(secretName);
            }
            else
            {
                return GetReleaseSecret(secretName);
            }
        }

        public string GetReleaseSecret(string secretName)
        {
            string result = string.Empty;
            try
            {
                var keyVaultUri = new Uri(AppSettings.Settings.VaultUri);

                var credential = new DefaultAzureCredential();

                var keyVaultClient = new SecretClient(keyVaultUri, credential);

                var secret = keyVaultClient.GetSecret(secretName);

                result = secret.Value.Value;
            }
            catch (Exception ex)
            {
                //TODO: REPORT TO LOG
                throw ex;
            }
            return result;
        }

        public string GetLocalSecret(string secretName)
        {
            string result = string.Empty;
            try
            {
                var credential = new ClientSecretCredential(AppSettings.Settings.TenantId, AppSettings.Settings.ClientId, AppSettings.Settings.ClientSecret);
                var keyVaultClient = new SecretClient(new Uri(AppSettings.Settings.VaultUri), credential);
                var secret = keyVaultClient.GetSecret(secretName);
                result = secret.Value.Value;
            }
            catch (Exception ex)
            {
                //TODO: REPORT TO LOG
                throw ex;
            }
            return result;
        }

       
    }
}
