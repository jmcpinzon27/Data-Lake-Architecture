﻿using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;

namespace Deloitte.QDR.Infrastructure.Config
{
    public class AppSettings
    {
        public static Settings Settings { get; set; }

        public static void BindSettings(Microsoft.AspNetCore.Builder.WebApplicationBuilder builder)
        {
            Settings = new Settings();
            builder.Configuration.Bind("app", Settings);
            builder.Services.Configure<MailSettings>(builder.Configuration.GetSection("MailSettings"));
        }

        public static void BindAzureFunctionSettings()
        {
            Settings = new Settings();
            IConfigurationRoot config = new ConfigurationBuilder()
                .SetBasePath(Directory.GetCurrentDirectory())
                .AddJsonFile("local.settings.json", optional: true, reloadOnChange: true)
                .AddEnvironmentVariables()
                .Build();
            config.Bind("app", Settings);
        }
    }
}