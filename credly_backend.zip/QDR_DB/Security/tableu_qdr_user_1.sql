﻿CREATE LOGIN [tableu_qdr_user]
    WITH PASSWORD = N'yfx4pkf?Wfmrg0iJskbyq~kqmsFT7_&#$!~<GsdtmDinN,it';

