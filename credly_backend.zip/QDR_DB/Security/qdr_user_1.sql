﻿CREATE LOGIN [qdr_user]
    WITH PASSWORD = N'y`fxDpkaffmr`sbyqUdkqsdtmsFT7_&#$!~<%maBiiiw{e}d';

