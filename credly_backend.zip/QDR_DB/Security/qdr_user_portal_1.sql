﻿CREATE LOGIN [qdr_user_portal]
    WITH PASSWORD = N'yf}xpky}fNOfm.UfrwsbyqVkmsFT7_&#$!~<KQqsdtmiiniw';

