﻿using Deloitte.QDR.Contracts.Services;
using Deloitte.QDR.DTO.CredlyAPI;
using Deloitte.QDR.DTO.CredlyAPI.Common;

namespace Deloitte.QDR.Tests.Mocks.Services
{
    public class CredlyAPIService : ICredlyAPIService
    {
        public Task<List<BadgeTemplate>> GetAllBadgeTemplates()
        {
            throw new NotImplementedException();
        }

        public Task<BadgeTemplate> GetSingleBadgeTemplate(Guid id)
        {
            throw new NotImplementedException();
        }

        public Task<BadgeTemplate> CreateBadgeTemplate(BadgeTemplate dto)
        {
            throw new NotImplementedException();
        }

        public Task<BadgeTemplate> UpdateBadgeTemplate(BadgeTemplate dto)
        {
            throw new NotImplementedException();
        }

        public Task<BadgeTemplate> ArchiveBadgeTemplate(Guid id)
        {
            throw new NotImplementedException();
        }

        public Task<BadgeTemplate> UnarchiveBadgeTemplate(Guid id)
        {
            throw new NotImplementedException();
        }

        public Task DeleteBadgeTemplate(Guid id)
        {
            throw new NotImplementedException();
        }

        public Task<List<Badge>> GetAllBadges()
        {
            throw new NotImplementedException();
        }

        public Task<Badge> CreateBadge(CredlyBadgeCreate dto)
        {
            throw new NotImplementedException();
        }

        public Task<Badge> ReplaceBadge(CredlyBadgeReplace dto)
        {
            throw new NotImplementedException();
        }

        public Task<Badge> RevokeBadge(CredlyBadgeRevoke dto)
        {
            throw new NotImplementedException();
        }

        public Task<T> GetEvent<T>(Guid id, OrganizationFor organizationFor)
        {
            throw new NotImplementedException();
        }
    }
}
