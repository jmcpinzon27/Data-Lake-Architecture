﻿using Microsoft.AspNetCore.Http;

namespace Deloitte.QDR.Tests.Mocks
{
    public class HttpContextAccessorMock : IHttpContextAccessor
    {
        public HttpContext HttpContext
        {
            get => HttpContext;
            set => throw new NotImplementedException();
        }
    }
}
