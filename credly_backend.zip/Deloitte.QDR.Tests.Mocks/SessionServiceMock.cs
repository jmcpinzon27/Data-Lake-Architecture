﻿using Deloitte.QDR.Contracts.Services;
using Deloitte.QDR.DTO;
using Deloitte.QDR.DTO.Common;

namespace Deloitte.QDR.Tests.Mocks
{
    public class SessionServiceMock : ISessionService
    {
        public SessionServiceMock() { }

        public UserSession GetSession(string email = default)
        {
            var userSession = new UserSession()
            {
                Email = "anroneal1@gmail.com",
                PersonID = "1",
                FirstName = "Ariel1",
                LastName = "Alejandro",
                Roles = new List<string>() { "cc038579-7e44-46c6-895c-ba12b19bc3c9" }
            };
            return userSession;
        }
        
        public async Task<UserSession> GetSessionAsync(string email = null)
        {
            var userSession = new UserSession()
            {
                Email = "anroneal1@gmail.com",
                PersonID = "1",
                FirstName = "Ariel1",
                LastName = "Alejandro",
                Roles = new List<string>() { "cc038579-7e44-46c6-895c-ba12b19bc3c9" }
            };
            return await Task.FromResult(userSession);
        }

        public async Task<ErrorLog> GetContextErrorLog()
        {
            return new ErrorLog
            {
                PersonID = "1",
                Body = null,
                Date = DateTime.UtcNow,
                Message = "Error Test",
                Method = "GET",
                Source = "Deloitte.QDR.Tests.Mocks",
                StatusCode = 500,
                Trace = "Deloitte.QDR.Tests.Mocks",
                URL = "https://Deloitte.QDR.Tests.Mocks.com",
                UserEmail = "anroneal1@deloitte.com"
            };
        }
    }
}
