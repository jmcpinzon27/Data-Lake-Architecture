﻿using System.Linq.Expressions;
using Deloitte.QDR.DAL;
using Deloitte.QDR.Entities;
using Microsoft.EntityFrameworkCore;
using Moq;
using Newtonsoft.Json;

namespace Deloitte.QDR.Tests.Mocks
{
    public static class DbContextMock
    {
        public static DefaultDBContext GetContext()
        {
            var mockContext = new Mock<DefaultDBContext>();

            var badges = GetBadgesList();
            var badgesDbSet = GetMockDbSet(badges, e => e.Id);
            mockContext.Setup(b => b.Badges).Returns(badgesDbSet.Object);
            mockContext.Setup(b => b.Set<Entities.Badge>()).Returns(badgesDbSet.Object);

            var badgeTemplates = GetBadgeTemplateList();
            var badgeTemplatesDbSet = GetMockDbSet(badgeTemplates, e => e.Id);
            mockContext.Setup(b => b.BadgeTemplates).Returns(badgeTemplatesDbSet.Object);
            mockContext
                .Setup(b => b.Set<Entities.BadgeTemplate>())
                .Returns(badgeTemplatesDbSet.Object);

            var employees = GetEmployeesList();
            var employeesDbSet = GetMockDbSet(employees, e => e.PersonID);
            mockContext.Setup(b => b.Employees).Returns(employeesDbSet.Object);
            mockContext.Setup(b => b.Set<Entities.Employee>()).Returns(employeesDbSet.Object);

            var employeesRoles = GetEmployeesRolesList();
            var employeesRolesDbSet = GetMockDbSet(employeesRoles, e => e.EmployeeId);
            mockContext.Setup(b => b.EmployeeRole).Returns(employeesRolesDbSet.Object);
            mockContext
                .Setup(b => b.Set<Entities.EmployeeRole>())
                .Returns(employeesRolesDbSet.Object);

            var notifications = GetNotificationList();
            var notificationsDbSet = GetMockDbSet(notifications, e => e.Id);
            mockContext.Setup(b => b.Notifications).Returns(notificationsDbSet.Object);
            mockContext
                .Setup(b => b.Set<Entities.Notification>())
                .Returns(notificationsDbSet.Object);

            var skills = GetSkillList();
            var skillsDbSet = GetMockDbSet(skills, e => e.Id);
            mockContext.Setup(b => b.Skills).Returns(skillsDbSet.Object);
            mockContext.Setup(b => b.Set<Entities.Skill>()).Returns(skillsDbSet.Object);

            var badgeTemplateSkill = GetBadgeTemplateSkillList();
            var badgeTemplateSkillDbSet = GetMockDbSet(badgeTemplateSkill, e => new { e.SkillId, e.BadgeTemplateId });
            mockContext.Setup(b => b.BadgeTemplateSkills).Returns(badgeTemplateSkillDbSet.Object);
            mockContext.Setup(b => b.Set<Entities.BadgeTemplateSkill>()).Returns(badgeTemplateSkillDbSet.Object);

            var badgeTemplateQueries = GetBadgeTemplateQueries();
            var badgeTemplateQueriesDbSet = GetMockDbSet(badgeTemplateQueries, e => e.Id);
            mockContext
                .Setup(b => b.BadgeTemplateQueries)
                .Returns(badgeTemplateQueriesDbSet.Object);
            mockContext
                .Setup(b => b.Set<Entities.Queries.BadgeTemplateQuery>())
                .Returns(badgeTemplateQueriesDbSet.Object);

            var badgeQuery = GetBadgeQuery();
            var badgeQueryDbSet = GetMockDbSet(badgeQuery, e => e.Id);
            mockContext.Setup(b => b.BadgeQueries).Returns(badgeQueryDbSet.Object);
            mockContext
                .Setup(b => b.Set<Entities.Queries.BadgeQuery>())
                .Returns(badgeQueryDbSet.Object);

            var userActivity = GetUserActivity();
            var userActivityDbSet = GetMockDbSet(userActivity, e => e.Id);
            mockContext.Setup(b => b.UserActivity).Returns(userActivityDbSet.Object);
            mockContext
                .Setup(b => b.Set<UserActivity>())
                .Returns(userActivityDbSet.Object);

            var badgeTemplateCriteria = GetBadgeTemplateCriteriaList();
            var BadgeTemplateCriteriaSet = GetMockDbSet(badgeTemplateCriteria, e => e.Id);
            mockContext.Setup(b => b.BadgeTemplateCriteria).Returns(BadgeTemplateCriteriaSet.Object);
            mockContext.Setup(b => b.Set<Entities.BadgeTemplateCriteria>()).Returns(BadgeTemplateCriteriaSet.Object);

            var education = GetEducationList();
            var educationSet = GetMockDbSet(education, e => e.Id);
            mockContext.Setup(b => b.Educations).Returns(educationSet.Object);
            mockContext.Setup(b => b.Set<Entities.Education>()).Returns(educationSet.Object);

            var experience = GetExperienceList();
            var experienceSet = GetMockDbSet(experience, e => e.Id);
            mockContext.Setup(b => b.Experiencies).Returns(experienceSet.Object);
            mockContext.Setup(b => b.Set<Entities.Experience>()).Returns(experienceSet.Object);

            var exposure = GetExposureList();
            var exposureSet = GetMockDbSet(exposure, e => e.Id);
            mockContext.Setup(b => b.Exposures).Returns(exposureSet.Object);
            mockContext.Setup(b => b.Set<Entities.Exposure>()).Returns(exposureSet.Object);

            var role = GetRoleList();
            var roleSet = GetMockDbSet(role, e => e.Id);
            mockContext.Setup(b => b.Role).Returns(roleSet.Object);
            mockContext.Setup(b => b.Set<Entities.Role>()).Returns(roleSet.Object);

            var awardingProcess = GetAwardingProcess();
            var awardingProcessSet = GetMockDbSet(awardingProcess, e => e.Id);
            mockContext.Setup(b => b.AwardingProcess).Returns(awardingProcessSet.Object);
            mockContext.Setup(b => b.Set<AwardingProcess>()).Returns(awardingProcessSet.Object);

            var badgeTemplateCriteriaType = GetBadgeTemplateCriteriaType();
            var badgeTemplateCriteriaTypeSet = GetMockDbSet(badgeTemplateCriteriaType, e => e.Id);
            mockContext.Setup(b => b.BadgeTemplateCriteriaType).Returns(badgeTemplateCriteriaTypeSet.Object);
            mockContext.Setup(b => b.Set<BadgeTemplateCriteriaType>()).Returns(badgeTemplateCriteriaTypeSet.Object);

            var badgeTemplateSKill = GetBadgeTemplateSkill();
            var badgeTemplateSKillSet = GetMockDbSet(badgeTemplateSKill, e => e.BadgeTemplateId);
            mockContext.Setup(b => b.BadgeTemplateSkills).Returns(badgeTemplateSKillSet.Object);
            mockContext.Setup(b => b.Set<BadgeTemplateSkill>()).Returns(badgeTemplateSKillSet.Object);

            var feedback = GetFeedback();
            var feedbackSet = GetMockDbSet(feedback, e => e.Id);
            mockContext.Setup(b => b.Feedback).Returns(feedbackSet.Object);
            mockContext.Setup(b => b.Set<Feedback>()).Returns(feedbackSet.Object);


            return mockContext.Object;
        }

        private static Mock<DbSet<T>> GetMockDbSet<T>(IQueryable<T> list, Func<T, object> getId)
            where T : class
        {
            var mockDbSet = new Mock<DbSet<T>>();
            mockDbSet.As<IQueryable<T>>().Setup(m => m.Provider).Returns(list.Provider);
            mockDbSet.As<IQueryable<T>>().Setup(m => m.Expression).Returns(list.Expression);
            mockDbSet.As<IQueryable<T>>().Setup(m => m.ElementType).Returns(list.ElementType);
            mockDbSet
                .As<IQueryable<T>>()
                .Setup(m => m.GetEnumerator())
                .Returns(() => list.GetEnumerator());
            mockDbSet
                .Setup(set => set.Find(It.IsAny<object[]>()))
                .Returns(
                    (object[] input) => list.SingleOrDefault(x => getId(x).Equals(input.First()))
                );
            mockDbSet.Setup(set => set.Add(It.IsAny<T>())).Callback<T>((s) => list.ToList().Add(s));
            return mockDbSet;
        }

        private static IQueryable<Entities.Badge> GetBadgesList()
        {
            var stringData = File.ReadAllText("./DataMock/Badge.json");
            return (JsonConvert.DeserializeObject<List<Entities.Badge>>(stringData)).AsQueryable();
        }

        private static IQueryable<Entities.BadgeTemplate> GetBadgeTemplateList()
        {
            var stringData = File.ReadAllText("./DataMock/BadgeTemplate.json");
            return (
                JsonConvert.DeserializeObject<List<Entities.BadgeTemplate>>(stringData)
            ).AsQueryable();
        }

        private static IQueryable<Entities.Employee> GetEmployeesList()
        {
            var stringData = File.ReadAllText("./DataMock/Employee.json");
            return (
                JsonConvert.DeserializeObject<List<Entities.Employee>>(stringData)
            ).AsQueryable();
        }

        private static IQueryable<Entities.EmployeeRole> GetEmployeesRolesList()
        {
            var stringData = File.ReadAllText("./DataMock/EmployeeRole.json");
            return (
                JsonConvert.DeserializeObject<List<Entities.EmployeeRole>>(stringData)
            ).AsQueryable();
        }

        private static IQueryable<Entities.Notification> GetNotificationList()
        {
            var stringData = File.ReadAllText("./DataMock/Notification.json");
            return (
                JsonConvert.DeserializeObject<List<Entities.Notification>>(stringData)
            ).AsQueryable();
        }

        private static IQueryable<Entities.Skill> GetSkillList()
        {
            var stringData = File.ReadAllText("./DataMock/Skill.json");
            return (JsonConvert.DeserializeObject<List<Entities.Skill>>(stringData)).AsQueryable();
        }

        private static IQueryable<Entities.BadgeTemplateSkill> GetBadgeTemplateSkillList()
        {
            var stringData = File.ReadAllText("./DataMock/BadgeTemplateSkill.json");
            return (JsonConvert.DeserializeObject<List<Entities.BadgeTemplateSkill>>(stringData)).AsQueryable();
        }


        private static IQueryable<Entities.Queries.BadgeTemplateQuery> GetBadgeTemplateQueries()
        {
            var stringData = File.ReadAllText("./DataMock/BadgeTemplateQuery.json");
            return (
                JsonConvert.DeserializeObject<List<Entities.Queries.BadgeTemplateQuery>>(stringData)
            ).AsQueryable();
        }

        private static IQueryable<Entities.Queries.BadgeQuery> GetBadgeQuery()
        {
            var stringData = File.ReadAllText("./DataMock/BadgeQuery.json");
            return (
                JsonConvert.DeserializeObject<List<Entities.Queries.BadgeQuery>>(stringData)
            ).AsQueryable();
        }

        private static IQueryable<Entities.UserActivity> GetUserActivity()
        {
            var stringData = File.ReadAllText("./DataMock/UserActivity.json");
            return (
                JsonConvert.DeserializeObject<List<Entities.UserActivity>>(stringData)
            ).AsQueryable();
        }

        private static IQueryable<Entities.BadgeTemplateCriteria> GetBadgeTemplateCriteriaList()
        {
            var stringData = File.ReadAllText("./DataMock/BadgeTemplateCriteria.json");
            return (JsonConvert.DeserializeObject<List<Entities.BadgeTemplateCriteria>>(stringData)).AsQueryable();
        }

        private static IQueryable<Entities.Education> GetEducationList()
        {
            var stringData = File.ReadAllText("./DataMock/Education.json");
            return (JsonConvert.DeserializeObject<List<Entities.Education>>(stringData)).AsQueryable();
        }

        private static IQueryable<Entities.Experience> GetExperienceList()
        {
            var stringData = File.ReadAllText("./DataMock/Experience.json");
            return (JsonConvert.DeserializeObject<List<Entities.Experience>>(stringData)).AsQueryable();
        }

        private static IQueryable<Entities.Exposure> GetExposureList()
        {
            var stringData = File.ReadAllText("./DataMock/Experience.json");
            return (JsonConvert.DeserializeObject<List<Entities.Exposure>>(stringData)).AsQueryable();
        }

        private static IQueryable<Entities.Role> GetRoleList()
        {
            var stringData = File.ReadAllText("./DataMock/Role.json");
            return (JsonConvert.DeserializeObject<List<Entities.Role>>(stringData)).AsQueryable();
        }

        private static IQueryable<AwardingProcess> GetAwardingProcess()
        {
            var stringData = File.ReadAllText("./DataMock/AwardingProcess.json");
            return (JsonConvert.DeserializeObject<List<AwardingProcess>>(stringData)).AsQueryable();
        }
        private static IQueryable<BadgeTemplateCriteriaType> GetBadgeTemplateCriteriaType()
        {
            var stringData = File.ReadAllText("./DataMock/BadgeTemplateCriteriaType.json");
            return (JsonConvert.DeserializeObject<List<BadgeTemplateCriteriaType>>(stringData)).AsQueryable();
        }

        private static IQueryable<BadgeTemplateSkill> GetBadgeTemplateSkill()
        {
            var stringData = File.ReadAllText("./DataMock/BadgeTemplateSkill.json");
            return (JsonConvert.DeserializeObject<List<BadgeTemplateSkill>>(stringData)).AsQueryable();
        }

        private static IQueryable<Feedback> GetFeedback()
        {
            var stringData = File.ReadAllText("./DataMock/Feedback.json");
            return (JsonConvert.DeserializeObject<List<Feedback>>(stringData)).AsQueryable();
        }

    }
};