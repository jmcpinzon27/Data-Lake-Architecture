﻿using Deloitte.QDR.Contracts;

namespace Deloitte.QDR.Tests.Mocks
{
    public class DataCacheMock : IDataCache
    {
        public void Bulk<T>(IList<T> values)
        {
            return;
        }

        public void Delete<T>(string key)
        {
            return;
        }

        public T Get<T>(string key)
        {
            return default;
        }
        public Task<T> GetAsync<T>(string key)
        {
            return default;
        }
        public IList<T> GetAll<T>()
        {
            return new List<T>();
        }

        public void InsertOrUpdate<T>(string key, T value, int expirationHours = 24)
        {
            return;
        }
    }
}
