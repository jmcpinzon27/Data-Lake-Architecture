﻿using AutoMapper;
using Deloitte.QDR.DTO.Common;
using Microsoft.EntityFrameworkCore;
using System.Collections;
using System.Linq.Expressions;
using System.Reflection;

namespace Deloitte.QDR.Infrastructure
{
    public static class EntityFrameworkExtensions
    {
        public static ListResponse<TD> PaginatedByFilters<TE, TD>(
            this IQueryable<TE> query,
            FilterBase filter,
            Mapper mapper
        )
        {
            if (filter.OrderBy == null ||
                filter.OrderBy is
                {
                    NestedOrUnforced: false,
                    Column:
                    {
                        Length: 0
                    }
                }
                )
            {
                var columnDefaultOrder = Utils.GetEntityIdName<TE>();
                if (!string.IsNullOrEmpty(columnDefaultOrder))
                {
                    filter.OrderBy = new OrderBy { Column = columnDefaultOrder, Desc = false };
                }
            }

            if (filter.OrderBy is { NestedOrUnforced: false })
            {
                query = OrderByProperty(query, filter.OrderBy.Column, filter.OrderBy.Desc);
            }

            foreach (var filterColumn in filter.FilterColumns.Where(x => !x.NestedOrUnforced))
            {
                if (filterColumn.FreeText)
                {
                    if (filterColumn.Exclude)
                    {
                        query = query
                            .Where(
                                e =>
                                    !(EF.Property<string?>(e, filterColumn.Column) ?? string.Empty)
                                    .ToLower()
                                    .Contains((filterColumn.Value ?? string.Empty).ToLower())
                            )
                            .AsQueryable();
                    }
                    else
                    {
                        query = query
                            .Where(
                                e =>
                                    (EF.Property<string?>(e, filterColumn.Column) ?? string.Empty)
                                    .ToLower()
                                    .Contains((filterColumn.Value ?? string.Empty).ToLower())
                            )
                            .AsQueryable();
                    }
                }
                else
                {
                    if (filterColumn.Exclude)
                    {
                        query = query
                            .Where(
                                e =>
                                    EF.Property<object>(e, filterColumn.Column)
                                    != (object)filterColumn.Value
                            )
                            .AsQueryable();
                    }
                    else
                    {
                        query = query
                            .Where(
                                e =>
                                    EF.Property<object>(e, filterColumn.Column)
                                    == (object)filterColumn.Value
                            )
                            .AsQueryable();
                    }
                }
            }

            var pageSize = filter.PageSize ?? 10;
            var currentPage = filter.PageIndex ?? 1;
            var data = query.Skip(pageSize * (currentPage - 1)).Take(pageSize).ToList();

            return new ListResponse<TD>
            {
                Count = query.Count(),
                Data = mapper.Map<IList<TE>, IList<TD>>(data)
            };
        }


        public static IQueryable<T> OrderByProperty<T>(this IQueryable<T> source, string propertyPath, bool descending = false)
        {
            if (source == null)
                throw new ArgumentNullException(nameof(source));

            if (string.IsNullOrWhiteSpace(propertyPath))
                throw new ArgumentNullException(nameof(propertyPath));

            var parameter = Expression.Parameter(typeof(T), "x");
            Expression property = parameter;
            Type parentType = typeof(T);
            propertyPath = propertyPath.Trim();

            foreach (var propertyName in propertyPath.Split('.'))
            {
                BindingFlags bindingFlags = BindingFlags.IgnoreCase | BindingFlags.Public | BindingFlags.Instance;
                var propertyInfo = parentType.GetProperty(propertyName, bindingFlags);
                if (propertyInfo == null)
                    throw new ArgumentException($"Can't find the property '{propertyName}' in the entity '{parentType.FullName}'.");

                property = Expression.Property(property, propertyName);
                parentType = propertyInfo.PropertyType;
            }

            var lambda = Expression.Lambda(property, parameter);

            var methodName = descending ? "OrderByDescending" : "OrderBy";

            var resultExpression = Expression.Call(typeof(Queryable), methodName,
                new[] { typeof(T), property.Type },
                source.Expression,
                Expression.Quote(lambda));

            return source.Provider.CreateQuery<T>(resultExpression);
        }


        public static IQueryable<T> OrderByNestedProperty<T, TCollection, TKey>(
            this IQueryable<T> source,
            Expression<Func<T, ICollection<TCollection>>> collectionSelector,
            Expression<Func<TCollection, TKey>> keySelector,
            bool descending = false)
        {
            if (source == null)
                throw new ArgumentNullException(nameof(source));



            if (collectionSelector == null)
                throw new ArgumentNullException(nameof(collectionSelector));



            if (keySelector == null)
                throw new ArgumentNullException(nameof(keySelector));



            var flattened = source.SelectMany(
                (T parent) => collectionSelector.Compile()(parent),
                (T parent, TCollection child) => new { Parent = parent, Child = child });



            var ordered = descending
                ? flattened.OrderByDescending(x => keySelector.Compile()(x.Child))
                : flattened.OrderBy(x => keySelector.Compile()(x.Child));



            return ordered.Select(x => x.Parent).AsQueryable();
        }
    }
}
