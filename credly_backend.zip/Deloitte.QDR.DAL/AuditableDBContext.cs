﻿using Deloitte.QDR.Entities;
using Microsoft.EntityFrameworkCore;

namespace Deloitte.QDR.DAL
{
    public class AuditableDBContext : DefaultDBContext
    {
        public AuditableDBContext() { }

        public AuditableDBContext(DbContextOptions<AuditableDBContext> options)
            : base(options) { }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            base.OnConfiguring(optionsBuilder);
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);
        }

        public override int SaveChanges()
        {
            var auditLogsList = new List<AuditLog>();

            foreach (var entry in ChangeTracker.Entries().ToList())
            {
                if (
                    entry.Entity is not IAuditable && entry.State == EntityState.Detached
                    || entry.State == EntityState.Unchanged
                )
                    continue;
                var properties = entry.Properties.ToList();
                var auditLog = new AuditLog();
                var Id = string.Empty;

                foreach (var property in entry.Properties)
                {
                    auditLog.EntityName = entry.Entity.GetType().Name;

                    if (property.Metadata.IsPrimaryKey())
                    {
                        Id = property.CurrentValue?.ToString();
                        continue;
                    }

                    auditLog.EntityId = Id;
                    auditLog.PropertyName = property.Metadata.Name;

                    switch (entry.State)
                    {
                        case EntityState.Added:
                            {
                                auditLog.NewValue = property.CurrentValue?.ToString();
                                break;
                            }
                        case EntityState.Deleted:
                            {
                                auditLog.OldValue = property.OriginalValue?.ToString();
                                break;
                            }
                        case EntityState.Modified:
                            {
                                if (property.IsModified)
                                {
                                    auditLog.NewValue = property.CurrentValue?.ToString();
                                    auditLog.OldValue = property.OriginalValue?.ToString();
                                }
                                break;
                            }
                    }

                    auditLog.Date = DateTime.UtcNow;

                    if (auditLog.NewValue != null || auditLog.OldValue != null)
                    {
                        auditLogsList.Add(auditLog);
                    }

                    auditLog = new AuditLog();
                }

                AuditLogs.AddRange(auditLogsList);
            }

            return base.SaveChanges();
        }
    }
}
