﻿using System.Runtime.CompilerServices;
using Deloitte.QDR.Contracts;
using Deloitte.QDR.Infrastructure;
using Deloitte.QDR.Infrastructure.KeyVault;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using StackExchange.Redis;
using System.Text.Json;
using static Deloitte.QDR.DTO.Common.GeneralConstants;

namespace Deloitte.QDR.Cache
{
    public class RedisDataCache : IDataCache
    {
        private readonly IConnectionMultiplexer _redis;
        private readonly string _host;
        private readonly string _port;
        private readonly IKeyVaultManager _keyVaultManager;
        private readonly JsonSerializerOptions _options;

        public RedisDataCache(IConfiguration conf, IKeyVaultManager keyVaultManager)
        {
            _keyVaultManager = keyVaultManager ?? throw new ArgumentNullException(nameof(keyVaultManager));

            bool isLocalEnv = false;
            bool.TryParse(conf["app:IsLocalEnv"], out isLocalEnv);

            var redisConnection = string.Empty;
            if (isLocalEnv)
            {
                redisConnection = conf["app:RedisConnectionString"];
            }
            else
            {
                redisConnection = _keyVaultManager.GetSecret(KeyVault.SECRET_REDISCONNECTIONSTRING);
            }

            _redis = ConnectionMultiplexer.Connect(redisConnection);

            _host = redisConnection.Split(",")[0];
            _port = redisConnection.Split(",")[0].Split(":")[1];
            _options = new JsonSerializerOptions
            {
                ReferenceHandler = System.Text.Json.Serialization.ReferenceHandler.Preserve
            };
        }

        public T Get<T>(string key)
        {
            string value = _redis.GetDatabase().StringGet(ToEntityKey<T>(key));
            return string.IsNullOrEmpty(value) ? default(T) : JsonSerializer.Deserialize<T>(value, _options);
        }

        public async Task<T> GetAsync<T>(string key)
        {
            string value = await _redis.GetDatabase().StringGetAsync(ToEntityKey<T>(key));
            return string.IsNullOrEmpty(value) ? default(T) : JsonSerializer.Deserialize<T>(value, _options);
        }

        public IList<T> GetAll<T>()
        {
            var pattern = $"{typeof(T).Name}-*";
            var keys = Getkeys(pattern);

            return _redis
                .GetDatabase()
                .StringGet(keys.ToArray())
                .Select(e => JsonSerializer.Deserialize<T>(e))
                .ToList();
        }

        public void InsertOrUpdate<T>(string key, T entity, int expirationHours)
        {
            var data = JsonSerializer.Serialize(entity, _options);
            var expires = TimeSpan.FromHours(expirationHours);
            _redis.GetDatabase().StringSet(ToEntityKey<T>(key), data, expires);

        }

        public void Delete<T>(string key)
        {
            _redis.GetDatabase().KeyDelete(ToEntityKey<T>(key));
        }

        public void Bulk<T>(IList<T> values)
        {
            var batch = values
                .Select(
                    e =>
                        new KeyValuePair<RedisKey, RedisValue>(
                            ToEntityKey<T>(Utils.GetEntityIdValue<T>(e)),
                            JsonSerializer.Serialize(e)
                        )
                )
                .ToArray();

            _redis.GetDatabase().StringSet(batch);
        }

        private string ToEntityKey<T>(string key)
        {
            return $"{typeof(T).Name}-{key}";
        }

        private IEnumerable<RedisKey> Getkeys(string pattern = null)
        {
            var server = _redis.GetServer(_host);
            return string.IsNullOrEmpty(pattern) ? server.Keys() : server.Keys(pattern: pattern);
        }

    }
}