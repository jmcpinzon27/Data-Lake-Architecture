﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Deloitte.QDR.Entities;

public class EmployeeRole
{
    [Key]
    [Column("Employee_Id", Order = 1)]
    public string EmployeeId { get; set; }

    [Key]
    [Column("Role_Id", Order = 2)]
    public Guid RoleId { get; set; }

    public DateTime? StartDate { get; set; }

    public virtual Employee Employee { get; set; }
    public virtual Role Role { get; set; }
}
