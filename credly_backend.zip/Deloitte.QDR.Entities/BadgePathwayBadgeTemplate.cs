﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Deloitte.QDR.Entities;

public class BadgePathwayBadgeTemplate
{
    [Key]
    public Guid Id { get; set; }

    [Column("BadgePathway_Id")]
    public Guid BadgePathwayId { get; set; }
    public virtual BadgePathway BadgePathway { get; set; }

    [Column("BadgeTemplate_Id")]
    public Guid BadgeTemplateId { get; set; }
    public virtual BadgeTemplate BadgeTemplate { get; set; }
}