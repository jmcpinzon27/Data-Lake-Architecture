﻿namespace Deloitte.QDR.Entities
{
    public enum ActivityType
    {
        Login = 1,
        Logout = 2,
        BadgeTemplateCreated = 3,
        BadgeTemplateApproved = 4,
        BadgeTemplateRejected = 5,
        BadgeTemplateUpdated = 6,
        BadgeInitiated = 7,
        BadgeWithdrawn = 8,
        BadgeApproved = 9,
        BadgeRejected = 10,
        BadgeAttentionRequired = 11,
        BadgeCriteriaApproved = 12,
        BadgeCriteriaRejected = 13,
        BadgeCriteriaAttentionRequired = 14,
        EmployeeRoleUpdated = 15,
        EmployeeRoleAdded = 16,
        EmployeeRoleDeleted = 17,
        BadgeTemplateArchived = 18,
        BadgeDeleted = 19,
        BadgeTemplateDeleted = 20,
        BadgeRevoked = 20,
        BadgeSubmitted = 21,
        AwardingProcessSubmitted = 22,
        FirstLogin = 23,
        BadgeTemplatePrivacyUpdated = 24,
        ActivityTypeNoIdentified = 0,
        BadgeDeletedByAutomaticProcess = 25,
        BadgeStateUpdatedByAutomaticProcess = 26,
    }
}