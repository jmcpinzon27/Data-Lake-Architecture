﻿namespace Deloitte.QDR.Entities
{
    public class BadgeCertMapping
    {
        public Guid SAPID { get; set; }
        public Guid CredlyID { get; set; }
        public string SAPDesc { get; set; }
        public string CredlyDesc { get; set; }
        public string Vendor { get; set; }
    }
}
