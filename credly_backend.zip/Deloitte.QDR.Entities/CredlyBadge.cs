﻿using System.ComponentModel.DataAnnotations;

namespace Deloitte.QDR.Entities
{
    public class CredlyBadge
    {
        [Key]
        public Guid Id { get; set; }

        public string? BadgeDescription { get; set; }
        public string? State { get; set; }
        public string? CredlyId { get; set; }
    }
}