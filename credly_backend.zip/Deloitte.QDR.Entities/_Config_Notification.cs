﻿using System.ComponentModel.DataAnnotations;

namespace Deloitte.QDR.Entities
{
    public class _Config_Notification
    {
        [Key]
        public string NotificationId { get; set; }
        [Key]
        public string? EntityType { get; set; }
        public string NotificationType   { get; set; }
        public string ActivityType { get; set; }
        public string Title { get; set; }
        public string Description { get; set; }
        public bool? SendEmail { get; set; }
        public string? EmailSubject { get; set; }
        public string? EmailTitle { get; set; }
        public string? EmailDescription { get; set; }
        public string? EmailImage { get; set; }
        public string? EmailLink { get; set; }
    }
}
