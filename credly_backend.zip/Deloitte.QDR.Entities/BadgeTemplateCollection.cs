﻿using System.ComponentModel.DataAnnotations.Schema;

namespace Deloitte.QDR.Entities
{
    public class BadgeTemplateCollection
    {
        [Column("Collection_Id")]
        public Guid CollectionId { get; set; }

        [Column("BadgeTemplate_Id")]
        public Guid BadgeTemplateId { get; set; }

        public virtual BadgeTemplate BadgeTemplate { get; set; }
        public virtual Collection Collection { get; set; }
    }
}