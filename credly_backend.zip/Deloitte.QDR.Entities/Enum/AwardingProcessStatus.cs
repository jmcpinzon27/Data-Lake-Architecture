﻿namespace Deloitte.QDR.Entities.Enum
{
    public enum AwardingProcessStatus
    {
        Draft = 1,
        Submitted = 2,
        Approved = 3,
        AttentionRequired = 4
    }
}
