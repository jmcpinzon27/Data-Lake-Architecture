﻿namespace Deloitte.QDR.Entities
{
    public interface IAuditable { }
}
