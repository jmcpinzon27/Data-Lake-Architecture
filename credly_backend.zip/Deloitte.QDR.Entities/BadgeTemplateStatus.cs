﻿using System.ComponentModel;

namespace Deloitte.QDR.Entities
{
    public enum BadgeTemplateStatus
    {
        #region internal

        [Description("NotCreated")]
        NotCreated = 0,

        [Description("Draft")] // In Front is "In Progress"
        Draft = 1,

        [Description("Submitted")] // In Front is "submitted for approval"
        Submitted = 2,

        [Description("Accepted")] // In Front is "Approved"
        Accepted = 3,

        [Description("Attention Required")]
        AttentionRequired = 4,

        [Description("Rejected")]
        Rejected = 5,

        [Description("Archived")]
        Archived = 6,

        [Description("Hide For Edit")]
        HideForEdit = 7,

        [Description("Deleted")]
        Deleted = 8,

        [Description("HideForArchive")]
        HideForArchive = 9

        #endregion internal

        #region credly

        /* Credly accept only this 3 status
        Draft = 1, same as internal
        Active, ?????
        Archived = 7, same as internal

        [Description("Active")]
        Active = 8
        */

        #endregion credly
    }
}