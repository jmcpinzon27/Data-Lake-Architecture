﻿namespace Deloitte.QDR.Entities
{
    public enum BadgeType
    {
        Experience = 1,
        Learning = 2,
        Validation = 3,
        Certification = 4
    }
}
