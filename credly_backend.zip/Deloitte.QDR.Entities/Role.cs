﻿using System.ComponentModel.DataAnnotations;

namespace Deloitte.QDR.Entities
{
    public class Role
    {
        [Key]
        public Guid Id { get; set; }
        public string Code { get; set; }
        public string Description { get; set; }
        public virtual IList<EmployeeRole> EmployeeRoles { get; set; } = new List<EmployeeRole>();
    }
}
