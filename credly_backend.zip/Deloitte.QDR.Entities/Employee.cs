﻿using System.ComponentModel.DataAnnotations;

namespace Deloitte.QDR.Entities
{
    public class Employee
    {
        [Key]
        public string PersonID { get; set; }
        public string? PersonnelNumber { get; set; }
        public string? PreferredFirstName { get; set; }
        public string? FirstName { get; set; }
        public string? MiddleName { get; set; }
        public string? LastName { get; set; }
        public string? Email { get; set; }
        public DateTime? OriginalHireDate { get; set; }
        public DateTime? MostRecentHireDate { get; set; }
        public DateTime? TerminationDate { get; set; }
        public string? JobCode { get; set; }
        public string? JobCodeDesc { get; set; }
        public string? JobLevelCode { get; set; }
        public string? JobLevelCodeDesc { get; set; }
        public string? CostCenterNumber { get; set; }
        public string? BusinessCode { get; set; }
        public string? BusinessDesc { get; set; }
        public string? BusinessAreaCode { get; set; }
        public string? BusinessAreaDesc { get; set; }
        public string? BusinessLineCode { get; set; }
        public string? BusinessLineDesc { get; set; }
        public int? EmployeePracticeCode { get; set; }
        public string? EmployeePracticeDesc { get; set; }
        public string? CapabilityCode { get; set; }
        public string? CapabilityDesc { get; set; }
        public string? SubCapabilityCode { get; set; }
        public string? SubCapabilityDesc { get; set; }
        public string? SubServiceLineCode { get; set; }
        public string? SubServiceLineDesc { get; set; }
        public bool? IsActive { get; set; }
        public bool? IsPPD { get; set; }
        public bool? IsFederal { get; set; }
        public bool? IsUSI { get; set; }
        public string? CompanyCode { get; set; }
        public DateTime? LastUpdated { get; set; }
        public virtual IList<EmployeeRole> EmployeeRoles { get; set; } = new List<EmployeeRole>();
        public virtual IList<Collection> Collections { get; set; } = new List<Collection>();
        public virtual IList<BadgePathway> BadgePathways { get; set; } = new List<BadgePathway>();
    }
}
