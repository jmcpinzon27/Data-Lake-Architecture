﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Deloitte.QDR.Entities
{
 
    public class BadgeTemplate : IAuditable, ISoftDeletable<BadgeTemplateStatus>
    {
        [Key]
        public Guid Id { get; set; }
        [StringLength(100)]
        public string? Issuer { get; set; }
        [StringLength(50)]
        public string? ExternalId { get; set; }
        [StringLength(50)]
        public string? Name { get; set; }
        [StringLength(255)]
        public string? Subtitle { get; set; }
        [StringLength(500)]
        public string? Description { get; set; }
        [StringLength(500)]
        public string? LearningObjectives { get; set; }
        public BadgeType? Type { get; set; }
        public BadgeLevel? Level { get; set; }
        public BadgeTemplateStatus? Status { get; set; }
        [StringLength(500)]
        public string? ImageUrl { get; set; }
        [StringLength(500)]
        public string? InfoUrl { get; set; }
        public DateTime? CreatedAt { get; set; }
        public DateTime? UpdateAt { get; set; }
        public DateTime? RetiredAt { get; set; }
        [StringLength(20)]
        public string? CreatedBy { get; set; }
        [StringLength(20)]
        public string? UpdatedBy { get; set; }
        public DateTime? ApprovedAt { get; set; }
        [Column("Approver_Id")]
        [StringLength(20)]
        public string? ApproverId { get; set; }
        public virtual Employee? Approver { get; set; }
        [Column("Owner_Id")]
        [StringLength(20)]
        public string? OwnerId { get; set; }
        public virtual Employee? Owner { get; set; }
        [Column("Sponsor_Id")]
        [StringLength(20)]
        public string? SponsorId { get; set; }
        public virtual Employee? Sponsor { get; set; }
        public DateTime? ReviewDate { get; set; }
        public ExpiresRange? ExpiresAt { get; set; }
        
        [Column("OptionalApprover_Id")]
        [StringLength(20)]
        public string? OptionalApproverId { get; set; }
        public virtual Employee? OptionalApprover { get; set; }
        
        [NotMapped]
        public string LastFeedback { get; set; }
        public bool? IsPublic { get; set; }
        public bool? HaveAlternativeCriteria { get; set; }
        public string? AlternativeDescription { get; set; }
        public string? ReleaseNotes { get; set; }
        public bool? ApplyReleaseNotesOnlyInitiated { get; set; }

        
        public DateTime? ArchiveDate { get; set; }

        public virtual IList<BadgeTemplateCriteria> Criterias { get; set; } =
            new List<BadgeTemplateCriteria>();

        public virtual IList<BadgeTemplateSkill> Skills { get; set; } =
            new List<BadgeTemplateSkill>();

        public virtual IList<BadgeTemplateCollection> Collections { get; set; } =
            new List<BadgeTemplateCollection>();

        public IList<BadgePathwayBadgeTemplate> BadgePathways { get; set; } =
            new List<BadgePathwayBadgeTemplate>();

        public void Delete()
        {
            Status = BadgeTemplateStatus.Deleted;
        }
    }
}