﻿using System.ComponentModel.DataAnnotations;

namespace Deloitte.QDR.Entities.Queries
{
    public class BadgeQuery
    {
        [Key]
        public Guid Id { get; set; }
        public string? ExternalId { get; set; }
        public bool IsExternalCert { get; set; }
        public string? EmployeePersonID { get; set; }
        public string? EmployeeName { get; set; }
        public Guid? BadgeTemplateId { get; set; }
        public string? BadgeTemplateName { get; set; }
        public string? BadgeTemplateSubtitle { get; set; }
        public string? BadgeTemplateDescription { get; set; }
        public BadgeType? BadgeTemplateType { get; set; }
        public BadgeLevel? BadgeTemplateLevel { get; set; }
        public string? BadgeTemplateIssuer { get; set; }
        public string? BadgeTemplateCollection { get; set; }
        public string? BadgeTemplateApproverID { get; set; }
        public string? BadgeTemplateApproverName { get; set; }
        public string? BadgeTemplateOptionalApproverID { get; set; }
        public string? BadgeTemplateOptionalApproverName { get; set; }
        public BadgeTemplateStatus? BadgeTemplateStatus { get; set; }
        public bool? BadgeTemplateIsPublic { get; set; }
        public BadgeStatus? Status { get; set; }
        public DateTime? DecisionAt { get; set; }
        public DateTime? InitiatedAt { get; set; }
        public DateTime? AwardedAt { get; set; }
        public DateTime? ExpiresAt { get; set; }
        public DateTime? SubmittedAt { get; set; }
        public BadgeStatus? EducationStatus { get; set; }
        public DateTime? EducationApprovedAt { get; set; }
        public BadgeStatus? ExperienceStatus { get; set; }
        public DateTime? ExperienceApprovedAt { get; set; }
        public BadgeStatus? ExposureStatus { get; set; }
        public DateTime? ExposureApprovedAt { get; set; }
        public bool? AlternativeCriteriaSelected { get; set; }
    }
}
