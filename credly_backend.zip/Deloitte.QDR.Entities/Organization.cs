﻿namespace Deloitte.QDR.Entities
{
    //public class Organization
    //{
    //    [Key]
    //    public Guid Id { get; set; }
    //    public string Name { get; set; }
    //    public bool External { get; set; }
    //}
}
