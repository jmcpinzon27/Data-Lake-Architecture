﻿namespace Deloitte.QDR.Entities
{
    public interface ISoftDeletable<T>
    {
        void Delete();
    }
}