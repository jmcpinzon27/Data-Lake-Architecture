﻿using System.ComponentModel.DataAnnotations;

namespace Deloitte.QDR.Entities
{
    public class CredlyEmployee
    {
        [Key]
        public string? PersonID { get; set; }
        public Guid? CredlyID { get; set; }

        //public CredlyEmployeeStatus Status { get; set; }
        public DateTime? RecordLastSent { get; set; }
        public DateTime? TermLastSent { get; set; }
        public string? EmployeeState { get; set; }
        public DateTime? EmployeeLastStateUpdatedAt { get; set; }
        public string? Email { get; set; }
        public string? PersonnelNumber { get; set; }
    }
}
