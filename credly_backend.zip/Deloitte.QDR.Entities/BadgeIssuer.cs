﻿namespace Deloitte.QDR.Entities
{
    public enum BadgeIssuer
    {
        Deloitte = 1
    }
}
