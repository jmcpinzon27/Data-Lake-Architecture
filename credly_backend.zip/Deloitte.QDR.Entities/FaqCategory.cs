﻿using System.ComponentModel.DataAnnotations;

namespace Deloitte.QDR.Entities
{
    public class FaqCategory
    {
        [Key]
        public Guid Id { get; set; }
        public string? Description { get; set; }
        public int? Order { get; set; }
        public Guid? Parent_Id { get; set; }
        public virtual IList<Faq> Faq { get; set; }
    }
}
