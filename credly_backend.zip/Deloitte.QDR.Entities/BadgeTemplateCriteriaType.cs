﻿using System.ComponentModel.DataAnnotations;

namespace Deloitte.QDR.Entities;

public class BadgeTemplateCriteriaType
{
    [Key]
    public Guid Id { get; set; }
    public string Description { get; set; }
    public IList<BadgeTemplateCriteria> BadgeTemplateCriteria { get; set; }
}