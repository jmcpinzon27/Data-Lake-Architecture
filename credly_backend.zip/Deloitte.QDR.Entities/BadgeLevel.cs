﻿namespace Deloitte.QDR.Entities
{
    public enum BadgeLevel
    {
        Foundation = 1,
        Intermediate = 2,
        Advanced = 3,
        Luminary = 4
    }
}
