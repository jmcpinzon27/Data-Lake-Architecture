﻿namespace Deloitte.QDR.Entities
{
    public enum CredlyEmployeeStatus
    {
        InSync = 0,
        ToInsert,
        ToUpdate,
        ToDelete
    }
}
