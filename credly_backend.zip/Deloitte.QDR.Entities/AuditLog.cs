﻿using System.ComponentModel.DataAnnotations;

namespace Deloitte.QDR.Entities
{
    public class AuditLog
    {
        [Key]
        public Guid Id { get; set; }
        public string EntityName { get; set; }
        public string PropertyName { get; set; }
        public string EntityId { get; set; }
        public string OldValue { get; set; }
        public string NewValue { get; set; }
        public DateTime Date { get; set; }
    }

    public class ProcessLog
    {
        [Key]
        public Guid Id { get; set; }
        public DateTime Date { set; get; }
        public string Pipeline { set; get; }
        public string EntityType { set; get; }
        public string EntityId { set; get; }
        public string Step { set; get; }
        public string EventMessage { set; get; }
    }
}
