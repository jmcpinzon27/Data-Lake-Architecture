﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Deloitte.QDR.Entities;

public class BadgePathway
{
    [Key]
    public Guid Id { get; set; }

    [StringLength(40)]
    public string Name { get; set; } = string.Empty;

    [StringLength(20)]
    [Column("Owner_Id")]
    public string OwnerId { get; set; } = string.Empty;
    public virtual Employee Owner { get; set; } 

    [StringLength(500)]
    public string ImageUrl { get; set; } = string.Empty;

    public string Description { get; set; } = string.Empty;

    public DateTime CreatedAt { get; set; }

    public IList<BadgePathwayBadgeTemplate> BadgeTemplates { get; set; } = new List<BadgePathwayBadgeTemplate>();
    public IList<BadgePathwaySkill> Skills { get; set; } = new List<BadgePathwaySkill>();
}