﻿namespace Deloitte.QDR.Entities
{
    public enum ExpiresRange
    {
        None = 0,
        _1year = 1,
        _2years = 2,
        _3years = 3,
        _4years = 4,
        _5years = 5
    }
}
