﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Deloitte.QDR.Entities
{
    public class UserActivity : IAuditable
    {
        [Key]
        public Guid Id { get; set; }
        [Column("Employee_Id")]
        public string? EmployeeId { get; set; }
        public ActivityType Type { get; set; }
        public string? EntityId { get; set; }
        public string? Title { get; set; }
        public string? Description { get; set; }
        public DateTime? Date { get; set; }
        public virtual Employee? Employee { get; set; }
    }
}
