﻿namespace Deloitte.QDR.Entities;

public enum NotificationType
{
    Info = 1,
    Warning = 2,
    Danger = 3,
    Success = 4
}