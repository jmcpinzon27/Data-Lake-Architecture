﻿using System.ComponentModel;

namespace Deloitte.QDR.Entities
{
    public enum BadgeStatus
    {
        #region QDR

        [Description("Initiated")]
        Initiated = 1,

        [Description("Awarded")]
        Awarded = 2,

        [Description("In Progress")]
        InProgress = 3,

        [Description("Withdrawn")]
        Withdrawn = 4,

        [Description("Submitted for Approval")]
        SubmittedForApproval = 5,

        [Description("Attention Required")]
        AttentionRequired = 6,

        [Description("Approved")]
        Approved = 7,

        [Description("Rejected")]
        Rejected = 8,

        [Description("Revoked")]
        Revoked = 9,

        [Description("Archived")]
        Archived = 10,

        [Description("Expired")]
        Expired = 11,

        [Description("Deleted")]
        Deleted = 12,

        [Description("ToBeArchived")]
        ToBeArchived = 13,

        [Description("Discarded")]
        Discarded = 14,

        [Description("NoIdentified")]
        ActivityTypeNoIdentified = 14

        #endregion QDR

        #region Credly

        /*
        [Description("Pending")]
        Pending = 10,
        [Description("Accept")]
        Accept = 11,
        [Description("Archived")]
        Archived = 12,
        [Description("Expired")]
        Expired = 13,
        [Description("Revoked")]
        Revoked = 9,
        */

        #endregion Credly
    }
}