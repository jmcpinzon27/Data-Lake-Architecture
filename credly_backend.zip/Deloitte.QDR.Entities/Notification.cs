﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Deloitte.QDR.Entities
{
    public class Notification
    {
        [Key]
        public Guid Id { get; set; }
        public DateTime? Date { get; set; }
        public string? Title { get; set; }
        public string? Description { get; set; }
        public string? Detail { get; set; }
        public EntityType? EntityType { get; set; }
        public string? EntityId { get; set; }
        [Column("Employee_Id")]
        public string? EmployeeId { get; set; }
        public virtual Employee? Employee { get; set; }
        public bool? Read { get; set; }
        public DateTime? ReadDate { get; set; }
        public string? Status { get; set; }
    }
}
