﻿namespace Deloitte.QDR.Entities
{
    public enum BadgeTemplateType
    {
        Education = 1,
        Experience = 2,
        Eminence = 3
    }
}
