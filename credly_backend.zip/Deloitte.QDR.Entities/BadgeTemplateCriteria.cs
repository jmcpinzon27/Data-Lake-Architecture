﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Deloitte.QDR.Entities
{
    public class BadgeTemplateCriteria
    {
        [Key]
        public Guid Id { get; set; }

        public virtual BadgeTemplate BadgeTemplate { get; set; }
        public BadgeTemplateType Type { get; set; }
        [StringLength(100)]
        public string? Name { get; set; }
        [StringLength(500)]
        public string? Description { get; set; }
        public string? InfoUrl { get; set; }
        public virtual Employee Approver { get; set; }
        [Column("BadgeTemplateCriteriaType_Id")]
        public Guid? BadgeTemplateCriteriaTypeId { get; set; }
        public BadgeTemplateCriteriaType? BadgeTemplateCriteriaType { get; set; }
        public String? EvidenceExpected { get; set; }
        public bool? BusinessValidation { get; set; }
        public bool? Deleted { get; set; }
        public bool? IsAlternative { get; set; }
        public bool? SABAValidationNeeded { get; set; }
        [StringLength(15)]
        public string? SABACourseID { get; set; }
        [StringLength(250)]
        public string? SABACourseName { get; set; }

    }
}
