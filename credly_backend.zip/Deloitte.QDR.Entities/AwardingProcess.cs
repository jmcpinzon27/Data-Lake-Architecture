﻿using Deloitte.QDR.Entities.Enum;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Deloitte.QDR.Entities
{
    public class AwardingProcess : IAuditable
    {
        [Key]
        public Guid Id { get; set; }
        [DatabaseGeneratedAttribute(DatabaseGeneratedOption.Identity)]
        public int CohortId { get; set; }
        public string? Title { get; set; }
        public DateTime? CompletionDate { get; set; }
        public string? CreatedBy { get; set; }
        public DateTime Createdate { get; set; }
        public AwardingProcessStatus? Status { get; set; }
        public Guid? BadgeTemplate_Id { get; set; }
        public string? Approver_Id { get; set; }
        public string? CsvUrlFile { get; set; }
        public string? ZipUrlFile { get; set; }
        [NotMapped]
        public string? LastFeedback { get; set; }

        public virtual BadgeTemplate BadgeTemplate { get; set; }
        public virtual Employee? Approver { get; set; }
    }
}
