﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Deloitte.QDR.Entities
{
    public class Faq
    {
        [Key]
        public Guid Id { get; set; }
        public string? Question { get; set; }
        public string? Answer { get; set; }
        public int? Order { get; set; }
        [Column("Category_Id")]
        public Guid? CategoryId { get; set; }
        public virtual FaqCategory? Category { get; set; }
    }
}
