﻿using System.ComponentModel.DataAnnotations;

namespace Deloitte.QDR.Entities;

public class Feedback
{
    [Key]
    public Guid Id { get; set; }
    public DateTime Date { get; set; }
    public EntityType EntityType { get; set; }
    public string EntityId { get; set; }
    public int Status { get; set; }
    public string Detail { get; set; }

}