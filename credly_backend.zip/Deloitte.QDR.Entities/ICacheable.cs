﻿namespace Deloitte.QDR.Entities
{
    public interface ICacheable { }
}
