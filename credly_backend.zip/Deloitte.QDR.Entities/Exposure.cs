﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Deloitte.QDR.Entities
{
    public class Exposure : IAuditable
    {
        [Key]
        public Guid Id { get; set; }

        [Column("Badge_Id")]
        public Guid? BadgeId { get; set; }
        public virtual Badge? Badge { get; set; }
        [Column("BadgeTemplateCriteria_Id")]
        public Guid? BadgeTemplateCriteriaId { get; set; }
        public virtual BadgeTemplateCriteria? Criteria { get; set; }
        [StringLength(200)]
        public string? ValidatorEmail { get; set; }
        [StringLength(500)]
        public string? Description { get; set; }
        public int? Hours { get; set; }
        [StringLength(100)]
        public string? Title { get; set; }
        public string? Upload { get; set; }
        [StringLength(300)]
        public String? Url { get; set; }
        public bool? IsAlternative { get; set; }
    }
}