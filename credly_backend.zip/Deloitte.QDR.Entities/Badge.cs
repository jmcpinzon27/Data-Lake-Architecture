﻿using System.ComponentModel.DataAnnotations;

namespace Deloitte.QDR.Entities
{
    public class Badge : IAuditable, ISoftDeletable<BadgeStatus>
    {
        [Key]
        public Guid Id { get; set; }
        [StringLength(50)]
        public string? ExternalId { get; set; }
        public virtual BadgeTemplate BadgeTemplate { get; set; }
        public virtual Guid BadgeTemplateId { get; set; }
        public virtual Employee Employee { get; set; }
        public virtual string PersonID { get; set; }
        public BadgeStatus? Status { get; set; }
        public DateTime? InitiatedAt { get; set; }
        public DateTime? DecisionAt { get; set; }
        public DateTime? AwardedAt { get; set; }
        public DateTime? ExpiresAt { get; set; }
        public DateTime? SubmittedAt { get; set; }
        public BadgeStatus? EducationStatus { get; set; }
        public DateTime? EducationApprovedAt { get; set; }
        public BadgeStatus? ExperienceStatus { get; set; }
        public DateTime? ExperienceApprovedAt { get; set; }
        public BadgeStatus? ExposureStatus { get; set; }
        public DateTime? ExposureApprovedAt { get; set; }
        public virtual IList<Education> Education { get; set; }
        public virtual IList<Experience> Experience { get; set; }
        public virtual IList<Exposure> Exposure { get; set; }
        public bool? Private { get; set; }        
        public bool? AlternativeCriteriaSelected { get; set; }        
        public string? State { get; set; }        
        public DateTime? ArchiveDate { get; set; }
        public DateTime? RejectedAt { get; set; }
        public string? PersonnelNumber { get; set; }

        public void Delete()
        {
            Status = BadgeStatus.Deleted;
        }
    }
}