﻿using System.ComponentModel.DataAnnotations;

namespace Deloitte.QDR.Entities;

public class Skill : ICacheable
{
    [Key]
        public Guid Id { get; set; }
        public string Description { get; set; }

        public IList<BadgePathwaySkill> BadgePathwaySkill { get; set; }
}
