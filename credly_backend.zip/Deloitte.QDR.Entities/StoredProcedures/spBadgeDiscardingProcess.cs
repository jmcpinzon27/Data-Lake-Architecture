﻿namespace Deloitte.QDR.Entities.StoredProcedures;

public class spBadgeDiscardingProcess
{
    public Guid Id { set; get; }
}
