﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Deloitte.QDR.Entities;

public class BadgePathwaySkill
{
    [Key]
    public Guid Id { get; set; }

    [Column("BadgePathway_Id")]
    public Guid BadgePathwayId { get; set; }
    public virtual BadgePathway BadgePathway { get; set; }

    [Column("Skill_Id")]
    public Guid SkillId { get; set; }
    public virtual Skill Skill { get; set; }
}