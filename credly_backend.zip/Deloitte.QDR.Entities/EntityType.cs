﻿namespace Deloitte.QDR.Entities
{
    public enum EntityType
    {
        Employee = 1,
        BadgeTemplate = 2,
        Badge = 3,
        Notification = 4,
        AwardingProcess = 5
    }
}
