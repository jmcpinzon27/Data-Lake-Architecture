﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Deloitte.QDR.Entities.Enum;

namespace Deloitte.QDR.Entities
{
    public class BadgeTemplateSkill
    {
        [Key]
        [Column("BadgeTemplate_Id", Order = 1)]
        public Guid BadgeTemplateId { get; set; }

        [Key]
        [Column("Skill_Id", Order = 2)]
        public Guid SkillId { get; set; }

        public virtual BadgeTemplate BadgeTemplate { get; set; }
        public virtual Skill Skill { get; set; }
        public Int16? Proficiency { get; set; }
        public SkillType? SkillType { get; set; }
    }
}
