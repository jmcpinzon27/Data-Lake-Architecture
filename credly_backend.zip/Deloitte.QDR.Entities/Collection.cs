﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Deloitte.QDR.Entities
{
    public class Collection
    {
        [Key]
        public Guid Id { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
        public DateTime? DateCreated { get; set; }
        [Column("Owner")]
        public string? OwnerId { get; set; }
        public Employee Owner { get; set; }

        public virtual IList<BadgeTemplateCollection> BadgeTemplatesCollections { get; set; } =
            new List<BadgeTemplateCollection>();
    }
}