﻿using Deloitte.QDR.BLL.Base;
using Deloitte.QDR.Contracts;
using Deloitte.QDR.Contracts.BL;
using Deloitte.QDR.Contracts.Services;
using Deloitte.QDR.DTO.Common;

namespace Deloitte.QDR.BLL
{
    public class BlobFileBL : BaseBL, IBlobFileBL
    {
        private readonly IBlobStorageService _blobStorageService;
        private readonly ICredlyAPIService _credlyAPIService;

        public BlobFileBL(
            ISessionService sessionService,
            IDBContext dbContext,
            IDataCache dataCache,
            IBlobStorageService blobStorageService,
            ICredlyAPIService credlyAPIService
        )
            : base(sessionService, dbContext, dataCache)
        {
            _blobStorageService = blobStorageService;
            _credlyAPIService = credlyAPIService;
        }

        public async Task<BlobFileInfo> UploadBadgeFile(Base64File file)
        {
            return await _blobStorageService.UploadBlobFile(
                file.File,
                $"{file.FileName}",
                file.ContentType
            );
        }

        public async Task<BlobFileInfo> DownloadBadgeFile(
            string idBlobFile
        )
        {
            return await _blobStorageService.DownloadBlobFile($"{idBlobFile}");
        }

        public async Task DeleteBadgeFile(string idBlobFile)
        {
            await _blobStorageService.DeleteBlobFile($"{idBlobFile}");
        }

        public async Task<List<BlobFileInfo>> GetListBadgeFile(string prefix)
        {
            return await _blobStorageService.GetListOFBlobs(prefix);
        }
    }
}
