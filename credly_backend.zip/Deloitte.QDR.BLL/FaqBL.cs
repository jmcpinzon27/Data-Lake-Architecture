﻿using Deloitte.QDR.BLL.Base;
using Deloitte.QDR.Contracts;
using Deloitte.QDR.Contracts.BL;
using Deloitte.QDR.Contracts.Services;
using Deloitte.QDR.DTO.Common;
using Deloitte.QDR.DTO.Filters;
using Deloitte.QDR.Infrastructure;
using Microsoft.EntityFrameworkCore;
using Faq = Deloitte.QDR.DTO.Faq;

namespace Deloitte.QDR.BLL
{
    public class FaqBL : BaseBL, IFaqBL
    {
        public FaqBL(ISessionService sessionService, IDBContext dbContext, IDataCache dataCache)
            : base(sessionService, dbContext, dataCache) { }

        public ListResponse<DTO.Faq> GetByCategory(FaqFilter filterById)
        {
            //TODO: This method is not necessary because the method 'GetByFilter' should be used or not with FaqFilter 
            //if this method is remove, frontend should delete too
            var query = DbContext.Faq
                .Include(x => x.Category)
                .Where(e => e.Category.Id == filterById.CategoryId)
                .OrderBy(x => x.Category.Order).ThenBy(x => x.Order)
                .AsQueryable();
            return query.PaginatedByFilters<Entities.Faq, DTO.Faq>(filterById, Mapper);
        }

        public ListResponse<Faq> GetAll(FaqFilter filter)
        {
            //TODO: This method is not necessary because the method 'GetByFilter' should be used or not with FaqFilter 
            //if this method is remove, frontend should delete too
            var query = DbContext.Faq
                .Include(x => x.Category)
                .OrderBy(x => x.Category.Order).ThenBy(x => x.Order)
                .AsQueryable();

            var data = query.ToList();
            return new ListResponse<Faq>()
            {
                Count = data.Count,
                Data = Mapper.Map<IList<Entities.Faq>, IList<Faq>>(data),
            };
        }

        public Faq GetById(Guid id)
        {
            var entity = DbContext.Faq.Include(x => x.Category)
                .Single(x => x.Id == id);
            return Mapper.Map<Entities.Faq, DTO.Faq>(entity);
        }

        public ListResponse<Faq> GetByFilter(FaqFilter filter)
        {
            var query = DbContext.Faq
                .Include(x => x.Category)
                .OrderBy(x => x.Category.Order).ThenBy(x => x.Order)
                .AsQueryable();

            if (filter.CategoryId.HasValue)
            {
                query = query.Where(x => x.CategoryId == filter.CategoryId.Value);
            }

            return query.PaginatedByFilters<Entities.Faq, DTO.Faq>(filter, Mapper);
        }

        public Faq Create(Faq faqDTO)
        {
            throw new NotImplementedException();
        }

        public Faq Update(Faq faqDTO)
        {
            throw new NotImplementedException();
        }

        public void Delete(Guid id)
        {
            throw new NotImplementedException();
        }
    }
}
