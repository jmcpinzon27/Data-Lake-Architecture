﻿using Deloitte.QDR.BLL.Base;
using Deloitte.QDR.Contracts;
using Deloitte.QDR.Contracts.BL;
using Deloitte.QDR.Contracts.Services;
using Deloitte.QDR.DTO.Common;
using Deloitte.QDR.DTO.Filters;
using Deloitte.QDR.Infrastructure;
using Microsoft.EntityFrameworkCore;
using EmployeeRole = Deloitte.QDR.DTO.EmployeeRole;

namespace Deloitte.QDR.BLL
{
    public class EmployeeRoleBL : BaseBL, IEmployeeRoleBL
    {
        private ICacheService _cacheService;
        public EmployeeRoleBL(ISessionService sessionService, IDBContext dbContext, IDataCache dataCache, ICacheService cacheService)
            : base(sessionService, dbContext, dataCache)
        {
            _cacheService = cacheService ?? throw new ArgumentNullException(nameof(cacheService));
        }

        public DTO.EmployeeRole Create(DTO.EmployeeRole employeeRoleDTO)
        {
            #region EmployeeRole

            var roleInfo = DbContext.Role.FirstOrDefault(t => t.Id == employeeRoleDTO.RoleId);
            if (roleInfo == null)
            {
                throw new ValidationException(new Result { Messages = new List<string>() { GeneralConstants.ErrorMessages.ROLE_INVALID }, HasErrors = true });
            }

            var employeeInfo = DbContext.Employees.FirstOrDefault(t => t.PersonID == employeeRoleDTO.EmployeeId);
            if (employeeInfo == null)
            {
                throw new ValidationException(new Result { Messages = new List<string>() { GeneralConstants.ErrorMessages.ROLE_EMPLOYEE }, HasErrors = true });
            }

            var checkRole = DbContext.EmployeeRole.Any(t => t.RoleId == employeeRoleDTO.RoleId && t.EmployeeId == employeeRoleDTO.EmployeeId);

            if (checkRole)
            {
                throw new ValidationException(new Result { HasErrors = true, Messages = new List<string>() { GeneralConstants.ErrorMessages.ROLE_ALREADY_EXISTS } });
            }

            var defaultRole = DbContext.Role.Single(t => t.Code == GeneralConstants.Role.DEFAULT_CODE_ROLE);
            var currentUserRoles = (from item in DbContext.EmployeeRole
                                    where item.Employee == employeeInfo
                                    select item.RoleId).ToList();
            var currentCommonUserRoles = currentUserRoles.Except(new List<Guid> { defaultRole.Id });
            if (currentCommonUserRoles.Count() >= 1)
            {
                throw new ValidationException(new Result { HasErrors = true, Messages = new List<string>() { GeneralConstants.ErrorMessages.ROLE_INCONSISTENT } });
            }

            var newEntityEmployeeRole = new Entities.EmployeeRole
            {
                Employee = employeeInfo,
                EmployeeId = employeeRoleDTO.EmployeeId,
                Role = roleInfo,
                RoleId = employeeRoleDTO.RoleId,
                StartDate = DateTime.UtcNow
            };

            var contextResult = DbContext.EmployeeRole.Add(newEntityEmployeeRole);

            #region UserActivity

            var userActivity = new Entities.UserActivity()
            {
                EntityId = newEntityEmployeeRole.RoleId.ToString(),
                Employee = employeeInfo,
                Type = Entities.ActivityType.EmployeeRoleAdded,
                Date = DateTime.UtcNow
            };

            DbContext.UserActivity.Add(userActivity);

            #endregion UserActivity

            DbContext.SaveChanges();

            _cacheService.UpdateCache(employeeInfo.PersonID);
            return Mapper.Map<Entities.EmployeeRole, DTO.EmployeeRole>(newEntityEmployeeRole);

            #endregion EmployeeRole
        }

        public bool Delete(DTO.EmployeeRole employeeRoleDTO)
        {
            var roleInfo = DbContext.Role.Single(t => t.Id == employeeRoleDTO.RoleId);
            var employeeInfo = DbContext.Employees.Single(t => t.PersonID == employeeRoleDTO.EmployeeId);

            var defaultRole = DbContext.Role.Single(t => t.Code == GeneralConstants.Role.DEFAULT_CODE_ROLE);
            var checkDefaultRole = roleInfo.Id == defaultRole.Id;
            if (checkDefaultRole)
            {
                throw new ValidationException(new Result { HasErrors = true, Messages = new List<string>() { GeneralConstants.ErrorMessages.ROLE_CANNOT_REMOVED } });
            }

            var roleToRemove = DbContext.EmployeeRole.FirstOrDefault(t => t.EmployeeId == employeeRoleDTO.EmployeeId && t.RoleId == employeeRoleDTO.RoleId);
            if (roleToRemove == null)
            {
                throw new ValidationException(new Result { HasErrors = true, Messages = new List<string>() { GeneralConstants.ErrorMessages.ROLE_NOT_EXISTS } });
            }
            DbContext.EmployeeRole.Remove(roleToRemove);

            #region UserActivity

            var userActivity = new Entities.UserActivity()
            {
                EntityId = roleToRemove.RoleId.ToString(),
                Employee = employeeInfo,
                Type = Entities.ActivityType.EmployeeRoleDeleted,
                Date = DateTime.UtcNow
            };
            DbContext.UserActivity.Add(userActivity);

            #endregion UserActivity

            DbContext.SaveChanges();

            _cacheService.UpdateCache(employeeInfo.PersonID);
            return true;
        }

        public List<DTO.EmployeeRole> GetByGuid(Guid id)
        {
            throw new NotImplementedException();
        }

        public EmployeeRole GetById(Guid id)
        {
            throw new NotImplementedException();
        }

        public ListResponse<EmployeeRole> GetByFilter(EmployeeRoleFilter filter)
        {
            string roleCodeFilter = filter.Roles is null ? string.Empty : filter.Roles.ToLower();
            //0) default sorting by name to avoid FE send column name, this name must exists in dictionary
            if (filter.OrderBy != null && filter.OrderBy.Column != null)
            {
                string valueToConvert;
                GeneralConstants.Role.FILTER_DICTIONARY.TryGetValue(filter.OrderBy.Column.ToLower(),
                    out valueToConvert);
                if (valueToConvert is not null)
                {
                    filter.OrderBy.Column = valueToConvert;
                }
            }

            //TODO: always return empty if not set any role to find. that is how it is?
            var query = DbContext.EmployeeRole
                .Include(r => r.Employee)
                .Include(r => r.Role)
                .Where(r => r.Role.Code.ToLower() == roleCodeFilter);

            if (!string.IsNullOrWhiteSpace(filter.PersonID))
            {
                query = query.Where(x => x.EmployeeId.Equals(filter.PersonID));
            }

            return query.PaginatedByFilters<Entities.EmployeeRole, DTO.EmployeeRole>(filter, Mapper);
        }

        public EmployeeRole Update(EmployeeRole employeeRoleDTO)
        {
            var roleInfo = DbContext.Role.Single(t => t.Id == employeeRoleDTO.RoleId);
            var employeeInfo = DbContext.Employees
                .Include(x=>x.EmployeeRoles)
                .Single(t => t.PersonID == employeeRoleDTO.EmployeeId);

            var defaultRole = DbContext.Role.Single(t => t.Code == GeneralConstants.Role.DEFAULT_CODE_ROLE);
            var checkDefaultRole = roleInfo.Id == defaultRole.Id;
            if (checkDefaultRole)
            {
                throw new ValidationException(new Result { HasErrors = true, Messages = new List<string>() { GeneralConstants.ErrorMessages.ROLE_CANNOT_REMOVED } });
            }

            var currentUserRoles = employeeInfo.EmployeeRoles.Select(x=>x.RoleId).ToList();

            var currentCommonUserRoles = currentUserRoles.Except(new List<Guid> { defaultRole.Id });

            if (currentCommonUserRoles.Count() > 1)
            {
                throw new ValidationException(new Result { HasErrors = true, Messages = new List<string>() { GeneralConstants.ErrorMessages.ROLE_INCONSISTENT } });
            }
            if (currentCommonUserRoles.Count() == 0)
            {
                throw new ValidationException(new Result { HasErrors = true, Messages = new List<string>() { GeneralConstants.ErrorMessages.ROLE_EMPLOYEE_ROLE_EMPTY } });
            }

            if (currentCommonUserRoles.Count() == 1)
            {
                var currentEmployeeIdRole = currentCommonUserRoles.FirstOrDefault();
                if (currentEmployeeIdRole == roleInfo.Id)
                {
                    throw new ValidationException(new Result { HasErrors = true, Messages = new List<string>() { GeneralConstants.ErrorMessages.ROLE_ALREADY_EXISTS } });
                }

                var employeeRoleToUpdate = DbContext.EmployeeRole.Single(t => t.RoleId == currentEmployeeIdRole && t.Employee.PersonID == employeeInfo.PersonID);

                DbContext.EmployeeRole.Remove(employeeRoleToUpdate);
                var updatedEmployeeRole = new Entities.EmployeeRole { Employee = employeeInfo, RoleId = roleInfo.Id, StartDate = DateTime.UtcNow };
                DbContext.EmployeeRole.Add(updatedEmployeeRole);

                #region UserActivity

                var userActivity = new Entities.UserActivity()
                {
                    EntityId = employeeRoleToUpdate.RoleId.ToString(),
                    Employee = employeeInfo,
                    Type = Entities.ActivityType.EmployeeRoleUpdated,
                    Date = DateTime.UtcNow
                };
                DbContext.UserActivity.Add(userActivity);
                userActivity = new Entities.UserActivity()
                {
                    EntityId = updatedEmployeeRole.RoleId.ToString(),
                    Employee = employeeInfo,
                    Type = Entities.ActivityType.EmployeeRoleUpdated,
                    Date = DateTime.UtcNow
                };
                DbContext.UserActivity.Add(userActivity);

                #endregion UserActivity

                DbContext.SaveChanges();
                employeeRoleDTO = Mapper.Map<Entities.EmployeeRole, DTO.EmployeeRole>(employeeRoleToUpdate);
                _cacheService.UpdateCache(employeeInfo.PersonID);
            }

            return employeeRoleDTO;
        }

        public void Delete(Guid id)
        {
            throw new NotImplementedException();
        }
     
    }
}
