﻿using Deloitte.QDR.BLL.Base;
using Deloitte.QDR.Contracts;
using Deloitte.QDR.Contracts.BL;
using Deloitte.QDR.Contracts.Services;
using Deloitte.QDR.DTO;
using Deloitte.QDR.DTO.Common;
using Deloitte.QDR.DTO.Filters;
using Deloitte.QDR.Infrastructure;
using Microsoft.EntityFrameworkCore;

namespace Deloitte.QDR.BLL
{
    public class BadgeTemplateCollectionBL : BaseBL, IBadgeTemplateCollectionBL
    {
        public BadgeTemplateCollectionBL(ISessionService sessionService, IDBContext dbContext, IDataCache dataCache)
            : base(sessionService, dbContext, dataCache) { }

        public BadgeTemplateCollection GetById(Guid id)
        {
            throw new NotImplementedException();
        }

        public ListResponse<BadgeTemplateCollection> GetByFilter(BadgeTemplateCollectionFilter filter)
        {
            var query = DbContext.BadgeTemplateCollections
                .Include(x => x.BadgeTemplate)
                .Include(x => x.Collection)
                .Include(x => x.Collection.Owner)
                .AsQueryable();

            if (filter.BadgeTemplateId.HasValue && filter.BadgeTemplateId.Value != Guid.Empty)
            {
                query = query.Where(x => x.BadgeTemplateId == filter.BadgeTemplateId.Value);
            }
            if (filter.CollectionId.HasValue && filter.CollectionId.Value != Guid.Empty)
            {
                query = query.Where(x => x.CollectionId == filter.CollectionId.Value);
            }

            return query.PaginatedByFilters<Entities.BadgeTemplateCollection, DTO.BadgeTemplateCollection>(filter, Mapper);
        }

        public BadgeTemplateCollection Create(BadgeTemplateCollection badgeDTO)
        {
            if (badgeDTO == null)
            {
                throw new Exception("The BadgeTemplateCollection is null or empty");
            }

            if (badgeDTO.ListOfBadgeTemplateId == null || !badgeDTO.ListOfBadgeTemplateId.Any())
            {
                throw new Exception("The List of BadgeTemplate is null or empty");
            }

            Entities.Collection collection = new Entities.Collection
            {
                Id = Guid.NewGuid(),
                Name = badgeDTO.Name,
                Description = badgeDTO.Description,
                OwnerId = badgeDTO.OwnerId,
                DateCreated = DateTime.UtcNow
            };

            DbContext.Collections.Add(collection);

            List<Entities.BadgeTemplateCollection> badgeTemplateCollections = new List<Entities.BadgeTemplateCollection>();
            foreach (var badgeTemplateId in badgeDTO.ListOfBadgeTemplateId)
            {
                var btc = new Entities.BadgeTemplateCollection
                {
                    CollectionId = collection.Id,
                    BadgeTemplateId = badgeTemplateId
                };
                badgeTemplateCollections.Add(btc);
            }

            DbContext.BadgeTemplateCollections.AddRange(badgeTemplateCollections);

            DbContext.SaveChanges();

            badgeDTO.CollectionId = collection.Id;
            return badgeDTO;
        }

        public BadgeTemplateCollection Update(BadgeTemplateCollection badgeDTO)
        {
            if (badgeDTO == null)
            {
                throw new Exception("The BadgeTemplateCollection is null or empty");
            }

            if (badgeDTO.ListOfBadgeTemplateId == null || !badgeDTO.ListOfBadgeTemplateId.Any())
            {
                throw new Exception("The List of BadgeTemplate is null or empty");
            }

            Entities.Collection collection = DbContext.Collections.Single(x => x.Id == badgeDTO.CollectionId);
            collection.Name = badgeDTO.Name;
            collection.Description = badgeDTO.Description;

            var btcFromDB = DbContext.BadgeTemplateCollections.Where(x => x.CollectionId == badgeDTO.CollectionId)
                .Select(x => x.BadgeTemplateId).ToList();
            var btcToAdd = badgeDTO.ListOfBadgeTemplateId.Where(x => !btcFromDB.Contains(x))
                .Select(idBadgeTemplate =>
                new Entities.BadgeTemplateCollection
                {
                    BadgeTemplateId = idBadgeTemplate,
                    CollectionId = collection.Id
                }).ToList();
            var btcToDelete = btcFromDB.Where(x => !badgeDTO.ListOfBadgeTemplateId.Contains(x))
                .Select(idBadgeTemplate =>
                new Entities.BadgeTemplateCollection
                {
                    BadgeTemplateId = idBadgeTemplate,
                    CollectionId = collection.Id
                }).ToList();

            DbContext.BadgeTemplateCollections.RemoveRange(btcToDelete);
            DbContext.BadgeTemplateCollections.AddRange(btcToAdd);
            DbContext.SaveChanges();

            return badgeDTO;
        }

        public void Delete(Guid id)
        {
            var collection = DbContext.Collections.Include(x => x.BadgeTemplatesCollections).FirstOrDefault(x => x.Id == id);
            if (collection == null)
            {
                throw new Exception("The collection not exists.");
            }
            DbContext.BadgeTemplateCollections.RemoveRange(collection.BadgeTemplatesCollections);
            DbContext.Collections.Remove(collection);
            DbContext.SaveChanges();
        }
    }
}
