﻿using Deloitte.QDR.BLL.Base;
using Deloitte.QDR.Contracts;
using Deloitte.QDR.Contracts.BL;
using Deloitte.QDR.Contracts.Services;
using Deloitte.QDR.DTO.Common;
using Deloitte.QDR.DTO.Reports;
using Microsoft.EntityFrameworkCore;

namespace Deloitte.QDR.BLL
{
    public class ReportBL : BaseBL, IReportBL
    {
        private readonly ILoginValidationService _loginValidationService;

        public ReportBL(ISessionService sessionService, IDBContext dbContext, IDataCache dataCache,
            ILoginValidationService loginValidationService)
            : base(sessionService, dbContext, dataCache)
        {
            _loginValidationService = loginValidationService ?? throw new ArgumentNullException(nameof(loginValidationService));
        }

        public async Task<AdminSummaryReport> GetAdminSummaryReportAsync()
        {            

            var badgesApproved = DbContext.Badges.Count(
                e => e.Status == Entities.BadgeStatus.Approved
            );

            var pendingBadges = DbContext.Badges.Count(
                e => e.Status == Entities.BadgeStatus.SubmittedForApproval
            );

            var badgesTemplatesReviewed = DbContext.BadgeTemplates.Count(
                e => e.Status == Entities.BadgeTemplateStatus.Accepted
            );

            var badgesTemplatesToReview = DbContext.BadgeTemplates.Count(
                e =>
                    e.Status == Entities.BadgeTemplateStatus.Submitted
            );

            var unreadBadgeTemplateNotifications = DbContext.Notifications.Count(
                e =>
                    e.EntityType.HasValue
                    && e.EntityType.Value == Entities.EntityType.BadgeTemplate
                    && e.Read == false
            );

            var unreadBadgeNotifications = DbContext.Notifications.Count(
                e =>
                    e.EntityType.HasValue
                    && e.EntityType.Value == Entities.EntityType.Badge
                    && e.Read == false
            );

            return new AdminSummaryReport
            {
                PendingBadges = pendingBadges,
                BadgesApproved = badgesApproved,
                BadgesTemplatesReviewed = badgesTemplatesReviewed,
                BadgesTemplatesToReview = badgesTemplatesToReview,
                UnreadBadgeTemplateNotifications = unreadBadgeTemplateNotifications,
                UnreadBadgeNotifications = unreadBadgeNotifications
            };
        }

        public async Task<PractitionerSummaryReport> GetPractitionerSummaryReportAsync()
        {
            var session = SessionService.GetSession();

            await _loginValidationService.FirstLoginValidateAsync(session.PersonID);

            var unreadNotifications = DbContext.Notifications
                .Include(e => e.Employee)
                .Count(
                    e => string.Equals(e.Employee.PersonID, session.PersonID) && e.Read == false
                );

            var deloitteBadges = DbContext.BadgeQueries.Count(
                e =>
                    string.Equals(e.EmployeePersonID, session.PersonID)
                    && (
                        e.Status == Entities.BadgeStatus.Awarded
                    )
                    && !e.IsExternalCert
            );

            var externalBadges = DbContext.BadgeQueries.Count(
                e =>
                    string.Equals(e.EmployeePersonID, session.PersonID)
                    && (
                        e.Status == Entities.BadgeStatus.Awarded

                    )
                    && e.IsExternalCert
            );

            var badgesInProgress = DbContext.BadgeQueries.Count(
                e =>
                    string.Equals(e.EmployeePersonID, session.PersonID)
                    && (
                        e.Status == Entities.BadgeStatus.Initiated
                        || e.Status == Entities.BadgeStatus.AttentionRequired
                        || e.Status == Entities.BadgeStatus.SubmittedForApproval
                        || e.Status == Entities.BadgeStatus.InProgress
                        || e.Status == Entities.BadgeStatus.Approved
                    )
                    && !e.IsExternalCert
            );

            var now = DateTime.UtcNow;

            var fecha = DbContext.BadgeQueries.ToList();

            var badgesExpiringSoon = DbContext.BadgeQueries.Count(
                e =>
                    string.Equals(e.EmployeePersonID, session.PersonID)
                    && (
                        e.Status == Entities.BadgeStatus.Approved
                        || e.Status == Entities.BadgeStatus.Awarded
                    )
                    && e.ExpiresAt.HasValue
                    && EF.Functions.DateDiffDay(now, e.ExpiresAt.Value) > 0
                    && EF.Functions.DateDiffDay(now, e.ExpiresAt.Value) <= 90
            );

            return new PractitionerSummaryReport
            {
                UnreadNotifications = unreadNotifications,
                BadgesInProgress = badgesInProgress,
                BadgesExpiringSoon = badgesExpiringSoon,
                DeloitteBadges = deloitteBadges,
                ExternalBadges = externalBadges
            };
        }

        public IList<BadgesByPeriodReportItem> GetBadgesByPeriodReport(Interval interval)
        {
            var dateFrom = new DateTime(DateTime.UtcNow.Year, 1, 1);
            var dateTo = new DateTime(DateTime.UtcNow.Year, 12, 31);
            var dateAux = new DateTime(DateTime.UtcNow.Year, 1, 1);
            var result = new List<BadgesByPeriodReportItem>();

            Func<Entities.Badge, DateTime> groupBy;

            switch (interval)
            {
                case Interval.Week:
                    dateFrom = new DateTime(DateTime.UtcNow.Year, DateTime.UtcNow.Month, 1);
                    dateTo = dateFrom.AddMonths(1).AddMilliseconds(-1);
                    dateAux = dateFrom;

                    groupBy = (e) =>
                    {
                        var dayOfWeek = new DateTime(
                            e.SubmittedAt.Value.Year,
                            e.SubmittedAt.Value.Month,
                            1
                        ).DayOfWeek;
                        var diff = e.SubmittedAt.Value.DayOfWeek - dayOfWeek;

                        if (diff < 0)
                        {
                            diff += 7;
                        }

                        return e.SubmittedAt.Value.AddDays(-1 * diff).Date;
                    };

                    while (dateAux <= dateTo)
                    {
                        result.Add(
                            new BadgesByPeriodReportItem { Period = dateAux, BadgesCount = 0 }
                        );

                        var lastDayMonth = new DateTime(dateAux.Year, dateAux.Month, 1)
                            .AddMonths(1)
                            .AddDays(-1);
                        var diffDays = (lastDayMonth - dateAux).Days;

                        dateAux = diffDays > 7 ? dateAux.AddDays(7) : lastDayMonth.AddDays(1);
                    }

                    break;

                case Interval.Quarter:
                    groupBy = (e) =>
                    {
                        var quarter = (e.SubmittedAt.Value.Month - 1) / 3;

                        return new DateTime(e.SubmittedAt.Value.Year, quarter * 3 + 1, 1);
                    };

                    while (dateAux <= dateTo)
                    {
                        result.Add(
                            new BadgesByPeriodReportItem { Period = dateAux, BadgesCount = 0 }
                        );
                        ;

                        dateAux = dateAux.AddMonths(3);
                    }
                    break;

                default:
                    groupBy = (e) =>
                        new DateTime(e.SubmittedAt.Value.Year, e.SubmittedAt.Value.Month, 1);

                    while (dateAux <= dateTo)
                    {
                        result.Add(
                            new BadgesByPeriodReportItem { Period = dateAux, BadgesCount = 0 }
                        );
                        ;

                        dateAux = dateAux.AddMonths(1);
                    }
                    break;
            }

            var data = DbContext.Badges
                .Where(
                    e =>
                        (
                            e.Status == Entities.BadgeStatus.SubmittedForApproval
                        )
                        && e.SubmittedAt.HasValue
                        && e.SubmittedAt.Value >= dateFrom
                        && e.SubmittedAt.Value <= dateTo
                )
                .ToList()
                .GroupBy(groupBy)
                .Select(
                    e => new BadgesByPeriodReportItem { Period = e.Key, BadgesCount = e.Count() }
                )
                .ToList();

            foreach (var item in data)
            {
                var resultItem = result.Single(e => e.Period == item.Period);
                resultItem.BadgesCount = item.BadgesCount;
            }

            return result;
        }
    }
}