﻿using System.Runtime.InteropServices.ComTypes;
using AutoMapper;
using Deloitte.QDR.BLL.Base;
using Deloitte.QDR.Contracts;
using Deloitte.QDR.Contracts.BL;
using Deloitte.QDR.Contracts.Services;
using Deloitte.QDR.DTO;
using Deloitte.QDR.DTO.Common;
using Deloitte.QDR.Infrastructure;
using Microsoft.EntityFrameworkCore;

namespace Deloitte.QDR.BLL
{
    public class CollectionBL : BaseBL, ICollectionBL
    {
        public CollectionBL(ISessionService sessionService, IDBContext dbContext, IDataCache dataCache)
            : base(sessionService, dbContext, dataCache) { }

        public Collection GetById(Guid id)
        {
            var entity = DbContext.Collections
                .Include(x => x.BadgeTemplatesCollections).ThenInclude(x => x.BadgeTemplate)
                .Include(x => x.Owner)
                .SingleOrDefault(e => e.Id == id);
            return Mapper.Map<Entities.Collection, DTO.Collection>(entity);
        }

        public ListResponse<Collection> GetByFilter(FilterBase filter)
        {
            var query = DbContext.Collections
                .Include(x => x.BadgeTemplatesCollections)
                    .ThenInclude(x => x.BadgeTemplate)
                .Include(x => x.Owner)
                .AsQueryable();


            //Enable custom filter
            if (
                    (filter?.OrderBy?.Column?.Equals(
                                                GeneralConstants.Collection.FILTER_NUMBER_BADGESTEMPLATES, 
                                                StringComparison.InvariantCultureIgnoreCase
                                                ) ?? false
                    ) == true
                )
            {
                query = filter.OrderBy.Desc
                    ?
                    query.OrderByDescending(x => x.BadgeTemplatesCollections.Count())
                    : query.OrderBy(x => x.BadgeTemplatesCollections.Count());

                // When we are using custom ordering we need disabled order in paginated method with this flag
                filter.OrderBy.NestedOrUnforced = true;
            }

            if (!string.IsNullOrWhiteSpace(filter.SearchText))
            {
                query = query.Where(
                    x => (!string.IsNullOrEmpty(x.Name) && (x.Name).ToLower().Contains(filter.SearchText.ToLower())) ||
                         (!string.IsNullOrEmpty(x.Description) && (x.Description).ToLower().Contains(filter.SearchText.ToLower())));
            }

            return query.PaginatedByFilters<Entities.Collection, DTO.Collection>(filter, Mapper);
        }

        public Collection Create(Collection badgeDTO)
        {
            throw new NotImplementedException();
        }

        public Collection Update(Collection badgeDTO)
        {
            throw new NotImplementedException();
        }

        public void Delete(Guid id)
        {
            throw new NotImplementedException();
        }
    }
}
