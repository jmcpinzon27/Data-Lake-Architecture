﻿using AutoMapper;
using Deloitte.QDR.BLL.Base;
using Deloitte.QDR.Contracts;
using Deloitte.QDR.Contracts.BL;
using Deloitte.QDR.Contracts.Services;
using Deloitte.QDR.DTO;
using Deloitte.QDR.DTO.Common;
using Deloitte.QDR.DTO.Filters;
using Deloitte.QDR.Infrastructure;
using Microsoft.EntityFrameworkCore;

namespace Deloitte.QDR.BLL
{
    public class SkillBL : BaseBL, ISkillBL
    {
        public SkillBL(ISessionService sessionService, IDBContext dbContext, IDataCache dataCache)
            : base(sessionService, dbContext, dataCache) { }

        public Skill GetById(Guid id)
        {
            var entity = DbContext.Skills.SingleOrDefault(e => e.Id == id);
            return Mapper.Map<Entities.Skill, DTO.Skill>(entity);
        }

        public ListResponse<Skill> GetByFilter(SkillFilter filter)
        {
            var query = DbContext.Skills
                .AsQueryable();

            if (!string.IsNullOrWhiteSpace(filter.SearchText))
            {
                query = query.Where(x =>
                    !string.IsNullOrEmpty(x.Description) && x.Description.ToUpper().Contains(filter.SearchText.ToUpper()));
            }
            return query.PaginatedByFilters<Entities.Skill, DTO.Skill>(filter, Mapper);
        }

        public List<string> GetSkillsDistinctByName()
        {
            //TODO: This methodo will be remove and replaced for GetSkillsByBadgeTemplateStatus
            return DbContext.Skills
                .Where(x => !string.IsNullOrEmpty(x.Description))
                .Select(x => x.Description).Distinct().ToList();
        }

        public List<string> GetSkillsByBadgeTemplateStatus(SkillFilter filter)
        {
            var query = DbContext.BadgeTemplates
                .Include(x => x.Skills)
                .AsQueryable();

            if (filter.Status.Any())
            {
                var statusList = filter.Status.Select(
                    e => (Entities.BadgeTemplateStatus)Enum.Parse(typeof(Entities.BadgeTemplateStatus), e)
                );
                query = query.Where(x => x.Status.HasValue && statusList.Contains(x.Status.Value));
            }

            return query.SelectMany(x => x.Skills.Select(j => j.Skill.Description)).Distinct().ToList();
        }
    }
}
