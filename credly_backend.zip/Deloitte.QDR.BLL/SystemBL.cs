﻿using Deloitte.QDR.BLL.Base;
using Deloitte.QDR.Contracts;
using Deloitte.QDR.Contracts.BL;
using Deloitte.QDR.Contracts.Services;
using Deloitte.QDR.Infrastructure.Config;
using static Deloitte.QDR.DTO.Common.GeneralConstants;

namespace Deloitte.QDR.BLL;

public class SystemBL : BaseBL, ISystemBL
{
    public SystemBL(ISessionService sessionService, IDBContext dbContext, IDataCache dataCache)
        : base(sessionService, dbContext, dataCache)
    {
    }

    public List<KeyValuePair<string, string>> GetParameters()
    {
        List<KeyValuePair<string, string>> parameters = new List<KeyValuePair<string, string>>();

        //Add the credly url base.
        parameters.Add(new KeyValuePair<string, string>(KeyVault.SECRET_CREDLYURLBASE, AppSettings.Settings.CredlyUrl));

        return parameters;
    }
}