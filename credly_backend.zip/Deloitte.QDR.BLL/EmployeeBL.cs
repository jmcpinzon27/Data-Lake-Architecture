﻿using Deloitte.QDR.BLL.Base;
using Deloitte.QDR.Contracts;
using Deloitte.QDR.Contracts.BL;
using Deloitte.QDR.Contracts.Services;
using Deloitte.QDR.DTO.Common;
using Deloitte.QDR.Infrastructure;
using Microsoft.EntityFrameworkCore;

namespace Deloitte.QDR.BLL
{
    public class EmployeeBL : BaseBL, IEmployeeBL
    {
        private readonly ICacheService _cacheService;

        public EmployeeBL(
            ISessionService sessionService,
            IDBContext dbContext,
            IDataCache dataCache,
            ICacheService cacheService
        )
            : base(sessionService, dbContext, dataCache)
        {
            _cacheService = cacheService ?? throw new ArgumentNullException(nameof(cacheService));
        }

        #region CUSTOM METHODS

        public UserSession GetUserSession()
        {
            return SessionService.GetSession();
        }

        #endregion CUSTOM METHODS

        #region PUBLIC METHODS
        public async Task<CacheResponse<ListResponse<UserSession>>> GetEmployeesByRoleAsync(FilterBaseWithRoles filter, CancellationToken cancellationToken = default)
        {
            var filterByRol = FilterByRol(filter);
            if (!filterByRol.HaveRoles)
            {
                throw new ValidationException(new Result { HasErrors = true, Messages = new List<string> { GeneralConstants.ErrorMessages.EMPLOYEE_FILTER_WITHOUT_ROLE } });
            }

            if (filterByRol.Roles.Contains(GeneralConstants.Role.DEFAULT_CODE_ROLE))
            {
                throw new ValidationException(new Result { HasErrors = true, Messages = new List<string> { GeneralConstants.ErrorMessages.EMPLOYEE_FILTER_PRACTITIONER_NOT_ALLOWED } });
            }

            CacheResponse<ListResponse<UserSession>> response = new CacheResponse<ListResponse<UserSession>>();
            var responseCache = await _cacheService.GetEmployeesRoleFromCacheAsync(filterByRol.Roles);
            
            /* If no cache, try directly from database */
            if (responseCache == null || responseCache.Data == null || !responseCache.Data.Any())
            {
                response.SourceCache = SourceCache.DataBase;
                response.IsCache = false;
                response.Data = GetResponseFromDataBase(filter, filterByRol.Roles);
            }
            else
            {
                response.SourceCache = responseCache.SourceCache;
                response.IsCache = true;
                response.Data = GetResponseFromCache(filter, responseCache.Data);
            }

            return response;
        }

        public async Task<CacheResponse<ListResponse<UserSession>>> GetByFilterAsync(FilterBaseWithRoles filter, CancellationToken cancellationToken = default)
        {
            CacheResponse<ListResponse<UserSession>> response = new CacheResponse<ListResponse<UserSession>>();
            var responseCache = await _cacheService.GetEmployeesFromCacheAsync();
            response.SourceCache = responseCache.SourceCache;

            /* If no cache, try directly from database */
            if (responseCache.Data == null || !responseCache.Data.Any())
            {
                response.SourceCache = SourceCache.DataBase;
                response.IsCache = false;
                response.Data = GetResponseFromDataBase(filter);
            }
            else
            {
                response.IsCache = true;
                response.Data = GetResponseFromCache(filter, responseCache.Data);
            }

            return response;
        }

        #endregion PUBLIC METHODS

        #region PRIVATE METHODS

        private ListResponse<UserSession> GetResponseFromCache(FilterBaseWithRoles filter, IEnumerable<UserSession> dataEmployee)
        {
            var query = dataEmployee.AsQueryable();
            if (!string.IsNullOrEmpty(filter.SearchText))
            {
                filter.SearchText = filter.SearchText.ToLower().Trim();
                if (filter.SearchText.Contains("@"))
                {
                    filter.SearchText = filter.SearchText.Substring(0, filter.SearchText.IndexOf("@"));
                }

                query = query.Where(e =>
                            (e.FirstName + " " + e.LastName).ToLower().Contains(filter.SearchText)
                            || !string.IsNullOrEmpty(e.Email) && e.Email.ToLower().Substring(0, e.Email.IndexOf("@"))
                        .Contains(filter.SearchText)
                );
            }

            return query.PaginatedByFilters<UserSession, UserSession>(filter, Mapper);
        }

        private ListResponse<UserSession> GetResponseFromDataBase(FilterBaseWithRoles filter, List<string> roles = null)
        {
            var query = DbContext.Employees
                .Include(x => x.EmployeeRoles).ThenInclude(x => x.Role)
                .Where(x => x.IsActive == true);

            if (roles is not null && roles.Any())
            {
                query = query.Where(x => x.IsActive == true && x.EmployeeRoles.Any(j => roles.Contains(j.Role.Code)));
            }

            if (!string.IsNullOrEmpty(filter.SearchText))
            {
                filter.SearchText = filter.SearchText.ToLower().Trim();
                if (filter.SearchText.Contains("@"))
                {
                    filter.SearchText = filter.SearchText.Substring(0, filter.SearchText.IndexOf("@"));
                }

                query = query.Where(e =>
                    (e.FirstName + " " + e.LastName).ToLower().Contains(filter.SearchText)
                    || !string.IsNullOrEmpty(e.Email) && e.Email.ToLower().Substring(0, e.Email.IndexOf("@"))
                        .Contains(filter.SearchText)
                );
            }

            return query.PaginatedByFilters<Entities.Employee, UserSession>(filter, Mapper);
        }

        private (bool HaveRoles, List<string> Roles) FilterByRol(FilterBaseWithRoles filter)
        {
            if (string.IsNullOrEmpty(filter.Roles)) return (false, null);
            var rolesToFilter = filter.Roles.Split('|');
            var checkAllowedRoles = from item in GeneralConstants.Role.FILTER_EMPLOYEE
                                    where rolesToFilter.Contains(item)
                                    select item;

            if (!checkAllowedRoles.Any())
            {
                return (false, null);
            }

            return (true, checkAllowedRoles.ToList());
        }

        #endregion PRIVATE METHODS
    }
}