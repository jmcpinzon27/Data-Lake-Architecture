﻿//using AutoMapper;
//using Deloitte.QDR.Cache;
//using Deloitte.QDR.DAL;
//using Deloitte.QDR.DTO.Common;
//using Deloitte.QDR.Entities;
//using Deloitte.QDR.Infrastructure;
//using Microsoft.AspNetCore.Http;
//using Microsoft.EntityFrameworkCore;
//using Microsoft.EntityFrameworkCore.Query;
//using System;
//using System.Collections.Generic;
//using System.Linq;

//namespace Deloitte.QDR.BLL.Base
//{
//    public abstract class BaseCrudBL<TID, TE, TD, TF> : BaseBL
//        where TE : class
//        where TF : FilterBase
//    {
//        public BaseCrudBL() { }

//        public BaseCrudBL(
//            IDBContext context,
//            IHttpContextAccessor contextAccessor,
//            IDataCache dataCache
//        )
//            : base(context, contextAccessor, dataCache)
//        {
//            DbContext = context;
//            ContextAccessor = contextAccessor;
//            DataCache = dataCache;
//        }

//        public virtual TD GetById(TID id)
//        {
//            var entity = DbContext.Set<TE>().Find(id);
//            return Mapper.Map<TE, TD>(entity);
//        }

//        public virtual IList<TD> GetAll()
//        {
//            var entities = default(IList<TE>);

//            if (Utils.IsType<TE>(typeof(ICacheable)))
//            {
//                entities = GetAllFromCache();
//            }
//            else
//            {
//                entities = DbContext.Set<TE>().AsQueryable().OfType<TE>().ToList();
//            }

//            return Mapper.Map<IList<TE>, IList<TD>>(entities);
//        }

//        public virtual ListResponse<TD> GetByFilter(TF filter)
//        {
//            var query = GetQuery(filter).OfType<TE>();

//            if (filter.OrderBy != null)
//            {
//                query = filter.OrderBy.Desc
//                    ? query
//                        .OrderByDescending(e => EF.Property<object>(e, filter.OrderBy.Column))
//                        .AsQueryable()
//                    : query
//                        .OrderBy(e => EF.Property<object>(e, filter.OrderBy.Column))
//                        .AsQueryable();
//            }

//            foreach (var filterColumn in filter.FilterColumns)
//            {
//                query = filterColumn.FreeText
//                    ? query
//                        .Where(
//                            e =>
//                                (EF.Property<string>(e, filterColumn.Column) ?? string.Empty)
//                                    .ToLower()
//                                    .Contains((filterColumn.Value ?? string.Empty).ToLower())
//                        )
//                        .AsQueryable()
//                    : query
//                        .Where(
//                            e =>
//                                EF.Property<object>(e, filterColumn.Column)
//                                == (object)filterColumn.Value
//                        )
//                        .AsQueryable();
//            }

//            var pageSize = filter.PageSize ?? 10;
//            var currentPage = filter.PageIndex ?? 1;
//            var data = query.Skip(pageSize * (currentPage - 1)).Take(pageSize).ToList();

//            return new ListResponse<TD>
//            {
//                Count = query.Count(),
//                Data = Mapper.Map<IList<TE>, IList<TD>>(data)
//            };
//        }

//        public virtual TD Create(TD dto)
//        {
//            Validate(dto);
//            var entity = ToEntity(dto);

//            DbContext.Set<TE>().Add(entity);
//            DbContext.SaveChanges();

//            if (entity is ICacheable)
//            {
//                DataCache.InsertOrUpdate(Utils.GetEntityIdValue(entity), entity);
//            }

//            return Mapper.Map<TE, TD>(entity);
//        }

//        public virtual TD Update(TD dto)
//        {
//            Validate(dto);
//            var entity = ToEntity(dto);

//            DbContext.SaveChanges();

//            if (entity is ICacheable)
//            {
//                DataCache.InsertOrUpdate(Utils.GetEntityIdValue(entity), entity);
//            }

//            return Mapper.Map<TE, TD>(entity);
//        }

//        public virtual void Delete(TID id)
//        {
//            var entity = DbContext.Set<TE>().Find(id);

//            DbContext.SaveChanges();
//        }

//        public virtual object GetDataList()
//        {
//            return null;
//        }

//        public virtual object GetDataEdit()
//        {
//            return null;
//        }

//        private IList<TE> GetAllFromCache()
//        {
//            var result = DataCache.GetAll<TE>();

//            if (!result.Any())
//            {
//                result = DbContext.Set<TE>().AsQueryable().OfType<TE>().ToList();
//                DataCache.Bulk(result);
//            }

//            return result;
//        }

//        #region Abstract Methods

//        public abstract TE ToEntity(TD dto);
//        public abstract void Validate(TD dto);
//        public abstract IQueryable GetQuery(TF filter);
//        #endregion
//    }
//}
