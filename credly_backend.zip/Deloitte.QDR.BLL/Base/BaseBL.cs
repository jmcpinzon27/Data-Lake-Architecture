﻿using AutoMapper;
using Deloitte.QDR.Contracts;
using Deloitte.QDR.Contracts.BL.Base;
using Deloitte.QDR.Contracts.Services;

namespace Deloitte.QDR.BLL.Base
{
    public abstract class BaseBL : IBaseBL
    {
        public ISessionService SessionService { get; set; }
        public IDBContext DbContext { get; set; }
        public IDataCache DataCache { get; set; }
        public Mapper Mapper { get; set; }

        public BaseBL(ISessionService sessionService, IDBContext dbContext, IDataCache dataCache)
        {
            SessionService = sessionService;
            DbContext = dbContext;
            DataCache = dataCache;
            Mapper = new Mapper(MapperBootstrapper.MapperConfiguration);
        }
    }
}
