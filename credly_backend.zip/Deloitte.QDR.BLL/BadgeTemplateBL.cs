﻿using Deloitte.QDR.BLL.Base;
using Deloitte.QDR.Contracts;
using Deloitte.QDR.Contracts.BL;
using Deloitte.QDR.Contracts.Services;
using Deloitte.QDR.DTO.BadgeTemplateFlow;
using Deloitte.QDR.DTO.Common;
using Deloitte.QDR.DTO.Filters;
using Deloitte.QDR.DTO.SABA;
using Deloitte.QDR.Entities;
using Deloitte.QDR.Entities.Enum;
using Deloitte.QDR.Infrastructure;
using Deloitte.QDR.Services;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using BadgeTemplate = Deloitte.QDR.DTO.BadgeTemplate;

namespace Deloitte.QDR.BLL
{
    public class BadgeTemplateBL : BaseBL, IBadgeTemplateBL
    {
        public const string _storagePrefix = "badgeTemplates";
        public const string _nameLogo = "Logo";
        private readonly IBlobStorageService _blobStorageService;
        private readonly ICredlyAPIService _credlyAPIService;
        private readonly IHubService _hubService;
        private readonly IStatusFlowValidator<BadgeTemplateStatus> _badgeTemplateStatusFlowService;
        private readonly INotificationService _notificationService;
        private readonly IFeedbackService _feedbackService;
        private readonly ISABAService _sabaService;
        private readonly IErrorLogBL _errorLog;

        public BadgeTemplateBL(
            ISessionService sessionService,
            IDBContext dbContext,
            IDataCache dataCache,
            IBlobStorageService blobStorageService,
            ICredlyAPIService credlyAPIService,
            IHubService hubService,
            BadgeTemplateStatusFlowService badgeTemplateStatusFlowService,
            INotificationService notificationService,
            IFeedbackService feedbackService,
            ISABAService sabaService,
            IErrorLogBL errorLog
        )
            : base(sessionService, dbContext, dataCache)
        {
            _blobStorageService = blobStorageService ?? throw new ArgumentNullException(nameof(blobStorageService));
            _credlyAPIService = credlyAPIService ?? throw new ArgumentNullException(nameof(credlyAPIService)); ;
            _hubService = hubService ?? throw new ArgumentNullException(nameof(hubService)); ;
            _badgeTemplateStatusFlowService = badgeTemplateStatusFlowService ?? throw new ArgumentNullException(nameof(badgeTemplateStatusFlowService));
            _notificationService = notificationService ?? throw new ArgumentNullException(nameof(notificationService));
            _feedbackService = feedbackService ?? throw new ArgumentNullException(nameof(feedbackService));
            _sabaService = sabaService ?? throw new ArgumentNullException(nameof(sabaService));
            _errorLog = errorLog ?? throw new ArgumentNullException(nameof(errorLog));
        }

        #region PublicMethods

        #region BaseMethods

        public async Task<DTO.BadgeTemplate?> GetByIdAsync(Guid id, CancellationToken cancellationToken = default)
        {
            var entity = DbContext.BadgeTemplates
                .Include(x => x.Approver)
                .Include(x => x.OptionalApprover)
                .Include(x => x.Owner)
                .Include(x => x.Sponsor)
                .Include(x => x.Criterias.Where(j => j.Deleted != true)).ThenInclude(x => x.BadgeTemplateCriteriaType)
                .Include(x => x.Skills).ThenInclude(x => x.Skill)
                .Include(x => x.Collections).ThenInclude(x => x.Collection)
                .SingleOrDefault(e => e.Id == id);

            if (entity == null)
            {
                return null;
            }

            var feedback = _feedbackService.GetLastFeedback(id, EntityType.BadgeTemplate);
            if (feedback != null && entity != null)
                entity.LastFeedback = feedback.Detail;

            var entityDTO = Mapper.Map<Entities.BadgeTemplate, DTO.BadgeTemplate>(entity);
            if (!string.IsNullOrWhiteSpace(entity.ImageUrl))
            {
                var resultLogo = await _blobStorageService.DownloadBlobFile(entity.ImageUrl);

                if (resultLogo != null)
                {
                    entityDTO.Logo = new Base64File
                    {
                        Base64 = Utils.ConvertToBase64(resultLogo.Content, resultLogo.ContentType),
                        FileName = resultLogo.NameFile
                    };
                }
            }

            var session = SessionService.GetSession();
            var badges = DbContext.Badges.Where(j => j.Status != BadgeStatus.Discarded &&
                                                    j.BadgeTemplateId == entity.Id && string.Equals(j.Employee.PersonID, session.PersonID)).ToList();

            if (badges != null && badges.Any(x=>x.Status == BadgeStatus.Initiated))
            {
                entityDTO.BadgeStatusForCurrentUser = BadgeStatus.Initiated.ToString();
                entityDTO.BadgeIdForCurrentUser = badges.First(x => x.Status == BadgeStatus.Initiated).Id;
            }
            else
            {
                entityDTO.BadgeStatusForCurrentUser = badges?.FirstOrDefault()?.Status.ToString();
                entityDTO.BadgeIdForCurrentUser = badges?.FirstOrDefault()?.Id;
            }

            return entityDTO;
        }

        public ListResponse<BadgeTemplate> GetByFilter(BadgeTemplateFilter filter)
        {
            var query = DbContext.BadgeTemplates.Include(x => x.Skills).ThenInclude(x => x.Skill).AsQueryable();

            if (filter.Status.Any())
            {
                var statusList = filter.Status.Select(
                    e => (BadgeTemplateStatus)Enum.Parse(typeof(Entities.BadgeTemplateStatus), e)
                );
                query = query
                    .Where(e => e.Status.HasValue && statusList.Contains(e.Status.Value))
                    .AsQueryable();
            }
            if (filter.Levels.Any())
            {
                var statusList = filter.Levels.Select(
                    e => (BadgeLevel)Enum.Parse(typeof(Entities.BadgeLevel), e)
                );
                query = query
                    .Where(e => e.Level.HasValue && statusList.Contains(e.Level.Value))
                    .AsQueryable();
            }
            if (filter.Skills.Any())
            {
                foreach (var skill in filter.Skills)
                {
                    query = query.Where(e =>
                        e.Skills.Any(j => !string.IsNullOrEmpty(j.Skill.Description) && j.Skill.Description.ToUpper().Contains(skill.ToUpper())));
                }
            }
            return query.PaginatedByFilters<Entities.BadgeTemplate, DTO.BadgeTemplate>(
                filter,
                Mapper
            );
        }

        public async Task<DTO.BadgeTemplate> CreateAsync(DTO.BadgeTemplate badgeTemplateDTO, CancellationToken cancellationToken = default)
        {
            #region BadgeTemplate

            Entities.BadgeTemplate entity = null;
            //Define skill entity and a list of skills save in Skill table
            Entities.Skill skillEntity = null;
            List<Skill> skillToAdd = new List<Skill>();
            List<BadgeTemplateSkill> badgeTemplateSkillsToAdd = new List<BadgeTemplateSkill>();
            try
            {
                //Validates if the new badge template already exists with same name and same level
                var levelEnum = badgeTemplateDTO.Level.ResolveEnum<BadgeLevel>();

                var badgeTemplateExist = DbContext.BadgeTemplates.Any(x => string.Equals(x.Name.ToLower(), badgeTemplateDTO.Name.ToLower()) && x.Level == levelEnum);

                if (badgeTemplateExist)
                {
                    throw new ValidationException(new Result { Messages = new List<string>() { string.Format(GeneralConstants.ErrorMessages.BADGE_TEMPLATE_ALREADY_EXIST, badgeTemplateDTO.Name) }, HasErrors = true });
                }

                var status = badgeTemplateDTO.Status.ResolveEnum<BadgeTemplateStatus>();
                status = _badgeTemplateStatusFlowService.SetAndValidateStatus(BadgeTemplateStatus.NotCreated, status);

                var personIDValue = SessionService.GetSession().PersonID;

                var type = string.IsNullOrEmpty(badgeTemplateDTO.Type) ? default(BadgeType?) : badgeTemplateDTO.Type.ResolveEnum<BadgeType>();

                var level = string.IsNullOrEmpty(badgeTemplateDTO.Level) ? default(BadgeLevel?) : badgeTemplateDTO.Level.ResolveEnum<BadgeLevel>();

                var expiresAt = string.IsNullOrEmpty(badgeTemplateDTO.ExpiresAt) ? default(ExpiresRange?) : badgeTemplateDTO.ExpiresAt.ResolveEnum<ExpiresRange>();

                var owner = DbContext.Employees.FirstOrDefault(e => string.Equals(e.PersonID, badgeTemplateDTO.OwnerPersonID));

                var sponsor = DbContext.Employees.FirstOrDefault(e => string.Equals(e.PersonID, badgeTemplateDTO.SponsorPersonID));

                var approver = DbContext.Employees.FirstOrDefault(e => string.Equals(e.PersonID, badgeTemplateDTO.ApproverPersonID));

                var optionalApprover = DbContext.Employees.FirstOrDefault(e => string.Equals(e.PersonID, badgeTemplateDTO.OptionalApproverPersonID));

                entity = new Entities.BadgeTemplate()
                {
                    Id = Guid.NewGuid(),
                    Issuer = BadgeIssuer.Deloitte.ToString(),
                    ExternalId = badgeTemplateDTO.ExternalId,
                    Name = badgeTemplateDTO.Name,
                    Subtitle = badgeTemplateDTO.Subtitle,
                    Description = badgeTemplateDTO.Description,
                    Type = type,
                    Level = level,
                    Status = status,
                    ImageUrl = badgeTemplateDTO.ImageUrl,
                    InfoUrl = badgeTemplateDTO.InfoUrl,
                    CreatedAt = DateTime.UtcNow,
                    CreatedBy = personIDValue,
                    ExpiresAt = expiresAt,
                    ReviewDate = badgeTemplateDTO.ReviewDate,
                    Owner = owner,
                    Sponsor = sponsor,
                    Approver = approver,
                    OptionalApprover = optionalApprover,
                    LearningObjectives = badgeTemplateDTO.LearningObjectives,
                    IsPublic = true,
                    HaveAlternativeCriteria = badgeTemplateDTO.HaveAlternativeCriteria,
                    AlternativeDescription = badgeTemplateDTO.AlternativeDescription
                };
                DbContext.BadgeTemplates.Add(entity);

                #endregion BadgeTemplate
            }
            catch (Exception e)
            {
                throw (ValidationException)e;
            }

            var skills = new List<Skill>();
            var newBadgeTemplateSkills = new List<BadgeTemplateSkill>();
            try
            {
                #region Skills

                if (!string.Equals(badgeTemplateDTO.Status, BadgeTemplateStatus.Draft) &&
                    badgeTemplateDTO.Skills.IsNullOrEmpty())
                {
                    throw new ValidationException(new Result
                    {
                        Messages = new List<string>() { GeneralConstants.ErrorMessages.BADGE_TEMPLATE_SKILLS_MINIMUM },
                        HasErrors = true
                    });
                }

                var skillNames = badgeTemplateDTO.Skills.Where(x => !string.IsNullOrWhiteSpace(x.SkillName))
                    .Select(x => x.SkillName.ToUpper().Trim()).ToList();
                var existingSkills = DbContext.Skills.Where(x => skillNames.Contains(x.Description.Trim().ToUpper()))
                    .ToList();
                var notExistingSkills = skillNames
                    .Where(x => !existingSkills.Any(j => j.Description.Trim().ToUpper().Contains(x)))
                    .Select(x => new Entities.Skill { Description = x }).ToList();
                DbContext.Skills.AddRange(notExistingSkills);

                skills.AddRange(existingSkills);
                skills.AddRange(notExistingSkills);

                #endregion Skills

                #region Add BadgeTemplateSkill

                var skillsToAdd = skillNames
                    .Where(x => !entity.Skills.Any(j => j.Skill.Description.Trim().ToUpper().Contains(x)))
                    .Select(x =>
                    {
                        var skillDto = badgeTemplateDTO.Skills.Single(j => string.Equals(x.Trim().ToUpper(), j.SkillName.Trim().ToUpper()));
                        return new BadgeTemplateSkill
                        {
                            BadgeTemplate = entity,
                            Skill = skills.Single(j => string.Equals(j.Description.Trim().ToUpper(), x.Trim().ToUpper())),
                            Proficiency = skillDto.Proficiency,
                            SkillType = skillDto.SkillType != null ? Enum.Parse<SkillType>(skillDto.SkillType) : null
                        };
                    }).ToList();
                DbContext.BadgeTemplateSkills.AddRange(skillsToAdd);
                badgeTemplateSkillsToAdd = skillsToAdd;

                #endregion Add BadgeTemplateSkill
            }
            catch (Exception e)
            {
                if (e is ValidationException) throw (ValidationException)e;

                throw new Exception($"Skills {e.Message}", e);
            }

            try
            {
                #region Criterias

                entity.Criterias = badgeTemplateDTO.Criterias
                    .Select(
                        e =>
                            new Entities.BadgeTemplateCriteria
                            {
                                Type = (BadgeTemplateType)Enum.Parse(typeof(BadgeTemplateType), e.Type),
                                BadgeTemplateCriteriaTypeId = e.BadgeTemplateCriteriaType?.Id,
                                BadgeTemplate = entity,
                                Name = e.Name,
                                Description = e.Description,
                                InfoUrl = e.InfoUrl,
                                EvidenceExpected = e.EvidenceExpected,
                                BusinessValidation = e.BusinessValidation,
                                SABACourseID = e.SABACourseID,
                                SABACourseName = e.SABACourseName,
                                SABAValidationNeeded = e.SABAValidationNeeded,
                                IsAlternative = e.IsAlternative
                            }
                    )
                    .ToList();

                #endregion Criterias
            }
            catch (Exception e)
            {
                throw new Exception($"Criterias {e.Message}", e);
            }

            SetUserActivityForBadgeTemplate(
                entity.Id.ToString(GeneralConstants.Common.FORMAT_GUID_TO_STRING),
                SessionService.GetSession().PersonID,
                GeneralConstants.UserActivity.BADGE_TEMPLATE_CREATE_TITLE,
                GeneralConstants.UserActivity.BADGE_TEMPLATE_CREATE_DESC,
                ActivityType.BadgeTemplateCreated
            );

            try
            {
                #region Logo

                if (badgeTemplateDTO.Logo != null && badgeTemplateDTO.Logo.HaveFile)
                {
                    var result = await _blobStorageService.UploadBlobFile(
                        badgeTemplateDTO.Logo.File,
                        $"{_storagePrefix}/{entity.Id}/{_nameLogo}{badgeTemplateDTO.Logo.Extension}",
                        badgeTemplateDTO.Logo.ContentType
                    );
                    entity.ImageUrl = result.IdBlob;
                }

                #endregion Logo
            }
            catch (Exception e)
            {
                throw new Exception($"Logo {e.Message}", e);
            }

            try
            {
                await DbContext.SaveChangesAsync(cancellationToken);
                var result = Mapper.Map<Entities.BadgeTemplate, DTO.BadgeTemplate>(entity);
                result.Skills = Mapper.Map<
                    IList<Entities.BadgeTemplateSkill>,
                    IList<DTO.BadgeTemplateSkill>
                >(badgeTemplateSkillsToAdd);

                return result;
            }
            catch (Exception e)
            {
                if (e is DbUpdateException) throw new Exception($"SaveChanges {e.GetFullMessage()}", e);

                throw new Exception($"SaveChanges {e.Message}", e);
            }
        }

        public async Task<DTO.BadgeTemplate> UpdateAsync(DTO.BadgeTemplate badgeTemplateDTO, CancellationToken cancellationToken = default)
        {
            var entity = DbContext.BadgeTemplates
                .Include(e => e.Skills).ThenInclude(x => x.Skill)
                .Include(e => e.Criterias.Where(x => x.Deleted != true)).ThenInclude(x => x.BadgeTemplateCriteriaType)
                .FirstOrDefault(e => e.Id == badgeTemplateDTO.Id);

            if (entity == null)
            {
                throw new ValidationException(new Result { Messages = new List<string>() { GeneralConstants.ErrorMessages.BADGE_TEMPLATE_INVALID }, HasErrors = true });
            }

            var levelEnum = badgeTemplateDTO.Level.ResolveEnum<BadgeLevel>();
            var badgeTemplateExist = DbContext.BadgeTemplates.Any(x => x.Id != badgeTemplateDTO.Id && string.Equals(x.Name.ToLower(), badgeTemplateDTO.Name.ToLower()) && x.Level == levelEnum);
            if (badgeTemplateExist)
            {
                throw new ValidationException(new Result { Messages = new List<string>() { string.Format(GeneralConstants.ErrorMessages.BADGE_TEMPLATE_ALREADY_EXIST, badgeTemplateDTO.Name) }, HasErrors = true });
            }

            #region BadgeTemplate

            var sessionPerson = SessionService.GetSession();
            var personIDValue = sessionPerson?.PersonID;

            var owner = DbContext.Employees.Single(
                e => string.Equals(e.PersonID, badgeTemplateDTO.OwnerPersonID)
            );

            var sponsor = DbContext.Employees.SingleOrDefault(
                e => string.Equals(e.PersonID, badgeTemplateDTO.SponsorPersonID)
            );

            var approver = DbContext.Employees.SingleOrDefault(
                e => string.Equals(e.PersonID, badgeTemplateDTO.ApproverPersonID)
            );

            var optionalApprover = DbContext.Employees.SingleOrDefault(
                e => string.Equals(e.PersonID, badgeTemplateDTO.OptionalApproverPersonID)
            );

            var type = string.IsNullOrEmpty(badgeTemplateDTO.Type)
                ? default(BadgeType?)
                : (BadgeType)Enum.Parse(typeof(BadgeType), badgeTemplateDTO.Type);
            var level = string.IsNullOrEmpty(badgeTemplateDTO.Level)
                ? default(BadgeLevel?)
                : (BadgeLevel)Enum.Parse(typeof(BadgeLevel), badgeTemplateDTO.Level);
            var status = (BadgeTemplateStatus)
                Enum.Parse(typeof(BadgeTemplateStatus), badgeTemplateDTO.Status);

            var expiresAt = string.IsNullOrEmpty(badgeTemplateDTO.ExpiresAt)
                ? default(ExpiresRange?)
                : (ExpiresRange)Enum.Parse(typeof(ExpiresRange), badgeTemplateDTO.ExpiresAt);

            entity.Status = _badgeTemplateStatusFlowService.SetAndValidateStatus(entity.Status, status);
            entity.Name = badgeTemplateDTO.Name;
            entity.Subtitle = badgeTemplateDTO.Subtitle;
            entity.Description = badgeTemplateDTO.Description;
            entity.Type = type;
            entity.Level = level;
            entity.ImageUrl = badgeTemplateDTO.ImageUrl;
            entity.InfoUrl = badgeTemplateDTO.InfoUrl;
            entity.UpdateAt = DateTime.UtcNow;
            entity.UpdatedBy = personIDValue;
            entity.Owner = owner;
            entity.Approver = approver;
            entity.OptionalApprover = optionalApprover;
            entity.Sponsor = sponsor;
            entity.ExpiresAt = expiresAt;
            entity.ReviewDate = badgeTemplateDTO.ReviewDate;
            entity.LearningObjectives = badgeTemplateDTO.LearningObjectives;
            entity.AlternativeDescription = badgeTemplateDTO.AlternativeDescription;
            entity.HaveAlternativeCriteria = badgeTemplateDTO.HaveAlternativeCriteria;

            #endregion BadgeTemplate

            #region Skills

            var skills = new List<Skill>();
            var newBadgeTemplateSkills = new List<BadgeTemplateSkill>();
            var skillNames = badgeTemplateDTO.Skills.Where(x => !string.IsNullOrWhiteSpace(x.SkillName)).Select(x => x.SkillName.ToUpper().Trim()).ToList();
            var existingSkills = DbContext.Skills.Where(x => skillNames.Contains(x.Description.Trim().ToUpper())).ToList();
            var notExistingSkills = skillNames.Where(x => !existingSkills.Any(j => j.Description.Trim().ToUpper().Contains(x)))
                .Select(x => new Entities.Skill { Description = x }).ToList();
            DbContext.Skills.AddRange(notExistingSkills);

            skills.AddRange(existingSkills);
            skills.AddRange(notExistingSkills);

            var skillsToDelete = entity.Skills.Where(x => !skillNames.Contains(x.Skill.Description.Trim().ToUpper())).ToList();
            var skillsToAdd = skillNames.Where(x => !entity.Skills.Any(j => j.Skill.Description.Trim().ToUpper().Contains(x)))
                .Select(x =>
                {
                    var skillDto = badgeTemplateDTO.Skills.Single(j => string.Equals(x, j.SkillName.Trim().ToUpper()));
                    return new BadgeTemplateSkill
                    {
                        BadgeTemplate = entity,
                        Skill = skills.Single(j => string.Equals(j.Description.Trim().ToUpper(), x)),
                        Proficiency = skillDto.Proficiency,
                        SkillType = Enum.Parse<SkillType>(skillDto.SkillType)
                    };
                }).ToList();
            newBadgeTemplateSkills.AddRange(skillsToAdd);
            var skillsToUpdate = entity.Skills.Where(x => skillNames.Contains(x.Skill.Description.Trim().ToUpper())).ToList();
            skillsToUpdate.ForEach(x =>
            {
                var skillDto = badgeTemplateDTO.Skills.Single(j => string.Equals(x.Skill.Description.Trim().ToUpper(), j.SkillName.Trim().ToUpper()));
                x.Proficiency = skillDto.Proficiency;
                x.SkillType = Enum.Parse<SkillType>(skillDto.SkillType);
            });
            newBadgeTemplateSkills.AddRange(skillsToUpdate);
            DbContext.BadgeTemplateSkills.RemoveRange(skillsToDelete);
            DbContext.BadgeTemplateSkills.AddRange(skillsToAdd);
            DbContext.BadgeTemplateSkills.UpdateRange(skillsToUpdate);

            #endregion Skills

            #region Criterias

            List<BadgeTemplateCriteria> newCriterias = new List<BadgeTemplateCriteria>();
            var criteriasToAddDto = badgeTemplateDTO.Criterias.Where(e => !e.Id.HasValue).ToList();
            var criteriasIdsDto = badgeTemplateDTO.Criterias
                .Where(e => e.Id.HasValue)
                .Select(e => e.Id.Value)
                .ToList();
            var criteriasIdsEntity = entity.Criterias.Select(e => e.Id).ToList();
            var criteriasIdsToUpdate = criteriasIdsDto.Intersect(criteriasIdsEntity);
            var criteriasIdsToDelete = criteriasIdsEntity.Except(criteriasIdsDto);

            var criteriasToAdd = criteriasToAddDto.Select(
                e =>
                {
                    var badgeTempCriteriaTypeGuid = e.BadgeTemplateCriteriaType != null ? e.BadgeTemplateCriteriaType?.Id : Guid.Empty;
                    return new Entities.BadgeTemplateCriteria
                    {
                        Type = (BadgeTemplateType)Enum.Parse(typeof(BadgeTemplateType), e.Type),
                        BadgeTemplateCriteriaType = DbContext.BadgeTemplateCriteriaType.FirstOrDefault(x => x.Id == badgeTempCriteriaTypeGuid),
                        BadgeTemplateCriteriaTypeId = badgeTempCriteriaTypeGuid,
                        BadgeTemplate = entity,
                        Name = e.Name,
                        Description = e.Description,
                        InfoUrl = e.InfoUrl,
                        BusinessValidation = e.BusinessValidation,
                        EvidenceExpected = e.EvidenceExpected,
                        SABACourseID = e.SABACourseID,
                        SABACourseName = e.SABACourseName,
                        SABAValidationNeeded = e.SABAValidationNeeded,
                        Deleted = false,
                        IsAlternative = e.IsAlternative
                    };
                }
            ).ToList();
            newCriterias.AddRange(criteriasToAdd);
            DbContext.BadgeTemplateCriteria.AddRange(criteriasToAdd);

            foreach (var id in criteriasIdsToUpdate)
            {
                var criteriaDto = badgeTemplateDTO.Criterias.Single(e => e.Id == id);
                var criteriaEntity = entity.Criterias.Single(e => e.Id == id);
                var badgeTempCriteriaTypeGuid = criteriaDto.BadgeTemplateCriteriaType != null ? criteriaDto.BadgeTemplateCriteriaType?.Id : Guid.Empty;

                //Verify when status is approved, its required receive a valid criteriaDto.BadgeTemplateCriteriaType.Id

                if ((entity.Status == BadgeTemplateStatus.Submitted || entity.Status == BadgeTemplateStatus.Accepted)
                    && (criteriaDto.BadgeTemplateCriteriaType == null && !criteriaDto.BadgeTemplateCriteriaType.Id.HasValue))
                {
                    throw new ValidationException(new Result
                    {
                        Messages = new List<string>()
                        { GeneralConstants.ErrorMessages.BADGE_TEMPLATE_CRITERIA_INVALID_DATA },
                        HasErrors = true
                    });
                }

                //When status is accepted or submitted, it's allow to execute update
                if (!(entity.Status == BadgeTemplateStatus.Draft))
                {
                    criteriaEntity.BadgeTemplateCriteriaType =
                                    DbContext.BadgeTemplateCriteriaType.FirstOrDefault(x => x.Id == criteriaDto.BadgeTemplateCriteriaType.Id);
                    criteriaEntity.BadgeTemplateCriteriaTypeId = badgeTempCriteriaTypeGuid;
                    criteriaEntity.Name = criteriaDto.Name;
                    criteriaEntity.Description = criteriaDto.Description;
                    criteriaEntity.InfoUrl = criteriaDto.InfoUrl;
                    criteriaEntity.BusinessValidation = criteriaDto.BusinessValidation;
                    criteriaEntity.EvidenceExpected = criteriaDto.EvidenceExpected;
                    criteriaEntity.Deleted = false;
                    criteriaEntity.SABACourseID = criteriaDto.SABACourseID;
                    criteriaEntity.SABACourseName = criteriaDto.SABACourseName;
                    criteriaEntity.SABAValidationNeeded = criteriaDto.SABAValidationNeeded;
                    criteriaEntity.IsAlternative = criteriaDto.IsAlternative;
                    DbContext.BadgeTemplateCriteria.Update(criteriaEntity);

                    newCriterias.Add(criteriaEntity);
                }
            }

            foreach (var id in criteriasIdsToDelete)
            {
                var criteriaEntity = entity.Criterias.Single(e => e.Id == id);
                if (CheckValidStatusForDelete(criteriaEntity, entity.Status))
                {
                    DbContext.BadgeTemplateCriteria.Remove(criteriaEntity);
                }
                else
                {
                    throw new ValidationException(new Result
                    {
                        Messages = new List<string>()
                        { GeneralConstants.ErrorMessages.BADGE_TEMPLATE_DELETE_CRITERIAS_NOT_ALLOWED },
                        HasErrors = true
                    });
                }
            }

            #endregion Criterias

            #region UserActivity

            SetUserActivityForBadgeTemplate(
                entity.Id.ToString(GeneralConstants.Common.FORMAT_GUID_TO_STRING),
                personIDValue,
                GeneralConstants.UserActivity.BADGE_TEMPLATE_UPDATE_TITLE,
                GeneralConstants.UserActivity.BADGE_TEMPLATE_UPDATE_DESC,
                ActivityType.BadgeTemplateUpdated
            );

            #endregion UserActivity

            #region Logo

            if (badgeTemplateDTO.Logo != null && badgeTemplateDTO.Logo.HaveFile)
            {
                var resultUpload = await _blobStorageService.UploadBlobFile(
                    badgeTemplateDTO.Logo.File,
                    $"{_storagePrefix}/{entity.Id}/{_nameLogo}{badgeTemplateDTO.Logo.Extension}",
                    badgeTemplateDTO.Logo.ContentType
                );
                entity.ImageUrl = resultUpload.IdBlob;
            }

            #endregion Logo

            bool isAdmin = sessionPerson?.IsAdmin ?? false;
            var contentParams = new[] { entity.Name };

            try
            {
                switch (entity.Status)
                {
                    case BadgeTemplateStatus.Accepted:
                        entity.ApprovedAt = DateTime.UtcNow;
                        await SetNewCriteriasToRelatedBadge(entity);
                        await CreateOrUpdateBadgeTemplateInCredlyAsync(entity);
                        break;

                    case BadgeTemplateStatus.Archived:
                        await ChangeStatusInCredlyAsync(entity);
                        break;

                    case BadgeTemplateStatus.HideForEdit:
                        await NotificationBadgeTemplateProcessAsync(entity, GeneralConstants.Notification.SUCCESSFUL_SAVED, contentParams);
                        break;

                    case BadgeTemplateStatus.Submitted:
                        await NotificationBadgeTemplateProcessAsync(entity, entity.Status.ToString(), contentParams, isAdmin);
                        break;
                }
            }
            catch (Exception e)
            {
                throw new ValidationException(new Result
                {
                    Messages = new List<string>()
                        { GeneralConstants.ErrorMessages.BADGE_TEMPLATE_INVLID_ACTION },
                    HasErrors = true
                });
            }

            await DbContext.SaveChangesAsync(cancellationToken);

            entity.Criterias = newCriterias;
            entity.Skills = newBadgeTemplateSkills;
            var result = Mapper.Map<Entities.BadgeTemplate, DTO.BadgeTemplate>(entity);

            return result;
        }

        private bool CheckValidStatusForDelete(BadgeTemplateCriteria criteriaEntity, BadgeTemplateStatus? status)
        {
            if (criteriaEntity.IsAlternative == null || (bool)!criteriaEntity.IsAlternative ||
                 ((status == BadgeTemplateStatus.AttentionRequired || status == BadgeTemplateStatus.Submitted || status == BadgeTemplateStatus.Draft) &&
                 criteriaEntity.IsAlternative != null && (bool)criteriaEntity.IsAlternative))
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public async Task DeleteAsync(Guid id, CancellationToken cancellationToken = default)
        {
            Entities.BadgeTemplate badgeTemplate = DbContext.BadgeTemplates.Include(x => x.Approver).Single(x => x.Id == id);

            if (badgeTemplate == null)
            {
                throw new ValidationException(new Result
                {
                    Messages = new List<string>()
                        { GeneralConstants.ErrorMessages.BADGE_TEMPLATE_INVALID },
                    HasErrors = true
                });
            }

            SetUserActivityForBadgeTemplate(
                badgeTemplate.Id.ToString(),
                badgeTemplate.Approver.PersonID,
                GeneralConstants.UserActivity.BADGE_TEMPLATE_DELETE_TITLE,
                GeneralConstants.UserActivity.BADGE_TEMPLATE_DELETE_DESC,
                ActivityType.BadgeTemplateDeleted);

            DbContext.BadgeTemplates.Remove(badgeTemplate);

            try
            {
                if (!string.IsNullOrEmpty(badgeTemplate.ExternalId))
                {
                    await _credlyAPIService.DeleteBadgeTemplate(new Guid(badgeTemplate.ExternalId));
                }
            }
            catch (Exception e)
            {
                throw new ValidationException(new Result { Messages = new List<string>() { GeneralConstants.ErrorMessages.BADGE_TEMPLATE_DELETION_FAILED }, HasErrors = true });
            }

            DbContext.SaveChanges();
        }

        #endregion BaseMethods

        #region Custom Methods

        public ListResponse<DTO.Queries.BadgeTemplateQuery> GetBadgeTemplatesBusinessRep(
           BadgeTemplateFilter filter
        )
        {
            var session = SessionService.GetSession();

            var query = DbContext.BadgeTemplateQueries
                .Where(e => string.Equals(e.OwnerId, session.PersonID))
                .AsQueryable();

            if (!string.IsNullOrWhiteSpace(filter.SearchText))
            {
                query = query.Where(e =>
                    !string.IsNullOrWhiteSpace(e.Name) && e.Name.ToLower().Contains(filter.SearchText.ToLower()));
            }
            if (filter.Status.Any())
            {
                var statusList = filter.Status.Select(
                    e => (BadgeTemplateStatus)Enum.Parse(typeof(Entities.BadgeTemplateStatus), e)
                );
                query = query
                    .Where(e => e.Status.HasValue && statusList.Contains(e.Status.Value))
                    .AsQueryable();
            }
            if (filter.Levels.Any())
            {
                var statusList = filter.Levels.Select(
                    e => (BadgeLevel)Enum.Parse(typeof(Entities.BadgeLevel), e)
                );
                query = query
                    .Where(e => e.Level.HasValue && statusList.Contains(e.Level.Value))
                    .AsQueryable();
            }
            if (filter.Skills.Any())
            {
                foreach (var skill in filter.Skills)
                {
                    query = query.Where(e => !string.IsNullOrWhiteSpace(e.Skills) &&
                                             e.Skills.ToUpper().Contains(skill.ToUpper()));
                }
            }
            if (!filter.ShowExternals)
            {
                query = query.Where(x => !x.IsExternal);
            }

            return query.PaginatedByFilters<
                Entities.Queries.BadgeTemplateQuery,
                DTO.Queries.BadgeTemplateQuery
            >(filter, Mapper);
        }

        public ListResponse<DTO.Queries.BadgeTemplateQuery> GetBadgesTemplatesAdmin(
            BadgeTemplateFilter filter
        )
        {
            var userId = SessionService.GetSession().PersonID;
            var query = DbContext.BadgeTemplateQueries.AsQueryable();

            if (filter.Status.Any())
            {
                var statusList = filter.Status.Select(
                    e => (BadgeTemplateStatus)Enum.Parse(typeof(Entities.BadgeTemplateStatus), e)
                );
                query = query
                    .Where(e => e.Status.HasValue && statusList.Contains(e.Status.Value))
                    .AsQueryable();
            }
            if (!string.IsNullOrWhiteSpace(filter.SearchText))
            {
                query = query.Where(e =>
                    !string.IsNullOrWhiteSpace(e.Name) && e.Name.ToLower().Contains(filter.SearchText.ToLower()));
            }
            if (filter.Status.Any())
            {
                var statusList = filter.Status.Select(
                    e => (BadgeTemplateStatus)Enum.Parse(typeof(Entities.BadgeTemplateStatus), e)
                );
                query = query
                    .Where(e => e.Status.HasValue && statusList.Contains(e.Status.Value))
                    .AsQueryable();
            }
            if (filter.Levels.Any())
            {
                var statusList = filter.Levels.Select(
                    e => (BadgeLevel)Enum.Parse(typeof(Entities.BadgeLevel), e)
                );
                query = query
                    .Where(e => e.Level.HasValue && statusList.Contains(e.Level.Value))
                    .AsQueryable();
            }
            if (filter.Skills.Any())
            {
                foreach (var skill in filter.Skills)
                {
                    query = query.Where(e => !string.IsNullOrWhiteSpace(e.Skills) &&
                                             e.Skills.ToUpper().Contains(skill.ToUpper()));
                }
            }
            if (!filter.ShowExternals)
            {
                query = query.Where(x => !x.IsExternal);
            }

            var result = query.PaginatedByFilters<
                Entities.Queries.BadgeTemplateQuery,
                DTO.Queries.BadgeTemplateQuery
            >(filter, Mapper);

            var data = result.Data.ToList();
            data.ForEach(badgeTemplate =>
            {
                var badge = DbContext.Badges.FirstOrDefault(j =>
                    j.BadgeTemplateId == badgeTemplate.Id && string.Equals(j.Employee.PersonID, userId));
                if (badge != null)
                {
                    badgeTemplate.BadgeStatusForCurrentUser = badge.Status.ToString();
                    badgeTemplate.BadgeIdForCurrentUser = badge.Id;
                }
            });
            result.Data = data;

            return result;
        }

        public ListResponse<DTO.BadgeTemplate> GetBadgeTemplatesQueryPractitioner(
            BadgeTemplateFilter filter
        )
        {
            var userId = SessionService.GetSession().PersonID;
            var query = DbContext.BadgeTemplates
                .Include(x => x.Collections).ThenInclude(x => x.Collection)
                .Include(x => x.Skills).ThenInclude(x => x.Skill)
                .Include(x => x.Approver)
                .Include(x => x.OptionalApprover)
                .Include(x => x.Owner)
                .Include(x => x.Sponsor)
                .Where(x => x.Status == BadgeTemplateStatus.Accepted)
                .Where(x => x.IsPublic == true)
                .AsQueryable();

            if (filter.OrderBy != null && !filter.OrderBy.Column.IsNullOrEmpty() && filter.OrderBy.Column.ToLower() == GeneralConstants.Collection.FILTER_ORDERBY_COLLECTION_TEXT.ToLower())
            {
                query = filter.OrderBy.Desc
                   ? query.OrderByDescending(x => x.Collections.FirstOrDefault().Collection.Name)
                   : query.OrderBy(x => x.Collections.FirstOrDefault().Collection.Name);
                filter.OrderBy.NestedOrUnforced = true;
            }

            if (!string.IsNullOrWhiteSpace(filter.SearchText))
            {
                query = query.Where(e =>
                    !string.IsNullOrWhiteSpace(e.Name) && e.Name.ToLower().Contains(filter.SearchText.ToLower()));
            }
            if (filter.Levels.Any())
            {
                var statusList = filter.Levels.Select(
                    e => (BadgeLevel)Enum.Parse(typeof(Entities.BadgeLevel), e)
                );
                query = query
                    .Where(e => e.Level.HasValue && statusList.Contains(e.Level.Value))
                    .AsQueryable();
            }
            if (filter.Skills.Any())
            {
                foreach (var skill in filter.Skills)
                {
                    query = query.Where(e =>
                        e.Skills.Any(j => !string.IsNullOrEmpty(j.Skill.Description) && j.Skill.Description.ToLower().Contains(skill.ToLower())));
                }
            }
            if (filter.FilterColumns != null && filter.FilterColumns.Any(x => x.Column.ToLower().Equals(GeneralConstants.Collection.FILTER_COLUMN_COLLECTION_TEXT.ToLower())))
            {
                var collecionFilter = filter.FilterColumns.First(x => x.Column.Equals(GeneralConstants.Collection.FILTER_COLUMN_COLLECTION_TEXT));
                var index = filter.FilterColumns.IndexOf(collecionFilter);
                collecionFilter.NestedOrUnforced = true;
                filter.FilterColumns[index] = collecionFilter;

                query = query.Where(e => e.Collections.Any(j =>
                    !string.IsNullOrEmpty(j.Collection.Name) && j.Collection.Name.ToLower().Contains(collecionFilter.Value.ToLower())));
            }
            if (!filter.ShowExternals)
            {
                query = query.Where(x => !string.IsNullOrEmpty(x.Issuer) && x.Issuer.ToLower().Contains(BadgeIssuer.Deloitte.ToString().ToLower()));
            }

            var result = query.PaginatedByFilters<
                Entities.BadgeTemplate,
                DTO.BadgeTemplate
            >(filter, Mapper);

            var data = result.Data.ToList();
            data.ForEach(badgeTemplate =>
            {
                var badges = DbContext.Badges.Where(j => j.Status != BadgeStatus.Discarded &&
                    j.BadgeTemplateId == badgeTemplate.Id && string.Equals(j.Employee.PersonID, userId)).ToList();

                Guid badgeInitiated = default;

                foreach (var item in badges)
                {
                    if (item.Status == BadgeStatus.Initiated)
                    {
                        badgeInitiated = item.Id;
                    }
                }

                if (badgeInitiated != default)
                {
                    badgeTemplate.BadgeStatusForCurrentUser = BadgeStatus.Initiated.ToString();
                    badgeTemplate.BadgeIdForCurrentUser = badgeInitiated;
                }
                else
                {
                    badgeTemplate.BadgeStatusForCurrentUser = badges?.FirstOrDefault()?.Status.ToString();
                    badgeTemplate.BadgeIdForCurrentUser = badges?.FirstOrDefault()?.Id;
                }
            });

            result.Data = data;
            return result;
        }

        public async Task<DTO.BadgeTemplate> ChangePrivacyAsync(DTO.BadgeTemplate badgeTemplate)
        {
            string updatedByPersonId = SessionService.GetSession().PersonID;
            var entity = DbContext.BadgeTemplates.FirstOrDefault(x => string.Equals(x.Id.ToString(), badgeTemplate.Id.ToString()));

            if (entity == null)
            {
                throw new ValidationException(new Result { Messages = new List<string>() { GeneralConstants.ErrorMessages.BADGE_TEMPLATE_INVALID }, HasErrors = true });
            }

            entity.IsPublic = badgeTemplate.IsPublic;

            SetUserActivityForBadgeTemplate(
                entity.Id.ToString(GeneralConstants.Common.FORMAT_GUID_TO_STRING),
                updatedByPersonId,
                GeneralConstants.UserActivity.BADGE_TEMPLATE_CHANGE_PRIVACY,
                string.Format(GeneralConstants.UserActivity.BADGE_TEMPLATE_CHANGE_PRIVACY_DESC, entity.IsPublic.ToString()),
                ActivityType.BadgeTemplatePrivacyUpdated
            );
            DbContext.BadgeTemplates.Update(entity);

            await DbContext.SaveChangesAsync();

            return Mapper.Map<Entities.BadgeTemplate, DTO.BadgeTemplate>(entity);
        }

        public async Task<DTO.BadgeTemplate> ChangeStatusAsync(TransitionStatus statusDto, CancellationToken cancellationToken = default)
        {
            string updatedByPersonId = SessionService.GetSession().PersonID;

            var isOwner = await DbContext.BadgeTemplates.AnyAsync(x => x.CreatedBy == updatedByPersonId, cancellationToken);

            var entity = await DbContext.BadgeTemplates
                .Include(x => x.Skills).ThenInclude(x => x.Skill)
                .Include(x => x.Owner)//REQUIRED FOR APPROVED(ACCEPTED) NOTIFICATION
                .ThenInclude(x => x.EmployeeRoles)
                .ThenInclude(x => x.Role)
                .Include(x => x.Criterias).ThenInclude(x => x.BadgeTemplateCriteriaType)
                .Include(x => x.Sponsor)
                .FirstOrDefaultAsync(e => e.Id == statusDto.Id, cancellationToken);

            if (entity == null)
            {
                throw new ValidationException(new Result { Messages = new List<string>() { GeneralConstants.ErrorMessages.BADGE_TEMPLATE_INVALID }, HasErrors = true });
            }

            var newStatus = statusDto.Status.ResolveEnum<BadgeTemplateStatus>();
            var oldStatus = entity.Status;

            entity.Status = _badgeTemplateStatusFlowService.SetAndValidateStatus(entity.Status, newStatus);

            //This validation should works with Create and Approve action by admin
            if (oldStatus == BadgeTemplateStatus.Draft && entity.Status == BadgeTemplateStatus.Submitted && isOwner && SessionService.GetSession().IsAdmin)
            {
                //Is just to force the status flow from draft to accepted
                newStatus = BadgeTemplateStatus.Accepted;
                entity.Status = _badgeTemplateStatusFlowService.SetAndValidateStatus(entity.Status, newStatus);
            }
            string?[] contentParams = new[] { entity.Name };
            switch (entity.Status)
            {
                case BadgeTemplateStatus.Accepted:
                    entity.ApprovedAt = DateTime.UtcNow;
                    await SetNewCriteriasToRelatedBadge(entity);
                    await CreateOrUpdateBadgeTemplateInCredlyAsync(entity);
                    contentParams = new[] { entity.Name };
                    break;

                case BadgeTemplateStatus.Archived:
                    await SetStatusArchive(entity);
                    break;

                case BadgeTemplateStatus.AttentionRequired:
                    SetFeedback(entity, statusDto.Feedback);
                    contentParams = new[] { entity.Name };
                    break;

                case BadgeTemplateStatus.HideForEdit:
                    contentParams = new[] { entity.Name };
                    break;

                case BadgeTemplateStatus.Submitted:
                    contentParams = new[] { entity.Name };
                    break;
            }

            SetUserActivityForBadgeTemplate(
                entity.Id.ToString(GeneralConstants.Common.FORMAT_GUID_TO_STRING),
                updatedByPersonId,
                GeneralConstants.UserActivity.BADGE_TEMPLATE_CHANGE_STATUS_TITLE,
                string.Format(GeneralConstants.UserActivity.BADGE_TEMPLATE_CHANGE_STATUS_DESC, entity.Status.ToString()),
                ActivityType.BadgeTemplateUpdated
            );

            entity.UpdateAt = DateTime.UtcNow;
            entity.UpdatedBy = updatedByPersonId;
            DbContext.BadgeTemplates.Update(entity);

            var status = entity.Status.ToString();

            bool isForAdmin = false;
            if (entity.Owner != null && entity.Owner.EmployeeRoles != null && entity.Owner.EmployeeRoles.Any(e => string.Equals(e.Role?.Code.ToLower(), RoleType.Admin.ToString().ToLower())))
            {
                isForAdmin = true;
            }

            if ((oldStatus != BadgeTemplateStatus.HideForArchive && oldStatus != BadgeTemplateStatus.HideForEdit) ||
                (oldStatus == BadgeTemplateStatus.HideForEdit && newStatus == BadgeTemplateStatus.Accepted))
            {
                await NotificationBadgeTemplateProcessAsync(entity, status, contentParams, isForAdmin, cancellationToken);
            }

            await DbContext.SaveChangesAsync(cancellationToken);

            return Mapper.Map<Entities.BadgeTemplate, DTO.BadgeTemplate>(entity);
        }

        public List<DTO.BadgeTemplateCriteriaType> GetBadgeTemplateCriteriaTypes()
        {
            var data = DbContext.BadgeTemplateCriteriaType.OrderBy(x => x.Description).ToList();
            return Mapper.Map<List<Entities.BadgeTemplateCriteriaType>, List<DTO.BadgeTemplateCriteriaType>>(data);
        }

        public DTO.BadgeTemplate SetReleaseNotes(ReleaseNotes releaseNotesDto)
        {
            var entity = DbContext.BadgeTemplates
                .FirstOrDefault(e => e.Id == releaseNotesDto.Id);

            if (entity == null)
            {
                throw new ValidationException(new Result { Messages = new List<string>() { GeneralConstants.ErrorMessages.BADGE_TEMPLATE_INVALID }, HasErrors = true });
            }

            if (entity.Status != BadgeTemplateStatus.HideForEdit)
            {
                throw new ValidationException(new Result { Messages = new List<string>() { GeneralConstants.ErrorMessages.BADGE_TEMPLATE_STATUS_NOT_RELEASENOTES }, HasErrors = true });
            }

            entity.ReleaseNotes = releaseNotesDto.Notes;
            entity.ApplyReleaseNotesOnlyInitiated = releaseNotesDto.ApplyOnlyInitiated;
            entity.UpdateAt = DateTime.UtcNow;
            entity.UpdatedBy = SessionService.GetSession().PersonID;

            DbContext.SaveChanges();

            return Mapper.Map<Entities.BadgeTemplate, DTO.BadgeTemplate>(entity);
        }

        public async Task<ArchivingFlow> ArchivingProcessAsync(ArchivingFlow archivingFlow, CancellationToken cancellationToken)
        {
            var entity = DbContext.BadgeTemplates
                .Include(t => t.Criterias).ThenInclude(x => x.BadgeTemplateCriteriaType)
                .Include(t => t.Skills).ThenInclude(x => x.Skill)
                .Include(t => t.Owner)//REQUIRED FOR ARCHIVE NOTIFICATION
                .FirstOrDefault(t => t.Id == archivingFlow.BadgeTemplateId);
            if (entity == null)
            {
                throw new ValidationException(new Result { Messages = new List<string>() { GeneralConstants.ErrorMessages.BADGE_TEMPLATE_INVALID }, HasErrors = true });
            }
            if (entity.OwnerId == null)
            {
                throw new ValidationException(new Result { Messages = new List<string>() { GeneralConstants.ErrorMessages.BADGE_TEMPLATE_WITH_OUT_OWNERID }, HasErrors = true });
            }

            var newStatus = archivingFlow.Status.ResolveEnum<BadgeTemplateStatus>();
            entity.Status = _badgeTemplateStatusFlowService.SetAndValidateStatus(entity.Status, newStatus);

            entity.ArchiveDate = archivingFlow.ArchiveDate;

            var status = entity.Status.ToString();
            string?[] contentParams = null;
            string badgestatus = string.Empty;
            List<DTO.BadgeStatusToArchive> badgeInfoList = (from badge in DbContext.Badges
                                                            join employee in DbContext.Employees on badge.Employee.PersonID equals employee.PersonID
                                                            where badge.BadgeTemplateId == entity.Id
                                                            select new DTO.BadgeStatusToArchive
                                                            {
                                                                EmailOwner = employee.Email,
                                                                EntityId = badge.Id,
                                                                Owner = employee,
                                                                Status = badge.Status.ToString()
                                                            }).ToList();

            await CreateOrUpdateBadgeTemplateInCredlyAsync(entity);// SYNCHRONIZE WITH CREDLY

            switch (entity.Status)
            {
                case BadgeTemplateStatus.HideForArchive:

                    status = archivingFlow.ArchiveDate.HasValue ?
                    GeneralConstants.BadgeTemplate.BADGETEMPLATE_TOBEARCHIVEDATE_STATUS
                    : GeneralConstants.BadgeTemplate.BADGETEMPLATE_TOBEARCHIVENODATE_STATUS;

                    contentParams = new[] { entity.Name };

                    badgestatus = archivingFlow.ArchiveDate.HasValue ? GeneralConstants.Badge.BADGE_TOBEARCHIVEDATE_STATUS : GeneralConstants.Badge.BADGE_TOBEARCHIVENODATE_STATUS;

                    var badgeContentParams = status.Equals(GeneralConstants.Badge.BADGE_TOBEARCHIVEDATE_STATUS) ?
                        new[] { entity.Name, archivingFlow.ArchiveDate.Value.ToString("MMMM dd, yyyy") } :
                        new[] { entity.Name };

                    await NotificationBadgeProcessAsync(badgestatus, badgeInfoList, badgeContentParams);
                    break;

                case BadgeTemplateStatus.Archived:

                    status = GeneralConstants.BadgeTemplate.BADGETEMPLATE_TOBEARCHIVEDATE_STATUS;

                    contentParams = new[] { entity.Name };

                    badgestatus = GeneralConstants.Badge.BADGE_HASBEENARCHIVED_STATUS;

                    await NotificationBadgeProcessAsync(badgestatus, badgeInfoList);
                    break;
            }

            await NotificationBadgeTemplateProcessAsync(entity, status, contentParams);
            await DbContext.SaveChangesAsync(cancellationToken);

            archivingFlow.Result = true;
            return archivingFlow;
        }

        #endregion Custom Methods

        #endregion PublicMethods

        #region PrivateMethods

        private static DTO.CredlyAPI.BadgeTemplate CreateInstanceCredlyApiBadgeTemplate(TransitionStatus statusDto, string status)
        {
            QDR.DTO.CredlyAPI.BadgeTemplate _credlyApiBadgeTemplate = new QDR.DTO.CredlyAPI.BadgeTemplate()
            {
                Id = statusDto.Id,
                State = status
            };
            return _credlyApiBadgeTemplate;
        }

        private async Task SetNewCriteriasToRelatedBadge(Entities.BadgeTemplate entity)
        {
            List<BadgeStatus> statusAllowed = new List<BadgeStatus> { BadgeStatus.Initiated, BadgeStatus.InProgress };
            var badges = DbContext.Badges
                .Include(x => x.Education)
                .Include(x => x.Experience)
                .Include(x => x.Exposure)
                .Where(x => x.BadgeTemplateId == entity.Id && x.Status.HasValue &&
                            statusAllowed.Contains(x.Status.Value))
                .ToList();

            List<Education> newEducations = new List<Education>();
            List<Experience> newExperiences = new List<Experience>();
            List<Exposure> newExposures = new List<Exposure>();

            foreach (var badge in badges)
            {
                foreach (var criteria in entity.Criterias)
                {
                    if (criteria.Type == BadgeTemplateType.Education && !badge.Education.Any(x => x.BadgeTemplateCriteriaId == criteria.Id))
                    {
                        newEducations.Add(new Education
                        {
                            Id = Guid.NewGuid(),
                            Badge = badge,
                            Criteria = criteria,
                            Title = criteria.Name,
                            IsAlternative = criteria.IsAlternative,
                            SABACourseValidated = false
                        });
                    }

                    if (criteria.Type == BadgeTemplateType.Experience && !badge.Experience.Any(x => x.BadgeTemplateCriteriaId == criteria.Id))
                    {
                        newExperiences.Add(new Experience
                        {
                            Id = Guid.NewGuid(),
                            Badge = badge,
                            Criteria = criteria,
                            Title = criteria.Name,
                            IsAlternative = criteria.IsAlternative
                        });
                    }

                    if (criteria.Type == BadgeTemplateType.Eminence && !badge.Exposure.Any(x => x.BadgeTemplateCriteriaId == criteria.Id))
                    {
                        newExposures.Add(new Exposure
                        {
                            Id = Guid.NewGuid(),
                            Badge = badge,
                            Criteria = criteria,
                            Title = criteria.Name,
                            IsAlternative = criteria.IsAlternative
                        });
                    }
                }
            }

            DbContext.Educations.AddRange(newEducations);
            DbContext.Experiencies.AddRange(newExperiences);
            DbContext.Exposures.AddRange(newExposures);
        }

        private async Task CreateOrUpdateBadgeTemplateInCredlyAsync(Entities.BadgeTemplate entity)
        {
            string base64Logo = string.Empty;
            List<string> errorList = new List<string>();
            List<BadgeTemplateCriteria>? noAlternateCriterias = new List<BadgeTemplateCriteria>();
            List<BadgeTemplateSkill>? noAdjancentSkills = new List<BadgeTemplateSkill>();
            if (entity.Criterias == null || !entity.Criterias.Any())
            {
                errorList.Add(GeneralConstants.ErrorMessages.BADGE_TEMPLATE_CRITERIAS_EMPTY);
            }
            else
            {
                noAlternateCriterias = entity.Criterias.Where(x => x.IsAlternative == false || !x.IsAlternative.HasValue).ToList();
                if (noAlternateCriterias == null || !noAlternateCriterias.Any())
                {
                    errorList.Add(GeneralConstants.ErrorMessages.BADGE_TEMPLATE_REQUIERED_NO_ALTERNATIVE_CRITERIA);
                }
                if (!noAlternateCriterias.Any(x => x.BadgeTemplateCriteriaTypeId.HasValue))
                {
                    errorList.Add(GeneralConstants.ErrorMessages.BADGE_TEMPLATE_HAVE_CRITERIA_TYPE);
                }
                if (noAlternateCriterias.Any(x=> x.Name.IsNullOrEmpty()))
                {
                    throw new ValidationException(new Result { Messages = new List<string>() { GeneralConstants.ErrorMessages.BADGE_TEMPLATE_CRITERIA_NAME_NULL }, HasErrors = true });
                }
            }

            noAdjancentSkills = entity.Skills.Where(x => !string.IsNullOrWhiteSpace(x.Skill.Description) && x.SkillType == SkillType.Core).ToList();
            if (noAdjancentSkills == null || noAdjancentSkills.Count < 3)
            {
                errorList.Add(GeneralConstants.ErrorMessages.BADGE_TEMPLATE_SKILLS_MINIMUM);
            }
            if (string.IsNullOrWhiteSpace(entity.ImageUrl))
            {
                errorList.Add(GeneralConstants.ErrorMessages.BADGE_TEMPLATE_LOGO_EMPTY);
            }
            else
            {
                try
                {
                    var resultLogo = await _blobStorageService.DownloadBlobFile(entity.ImageUrl);
                    if (resultLogo != null)
                    {
                        base64Logo = Utils.ConvertToBase64(resultLogo.Content, resultLogo.ContentType);
                    }
                }
                catch (Exception ex)
                {
                    errorList.Add(string.Format(GeneralConstants.ErrorMessages.BADGE_TEMPLATE_CRITERIA_BROKEN_LOGO, ex.Message));
                }

                if (string.IsNullOrWhiteSpace(base64Logo))
                {
                    errorList.Add(GeneralConstants.ErrorMessages.BADGE_TEMPLATE_LOGO_BAD_RESULT);
                }
            }
            if (entity.Criterias != null && entity.Criterias.Any())
            {
                if (entity.Criterias.Any(x => string.IsNullOrWhiteSpace(x.Name)))
                {
                    errorList.Add(GeneralConstants.ErrorMessages.BADGE_TEMPLATE_CRITERIAS_WITHOUT_NAME);
                }
                if (entity.Criterias.Any(x => !x.BadgeTemplateCriteriaTypeId.HasValue))
                {
                    errorList.Add(GeneralConstants.ErrorMessages.BADGE_TEMPLATE_CRITERIAS_WITHOUT_TYPE);
                }
            }

            if (errorList.Any())
            {
                throw new ValidationException(new Result { HasErrors = true, Messages = errorList });
            }

            try
            {

                var credlyBadgeTemplate = new DTO.CredlyAPI.BadgeTemplate
                {
                    Description = entity.Description,
                    Name = entity.Name,
                    State = "active",
                    BadgeTemplateActivities = noAlternateCriterias.Select(x => new DTO.CredlyAPI.BadgeTemplateActivity
                    {
                        Title = x.Name,
                        ActivityType = x.BadgeTemplateCriteriaType.Description
                    }).ToList(),
                    Skills = noAdjancentSkills.Select(x => x.Skill.Description).ToList(),
                    Image = new DTO.CredlyAPI.BadgeTemplateImage { RemoteUploadUrl = base64Logo }
                };

                if (string.IsNullOrWhiteSpace(entity.ExternalId))
                {
                    credlyBadgeTemplate = await _credlyAPIService.CreateBadgeTemplate(credlyBadgeTemplate);
                    entity.ExternalId = credlyBadgeTemplate.Id.Value.ToString(GeneralConstants.Common.FORMAT_GUID_TO_STRING);
                }
                else
                {
                    credlyBadgeTemplate.Id = Guid.Parse(entity.ExternalId);
                    await _credlyAPIService.UpdateBadgeTemplate(credlyBadgeTemplate);
                }
            }
            catch (Exception ex)
            {
                if (ex is ValidationException)
                {
                    throw (ValidationException)ex;
                }

                var errorToReport = await SessionService.GetContextErrorLog();
                errorToReport.Message = ex.GetFullMessage();
                errorToReport.Trace = ex.StackTrace;
                errorToReport.Source = ex.Source;
                await _errorLog.SaveErrorLogAsync(errorToReport);

                throw new ValidationException(new Result
                {
                    Messages = new List<string>()
                        { GeneralConstants.ErrorMessages.BADGE_TEMPLATE_FAILED_CREATE_IN_CREDLY },
                    HasErrors = true
                });
            }
        }

        private async Task SetStatusArchive(Entities.BadgeTemplate entity)
        {
            var badges = DbContext.Badges
                    .Include(x => x.BadgeTemplate)
                    .Include(x => x.Employee)
                    .Where(x => x.BadgeTemplate.Id == entity.Id && (x.Status == BadgeStatus.InProgress || x.Status == BadgeStatus.Awarded)).ToList();

            var badgesInProgress = badges.Where(x => x.Status == BadgeStatus.InProgress).ToList();
            var badgesAwarded = badges.Where(x => x.Status == BadgeStatus.Awarded).ToList();

            NotificacionHub? notificationHub = null;
            List<string?>? emails = null;

            if (badgesInProgress != null && badgesInProgress.Any())
            {
                notificationHub = GeneralConstants.Notification.BADGE_TEMPLATE_INPROGRESS_TO_ARCHIVED;
                var notifications = badges.Select(x => new Notification
                {
                    Id = Guid.NewGuid(),
                    Date = DateTime.UtcNow,
                    Title = notificationHub.Title,
                    Description = notificationHub.Description,
                    EntityType = EntityType.BadgeTemplate,
                    Status = x.BadgeTemplate.Status.ToString(),
                    EntityId = x.BadgeTemplate.Id.ToString(GeneralConstants.Common.FORMAT_GUID_TO_STRING),
                    ReadDate = null,
                    Read = false,
                    Employee = x.Employee,
                    Detail = null
                }).ToList();
                badgesInProgress.ForEach(x => x.Status = BadgeStatus.Archived);
                DbContext.Notifications.AddRange(notifications);
                emails = badgesInProgress.Where(x => x.Employee != null && !string.IsNullOrEmpty(x.Employee.Email)).Select(x => x.Employee.Email).Distinct().ToList();
            }

            if (badgesAwarded != null && badgesAwarded.Any())
            {
                notificationHub = GeneralConstants.Notification.BADGE_TEMPLATE_AWARDED_TO_ARCHIVED;
                var notifications = badges.Select(x => new Notification
                {
                    Id = Guid.NewGuid(),
                    Date = DateTime.UtcNow,
                    Title = notificationHub.Title,
                    Description = notificationHub.Description,
                    EntityType = EntityType.BadgeTemplate,
                    Status = x.BadgeTemplate.Status.ToString(),
                    EntityId = x.BadgeTemplate.Id.ToString(GeneralConstants.Common.FORMAT_GUID_TO_STRING),
                    ReadDate = null,
                    Read = false,
                    Employee = x.Employee,
                    Detail = null
                }).ToList();
                badgesAwarded.ForEach(x => x.Status = BadgeStatus.Archived);
                DbContext.Notifications.AddRange(notifications);
                emails = badgesAwarded.Where(x => x.Employee != null && !string.IsNullOrEmpty(x.Employee.Email)).Select(x => x.Employee.Email).Distinct().ToList();
            }

            await ChangeStatusInCredlyAsync(entity);

            if (notificationHub != null)
            {
                await _hubService.ReceiveNotification(notificationHub, emails);
            }
        }

        private void SetFeedback(Entities.BadgeTemplate badgeTemplate, string feedback)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(feedback))
                {
                    throw new ValidationException(new Result { HasErrors = true, Messages = new List<string> { GeneralConstants.ErrorMessages.FEEDBACK_REQUIRED } });
                }

                if (feedback.Length > GeneralConstants.Feedback.MAX_FEEDBACK_LENGHT)
                {
                    throw new ValidationException(new Result { HasErrors = true, Messages = new List<string> { GeneralConstants.ErrorMessages.MAX_FEEDBACK_LENGTH } });
                }

                var entity = new Feedback
                {
                    Id = Guid.NewGuid(),
                    Date = DateTime.UtcNow,
                    EntityType = EntityType.BadgeTemplate,
                    EntityId = badgeTemplate.Id.ToString(GeneralConstants.Common.FORMAT_GUID_TO_STRING),
                    Status = (int)BadgeTemplateStatus.AttentionRequired,
                    Detail = Utils.Sanitizer(feedback)
                };
                DbContext.Feedback.Add(entity);
            }
            catch (Exception e)
            {
                throw new ValidationException(new Result { HasErrors = true, Messages = new List<string> { e.Message } });
            }
        }

        private void SetUserActivityForBadgeTemplate(string entityId, string personID, string title, string description, ActivityType type)
        {
            try
            {
                var userActivity = new UserActivity()
                {
                    Type = type,
                    Date = DateTime.UtcNow,
                    EntityId = entityId,
                    EmployeeId = personID,
                    Title = title,
                    Description = description
                };

                DbContext.UserActivity.Add(userActivity);
            }
            catch (Exception e)
            {
                throw new ValidationException(new Result { HasErrors = true, Messages = new List<string> { e.Message } });
            }
        }

        private async Task ChangeStatusInCredlyAsync(Entities.BadgeTemplate badgeTemplate)
        {
            if (string.IsNullOrWhiteSpace(badgeTemplate.ExternalId))
            {
                throw new ValidationException(new Result { HasErrors = true, Messages = new List<string> { GeneralConstants.ErrorMessages.BADGE_TEMPLATE_WITH_OUT_EXTERNALID } });
            }

            var statusForCredly = new List<BadgeTemplateStatus> { BadgeTemplateStatus.Archived, BadgeTemplateStatus.Accepted, BadgeTemplateStatus.Draft };
            if (!badgeTemplate.Status.HasValue || !statusForCredly.Contains(badgeTemplate.Status.Value))
            {
                throw new ValidationException(new Result { HasErrors = true, Messages = new List<string> { GeneralConstants.ErrorMessages.BADGE_TEMPLATE_STATUS_NOT_VALID } });
            }

            var guidCredly = Guid.Parse(badgeTemplate.ExternalId);
            var badgeTemplateInCredly = await _credlyAPIService.GetSingleBadgeTemplate(guidCredly);

            if (badgeTemplate.Status == BadgeTemplateStatus.Archived)
            {
                if (!badgeTemplateInCredly.State.Equals(BadgeTemplateStatus.Archived.ToString(), StringComparison.OrdinalIgnoreCase))
                {
                    await _credlyAPIService.ArchiveBadgeTemplate(guidCredly);
                }
            }
            else
            {
                if (badgeTemplateInCredly.State.Equals(BadgeTemplateStatus.Archived.ToString(), StringComparison.OrdinalIgnoreCase))
                {
                    await _credlyAPIService.UnarchiveBadgeTemplate(guidCredly);
                }
                else
                {
                    await _credlyAPIService.UpdateBadgeTemplate(new DTO.CredlyAPI.BadgeTemplate
                    {
                        Id = guidCredly,
                        State = badgeTemplate.Status.ToString().ToLower()
                    });
                }
            }
        }

        private async Task NotificationBadgeTemplateProcessAsync(Entities.BadgeTemplate badgeTemplate, string notificationId, string[] contentParams = default,
                                                                bool isAdmin = false, CancellationToken cancellationToken = default)
        {
            const string entityType = "BadgeTemplate";
            try
            {
                if (!_notificationService.IsAllowedNotification(notificationId, entityType)) return;

                if (badgeTemplate.Owner == null)
                {
                    throw new Exception(GeneralConstants.ErrorMessages.BADGE_TEMPLATE_WITH_OUT_OWNERID);
                }

                DTO.Common.NotificacionHub notificationHub = await _notificationService.SendNotificationToHubAsync
                    (new List<string> { badgeTemplate.Owner.Email ?? string.Empty },
                    notificationId,
                    entityType,
                    contentParams,
                    isAdmin);

                var notificationEntity = new Entities.Notification
                {
                    Id = Guid.NewGuid(),
                    Date = DateTime.UtcNow,
                    Title = notificationHub.Title,
                    Description = notificationHub.Description,
                    EntityType = notificationHub.EntityType.ResolveEnum<EntityType>(),
                    EntityId = badgeTemplate.Id.ToString(GeneralConstants.Common.FORMAT_GUID_TO_STRING),
                    ReadDate = null,
                    Read = false,
                    Employee = badgeTemplate.Owner,
                    Detail = null,
                    Status = badgeTemplate.Status.ToString()
                };

                await DbContext.Notifications.AddAsync(notificationEntity, cancellationToken);
            }
            catch (Exception ex)
            {
                var errorToReport = await SessionService.GetContextErrorLog();
                errorToReport.Message = ex.GetFullMessage();
                errorToReport.Trace = ex.StackTrace;
                errorToReport.Source = ex.Source;
                await _errorLog.SaveErrorLogAsync(errorToReport);
            }
        }

        private async Task NotificationBadgeProcessAsync(string badgeStatus, List<DTO.BadgeStatusToArchive> badgeInfoList, string[] contentParams = default)
        {
            const string entityType = "Badge";
            try
            {
                if (!_notificationService.IsAllowedNotification(badgeStatus, entityType)) return;

                foreach (var badgeInfo in badgeInfoList)
                {
                    DTO.Common.NotificacionHub notificationHub = await _notificationService.SendNotificationToHubAsync
                    (new List<string> { badgeInfo.EmailOwner ?? string.Empty },
                    badgeStatus,
                    entityType,
                    contentParams);
                    var notificationEntity = new Entities.Notification
                    {
                        Id = Guid.NewGuid(),
                        Date = DateTime.UtcNow,
                        Title = notificationHub.Title,
                        Description = notificationHub.Description,
                        EntityType = notificationHub.EntityType.ResolveEnum<EntityType>(),
                        EntityId = badgeInfo.EntityId.ToString(GeneralConstants.Common.FORMAT_GUID_TO_STRING),
                        ReadDate = null,
                        Read = false,
                        Employee = badgeInfo.Owner,
                        Detail = null,
                        Status = badgeInfo.Status
                    };
                    DbContext.Notifications.Add(notificationEntity);
                }
            }
            catch (Exception ex)
            {
                //TODO: REPORT TO LOG
                throw ex;
            }
        }

        public async Task<Course> GetSABACourseByIdAsync(string courseId, CancellationToken cancellationToken = default)
        {
            if (string.IsNullOrWhiteSpace(courseId))
            {
                throw new ValidationException(new Result { Messages = new List<string>() { GeneralConstants.ErrorMessages.BADGE_EDUCATION_SABA_COURSEID_EMPTY }, HasErrors = true });
            }

            return await _sabaService.GetCourseById(courseId);
        }

        #endregion PrivateMethods
    }
}