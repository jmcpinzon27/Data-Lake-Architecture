﻿using Deloitte.QDR.BLL.Base;
using Deloitte.QDR.Contracts;
using Deloitte.QDR.Contracts.BL;
using Deloitte.QDR.Contracts.Services;
using Deloitte.QDR.DTO.Common;
using Deloitte.QDR.DTO.Filters;
using Deloitte.QDR.Entities;
using Deloitte.QDR.Infrastructure;
using Microsoft.EntityFrameworkCore;
using UserActivity = Deloitte.QDR.DTO.UserActivity;

namespace Deloitte.QDR.BLL
{
    public class UserActivityBL : BaseBL, IUserActivityBL
    {
        public UserActivityBL(ISessionService sessionService, IDBContext dbContext, IDataCache dataCache) : base(sessionService, dbContext, dataCache)
        {
        }

        public UserActivity GetById(Guid id)
        {
            var entity = DbContext.UserActivity
                .Include(e => e.Employee)
                .ThenInclude(e => e.EmployeeRoles)
                .ThenInclude(e => e.Role)
                .Single(x => x.Id == id);

            return Mapper.Map<Entities.UserActivity, UserActivity>(entity);
        }

        public ListResponse<UserActivity> GetByFilter(UserActivityFilter filter)
        {
            var query = DbContext.UserActivity
                .Include(e => e.Employee).ThenInclude(e => e.EmployeeRoles).ThenInclude(e => e.Role)
                .AsQueryable();

            if (filter.Type.HasValue)
            {
                query = query.Where(x => x.Type == filter.Type.Value);
            }
            if (filter.From.HasValue)
            {
                query = query.Where(x => x.Date >= filter.From.Value);
            }
            if (filter.To.HasValue)
            {
                query = query.Where(x => x.Date <= filter.To.Value);
            }
            if (!string.IsNullOrWhiteSpace(filter.PersonID))
            {
                query = query
                    .Where(e => !string.IsNullOrEmpty(e.EmployeeId) && string.Equals(e.EmployeeId, filter.PersonID));
            }

            if (filter.BadgeTemplateId.HasValue)
            {
                var badgeTemplate = DbContext.BadgeTemplates.FirstOrDefault(x => x.Id == filter.BadgeTemplateId.Value);
                if (badgeTemplate == null)
                {
                    return new ListResponse<UserActivity> { Result = new Result { HasErrors = false } };
                }
                else
                {
                    List<ActivityType> statusBadgeTemplates = new List<ActivityType>
                    {
                        ActivityType.BadgeTemplateCreated,
                        ActivityType.BadgeTemplateApproved,
                        ActivityType.BadgeTemplateRejected,
                        ActivityType.BadgeTemplateUpdated,
                        ActivityType.BadgeTemplateArchived
                    };
                    query = query.Where(x => statusBadgeTemplates.Contains(x.Type) &&
                                             !string.IsNullOrEmpty(x.EntityId) &&
                                             string.Equals(x.EntityId.ToLower(), badgeTemplate.Id.ToString(GeneralConstants.Common.FORMAT_GUID_TO_STRING).ToLower()));
                }
            }

            if (!string.IsNullOrWhiteSpace(filter.Roles))
            {
                query = query.Where(x => x.Employee.EmployeeRoles.Any(j => j.Role.Code == filter.Roles));
            }

            return query.PaginatedByFilters<Entities.UserActivity, DTO.UserActivity>(filter, Mapper);
        }

        public UserActivity Create(UserActivity badgeDTO)
        {
            throw new NotImplementedException();
        }

        public UserActivity Update(UserActivity badgeDTO)
        {
            throw new NotImplementedException();
        }

        public void Delete(Guid id)
        {
            throw new NotImplementedException();
        }

    }
}
