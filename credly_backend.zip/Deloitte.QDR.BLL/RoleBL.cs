﻿using Deloitte.QDR.BLL.Base;
using Deloitte.QDR.Contracts;
using Deloitte.QDR.Contracts.BL;
using Deloitte.QDR.Contracts.Services;

namespace Deloitte.QDR.BLL
{
    public class RoleBL : BaseBL, IRoleBL
    {
        public RoleBL(ISessionService sessionService, IDBContext dbContext, IDataCache dataCache)
            : base(sessionService, dbContext, dataCache)
        {
        }
        public IEnumerable<DTO.Role> GetRoles()
        {
            var roleList = DbContext.Role.ToList();

            return Mapper.Map<IEnumerable<Entities.Role>, IEnumerable<DTO.Role>>(roleList);
        }
    }
}