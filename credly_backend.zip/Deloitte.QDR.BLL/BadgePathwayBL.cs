﻿using Deloitte.QDR.BLL.Base;
using Deloitte.QDR.Contracts;
using Deloitte.QDR.Contracts.BL;
using Deloitte.QDR.Contracts.Services;
using Deloitte.QDR.DTO;
using Deloitte.QDR.DTO.Common;
using Deloitte.QDR.Infrastructure;
using Microsoft.EntityFrameworkCore;
using BadgePathwayBadgeTemplate = Deloitte.QDR.Entities.BadgePathwayBadgeTemplate;

namespace Deloitte.QDR.BLL;

public class BadgePathwayBL : BaseBL, IBadgePathwayBL
{
    public const string _storagePrefix = "badgePathway";
    public const string _nameLogo = "Logo";
    private readonly IBlobStorageService _blobStorageService;

    public BadgePathwayBL(ISessionService sessionService,
        IDBContext dbContext,
        IDataCache dataCache,
        IBlobStorageService blobStorageService)
        : base(sessionService, dbContext, dataCache)
    {
        _blobStorageService = blobStorageService ?? throw new ArgumentNullException(nameof(blobStorageService));
    }

    #region PUBLIC METHODS

    public async Task<BadgePathway> GetByIdAsync(Guid id, CancellationToken cancellationToken = default)
    {
        var entity = await DbContext.BadgePathway
            .Include(x => x.Owner)
            .Include(x => x.BadgeTemplates).ThenInclude(x => x.BadgeTemplate)
            .Include(x => x.Skills).ThenInclude(x => x.Skill)
            .SingleAsync(e => e.Id == id, cancellationToken);
        var result = Mapper.Map<Entities.BadgePathway, BadgePathway>(entity);
        await SetImages(result);
        return result;
    }

    public async Task<ListResponse<BadgePathway>> GetBadgePathwaysBusinessRepAndAdminAsync(FilterBase filter, CancellationToken cancellationToken = default)
    {
        //TODO: Filter by approvers when the functionality is created.
        var query = DbContext.BadgePathway
            .Include(x => x.Owner)
            .AsQueryable();

        if (!string.IsNullOrWhiteSpace(filter.SearchText))
        {
            query = query.Where(x =>
                !string.IsNullOrEmpty(x.Name) && x.Name.ToLower().Contains(filter.SearchText.ToLower()));
        }
        var result = query.PaginatedByFilters<Entities.BadgePathway, BadgePathway>(filter, Mapper);

        if (result.Data != null && result.Data.Any())
        {
            foreach (var badgePathway in result.Data)
            {
                if (!string.IsNullOrWhiteSpace(badgePathway.ImageUrl))
                {
                    var resultLogo = await _blobStorageService.DownloadBlobFile(badgePathway.ImageUrl);
                    if (resultLogo != null)
                    {
                        badgePathway.Logo = new Base64File
                        {
                            Base64 = Utils.ConvertToBase64(resultLogo.Content, resultLogo.ContentType),
                            FileName = resultLogo.NameFile
                        };
                    }
                }
            }
        }

        return result;
    }

    public async Task<BadgePathway> CreateAsync(BadgePathway badgePathwayDTO, CancellationToken cancellationToken = default)
    {
        List<string> errors = new List<string>();
        var exists = DbContext.BadgePathway.Any(x => string.Equals(x.Name.ToLower(), badgePathwayDTO.Name.ToLower()));
        if (exists)
        {
            errors.Add(string.Format(GeneralConstants.ErrorMessages.BADGE_PATHWAY_ALREADY_EXISTS, badgePathwayDTO.Name));
        }

        if (badgePathwayDTO.Logo == null || !badgePathwayDTO.Logo.HaveFile)
        {
            errors.Add(GeneralConstants.ErrorMessages.BADGE_PATHWAY_LOGO_REQUIRED);
        }

        if (errors.Count > 0)
        {
            throw new ValidationException(new Result { Messages = errors, HasErrors = true });
        }

        var entity = new Entities.BadgePathway
        {
            Id = Guid.NewGuid(),
            Name = badgePathwayDTO.Name,
            Description = badgePathwayDTO.Description,
            OwnerId = badgePathwayDTO.OwnerId,
            CreatedAt = DateTime.UtcNow
        };

        #region Badge Templates

        var badgeTemplatesRelate = new List<BadgePathwayBadgeTemplate>();
        foreach (var badgeTemplateId in badgePathwayDTO.BadgeTemplatesIds)
        {
            var badgePathwayBadgeTemplate = new BadgePathwayBadgeTemplate
            {
                Id = Guid.NewGuid(),
                BadgePathway = entity,
                BadgeTemplateId = badgeTemplateId
            };
            badgeTemplatesRelate.Add(badgePathwayBadgeTemplate);
        }

        #endregion

        #region Skills

        badgePathwayDTO.Skills = badgePathwayDTO.Skills.Where(x => !string.IsNullOrWhiteSpace(x)).Select(x => x.Trim()).Distinct().ToList();
        var skills = new List<Entities.Skill>();
        var skillNames = badgePathwayDTO.Skills.Select(x => x.ToLower().Trim()).ToList();
        var existingSkills = DbContext.Skills.Where(x => skillNames.Contains(x.Description.Trim().ToLower()))
            .ToList();
        var notExistingSkills = skillNames
            .Where(x => !existingSkills.Any(j => j.Description.Trim().ToLower().Contains(x)))
            .Select(x => new Entities.Skill { Description = x }).ToList();

        DbContext.Skills.AddRange(notExistingSkills);
        skills.AddRange(existingSkills);
        skills.AddRange(notExistingSkills);

        var skillsToAdd = skillNames
            .Where(x => !entity.Skills.Any(j => j.Skill.Description.Trim().ToLower().Contains(x)))
            .Select(x =>
            {
                return new Entities.BadgePathwaySkill
                {
                    Id = Guid.NewGuid(),
                    BadgePathway = entity,
                    Skill = skills.Single(j => string.Equals(j.Description.Trim().ToLower(), x.Trim().ToLower()))
                };
            }).ToList();
        DbContext.BadgePathwaySkill.AddRange(skillsToAdd);

        #endregion

        #region Logo

        var resultUpload = await _blobStorageService.UploadBlobFile(
            badgePathwayDTO.Logo.File,
            $"{_storagePrefix}/{entity.Id}/{_nameLogo}{badgePathwayDTO.Logo.Extension}",
            badgePathwayDTO.Logo.ContentType
        );
        entity.ImageUrl = resultUpload.IdBlob;

        #endregion

        entity.BadgeTemplates = badgeTemplatesRelate;
        DbContext.BadgePathway.Add(entity);
        await DbContext.SaveChangesAsync(cancellationToken);
        return await GetByIdAsync(entity.Id, cancellationToken);
    }

    public async Task<BadgePathway> UpdateAsync(BadgePathway badgePathwayDTO, CancellationToken cancellationToken = default)
    {
        var entity = await DbContext.BadgePathway
            .Include(x => x.Owner)
            .Include(x => x.BadgeTemplates).ThenInclude(x => x.BadgeTemplate)
            .Include(x => x.Skills).ThenInclude(x => x.Skill)
            .FirstOrDefaultAsync(e => e.Id == badgePathwayDTO.Id, cancellationToken);

        if (entity == null)
        {
            throw new ValidationException(new Result { Messages = new List<string>() { GeneralConstants.ErrorMessages.BADGE_PATHWAY_INVALID }, HasErrors = true });
        }

        List<string> errors = new List<string>();
        var exists = DbContext.BadgePathway.Any(x => x.Id != entity.Id && string.Equals(x.Name.ToLower(), badgePathwayDTO.Name.ToLower()));
        if (exists)
        {
            errors.Add(string.Format(GeneralConstants.ErrorMessages.BADGE_PATHWAY_ALREADY_EXISTS, badgePathwayDTO.Name));
        }

        if (errors.Count > 0)
        {
            throw new ValidationException(new Result { Messages = errors, HasErrors = true });
        }

        entity.Name = badgePathwayDTO.Name;
        entity.Description = badgePathwayDTO.Description;
        entity.OwnerId = badgePathwayDTO.OwnerId;
        DbContext.BadgePathway.Update(entity);

        #region Badge Templates

        //New BadgeTemplates to relate
        var newBadgeTemplates = badgePathwayDTO.BadgeTemplatesIds
            .Where(x => entity.BadgeTemplates.All(j => j.BadgeTemplateId != x))
            .Select(x => new BadgePathwayBadgeTemplate
            {
                Id = Guid.NewGuid(),
                BadgePathway = entity,
                BadgeTemplateId = x
            }).ToList();
        DbContext.BadgePathwayBadgeTemplate.AddRange(newBadgeTemplates);

        //filter the BadgeTemplates to remove
        var removeBadgeTemplates = entity.BadgeTemplates
            .Where(x => badgePathwayDTO.BadgeTemplatesIds.All(j => j != x.BadgeTemplateId)).ToList();
        DbContext.BadgePathwayBadgeTemplate.RemoveRange(removeBadgeTemplates);

        #endregion

        #region Skills

        badgePathwayDTO.Skills = badgePathwayDTO.Skills.Where(x => !string.IsNullOrWhiteSpace(x)).Select(x => x.Trim()).Distinct().ToList();
        var skills = new List<Entities.Skill>();
        var skillNames = badgePathwayDTO.Skills.Select(x => x.ToLower().Trim()).ToList();
        var existingSkills = DbContext.Skills.Where(x => skillNames.Contains(x.Description.Trim().ToLower()))
            .ToList();
        var notExistingSkills = skillNames
            .Where(x => !existingSkills.Any(j => j.Description.Trim().ToLower().Contains(x)))
            .Select(x => new Entities.Skill { Description = x }).ToList();

        DbContext.Skills.AddRange(notExistingSkills);
        skills.AddRange(existingSkills);
        skills.AddRange(notExistingSkills);

        var skillsToDelete = entity.Skills.Where(x => !skillNames.Contains(x.Skill.Description.Trim().ToLower())).ToList();
        var skillsToAdd = skillNames
            .Where(x => !entity.Skills.Any(j => j.Skill.Description.Trim().ToLower().Contains(x)))
            .Select(x =>
            {
                return new Entities.BadgePathwaySkill
                {
                    Id = Guid.NewGuid(),
                    BadgePathway = entity,
                    Skill = skills.Single(j => string.Equals(j.Description.Trim().ToLower(), x.Trim().ToLower()))
                };
            }).ToList();
        DbContext.BadgePathwaySkill.AddRange(skillsToAdd);
        DbContext.BadgePathwaySkill.RemoveRange(skillsToDelete);

        #endregion

        #region Logo

        if (badgePathwayDTO.Logo != null && badgePathwayDTO.Logo.HaveFile)
        {
            var resultUpload = await _blobStorageService.UploadBlobFile(
                badgePathwayDTO.Logo.File,
                $"{_storagePrefix}/{entity.Id}/{_nameLogo}{badgePathwayDTO.Logo.Extension}",
                badgePathwayDTO.Logo.ContentType
            );
            entity.ImageUrl = resultUpload.IdBlob;
        }

        #endregion



        await DbContext.SaveChangesAsync(cancellationToken);
        return await GetByIdAsync(entity.Id, cancellationToken);

    }

    public List<string> GetSkillsFromBadgeTemplates(List<Guid> idsBadgeTemplates)
    {
        return DbContext.BadgeTemplateSkills.Where(x => idsBadgeTemplates.Contains(x.BadgeTemplateId))
            .Select(x => x.Skill.Description).Distinct().ToList();
    }

    #endregion PUBLIC METHODS

    #region PRIVATE METHODS

    private async Task SetImages(BadgePathway badgePathway)
    {
        if (!string.IsNullOrWhiteSpace(badgePathway.ImageUrl))
        {
            var resultLogo = await _blobStorageService.DownloadBlobFile(badgePathway.ImageUrl);
            if (resultLogo != null)
            {
                badgePathway.Logo = new Base64File
                {
                    Base64 = Utils.ConvertToBase64(resultLogo.Content, resultLogo.ContentType),
                    FileName = resultLogo.NameFile
                };
            }
        }

        if (badgePathway.BadgeTemplatesData != null && badgePathway.BadgeTemplatesData.Any())
        {
            foreach (var badgeTemplatePathways in badgePathway.BadgeTemplatesData)
            {
                if (!string.IsNullOrWhiteSpace(badgeTemplatePathways.ImageUrl))
                {
                    var resultLogo = await _blobStorageService.DownloadBlobFile(badgeTemplatePathways.ImageUrl);
                    if (resultLogo != null)
                    {
                        badgeTemplatePathways.Logo = new Base64File
                        {
                            Base64 = Utils.ConvertToBase64(resultLogo.Content, resultLogo.ContentType),
                            FileName = resultLogo.NameFile
                        };
                    }
                }
            }
        }
    }

    #endregion PRIVATE METHODS

}