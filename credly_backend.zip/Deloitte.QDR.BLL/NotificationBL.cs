﻿using Deloitte.QDR.BLL.Base;
using Deloitte.QDR.Contracts;
using Deloitte.QDR.Contracts.BL;
using Deloitte.QDR.Contracts.Services;
using Deloitte.QDR.DTO.Common;
using Deloitte.QDR.DTO.Filters;
using Deloitte.QDR.Entities;
using Deloitte.QDR.Infrastructure;
using Microsoft.EntityFrameworkCore;

namespace Deloitte.QDR.BLL
{
    public class NotificationBL : BaseBL, INotificationBL
    {
        public NotificationBL(
            ISessionService sessionService,
            IDBContext dbContext,
            IDataCache dataCache
        )
            : base(sessionService, dbContext, dataCache) { }

        public ListResponse<DTO.Notification> GetNotificationsPractitioner(NotificationFilter filter)
        {
            var session = SessionService.GetSession();
            var query = DbContext.Notifications
                .Where(e => string.Equals(e.Employee.PersonID, session.PersonID))
                .AsQueryable();

            query = SetFilter(filter, query);

            return query.PaginatedByFilters<Entities.Notification, DTO.Notification>(
                filter,
                Mapper
            );
        }

        public ListResponse<DTO.Notification> GetNotificationsBusinessRep(NotificationFilter filter)
        {
            var session = SessionService.GetSession();
            var query = DbContext.Notifications
                .Where(e => string.Equals(e.Employee.PersonID, session.PersonID))
                .AsQueryable();

            query = SetFilter(filter, query);

            return query.PaginatedByFilters<Entities.Notification, DTO.Notification>(
                filter,
                Mapper
            );
        }

        public ListResponse<DTO.Notification> GetNotificationsAdmin(NotificationFilter filter)
        {
            var query = DbContext.Notifications
                .AsQueryable();

            query = SetFilter(filter, query);

            if (!string.IsNullOrWhiteSpace(filter.PersonID))
            {
                query = query.Where(x =>
                    !string.IsNullOrEmpty(x.EmployeeId) && string.Equals(x.EmployeeId, filter.PersonID));
            }

            return query.PaginatedByFilters<Entities.Notification, DTO.Notification>(
                filter,
                Mapper
            );
        }

        private IQueryable<Notification> SetFilter(NotificationFilter filter, IQueryable<Notification> query)
        {
            query = query.Include(x => x.Employee);

            if (!string.IsNullOrWhiteSpace(filter.Title))
            {
                query = query.Where(x => x.Title.ToUpper().Contains(filter.Title.ToUpper()));
            }
            if (!string.IsNullOrWhiteSpace(filter.Description))
            {
                query = query.Where(
                    x => x.Description.ToUpper().Contains(filter.Description.ToUpper())
                );
            }
            if (filter.EntityType.Any())
            {
                var entityTypeList = filter.EntityType.Select(
                    e => (EntityType)Enum.Parse(typeof(Entities.EntityType), e)
                );
                query = query.Where(
                    e => e.EntityType.HasValue && entityTypeList.Contains(e.EntityType.Value)
                );
            }
            if (filter.StartDate.HasValue)
            {
                query = query.Where(x => x.Date >= filter.StartDate.Value);
            }
            if (filter.EndDate.HasValue)
            {
                query = query.Where(x => x.Date <= filter.EndDate.Value);
            }
            if (filter.Read.HasValue)
            {
                query = query.Where(x => x.Read == filter.Read.Value);
            }

            return query;
        }
    }
}
