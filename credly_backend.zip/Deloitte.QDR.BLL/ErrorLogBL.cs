﻿using Deloitte.QDR.BLL.Base;
using Deloitte.QDR.Contracts;
using Deloitte.QDR.Contracts.BL;
using Deloitte.QDR.Contracts.Services;
using Deloitte.QDR.DTO;
using Deloitte.QDR.DTO.Common;
using Deloitte.QDR.DTO.Filters;
using Deloitte.QDR.Infrastructure;

namespace Deloitte.QDR.BLL;

public class ErrorLogBL : BaseBL, IErrorLogBL
{
    public ErrorLogBL(ISessionService sessionService, IDBContext dbContext, IDataCache dataCache)
        : base(sessionService, dbContext, dataCache) { }

    public async Task SaveErrorLogAsync(ErrorLog dto, CancellationToken cancellationToken = default)
    {
        //TODO: try and catch to send some log to the application insight.

        UserSession? session = await SessionService.GetSessionAsync();

        dto.Id = Guid.NewGuid();
        dto.Date = DateTime.UtcNow;
        dto.PersonID = session?.PersonID;
        dto.UserEmail = session?.Email;

        var entity = Mapper.Map<ErrorLog, Entities.ErrorLog>(dto);

        await DbContext.ErrorLog.AddAsync(entity, cancellationToken);
        await DbContext.SaveChangesAsync(cancellationToken);

    }

    public ListResponse<ErrorLog> GetByFilter(ErrorLogFilter filter)
    {
        var query = DbContext.ErrorLog.AsQueryable();

        if (filter.From.HasValue)
        {
            query = query.Where(x => x.Date >= filter.From.Value);
        }
        if (filter.To.HasValue)
        {
            query = query.Where(x => x.Date <= filter.To.Value);
        }
        if (filter.Method.HasValue)
        {
            query = query.Where(x => x.Method.ToLower() == filter.Method.Value.ToString().ToLower());
        }
        if (!string.IsNullOrWhiteSpace(filter.PersonID))
        {
            query = query.Where(x => !string.IsNullOrEmpty(x.PersonID) && x.PersonID == filter.PersonID);
        }
        if (!string.IsNullOrWhiteSpace(filter.Email))
        {
            query = query.Where(x => !string.IsNullOrEmpty(x.UserEmail) && x.UserEmail.ToLower().Contains(filter.Email.ToLower()));
        }
        if (!string.IsNullOrWhiteSpace(filter.SearchText))
        {
            query = query.Where(x => !string.IsNullOrEmpty(x.Message) && x.Message.ToLower().Contains(filter.SearchText.ToLower()));
        }

        return query.PaginatedByFilters<Entities.ErrorLog, ErrorLog>(filter, Mapper);
    }
}