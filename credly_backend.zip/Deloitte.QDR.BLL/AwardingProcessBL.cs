﻿using System.Web;
using Deloitte.QDR.BLL.Base;
using Deloitte.QDR.Contracts;
using Deloitte.QDR.Contracts.BL;
using Deloitte.QDR.Contracts.Services;
using Deloitte.QDR.DTO.Common;
using Deloitte.QDR.Entities;
using Deloitte.QDR.Entities.Enum;
using Deloitte.QDR.Infrastructure;
using Ganss.Xss;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;

namespace Deloitte.QDR.BLL
{
    public class AwardingProcessBL : BaseBL, IAwardingProcessBL
    {
        private readonly IBlobStorageService _blobStorageService;
        private readonly IHubService _hubService;
        private readonly IFeedbackService _feedbackService;

        public AwardingProcessBL(ISessionService sessionService, IDBContext dbContext, IDataCache dataCache, IBlobStorageService blobStorageService, IHubService hubService, IFeedbackService feedbackService) : base(sessionService, dbContext, dataCache)
        {
            _blobStorageService = blobStorageService;
            _hubService = hubService;
            _feedbackService = feedbackService;
        }

        public DTO.AwardingProcess GetById(Guid id)
        {
            var entity = DbContext.AwardingProcess.SingleOrDefault(e => e.Id.Equals(id));
            var feedback = _feedbackService.GetLastFeedback(entity.Id, EntityType.AwardingProcess);

            if (feedback != null && entity != null)
                entity.LastFeedback = feedback.Detail;

            return Mapper.Map<Entities.AwardingProcess, DTO.AwardingProcess>(entity);
        }

        public ListResponse<DTO.AwardingProcess> GetByFilter(FilterBase filter)
        {
            //TODO: Pending to apply task # 3510636 //var query = DbContext.AwardingProcess.AsQueryable();
            var query = DbContext.AwardingProcess.Where(x => true).AsQueryable();

            var response = query.PaginatedByFilters<Entities.AwardingProcess, DTO.AwardingProcess>(filter, Mapper);
            //TODO: With a FK on CreatedBy is no necessary this iteration.
            if (!response.Data.IsNullOrEmpty())
            {
                foreach (var awp in response.Data)
                {
                    //TODO: This is not good because for N size of page send two petitions to DB
                    var firstName = DbContext.Employees.FirstOrDefault(x => x.PersonID == awp.CreatedBy)?.FirstName;
                    var lastName = DbContext.Employees.FirstOrDefault(x => x.PersonID == awp.CreatedBy)?.LastName;

                    awp.CreatedById = awp.CreatedBy;
                    awp.CreatedBy = $"{lastName}, {firstName}";
                }
            }

            return response;
        }

        /// <summary>
        /// Update record created by Create Method and fill missing data 
        /// </summary>
        /// <param name="bulkAwardingProcessDTO"></param>
        /// <returns>AwardingProcess DTO</returns>
        /// <exception cref="Exception"></exception>
        public async Task<DTO.AwardingProcess> UpdateAsync(DTO.AwardingProcess bulkAwardingProcessDto, CancellationToken cancellationToken = default)
        {
            var awardingEntity = Mapper.Map<AwardingProcess>(bulkAwardingProcessDto);
            //Null validation
            if (bulkAwardingProcessDto == null)
            {
                throw new Exception($"Awarding process with cohort ID {bulkAwardingProcessDto.CohortId} not found");
            }


            //Find the specific object to update
            var awardingProcess = DbContext.AwardingProcess
                .Include(x => x.Approver)
                .FirstOrDefault(e => e.Id == awardingEntity.Id);

            if (awardingProcess == null)
            {
                throw new ValidationException(new Result { Messages = new List<string>() { GeneralConstants.ErrorMessages.AWARDING_PROCESS_INVALID }, HasErrors = true });
            }

            var badgeTemplateExist = DbContext.BadgeTemplates.Any(x => x.Id == bulkAwardingProcessDto.BadgeTemplate_Id);
            if (!badgeTemplateExist)
            {
                throw new ValidationException(new Result { Messages = new List<string>() { GeneralConstants.ErrorMessages.BADGE_TEMPLATE_INVALID }, HasErrors = true });
            }

            //Set new values tu update in
            awardingProcess.Title = bulkAwardingProcessDto.Title;
            awardingProcess.BadgeTemplate_Id = bulkAwardingProcessDto.BadgeTemplate_Id;
            awardingProcess.Approver_Id = bulkAwardingProcessDto.Approver_Id;
            awardingProcess.Status = (AwardingProcessStatus)Enum.Parse(typeof(AwardingProcessStatus), bulkAwardingProcessDto.Status);
            awardingProcess.CompletionDate = bulkAwardingProcessDto.CompletionDate;

            if (awardingProcess.Status == AwardingProcessStatus.Submitted)
            {

                var notificationHub = GeneralConstants.Notification.BULK_AWARD_SUBMITTED;

                notificationHub.Description = string.Format(notificationHub.Description, awardingProcess.CohortId.ToString());

                var employees = DbContext.EmployeeRole
                    .Include(x => x.Employee)
                    .Include(x => x.Role)
                    .Where(x => x.Role.Code == GeneralConstants.Role.ADMIN_ROLE)
                    .Select(x => x.Employee).ToList();

                if (awardingProcess.Approver != null)
                {
                    employees.Add(awardingProcess.Approver);
                }

                var notifications = new List<Notification>();

                foreach (var employee in employees)
                {
                    var notification = new Entities.Notification
                    {
                        Id = Guid.NewGuid(),
                        Date = DateTime.UtcNow,
                        Title = notificationHub.Title,
                        Description = notificationHub.Description,
                        EntityType = EntityType.AwardingProcess,
                        EntityId = awardingProcess.Id.ToString(GeneralConstants.Common.FORMAT_GUID_TO_STRING),
                        ReadDate = null,
                        Read = false,
                        Employee = employee,
                        Detail = null
                    };
                    notifications.Add(notification);
                }

                if (notifications.Count != 0)
                {
                    DbContext.Notifications.AddRange(notifications);
                }

                List<string?> emails = employees.Select(x => x.Email).ToList();

                await _hubService.ReceiveNotification(notificationHub, emails);
            }

            //Verify and upload CSV file to blob storage and return URI
            if (bulkAwardingProcessDto.CsvUrlFileBase64 != null && bulkAwardingProcessDto.CsvUrlFileBase64.HaveFile)
            {
                string prefix = GeneralConstants.AwardingProcess.STORAGE_PREFIX;
                string csvName = GeneralConstants.AwardingProcess.CSV_NAME;
                string extension = bulkAwardingProcessDto.CsvUrlFileBase64.Extension;

                awardingProcess.CsvUrlFile = await _blobStorageService.SendFileToStorageAsync(
                    bulkAwardingProcessDto.CsvUrlFileBase64.File,
                    awardingProcess.Id,
                    bulkAwardingProcessDto.CsvUrlFileBase64.ContentType,
                    prefix,
                    $"{csvName}{extension}"
                );
            }

            //Verify and upload ZIP file to blob storage and return URI
            if (bulkAwardingProcessDto.ZipUrlFileBase64 != null && bulkAwardingProcessDto.ZipUrlFileBase64.HaveFile)
            {
                string prefix = GeneralConstants.AwardingProcess.STORAGE_PREFIX;
                string zipName = GeneralConstants.AwardingProcess.ZIP_NAME;
                string extension = bulkAwardingProcessDto.ZipUrlFileBase64.Extension;

                awardingProcess.ZipUrlFile = await _blobStorageService.SendFileToStorageAsync(
                    bulkAwardingProcessDto.ZipUrlFileBase64.File,
                    awardingProcess.Id,
                    bulkAwardingProcessDto.ZipUrlFileBase64.ContentType,
                    prefix,
                    $"{zipName}{extension}"
                );
            }

            try
            {
                //Upload register
                DbContext.SaveChanges();

                //Map the entity into DTO
                var awardingProcessDto = Mapper.Map<DTO.AwardingProcess>(awardingProcess);
                return awardingProcessDto;
            }
            catch (Exception e)
            {
                throw new Exception(e.GetFullMessage());
            }

        }

        /// <summary>
        /// Create a new record without any data,
        /// only save CohortId
        /// </summary>
        /// <returns>AwardingProcess DTO</returns>
        public DTO.AwardingProcess CreateAwardingProcess()
        {
            //Set an instance of AwardingProcess entity with the new record
            var awardingProcess = new AwardingProcess()
            {
                CreatedBy = SessionService.GetSession().PersonID,
                Createdate = DateTime.UtcNow,
                Status = AwardingProcessStatus.Draft,

            };

            //Add the entity to Db context
            var result = DbContext.AwardingProcess.Add(awardingProcess);
            //Update the new record into Database
            DbContext.SaveChanges();

            //Map the entity into DTO
            var awardingProcessDto = Mapper.Map<DTO.AwardingProcess>(awardingProcess);

            return awardingProcessDto;
        }

        public void Delete(Guid id)
        {
            try
            {
                //Find the specific object to delete
                var awardingProcess = DbContext.AwardingProcess.FirstOrDefault(e => e.Id == id);

                if (awardingProcess == null)
                {
                    throw new Exception($"Awarding process with ID {id} not found");
                }

                DbContext.AwardingProcess.Remove(awardingProcess);
                DbContext.SaveChanges();
            }
            catch (Exception e)
            {
                throw new Exception(e.GetFullMessage());
            }
        }

        public DTO.AwardingProcess ChangeStatus(DTO.AwardingProcess bulkAwardingProcessDto)
        {
            var awardingEntity = Mapper.Map<AwardingProcess>(bulkAwardingProcessDto);
            //Null validation
            if (bulkAwardingProcessDto == null)
            {
                return null;
            }

            try
            {
                //Find the specific object to update
                var awardingProcess = DbContext.AwardingProcess.FirstOrDefault(e => e.Id == awardingEntity.Id);

                if (bulkAwardingProcessDto.Status == AwardingProcessStatus.AttentionRequired.ToString())
                {
                    SetFeedback(EntityType.AwardingProcess, awardingEntity.Id,
                        (int)AwardingProcessStatus.AttentionRequired, bulkAwardingProcessDto.LastFeedback);
                }

                //Set new Status to update in
                awardingProcess.Status = (AwardingProcessStatus)Enum.Parse(typeof(AwardingProcessStatus), bulkAwardingProcessDto.Status);

                //Upload register
                DbContext.SaveChanges();

                //Map the entity into DTO
                var awardingProcessDto = Mapper.Map<DTO.AwardingProcess>(awardingProcess);
                return awardingProcessDto;
            }
            catch (Exception e)
            {
                throw new Exception(e.GetFullMessage());
            }
        }

        private void SetFeedback(EntityType entityType, Guid entityId, int status, string feedback)
        {
            var feedBackSafe = Utils.Sanitizer(feedback);
            if (feedBackSafe.Length <= 0 && feedback.Length > 0)
            {
                throw new ValidationException(new Result
                {
                    HasErrors = true,
                    Messages = new List<string> { GeneralConstants.ErrorMessages.FEEDBACK_SANITIZER }
                });
            }

            var feedbackEntity = new Feedback
            {
                Id = Guid.NewGuid(),
                Date = DateTime.UtcNow,
                EntityType = entityType,
                EntityId = entityId.ToString(GeneralConstants.Common.FORMAT_GUID_TO_STRING),
                Status = status,
                Detail = feedBackSafe
            };
            DbContext.Feedback.Add(feedbackEntity);
        }
    }
}
