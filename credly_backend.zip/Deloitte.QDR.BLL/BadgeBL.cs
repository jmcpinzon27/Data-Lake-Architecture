﻿using AngleSharp.Dom;
using AutoMapper;
using Deloitte.QDR.BLL.Base;
using Deloitte.QDR.Contracts;
using Deloitte.QDR.Contracts.BL;
using Deloitte.QDR.Contracts.Services;
using Deloitte.QDR.DTO.Common;
using Deloitte.QDR.DTO.CredlyAPI.Common;
using Deloitte.QDR.DTO.Filters;
using Deloitte.QDR.DTO.Queries;
using Deloitte.QDR.Entities;
using Deloitte.QDR.Infrastructure;
using Deloitte.QDR.Infrastructure.Config;
using Deloitte.QDR.Services;
using Microsoft.EntityFrameworkCore;
using System.Net;
using System.Threading;

namespace Deloitte.QDR.BLL
{
    public class BadgeBL : BaseBL, IBadgeBL
    {
        private readonly IBlobStorageService _blobStorageService;
        private readonly ICredlyAPIService _credlyAPIService;
        private readonly IStatusFlowValidator<BadgeStatus> _statusFlowService;
        private readonly IHubService _hubService;
        private readonly INotificationService _notificationService;
        private readonly IEmailValidation _emailValidation;
        private readonly IFeedbackService _feedbackService;
        private readonly ILoginValidationService _loginValidationService;
        private readonly IErrorLogBL _errorLog;
        private readonly ISABAService _sabaService;

        public BadgeBL(ISessionService sessionService,
            IDBContext dbContext,
            IDataCache dataCache,
            IBlobStorageService blobStorageService,
            BadgeStatusFlowService statusFlowService,
            ICredlyAPIService credlyAPIService,
            IHubService hubService,
            INotificationService notificationService,
            IFeedbackService feedbackService,
            IEmailValidation emailValidation,
            ILoginValidationService loginValidationService,
            ISABAService sabaService,
            IErrorLogBL errorLog)
            : base(sessionService, dbContext, dataCache)
        {
            _blobStorageService = blobStorageService ?? throw new ArgumentNullException(nameof(blobStorageService));
            _statusFlowService = statusFlowService ?? throw new ArgumentNullException(nameof(statusFlowService));
            _hubService = hubService ?? throw new ArgumentNullException(nameof(hubService));
            _credlyAPIService = credlyAPIService ?? throw new ArgumentNullException(nameof(credlyAPIService));
            _notificationService = notificationService ?? throw new ArgumentNullException(nameof(notificationService));
            _emailValidation = emailValidation ?? throw new ArgumentNullException(nameof(emailValidation));
            _feedbackService = feedbackService ?? throw new ArgumentNullException(nameof(feedbackService));
            _loginValidationService = loginValidationService ?? throw new ArgumentNullException(nameof(loginValidationService));
            _sabaService = sabaService ?? throw new ArgumentNullException(nameof(sabaService));
            _errorLog = errorLog ?? throw new ArgumentNullException(nameof(errorLog));
        }

        #region PUBLIC METHODS

        #region BASE METHODS

        public DTO.Badge GetById(Guid id)
        {
            var entity = DbContext.Badges
                .Include(x => x.BadgeTemplate)
                .Include(x => x.Education).ThenInclude(x => x.Criteria)
                .Include(x => x.Experience)
                .Include(x => x.Exposure)
                .Include(x => x.Employee)
                .FirstOrDefault(e => e.Id == id);

            if (entity == null)
            {
                throw new ValidationException(new Result { Messages = new List<string>() { GeneralConstants.ErrorMessages.BADGE_INVALID }, HasErrors = true });
            }

            var dto = Mapper.Map<Entities.Badge, DTO.Badge>(entity);
            dto.BadgeTemplateReleaseNotes = entity.BadgeTemplate.ReleaseNotes;
            dto.ApplyReleaseNotesOnlyInitiated = entity.BadgeTemplate.ApplyReleaseNotesOnlyInitiated;
            dto.BadgeTemplateLastUpdate = entity.BadgeTemplate.UpdateAt;
            dto.BadgeTemplateHaveAlternativeCriteria = entity.BadgeTemplate.HaveAlternativeCriteria;

            var feedback = _feedbackService.GetLastFeedback(id, EntityType.Badge);
            if (feedback != null && dto != null)
                dto.LastFeedback = feedback.Detail;

            return dto;
        }

        public ListResponse<DTO.Badge> GetByFilter(BadgesFilter filter)
        {
            var query = DbContext.Badges
                .Include(e => e.Employee)
                .Include(e => e.BadgeTemplate)
                .AsQueryable();

            if (!string.IsNullOrEmpty(filter.PersonID))
            {
                query = query.Where(
                     e => e.Employee.PersonID.ToUpper().Equals(filter.PersonID.ToUpper())
                 );
            }

            if (filter.Status.Any())
            {
                var statusList = filter.Status.Select(
                    e => (BadgeStatus)Enum.Parse(typeof(Entities.BadgeStatus), e)
                );
                query = query
                    .Where(e => e.Status.HasValue && statusList.Contains(e.Status.Value))
                    .AsQueryable();
            }

            return query.PaginatedByFilters<Entities.Badge, DTO.Badge>(filter, Mapper);
        }

        public DTO.Badge Create(DTO.Badge badgeDTO)
        {
            var employeeInfo = DbContext.Employees.Single(t => t.PersonID == badgeDTO.EmployeePersonID);
            var badgeTemplateInfo = DbContext.BadgeTemplates
                .Include(x => x.Criterias)
                .FirstOrDefault(t => t.Id == badgeDTO.BadgeTemplateId);

            if (badgeTemplateInfo == null)
            {
                throw new ValidationException(new Result { Messages = new List<string>() { GeneralConstants.ErrorMessages.BADGE_TEMPLATE_INVALID }, HasErrors = true });
            }

            List<BadgeStatus> statusNotAllowed = new List<BadgeStatus> { BadgeStatus.Withdrawn, BadgeStatus.Deleted, BadgeStatus.Discarded };
            var badgeExist = DbContext.Badges.Any(x =>
                string.Equals(x.Employee.PersonID, employeeInfo.PersonID) &&
                x.BadgeTemplateId == badgeTemplateInfo.Id &&
                x.Status.HasValue &&
                !statusNotAllowed.Contains(x.Status.Value));

            if (badgeExist)
            {
                throw new ValidationException(new Result { Messages = new List<string>() { GeneralConstants.ErrorMessages.BADGE_ALREADY_EXIST }, HasErrors = true });
            }

            DateTime? badgeExpiresAt = null;
            if (badgeTemplateInfo.CreatedAt.HasValue && badgeTemplateInfo.ExpiresAt.HasValue && badgeTemplateInfo.ExpiresAt.Value != ExpiresRange.None)
            {
                badgeExpiresAt = badgeTemplateInfo.CreatedAt.Value.AddYears((int)badgeTemplateInfo.ExpiresAt.Value);
            }

            var newEntityBadge = new Entities.Badge
            {
                Id = Guid.NewGuid(),
                BadgeTemplate = badgeTemplateInfo,
                Employee = employeeInfo,
                Private = true,
                Status = BadgeStatus.Initiated,
                ExpiresAt = badgeExpiresAt,
                InitiatedAt = DateTime.UtcNow,
                AlternativeCriteriaSelected = badgeDTO.AlternativeCriteriaSelected
            };

            DbContext.Badges.Add(newEntityBadge);

            foreach (var criteria in badgeTemplateInfo.Criterias.Where(x => x.Deleted != true))
            {
                // TODO: set this property when the SABA integration was finished
                var validatedInSABA = false;
                if (criteria.SABAValidationNeeded == true)
                {
                    validatedInSABA = _sabaService.ValidateCourse(employeeInfo.PersonID, criteria.SABACourseID);
                }

                if (criteria.Type == BadgeTemplateType.Education)
                {
                    DbContext.Educations.Add(new Entities.Education
                    {
                        Id = Guid.NewGuid(),
                        Badge = newEntityBadge,
                        Criteria = criteria,
                        Title = criteria.Name,
                        IsAlternative = criteria.IsAlternative,
                        SABACourseValidated = validatedInSABA
                    });
                }
                else if (criteria.Type == BadgeTemplateType.Experience)
                {
                    DbContext.Experiencies.Add(new Entities.Experience
                    {
                        Id = Guid.NewGuid(),
                        Badge = newEntityBadge,
                        Criteria = criteria,
                        Title = criteria.Name,
                        IsAlternative = criteria.IsAlternative
                    });
                }
                else if (criteria.Type == BadgeTemplateType.Eminence)
                {
                    DbContext.Exposures.Add(new Entities.Exposure
                    {
                        Id = Guid.NewGuid(),
                        Badge = newEntityBadge,
                        Criteria = criteria,
                        Title = criteria.Name,
                        IsAlternative = criteria.IsAlternative
                    });
                }
            }

            #region User_activity

            var userActivity = new UserActivity()
            {
                EntityId = newEntityBadge.Id.ToString(),
                Employee = employeeInfo,
                Type = ActivityType.BadgeInitiated,
                Date = DateTime.UtcNow
            };

            DbContext.UserActivity.Add(userActivity);

            #endregion User_activity

            DbContext.SaveChanges();

            return Mapper.Map<Entities.Badge, DTO.Badge>(newEntityBadge);
        }

        public async Task<DTO.Badge> UpdateAsync(DTO.Badge badgeDTO, CancellationToken cancellationToken = default)
        {
            #region Setting_common_badge_information

            Badge? entityToUpdate = null;

            try
            {
                entityToUpdate = DbContext.Badges
                                            .Include(x => x.Employee)
                                          .Include(x => x.BadgeTemplate)
                                            .ThenInclude(x => x.Approver)
                                          .Include(x => x.BadgeTemplate)
                                            .ThenInclude(x => x.OptionalApprover)
                                          .FirstOrDefault(e => e.Id == badgeDTO.Id);
            }
            catch (Exception e)
            {
                //If some info is not correct, like FK not exist or some ID is null or not exist
                //we just check "entityToUpdate" variable, is not null
            }

            if (entityToUpdate == null)
            {
                throw new ValidationException(new Result { Messages = new List<string>() { GeneralConstants.ErrorMessages.BADGE_INVALID }, HasErrors = true });
            }

            var listBadgeTemplateCriteriaIds = badgeDTO.Education
                .Select(t => t.BadgeTemplateCriteriaId)
                .Distinct()
                    .Union(badgeDTO.Experience.Select(t => t.BadgeTemplateCriteriaId).Distinct())
                    .Union(badgeDTO.Eminence.Select(t => t.BadgeTemplateCriteriaId).Distinct()
                    .Union(badgeDTO.Education.Select(t => t.BadgeTemplateCriteriaId).Distinct())
                );
            var badgeTemplateCriteriaInfo = DbContext.BadgeTemplateCriteria
                .Where(t => listBadgeTemplateCriteriaIds.Contains(t.Id))
                .ToList();

            #endregion Setting_common_badge_information

            #region Badge

            entityToUpdate.Private = badgeDTO.Private;
            entityToUpdate.AlternativeCriteriaSelected = badgeDTO.AlternativeCriteriaSelected;
            var statusValue = badgeDTO.Status.ResolveEnum<BadgeStatus>();
            entityToUpdate.Status = _statusFlowService.SetAndValidateStatus(entityToUpdate.Status, statusValue);

            await NotificationProcessAsync(entityToUpdate, statusValue.ToString(), new string[]
            {
                entityToUpdate.BadgeTemplate.Name ?? string.Empty,
                AppSettings.Settings.CredlyUrl
            });

            #endregion Badge

            if (entityToUpdate.Status == BadgeStatus.Withdrawn)
            {
                badgeDTO.Education = new List<DTO.Education>();
                badgeDTO.Experience = new List<DTO.Experience>();
                badgeDTO.Eminence = new List<DTO.Exposure>();
            }

            await EducationHandlerAsync(entityToUpdate, badgeDTO, badgeTemplateCriteriaInfo);
            var experienceResult = await ExperienceHandlerAsync(entityToUpdate, badgeDTO, badgeTemplateCriteriaInfo);
            if (experienceResult.Count > 0)
            {
                throw new ValidationException(new Result { HasErrors = true, Messages = experienceResult });
            }
            await EminenceHandlerAsync(entityToUpdate, badgeDTO, badgeTemplateCriteriaInfo);

            #region User_activity

            await AddUserActivityTraceAsync(entityToUpdate.Status.ToString(), entityToUpdate.Id, cancellationToken);            

            #endregion User_activity

            ValidateBadgeData(entityToUpdate.Id);
            await SetDataByStatus(entityToUpdate);
            await DbContext.SaveChangesAsync(cancellationToken);

            var result = Mapper.Map<Entities.Badge, DTO.Badge>(entityToUpdate);

            var educations = DbContext.Educations.Where(e => e.Badge == entityToUpdate).ToList();
            result.Education = Mapper.Map<IList<Entities.Education>, IList<DTO.Education>>(educations);

            var experiences = DbContext.Experiencies.Where(e => e.Badge == entityToUpdate).ToList();
            result.Experience = Mapper.Map<IList<Entities.Experience>, IList<DTO.Experience>>(experiences);

            var exposure = DbContext.Exposures.Where(e => e.Badge == entityToUpdate).ToList();
            result.Eminence = Mapper.Map<IList<Entities.Exposure>, IList<DTO.Exposure>>(exposure);

            return result;
        }

        public void Delete(Guid id)
        {
            var badgeToDelete = DbContext.Badges.FirstOrDefault(t => t.Id == id);
            if (badgeToDelete == null)
            {
                throw new ValidationException(new Result { Messages = new List<string>() { GeneralConstants.ErrorMessages.BADGE_INVALID }, HasErrors = true });
            }

            var userActivity = new UserActivity()
            {
                EntityId = badgeToDelete.Id.ToString(),
                Employee = badgeToDelete.Employee,
                Type = ActivityType.BadgeDeleted,
                Date = DateTime.UtcNow
            };

            DbContext.Badges.Remove(badgeToDelete);
            DbContext.UserActivity.Add(userActivity);
            DbContext.SaveChanges();
        }

        #endregion BASE METHODS

        #region CUSTOM METHODS

        public ListResponse<BadgeQuery> GetBadgesAdmin(BadgesFilter filter)
        {
            var query = DbContext.BadgeQueries.AsQueryable();

            if (filter.Status.Any())
            {
                var statusList = filter.Status.Select(
                    e => (BadgeStatus)Enum.Parse(typeof(Entities.BadgeStatus), e)
                );
                query = query
                    .Where(e => e.Status.HasValue && statusList.Contains(e.Status.Value))
                    .AsQueryable();
            }

            if (!string.IsNullOrWhiteSpace(filter.PersonID))
            {
                query = query.Where(x =>
                    !string.IsNullOrEmpty(x.EmployeePersonID) && string.Equals(x.EmployeePersonID, filter.PersonID));
            }

            return query.PaginatedByFilters<Entities.Queries.BadgeQuery, DTO.Queries.BadgeQuery>(
                filter,
                Mapper
            );
        }

        public async Task<ListResponse<BadgeQuery>> GetBadgesBusinessRepAsync(BadgesFilter filter)
        {
            var session = SessionService.GetSession();

            var query = DbContext.BadgeQueries
                .Where(e => string.Equals(e.BadgeTemplateApproverID, session.PersonID) || string.Equals(e.BadgeTemplateOptionalApproverID, session.PersonID))
                .AsQueryable();

            if (filter.Status.Any())
            {
                var statusList = filter.Status.Select(
                    e => (BadgeStatus)Enum.Parse(typeof(Entities.BadgeStatus), e)
                );
                query = query
                    .Where(e => e.Status.HasValue && statusList.Contains(e.Status.Value))
                    .AsQueryable();
            }

            return query.PaginatedByFilters<Entities.Queries.BadgeQuery, DTO.Queries.BadgeQuery>(
                filter,
                Mapper
            );
        }

        public ListResponse<BadgeQuery> GetBadgesPractitioner(BadgesFilter filter)
        {
            var session = SessionService.GetSession();
            var query = DbContext.BadgeQueries
                .Where(e => string.Equals(e.EmployeePersonID, session.PersonID))
                .AsQueryable();

            if (filter.Status.Any())
            {
                var statusList = filter.Status.Select(
                    e => (BadgeStatus)Enum.Parse(typeof(Entities.BadgeStatus), e)
                );
                query = query
                    .Where(e => e.Status.HasValue && statusList.Contains(e.Status.Value))
                    .AsQueryable();
            }

            return query.PaginatedByFilters<Entities.Queries.BadgeQuery, DTO.Queries.BadgeQuery>(
                filter,
                Mapper
            );
        }

        public async Task<DTO.BadgeStatusFlow> StatusFlowAsync(DTO.BadgeStatusFlow badgeStatusFlow)
        {
            var badgeEntity = DbContext.Badges
                .Include(x => x.BadgeTemplate)
                .Include(x => x.Employee)
                .Single(e => e.Id == badgeStatusFlow.Id);

            badgeEntity.ArchiveDate = badgeStatusFlow.ArchiveDate;

            var statusValue = badgeStatusFlow.Status.ResolveEnum<BadgeStatus>();
            badgeEntity.Status = _statusFlowService.SetAndValidateStatus(badgeEntity.Status, statusValue);

            ValidateBadgeData(badgeEntity.Id);

            await SetDataByStatus(badgeEntity, badgeStatusFlow.Feedback);

            await NotificationProcessAsync(badgeEntity, badgeEntity.Status.ToString(), new string[]
                  {
                    badgeEntity.BadgeTemplate.Name ?? string.Empty,
                    AppSettings.Settings.CredlyUrl
                  });

            #region User_activity

            await AddUserActivityTraceAsync(badgeEntity.Status.ToString(), badgeEntity.Id);

            #endregion User_activity

            await DbContext.SaveChangesAsync();

            return badgeStatusFlow;
        }

        public async Task<DTO.Badge> ReInitiatedBadgeAsync(Guid badgeId, CancellationToken cancellationToken = default)
        {
            var badgeInfo = await DbContext.Badges.FirstOrDefaultAsync(x => x.Id == badgeId, cancellationToken);

            if (badgeInfo == null)
            {
                throw new ValidationException(new Result { Messages = new List<string>() { GeneralConstants.ErrorMessages.BADGE_INVALID }, HasErrors = true });
            }

            badgeInfo.Status = BadgeStatus.Discarded;
            await DbContext.SaveChangesAsync(cancellationToken);

            return Create(new DTO.Badge
            {
                BadgeTemplateId = badgeInfo.BadgeTemplateId,
                EmployeePersonID = badgeInfo.PersonID,
            });
        }

        #endregion CUSTOM METHODS

        #endregion PUBLIC METHODS

        #region PRIVATE METHODS

        private async Task SetDataByStatus(Entities.Badge badgeEntity, string feedback = null)
        {
            if (badgeEntity.Status == BadgeStatus.Approved)
            {
                await CreateBadgeCredlyPortalAsync(badgeEntity);
                //TODO: Pending confirmation
                //badgeEntity.DecisionAt = DateTime.Now;
            }
            else if (badgeEntity.Status == BadgeStatus.SubmittedForApproval)
            {
                badgeEntity.SubmittedAt = DateTime.UtcNow;
                //Temporaly fix for mpv_1_2 regarding bug: 4010891
                //Uncomment this line when it will be merged with mvp_2_0
                //DeleteCriteriaForPathNotSelected(badgeEntity);
                //Temporaly fix for mpv_1_2 regarding bug: 4010891
            }
            else if (badgeEntity.Status == BadgeStatus.AttentionRequired)
            {
                SetFeedback(badgeEntity, feedback);
            }
            else if (badgeEntity.Status == BadgeStatus.Rejected)
            {
                badgeEntity.RejectedAt = DateTime.UtcNow;
                SetFeedback(badgeEntity, feedback);
            }
        }

        private void DeleteCriteriaForPathNotSelected(Entities.Badge badgeEntity)
        {
            var isAlternativePath = badgeEntity.AlternativeCriteriaSelected == true;
            var educations = DbContext.Educations.Where(x => x.BadgeId == badgeEntity.Id && x.IsAlternative != isAlternativePath).ToList();
            DbContext.Educations.RemoveRange(educations);
            var experiences = DbContext.Experiencies.Where(x => x.BadgeId == badgeEntity.Id && x.IsAlternative != isAlternativePath).ToList();
            DbContext.Experiencies.RemoveRange(experiences);
            var exposures = DbContext.Exposures.Where(x => x.BadgeId == badgeEntity.Id && x.IsAlternative != isAlternativePath).ToList();
            DbContext.Exposures.RemoveRange(exposures);
        }

        private void SetFeedback(Entities.Badge badgeEntity, string feedback)
        {
            if (string.IsNullOrWhiteSpace(feedback))
            {
                throw new ValidationException(new Result { HasErrors = true, Messages = new List<string> { GeneralConstants.ErrorMessages.FEEDBACK_REQUIRED } });
            }

            if (feedback.Length > GeneralConstants.Feedback.MAX_FEEDBACK_LENGHT)
            {
                throw new ValidationException(new Result { HasErrors = true, Messages = new List<string> { GeneralConstants.ErrorMessages.MAX_FEEDBACK_LENGTH } });
            }

            var entity = new Feedback
            {
                Id = Guid.NewGuid(),
                Date = DateTime.UtcNow,
                EntityType = EntityType.Badge,
                EntityId = badgeEntity.Id.ToString(GeneralConstants.Common.FORMAT_GUID_TO_STRING),
                Status = (int)badgeEntity.Status,
                Detail = Utils.Sanitizer(feedback)
            };
            DbContext.Feedback.Add(entity);
        }

        private async Task DeleteFileFromStorageAsync(string prefix, string idBlob)
        {
            var storageResul = await _blobStorageService.GetListOFBlobs(prefix);
            var fileResult = (from item in storageResul where item.IdBlob == idBlob select item).ToList();

            if (fileResult.Any())
            {
                await _blobStorageService.DeleteBlobFile(idBlob);
            }
        }

        private async Task CreateBadgeCredlyPortalAsync(Entities.Badge badgeEntity)
        {
            var errors = new List<string>();

            if (badgeEntity.Employee == null)
            {
                errors.Add(GeneralConstants.Badge.BADGE_NOT_HAVE_EMPLOYEE);
            }
            if (string.IsNullOrWhiteSpace(badgeEntity.Employee.Email))
            {
                errors.Add(GeneralConstants.Badge.BADGE_EMPLOYEE_INVALID_EMAIL);
            }
            if (string.IsNullOrWhiteSpace(badgeEntity.BadgeTemplate.ExternalId))
            {
                errors.Add(GeneralConstants.Badge.BADGE_BADGETEMPLATE_INVALID_EXTERNALID);
            }
            if (errors.Any())
            {
                throw new ValidationException(new Result { HasErrors = true, Messages = errors });
            }

            var credlyBadge = await _credlyAPIService.CreateBadge(new CredlyBadgeCreate
            {
                RecipientEmail = badgeEntity.Employee.Email,
                BadgeTemplateId = badgeEntity.BadgeTemplate.ExternalId,
                IssuedAt = DateTime.UtcNow,
                IssuerEarnerId = badgeEntity.Employee.PersonID,
                SuppressBadgeNotificationEmail = false,
                ExpiresAt = badgeEntity.ExpiresAt
            });
            badgeEntity.ExternalId = credlyBadge.Id.ToString(GeneralConstants.Common.FORMAT_GUID_TO_STRING);
        }

        private Entities.BadgeTemplateCriteria ValidateAndReturnBadgeTemplateCriteria(Guid? badgeTemplateCriteriaId, List<Entities.BadgeTemplateCriteria> badgeTemplateCriteriaInfo)
        {
            if (!badgeTemplateCriteriaId.HasValue)
            {
                return null;
            }
            else
            {
                return badgeTemplateCriteriaInfo.FirstOrDefault(x => x.Id == badgeTemplateCriteriaId.Value);
            }
        }

        private async Task NotificationProcessAsync(Entities.Badge badgeEntity, string badgeStatus, string[] contentParams = default)
        {
            const string entityType = "Badge";
            try
            {
                if (!_notificationService.IsAllowedNotification(badgeStatus, entityType)) return;

                DTO.Common.NotificacionHub notificationHub;

                if (badgeStatus.ResolveEnum<BadgeStatus>() == BadgeStatus.SubmittedForApproval)
                {
                    string optionalApprover = string.Empty;
                    var emailList = new List<string>();

                    //At least an approver or optionalApprover email is required
                    if (badgeEntity.BadgeTemplate.OptionalApprover is null && badgeEntity.BadgeTemplate.Approver is null)
                    {
                        throw new Exception($"{GeneralConstants.ErrorMessages.NOTIFICATIONS_NOT_EMAIL}, {GeneralConstants.ErrorMessages.BADGE_INCONSISTENT_DATA_FOR_BADGETEMPLATE}");
                    }

                    if (badgeEntity.BadgeTemplate.OptionalApprover != null)
                    {
                        emailList.Add(badgeEntity.BadgeTemplate.OptionalApprover.Email ?? string.Empty);
                    }
                    if (badgeEntity.BadgeTemplate.Approver != null)
                    {
                        emailList.Add(badgeEntity.BadgeTemplate.Approver.Email ?? string.Empty);
                    }

                    notificationHub = await _notificationService.SendNotificationToHubAsync
                                                                    (emailList,
                                                                    badgeStatus,
                                                                    entityType,
                                                                    contentParams);
                }
                else
                {
                    notificationHub = await _notificationService.SendNotificationToHubAsync
                                                                       (new List<string> { badgeEntity.Employee.Email ?? string.Empty },
                                                                       badgeStatus,
                                                                       entityType,
                                                                       contentParams);
                }

                var notificationEntity = new Entities.Notification
                {
                    Id = Guid.NewGuid(),
                    Date = DateTime.UtcNow,
                    Title = notificationHub.Title,
                    Description = notificationHub.Description,
                    EntityType = notificationHub.EntityType.ResolveEnum<EntityType>(),
                    EntityId = badgeEntity.Id.ToString(GeneralConstants.Common.FORMAT_GUID_TO_STRING),
                    ReadDate = null,
                    Read = false,
                    Employee = badgeEntity.Employee,
                    Detail = null,
                    Status = badgeEntity.Status.ToString()
                };

                DbContext.Notifications.Add(notificationEntity);
            }
            catch (Exception ex)
            {
                var errorToReport = await SessionService.GetContextErrorLog();
                errorToReport.Message = ex.GetFullMessage();
                errorToReport.Trace = ex.StackTrace;
                errorToReport.Source = ex.Source;
                await _errorLog.SaveErrorLogAsync(errorToReport);
            }
        }

        private async Task<List<string>> ExperienceHandlerAsync(Entities.Badge entityToUpdate, DTO.Badge badgeDTO, List<BadgeTemplateCriteria> badgeTemplateCriteriaInfo)
        {
            var currentExperience = DbContext.Experiencies.Where(t => t.Badge == entityToUpdate).ToList();
            var experienceIdsEntity = currentExperience.Select(e => e.Id).ToList();
            var experienceIdsDto = badgeDTO.Experience.Where(e => e.Id.HasValue).Select(e => e.Id.Value).ToList();
            var experienceToAddDto = badgeDTO.Experience.Where(e => !e.Id.HasValue).Select(e => e).ToList();
            var experienceIdsToUpdate = experienceIdsEntity.Where(t => experienceIdsDto.Contains(t)).Select(x => x).ToList();
            var experienceIdsToDelete = experienceIdsEntity.Except(experienceIdsDto);

            #region Add_experience

            List<Experience> experienceToAdd = new List<Experience>();
            List<string> errorList = new List<string>();

            foreach (DTO.Experience experience in experienceToAddDto)
            {
                try
                {
                    var emailExist = await _emailValidation.ValidateQDREmail(experience.ValidatorEmail);
                    if (!emailExist)
                    {
                        errorList.Add(GeneralConstants.ErrorMessages.EMAIL_VALIDATION_NOT_EXIST);
                    }

                    var badgeTemplateCriteria = ValidateAndReturnBadgeTemplateCriteria(experience.BadgeTemplateCriteriaId, badgeTemplateCriteriaInfo);

                    var newExperience = new Experience
                    {
                        #region Experience

                        Badge = entityToUpdate,
                        Criteria = badgeTemplateCriteria,
                        Description = experience.Description,
                        Hours = experience.Hours,
                        ValidatorEmail = experience.ValidatorEmail,
                        WBSCode = experience.WBSCode,
                        Title = experience.Title,
                        Id = Guid.NewGuid(),
                        Url = experience.Url,
                        IsAlternative = experience.IsAlternative

                        #endregion Experience
                    };

                    if (experience.UploadBase64 != null && experience.UploadBase64.HaveFile)
                    {
                        #region Storage

                        var uploadResult = await _blobStorageService.SendFileToStorageAsync(
                                                                    experience.UploadBase64.File,
                                                                    newExperience.Id,
                                                                    experience.UploadBase64.ContentType,
                                                                    GeneralConstants.Experience.STORAGE_PREFIX,
                                                                    experience.UploadBase64.FileName);

                        newExperience.Upload = uploadResult;

                        #endregion Storage
                    };

                    experienceToAdd.Add(newExperience);
                }
                catch (Exception e)
                {
                    errorList.Add(string.Format(GeneralConstants.ErrorMessages.BADGE_EXPERIENCE_HANDLER_FAILED, e.Message));
                }
            }

            DbContext.Experiencies.AddRange(experienceToAdd);

            #endregion Add_experience

            #region Update_experience

            foreach (Guid id in experienceIdsToUpdate)
            {
                var experienceDto = badgeDTO.Experience.Single(t => t.Id == id);
                var experienceEntity = currentExperience.Single(t => t.Id == id);

                if (experienceDto.IsAlternative == null)
                {
                    experienceDto.IsAlternative = false;
                }

                experienceEntity.Hours = experienceDto.Hours;
                experienceEntity.Description = experienceDto.Description;
                experienceEntity.ValidatorEmail = experienceDto.ValidatorEmail;
                experienceEntity.WBSCode = experienceDto.WBSCode;
                experienceEntity.Url = experienceDto.Url;
                experienceEntity.IsAlternative = experienceDto.IsAlternative;
                if (!experienceEntity.BadgeTemplateCriteriaId.HasValue)
                {
                    experienceEntity.Title = experienceDto.Title;
                }

                // Check if we have to change the file
                if (experienceDto.UploadBase64 != null && experienceDto.UploadBase64.HaveFile)
                {
                    if (!string.IsNullOrEmpty(experienceEntity.Upload))
                    {
                        await DeleteFileFromStorageAsync(GeneralConstants.Education.STORAGE_PREFIX, experienceEntity.Upload);
                    }

                    var uploadResult = await _blobStorageService.SendFileToStorageAsync(
                        experienceDto.UploadBase64.File,
                        experienceEntity.Id,
                        experienceDto.UploadBase64.ContentType,
                        GeneralConstants.Experience.STORAGE_PREFIX,
                        experienceDto.UploadBase64.FileName);

                    experienceEntity.Upload = uploadResult;
                }

                // Check if we have to delete the file
                if (string.IsNullOrEmpty(experienceDto.Upload))
                {
                    if (!string.IsNullOrEmpty(experienceEntity.Upload))
                    {
                        await DeleteFileFromStorageAsync(GeneralConstants.Education.STORAGE_PREFIX, experienceEntity.Upload);

                        experienceEntity.Upload = string.Empty;
                    }
                }
            }

            #endregion Update_experience

            #region Delete_experience

            foreach (Guid education in experienceIdsToDelete)
            {
                var experienceEntity = currentExperience.Single(t => t.Id == education);
                DbContext.Experiencies.Remove(experienceEntity);

                if (!string.IsNullOrEmpty(experienceEntity.Upload))
                {
                    await DeleteFileFromStorageAsync(GeneralConstants.Education.STORAGE_PREFIX, experienceEntity.Upload);
                }
            }

            #endregion Delete_experience

            return errorList;
        }

        private async Task EducationHandlerAsync(Entities.Badge entityToUpdate, DTO.Badge badgeDTO, List<BadgeTemplateCriteria> badgeTemplateCriteriaInfo)
        {
            var currentEducation = DbContext.Educations.Where(t => t.Badge == entityToUpdate).ToList();
            var educationIdsEntity = currentEducation.Select(e => e.Id).ToList();
            var educationIdsDto = badgeDTO.Education.Where(e => e.Id.HasValue).Select(e => e.Id.Value).ToList();
            var educationToAddDto = badgeDTO.Education.Where(e => !e.Id.HasValue).Select(e => e).ToList();
            var educationIdsToUpdate = educationIdsEntity.Where(t => educationIdsDto.Contains(t)).Select(x => x).ToList();
            var educationIdsToDelete = educationIdsEntity.Except(educationIdsDto);

            #region Add_education

            List<Education> educationToAdd = new List<Education>();
            foreach (DTO.Education education in educationToAddDto)
            {
                var badgeTemplateCriteria = ValidateAndReturnBadgeTemplateCriteria(education.BadgeTemplateCriteriaId, badgeTemplateCriteriaInfo);

                var newEducation = new Education
                {
                    #region Education

                    Badge = entityToUpdate,
                    CompletionDate = education.CompletionDate,
                    Criteria = badgeTemplateCriteria,
                    Description = education.Description,
                    Title = education.Title,
                    Vendor = education.Vendor,
                    Id = Guid.NewGuid(),
                    Url = education.Url,
                    IsAlternative = education.IsAlternative

                    #endregion Education
                };

                if (education.UploadBase64 != null && education.UploadBase64.HaveFile)
                {
                    #region Storage

                    var uploadResult = await _blobStorageService.SendFileToStorageAsync(
                                    education.UploadBase64.File,
                                    newEducation.Id,
                                    education.UploadBase64.ContentType,
                                    GeneralConstants.Education.STORAGE_PREFIX,
                                    education.UploadBase64.FileName);
                    newEducation.Upload = uploadResult;

                    #endregion Storage
                }

                educationToAdd.Add(newEducation);
            }

            DbContext.Educations.AddRange(educationToAdd);

            #endregion Add_education

            #region Update_education

            foreach (Guid id in educationIdsToUpdate)
            {
                var educationDto = badgeDTO.Education.Single(t => t.Id == id);
                var educationEntity = currentEducation.Single(t => t.Id == id);

                if (educationDto.IsAlternative == null)
                {
                    educationDto.IsAlternative = false;
                }

                educationEntity.Description = educationDto.Description;
                educationEntity.Vendor = educationDto.Vendor;
                educationEntity.CompletionDate = educationDto.CompletionDate;
                educationEntity.Url = educationDto.Url;
                educationEntity.IsAlternative = educationDto.IsAlternative;
                if (!educationEntity.BadgeTemplateCriteriaId.HasValue)
                {
                    educationEntity.Title = educationDto.Title;
                }

                if (educationDto.UploadBase64 != null && educationDto.UploadBase64.HaveFile)
                {
                    #region Storage

                    if (!string.IsNullOrEmpty(educationEntity.Upload))
                    {
                        await DeleteFileFromStorageAsync(GeneralConstants.Education.STORAGE_PREFIX, educationEntity.Upload);
                    }
                    var uploadResult = await _blobStorageService.SendFileToStorageAsync(
                        educationDto.UploadBase64.File,
                        educationEntity.Id,
                        educationDto.UploadBase64.ContentType,
                        GeneralConstants.Education.STORAGE_PREFIX,
                        educationDto.UploadBase64.FileName);
                    educationEntity.Upload = uploadResult;

                    #endregion Storage
                }
            }

            #endregion Update_education

            #region Delete_education

            foreach (Guid education in educationIdsToDelete)
            {
                var educationEntity = currentEducation.Single(t => t.Id == education);
                DbContext.Educations.Remove(educationEntity);

                if (!string.IsNullOrEmpty(educationEntity.Upload))
                {
                    await DeleteFileFromStorageAsync(GeneralConstants.Education.STORAGE_PREFIX, educationEntity.Upload);
                }
            }

            #endregion Delete_education
        }

        private async Task EminenceHandlerAsync(Entities.Badge entityToUpdate, DTO.Badge badgeDTO, List<BadgeTemplateCriteria> badgeTemplateCriteriaInfo)
        {
            var currentExposure = DbContext.Exposures.Where(t => t.Badge == entityToUpdate).ToList();
            var exposureIdsEntity = currentExposure.Select(e => e.Id).ToList();
            var exposureIdsDto = badgeDTO.Eminence.Where(e => e.Id.HasValue).Select(e => e.Id.Value).ToList();
            var exposureToAddDto = badgeDTO.Eminence.Where(e => !e.Id.HasValue).Select(e => e).ToList();
            var exposureIdsToUpdate = exposureIdsEntity.Where(t => exposureIdsDto.Contains(t)).Select(x => x).ToList();
            var exposureIdsToDelete = exposureIdsEntity.Except(exposureIdsDto);

            #region Add_exposure

            List<Exposure> exposureToAdd = new List<Exposure>();
            foreach (DTO.Exposure exposure in exposureToAddDto)
            {
                var badgeTemplateCriteria = ValidateAndReturnBadgeTemplateCriteria(exposure.BadgeTemplateCriteriaId, badgeTemplateCriteriaInfo);

                var newExposure = new Exposure
                {
                    #region Eminence

                    Badge = entityToUpdate,
                    Criteria = badgeTemplateCriteria,
                    Description = exposure.Description,
                    Hours = exposure.Hours,
                    ValidatorEmail = exposure.ValidatorEmail,
                    Title = exposure.Title,
                    Id = Guid.NewGuid(),
                    Url = exposure.Url,
                    IsAlternative = exposure.IsAlternative

                    #endregion Eminence
                };

                exposureToAdd.Add(newExposure);

                if (exposure.UploadBase64 != null && exposure.UploadBase64.HaveFile)
                {
                    #region Storage

                    var uploadResult = await _blobStorageService.SendFileToStorageAsync(
                                    exposure.UploadBase64.File,
                                    newExposure.Id,
                                    exposure.UploadBase64.ContentType,
                                    GeneralConstants.Exposure.STORAGE_PREFIX,
                                    exposure.UploadBase64.FileName);
                    newExposure.Upload = uploadResult;

                    #endregion Storage
                }
            }
            DbContext.Exposures.AddRange(exposureToAdd);

            #endregion Add_exposure

            #region Update_exposure

            foreach (Guid id in exposureIdsToUpdate)
            {
                var exposureDto = badgeDTO.Eminence.Single(t => t.Id == id);
                var exposureEntity = currentExposure.Single(t => t.Id == id);

                if (exposureDto.IsAlternative == null)
                {
                    exposureDto.IsAlternative = false;
                }

                exposureEntity.Hours = exposureDto.Hours;
                exposureEntity.Description = exposureDto.Description;
                exposureEntity.ValidatorEmail = exposureDto.ValidatorEmail;
                exposureEntity.Url = exposureDto.Url;
                exposureEntity.IsAlternative = exposureDto.IsAlternative;
                if (!exposureEntity.BadgeTemplateCriteriaId.HasValue)
                {
                    exposureEntity.Title = exposureDto.Title;
                }

                if (exposureDto.UploadBase64 != null && exposureDto.UploadBase64.HaveFile)
                {
                    #region Storage

                    if (!string.IsNullOrEmpty(exposureEntity.Upload))
                    {
                        await DeleteFileFromStorageAsync(GeneralConstants.Education.STORAGE_PREFIX, exposureEntity.Upload);
                    }

                    var uploadResult = await _blobStorageService.SendFileToStorageAsync(
                        exposureDto.UploadBase64.File,
                        exposureEntity.Id,
                        exposureDto.UploadBase64.ContentType,
                        GeneralConstants.Exposure.STORAGE_PREFIX,
                        exposureDto.UploadBase64.FileName);
                    exposureEntity.Upload = uploadResult;

                    #endregion Storage
                }
            }

            #endregion Update_exposure

            #region Delete_exposure

            foreach (Guid education in exposureIdsToDelete)
            {
                var exposureEntity = currentExposure.Single(t => t.Id == education);
                DbContext.Exposures.Remove(exposureEntity);

                if (!string.IsNullOrEmpty(exposureEntity.Upload))
                {
                    await DeleteFileFromStorageAsync(GeneralConstants.Exposure.STORAGE_PREFIX, exposureEntity.Upload);
                }
            }

            #endregion Delete_exposure
        }

        private void ValidateBadgeData(Guid badgeId)
        {
            List<string> errors = new List<string>();
            var badgeEntity = DbContext.Badges
                .Include(x => x.BadgeTemplate.Criterias)
                .Include(x => x.Education)
                .Include(x => x.Experience)
                .Include(x => x.Exposure)
                .Single(x => x.Id == badgeId);

            if (badgeEntity.Status == BadgeStatus.InProgress || badgeEntity.Status == BadgeStatus.Rejected || badgeEntity.Status == BadgeStatus.Withdrawn)
            {
                return;
            }

            var isAlternativePath = badgeEntity.AlternativeCriteriaSelected == true;

            int educationsRequired = badgeEntity.BadgeTemplate.Criterias.Count(x => x.Type == BadgeTemplateType.Education && x.IsAlternative == isAlternativePath);
            if (badgeEntity.Education == null || badgeEntity.Education.Count < educationsRequired)
            {
                errors.Add(string.Format(GeneralConstants.ErrorMessages.BADGE_EDUCATIONS_REQUIRED, educationsRequired));
            }

            int experienceRequired = badgeEntity.BadgeTemplate.Criterias.Count(x => x.Type == BadgeTemplateType.Experience && x.IsAlternative == isAlternativePath);
            if (badgeEntity.Experience == null || badgeEntity.Experience.Count < experienceRequired)
            {
                errors.Add(string.Format(GeneralConstants.ErrorMessages.BADGE_EXPERIENCE_REQUIRED, experienceRequired));
            }

            int eminenceRequired = badgeEntity.BadgeTemplate.Criterias.Count(x => x.Type == BadgeTemplateType.Eminence && x.IsAlternative == isAlternativePath);
            if (badgeEntity.Exposure == null || badgeEntity.Exposure.Count < eminenceRequired)
            {
                errors.Add(string.Format(GeneralConstants.ErrorMessages.BADGE_EMINENCE_REQUIRED, eminenceRequired));
            }

            foreach (var education in badgeEntity.Education.Where(x => x.IsAlternative == isAlternativePath))
            {
                if (string.IsNullOrWhiteSpace(education.Title) ||
                    string.IsNullOrWhiteSpace(education.Url) ||
                    string.IsNullOrWhiteSpace(education.Upload) ||
                    !education.CompletionDate.HasValue)
                {
                    errors.Add(string.Format(GeneralConstants.ErrorMessages.BADGE_EDUCATIONS_FIELDS_REQUIRED, education.Title));
                }
            }

            foreach (var experience in badgeEntity.Experience.Where(x => x.IsAlternative == isAlternativePath))
            {
                if (string.IsNullOrWhiteSpace(experience.Title) ||
                    string.IsNullOrWhiteSpace(experience.ValidatorEmail) ||
                    string.IsNullOrWhiteSpace(experience.Description) ||
                    !experience.Hours.HasValue ||
                    (string.IsNullOrWhiteSpace(experience.Upload) && string.IsNullOrWhiteSpace(experience.WBSCode))
                   )
                {
                    errors.Add(string.Format(GeneralConstants.ErrorMessages.BADGE_EXPERIENCE_FIELDS_REQUIRED, experience.Title));
                }
            }

            foreach (var eminence in badgeEntity.Exposure.Where(x => x.IsAlternative == isAlternativePath))
            {
                if (string.IsNullOrWhiteSpace(eminence.Title) ||
                    string.IsNullOrWhiteSpace(eminence.Upload) ||
                    string.IsNullOrWhiteSpace(eminence.Description) ||
                    string.IsNullOrWhiteSpace(eminence.ValidatorEmail) ||
                    !eminence.Hours.HasValue
                   )
                {
                    errors.Add(string.Format(GeneralConstants.ErrorMessages.BADGE_EMINENCE_FIELDS_REQUIRED, eminence.Title));
                }
            }

            if (errors.Any())
            {
                throw new ValidationException(new Result { Messages = errors, HasErrors = true });
            }
        }

        private async Task AddUserActivityTraceAsync(string badgeStatus, Guid entityToUpdate, CancellationToken cancellationToken = default)
        {
            try
            {
                var currentUser = this.SessionService.GetSession();
                var userActivityEmployee = await DbContext.Employees.FirstOrDefaultAsync(t => t.PersonID == currentUser.PersonID, cancellationToken);
                var activityTypeParameters = UserActivityHelper.GetActivityType(EntityType.Badge, badgeStatus);

                var userActivity = new UserActivity()
                {
                    EntityId = entityToUpdate.ToString(),
                    Employee = userActivityEmployee,
                    Type = activityTypeParameters.ActivityType,
                    Date = DateTime.UtcNow,
                    Description = activityTypeParameters.Description
                };

                DbContext.UserActivity.Add(userActivity);
            }
            catch (Exception ex)
            {
                var errorToReport = new DTO.ErrorLog
                {
                    Date = DateTime.UtcNow,
                    Message = ex.Message,
                    Method = $"BadgeBL.AddUserActivityTraceAsync",
                    Source = ex.Source,
                    Trace = ex.StackTrace                    
                };
                await _errorLog.SaveErrorLogAsync(errorToReport, cancellationToken);
                
            }
        }

        #endregion PRIVATE METHODS
    }
}
