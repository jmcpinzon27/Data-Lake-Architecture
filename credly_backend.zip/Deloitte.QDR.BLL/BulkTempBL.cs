﻿using Deloitte.QDR.BLL.Base;
using Deloitte.QDR.Contracts;
using Deloitte.QDR.Contracts.BL;
using Deloitte.QDR.Contracts.Services;
using Deloitte.QDR.DTO.Common;
using Deloitte.QDR.Entities;
using Deloitte.QDR.Infrastructure;
using Deloitte.QDR.Services;
using Microsoft.EntityFrameworkCore;
using static Deloitte.QDR.DTO.Common.GeneralConstants;

namespace Deloitte.QDR.BLL
{
    // NOTE: this functionality is only for test purpose
    public class BulkTempBL : BaseBL, IBulkTempBL
    {
        private readonly ICacheService _cacheService;
        private readonly IEmailService _emailService;
        private readonly ISMTPEmailHandler _SMTPemailHandler;

        public BulkTempBL(
            ISessionService sessionService,
            IDBContext dbContext,
            IDataCache dataCache,
            ICacheService cacheService,
            IEmailService emailService,
            ISMTPEmailHandler smtpEmailHandler  
        )
            : base(sessionService, dbContext, dataCache)
        {
            _cacheService = cacheService ?? throw new ArgumentNullException(nameof(cacheService));
            _emailService = emailService ?? throw new ArgumentNullException(nameof(emailService));
            _SMTPemailHandler = smtpEmailHandler ?? throw new ArgumentNullException(nameof(smtpEmailHandler));
        }

        #region PUBLIC METHODS

        public bool BulkEmployeeData(string email, RoleType role, bool? isActive)
        {
            if (isActive == null)
            {
                throw new ValidationException(new Result { Messages = new List<string>() { GeneralConstants.ErrorMessages.USER_CREATE_IS_ACTIVE_NULL }, HasErrors = true });
            }
            CheckEmpty(email, role);
            Utils.CheckValidEmail(email);
            CheckRole(role);
            var rand = new Random();

            #region Employee

            var employee = DbContext.Employees.SingleOrDefault(e => string.Equals(e.Email, email));

            if (employee == null)
            {
                string lastPersonID = DbContext.Employees.Max(e => e.PersonID) ?? 0.ToString();
                var newPersonId = int.Parse(lastPersonID);
                newPersonId++;

                var emailSanitized = Utils.Sanitizer(email);
                var personIdSanitized = Utils.Sanitizer(newPersonId.ToString());
                var active = isActive == true;
                employee = new Entities.Employee
                {
                    PersonID = personIdSanitized,
                    Email = emailSanitized,
                    FirstName = emailSanitized.Split("@")[0],
                    LastName = String.Empty,
                    IsActive = active
                };

                DbContext.Employees.Add(employee);
                DbContext.SaveChanges();
            }
            else
            {
                _cacheService.DeleteEmployeeFromCache(email);
            }

            #endregion

            #region Roles

            var employeeRoles = DbContext.EmployeeRole
                .Include(i => i.Employee)
                .Include(i => i.Role)
                .Where(e => string.Equals(email, e.Employee.Email))
                .ToList();

            var roleIds = employeeRoles.Select(e => e.RoleId);

            foreach (var id in roleIds)
            {
                var roleEntity = employeeRoles.Single(e => e.RoleId == id);
                DbContext.EmployeeRole.Remove(roleEntity);
            }

            DbContext.SaveChanges();

            var newRole = DbContext.Role.Single(e => string.Equals(e.Code, role.ToString()));
            var newEmployeeRole = new Entities.EmployeeRole
            {
                RoleId = newRole.Id,
                EmployeeId = employee.PersonID
            };

            DbContext.EmployeeRole.Add(newEmployeeRole);
            DbContext.SaveChanges();
            _cacheService.UpdateCache(employee.PersonID);
            #endregion

            #region BadgesClear

            var badges = DbContext.Badges
                .Include(e => e.Employee)
                .Where(e => string.Equals(e.Employee.PersonID, employee.PersonID))
                .ToList();

            var badgesIds = badges.Select(e => e.Id).ToList();

            var educations = DbContext.Educations
                .Include(e => e.Badge)
                .Where(e => e.Badge != null && badgesIds.Contains(e.Badge.Id))
                .ToList();
            var experiences = DbContext.Experiencies
                .Include(e => e.Badge)
                .Where(e => e.Badge != null && badgesIds.Contains(e.Badge.Id))
                .ToList();
            var exposures = DbContext.Exposures
                .Include(e => e.Badge)
                .Where(e => e.Badge != null && badgesIds.Contains(e.Badge.Id))
                .ToList();

            var eduationsIds = educations.Select(e => e.Id).ToList();
            var experiencesIds = experiences.Select(e => e.Id).ToList();
            var exposuresIds = exposures.Select(e => e.Id).ToList();

            foreach (var id in eduationsIds)
            {
                var e = educations.Single(e => e.Id == id);
                DbContext.Educations.Remove(e);
            }

            foreach (var id in experiencesIds)
            {
                var e = experiences.Single(e => e.Id == id);
                DbContext.Experiencies.Remove(e);
            }

            foreach (var id in exposuresIds)
            {
                var e = exposures.Single(e => e.Id == id);
                DbContext.Exposures.Remove(e);
            }

            foreach (var id in badgesIds)
            {
                var badge = badges.Single(e => e.Id == id);
                DbContext.Badges.Remove(badge);
            }

            DbContext.SaveChanges();

            #endregion

            #region NotificationsClear

            var notifications = DbContext.Notifications
                .Include(e => e.Employee)
                .Where(e => string.Equals(e.Employee.PersonID, employee.PersonID))
                .ToList();

            var notificationIDs = notifications.Select(e => e.Id).ToList();

            foreach (var id in notificationIDs)
            {
                var notification = notifications.Single(e => e.Id == id);
                DbContext.Notifications.Remove(notification);
            }

            DbContext.SaveChanges();

            #endregion

            return true;
        }

        public bool ChangeRole(string email, RoleType role)
        {
            CheckRole(role);
            CheckEmployee(email);
            Utils.CheckValidEmail(email);
            var employee = DbContext.Employees.Single(e => string.Equals(e.Email, email));

            #region Roles

            var employeeRoles = DbContext.EmployeeRole
                .Include(i => i.Employee)
                .Include(i => i.Role)
                .Where(e => string.Equals(email, e.Employee.Email))
                .ToList();

            var roleIds = employeeRoles.Select(e => e.RoleId);

            foreach (var id in roleIds)
            {
                var roleEntity = employeeRoles.Single(e => e.RoleId == id);
                DbContext.EmployeeRole.Remove(roleEntity);
            }

            DbContext.SaveChanges();

            var newRole = DbContext.Role.Single(e => string.Equals(e.Code, role.ToString()));
            var newEmployeeRole = new EmployeeRole
            {
                Role = newRole,
                RoleId = newRole.Id,
                Employee = employee,
                EmployeeId = employee.PersonID
            };

            DbContext.EmployeeRole.Add(newEmployeeRole);
            DbContext.SaveChanges();
            _cacheService.UpdateCache(employee.PersonID);

            #endregion

            return true;
        }

        public async Task RefreshEmployeesCache()
        {
            await _cacheService.LoadDataEmployeeToCache();
        }

        public async Task<bool> SendMailAsync(NotificationEmailData maildata)
        {
            var mailConfig = new _Config_Notification
            {
                EmailSubject = maildata.Subject,
                EmailTitle = maildata.BodyTitle,
                EmailDescription = maildata.BodyDescription,
                EmailImage = maildata.ImagePath,
                EmailLink = maildata.Link
            };
            
            return await _emailService.SendEmailAsync(maildata.To, maildata.HtmlString, mailConfig);
        }

        public async Task<bool> SendMailTestAsync(NotificationEmailData mailData)
        {
            var mailConfig = new MailData
            {
                EmailToId = new List<string>(){ mailData.To },
                EmailSubject = mailData.Subject,
                EmailBody = String.Concat(mailData.BodyTitle, mailData.BodyDescription)
            };

            return await _SMTPemailHandler.SendEmailAsync(mailConfig);
        }

        #endregion PUBLIC METHODS

        #region PRIVATE METHODS

        private void CheckRole(RoleType role)
        {
            if (
                !string.Equals(role, RoleType.Admin)
                && !string.Equals(role, RoleType.BusinessRep)
                && !string.Equals(role, RoleType.Practitioner)
            )
            {
                var result = new Result
                {
                    HasErrors = true,
                    Messages = new List<string>
                    {
                        "Invalid role. Possible values: Admin, BusinessRep, Practitioner"
                    }
                };

                throw new DTO.Common.ValidationException(result);
            }
        }

        private void CheckEmployee(string email)
        {
            var exists = DbContext.Employees.Any(e => string.Equals(e.Email, email));

            if (!exists)
            {
                var result = new Result
                {
                    HasErrors = true,
                    Messages = new List<string>
                    {
                        $"there is no employee with email {email}. Please invoke 'bulk employee data' method"
                    }
                };

                throw new DTO.Common.ValidationException(result);
            }
        }

        private void CheckEmpty(string email, RoleType role)
        {
            if (string.IsNullOrEmpty(email) || string.IsNullOrEmpty(email))
            {
                var result = new Result
                {
                    HasErrors = true,
                    Messages = new List<string>
                    {
                        "'email' and 'role' params are required. Querystring should be: http://url?email=EMAIL&role=ROLE"
                    }
                };

                throw new DTO.Common.ValidationException(result);
            }
        }



        #endregion PRIVATE METHODS
    }
}
