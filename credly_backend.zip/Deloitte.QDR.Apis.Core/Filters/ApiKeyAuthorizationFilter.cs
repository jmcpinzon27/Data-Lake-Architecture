﻿using Deloitte.QDR.DTO.Common;
using Deloitte.QDR.Infrastructure.Config;
using Microsoft.AspNetCore.Mvc.Filters;

namespace Deloitte.QDR.Apis.Core.Filters
{
    /// <summary>
    /// ApiKeyAuthorizationFilter class
    /// </summary>
    public class ApiKeyAuthorizationFilter : IAsyncActionFilter
    {
        private readonly ILogger<ApiKeyAuthorizationFilter> _logger;
        private const string _keyName = "apiKey";
        private const string _inboundSystemName = "inboundsystem";

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="logger"></param>
        /// <exception cref="ArgumentNullException"></exception>
        public ApiKeyAuthorizationFilter(ILogger<ApiKeyAuthorizationFilter> logger)
        {
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
        }

        /// <summary>
        /// Check allowed access to the endpoint.
        /// </summary>
        /// <param name="context">context param</param>
        /// <param name="next">next param</param>
        /// <returns>Completion task caller, otherwise 401 code</returns>
        public async Task OnActionExecutionAsync(ActionExecutingContext context, ActionExecutionDelegate next)
        {
            var apiKey = GetValueByKey(context.HttpContext, _keyName);
            var inBoundSystem = GetValueByKey(context.HttpContext, _inboundSystemName);
            var nameSecret = $"APIKEY-{inBoundSystem.ToUpper()}";
            var internalApiKey = AppSettings.Settings.GetSecret(nameSecret);

            if (internalApiKey.Equals(apiKey))
            {
                _logger.LogInformation("This caller can enter");
                await next();
            }
            else
            {
                ReturnApiKeyNotFound();
            }
        }

        private void ReturnApiKeyNotFound()
        {
            throw new UnauthorizedAccessException(GeneralConstants.ErrorMessages.AUTHORIZATION_APIKEY_MISSING);
        }

        private string GetValueByKey(HttpContext context, string key)
        {
            var value = string.Empty;
            value = context.Request.Headers[key].ToString();

            if (string.IsNullOrEmpty(value))
            {
                value = context.Request.Query[key].ToString();
            }
            return value;
        }
    }
}