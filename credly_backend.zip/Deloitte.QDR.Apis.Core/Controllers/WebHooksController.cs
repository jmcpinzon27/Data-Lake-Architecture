﻿using Deloitte.QDR.DTO.Common;
using Deloitte.QDR.Infrastructure.ServiceBus;
using Microsoft.AspNetCore.Mvc;
using System.Text.Json.Nodes;

namespace Deloitte.QDR.Apis.Core.Controllers
{
    [Route("api/[controller]")]
    [ApiController]    
    public class WebHooksController
    {
        private readonly IQueueService _queueService;

        public WebHooksController(IQueueService queueService)
        {
            _queueService = queueService ?? throw new ArgumentNullException(nameof(queueService));
        }

        /// <summary>
        /// Send message to servicebus queue.
        /// </summary>
        /// <param name="payload">message</param>
        /// <returns></returns>
        /// <remarks>
        /// Allow queue a message into servicebus.
        /// </remarks>

        [HttpPost("QueueMessage")]
        public async Task QueueMessageAsync([FromBody] object payload)
        {
            try
            {
                var inputPayload = JsonValue.Parse(payload.ToString());
                await _queueService.SendAsync(inputPayload.ToString());
            }
            catch (Exception ex)
            {
                throw new ValidationException(new Result { Messages = new List<string>() { GeneralConstants.ErrorMessages.WEBHOOKS_INVALID_PAYLOAD }, HasErrors = true });
            }
        }
    }
}