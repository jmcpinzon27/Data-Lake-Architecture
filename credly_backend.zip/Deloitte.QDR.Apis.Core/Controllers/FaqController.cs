﻿using Deloitte.QDR.Apis.Core.Controllers.Base;
using Deloitte.QDR.Contracts.BL;
using Deloitte.QDR.DTO.Common;
using Deloitte.QDR.DTO.Filters;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace Deloitte.QDR.Apis.Core.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [Authorize]
    public class FaqController : BaseCrudController<Guid, DTO.Faq, FaqFilter>
    {
        public FaqController(IFaqBL bl)
            : base(bl) { }

        [HttpGet("query/byId")]
        public ActionResult<ListResponse<DTO.Faq>> GetByCategory([FromQuery] FaqFilter filterById)
        {
            return ((IFaqBL)BL).GetByCategory(filterById);
        }

        [HttpGet("query/all")]
        public ActionResult<ListResponse<DTO.Faq>> GetAll([FromQuery] FaqFilter filterById)
        {
            return ((IFaqBL)BL).GetAll(filterById);
        }
    }
}
