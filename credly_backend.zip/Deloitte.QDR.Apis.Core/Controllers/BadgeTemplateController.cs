﻿using Deloitte.QDR.Apis.Core.Controllers.Base;
using Deloitte.QDR.Contracts.BL;
using Deloitte.QDR.DTO;
using Deloitte.QDR.DTO.BadgeTemplateFlow;
using Deloitte.QDR.DTO.Common;
using Deloitte.QDR.DTO.Filters;
using Deloitte.QDR.DTO.SABA;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace Deloitte.QDR.Apis.Core.Controllers
{
    [Route("api/[controller]")]
    [Authorize]
    [ApiController]
    public class BadgeTemplateController : ControllerBase,
        IGetByIdAsync<Guid, BadgeTemplate>,
        IGetByFilter<BadgeTemplate,BadgeTemplateFilter>,
        ICreateAsync<BadgeTemplate>,
        IUpdateAsync<BadgeTemplate>,
        IDeleteAsync<Guid>
    {
        private readonly IBadgeTemplateBL _bl;
        public BadgeTemplateController(IBadgeTemplateBL bl)
        {
            _bl = bl ?? throw new ArgumentNullException(nameof(bl));
        }

        #region Base Endpoints

        [HttpGet("{id}")]
        public async Task<ActionResult<BadgeTemplate>> GetByIdAsync(Guid id, CancellationToken cancellationToken = default)
        {
            var result = await _bl.GetByIdAsync(id, cancellationToken);
            if (result == null)
            {
                return NotFound();
            }
            return result;
        }

        [HttpGet]
        public ActionResult<ListResponse<BadgeTemplate>> GetByFilter([FromQuery] BadgeTemplateFilter filter)
        {
            return _bl.GetByFilter(filter);
        }

        
        [HttpPost]
        public async Task<BadgeTemplate> CreateAsync(BadgeTemplate badgeDTO, CancellationToken cancellationToken = default)
        {
            return await _bl.CreateAsync(badgeDTO, cancellationToken);
        }

        
        [HttpPut]
        public async Task<BadgeTemplate> UpdateAsync(BadgeTemplate badgeDTO, CancellationToken cancellationToken = default)
        {
            return await _bl.UpdateAsync(badgeDTO, cancellationToken);
        }

        
        [HttpDelete("{id}")]
        public async Task DeleteAsync(Guid id, CancellationToken cancellationToken = default)
        {
            await _bl.DeleteAsync(id, cancellationToken);
        }

        #endregion

        #region Custom Enpoints

        [HttpGet("query/businessrep")]
        public ActionResult<
            ListResponse<DTO.Queries.BadgeTemplateQuery>
        > GetBadgeTemplatesBusinessRep([FromQuery] DTO.Filters.BadgeTemplateFilter filter)
        {
            return _bl.GetBadgeTemplatesBusinessRep(filter);
        }

        [HttpGet("query/admin")]
        public ActionResult<ListResponse<DTO.Queries.BadgeTemplateQuery>> GetBadgesTempleatesAdmin(
            [FromQuery] DTO.Filters.BadgeTemplateFilter filter
        )
        {
            return _bl.GetBadgesTemplatesAdmin(filter);
        }

        [HttpGet("query/practitioner")]
        public ActionResult<ListResponse<DTO.BadgeTemplate>> GetBadgeTemplatesQueryPractitioner(
            [FromQuery] DTO.Filters.BadgeTemplateFilter filter
        )
        {
            return _bl.GetBadgeTemplatesQueryPractitioner(filter);
        }

        /// <summary>
        /// Validate badge template status flow.
        /// </summary>
        /// <param name="badgeTemplateStatusFlow"></param>
        /// <returns>DTO.BadgeTemplate</returns>
        /// <remarks>
        /// Update the status for a badge Template.
        /// - Valid values for status: AttentionRequired, Archived
        /// - Returns a BadgeTemplate DTO updated.
        /// </remarks>
        
        [HttpPut("query/changestatus")]
        public async Task<DTO.BadgeTemplate> ChangeStatusAsync([FromBody] TransitionStatus statusDto, CancellationToken cancellationToken = default)
        {
            return await _bl.ChangeStatusAsync(statusDto, cancellationToken);
        }

        [HttpPut("query/changeprivacy")]
        public Task<DTO.BadgeTemplate> ChangePrivacyAdmin([FromBody] BadgeTemplate badgeTemplateDto)
        {
            return _bl.ChangePrivacyAsync(badgeTemplateDto);
        }

        [HttpGet("BadgeTemplateCriteriaType")]
        public ActionResult<List<DTO.BadgeTemplateCriteriaType>> GetBadgeTemplateCriteriaType()
        {
            return _bl.GetBadgeTemplateCriteriaTypes();
        }

        [HttpPatch]
        public ActionResult<DTO.BadgeTemplate> Patch(ReleaseNotes releaseNotesDto)
        {
            return _bl.SetReleaseNotes(releaseNotesDto);
        }

        /// <summary>
        /// Allows to change the status of a BadgeTemplate from Approved to HideForArchive.
        /// </summary>
        /// <param name="archivingFlow"></param>
        /// <returns>DTO.ArchivingFlow</returns>
        /// <remarks>
        /// Update the status for a badge Template.
        /// - Valid values for status: HideForArchive
        /// - Returns a ArchivingFlow DTO updated.
        /// </remarks>
        [HttpPatch("admin/ArchivingProcess")]
        public async Task<ActionResult<ArchivingFlow>> ArchivingProcessAsync(ArchivingFlow archivingFlow, CancellationToken cancellationToken = default)
        {
            return await _bl.ArchivingProcessAsync(archivingFlow, cancellationToken);
        }

        /// <summary>
        /// Validate a course in SABA
        /// </summary>
        /// <param name="courseId"></param>
        /// <returns></returns>
        [HttpGet("GetSABACourseById")]
        public async Task<ActionResult<Course>> GetSABACourseByIdAsync(string courseId, CancellationToken cancellationToken = default)
        {
            return await _bl.GetSABACourseByIdAsync(courseId, cancellationToken);
        }

        #endregion

    }
}
