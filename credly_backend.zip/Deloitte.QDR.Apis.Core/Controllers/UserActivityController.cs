﻿using Deloitte.QDR.Apis.Core.Controllers.Base;
using Deloitte.QDR.Contracts.BL;
using Deloitte.QDR.DTO.Filters;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace Deloitte.QDR.Apis.Core.Controllers
{
    [Route("api/[controller]")]
    [Authorize]
    [ApiController]
    public class UserActivityController : BaseCrudController<Guid, DTO.UserActivity, UserActivityFilter>
    {
        private readonly IUserActivityBL _bl;

        public UserActivityController(IUserActivityBL bl)
            : base(bl) { }

    }
}
