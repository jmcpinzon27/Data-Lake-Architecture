﻿using Deloitte.QDR.Apis.Core.Filters;
using Deloitte.QDR.Contracts.BL;
using Deloitte.QDR.DTO.Common;
using Deloitte.QDR.DTO.Filters;
using Deloitte.QDR.DTO.Notifications;
using Deloitte.QDR.Hubs;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.SignalR;

namespace Deloitte.QDR.Apis.Core.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [Authorize]
    public class NotificationController : Controller
    {
        private readonly INotificationBL _bl;
        private readonly IHubContext<NotificationHub> _notificationHub;

        public NotificationController(
            INotificationBL bl,
            IHubContext<NotificationHub> notificationHub
        )
        {
            _bl = bl ?? throw new ArgumentNullException(nameof(bl));
            _notificationHub = notificationHub ?? throw new ArgumentNullException(nameof(notificationHub));
        }

        [HttpGet("query/practitioner")]
        public ActionResult<ListResponse<DTO.Notification>> GetNotificationsPractitioner([FromQuery] NotificationFilter filter)
        {
            return _bl.GetNotificationsPractitioner(filter);
        }

        [HttpGet("query/businessrep")]
        public ActionResult<ListResponse<DTO.Notification>> GetNotificationsBusinessRep([FromQuery] NotificationFilter filter)
        {
            return _bl.GetNotificationsBusinessRep(filter);
        }

        [HttpGet("query/admin")]
        public ActionResult<ListResponse<DTO.Notification>> GetNotificationsAdmin([FromQuery] NotificationFilter filter)
        {
            return _bl.GetNotificationsAdmin(filter);
        }

        [HttpGet("GetAuthorization")]
        public ActionResult GetAuthorization()
        {
            return Ok(new { accessToken = HttpContext.Request.Headers.Authorization.ToString().Replace("Bearer ", "") });
        }

        [HttpPost("ReceiveNotification")]
        public async Task<ActionResult> ReceiveNotification(NotificacionHub notification)
        {
            await _notificationHub.Clients
                .Group(HttpContext.User.Identity.Name)
                .SendAsync("ReceiveNotification", notification);
            return Ok();
        }

        /// <summary>
        /// SendNotification allow send notifications to signarR bus
        /// </summary>
        /// <param name="sendNotificationDTO">sendNotificationDTO param</param>
        /// <param name="cancellationToken">cancellationToken param</param>
        /// <returns>Returns 200 code</returns>
        [HttpPost("SendNotification")]
        [AllowAnonymous]
        [ServiceFilter(typeof(ApiKeyAuthorizationFilter))]
        public async Task<ActionResult> SendNotificationAsync(SendNotificationDTO sendNotificationDTO, CancellationToken cancellationToken = default)
        {
            await _notificationHub.Clients
                .Groups(sendNotificationDTO.EmailGroup)
                .SendAsync("ReceiveNotification", sendNotificationDTO.NotificacionHub, cancellationToken);
            return Ok();
        }
    }
    
}
