﻿using Deloitte.QDR.Contracts.BL;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace Deloitte.QDR.Apis.Core.Controllers
{
    [Route("api/[controller]")]
    [Authorize]
    [ApiController]
    public class RoleController : Controller
    {
        private readonly IRoleBL _roleBL;

        public RoleController(IRoleBL roleBL)
        {
            _roleBL = roleBL ?? throw new ArgumentNullException(nameof(roleBL));
        }

        /// <summary>
        /// Get available roles.
        /// </summary>
        /// <returns>Collection of roles</returns>
        [HttpGet]
        [ProducesResponseType(typeof(IEnumerable<DTO.Role>), 200)]
        public ActionResult<IEnumerable<DTO.Role>> Get()
        {
            return Ok(_roleBL.GetRoles().ToList());
        }
    }
}