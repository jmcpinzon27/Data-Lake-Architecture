﻿using Deloitte.QDR.Contracts.BL;
using Deloitte.QDR.DTO.Common;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace Deloitte.QDR.Apis.Core.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [Authorize]
    public class EmployeeController : ControllerBase
    {
        private readonly IEmployeeBL _bl;

        public EmployeeController(IEmployeeBL bl)
        {
            _bl = bl;
        }

        /// <summary>
        /// Fetch employee information from cache
        /// </summary>
        /// <param name="filterow"></param>
        /// <returns>Employee list</returns>
        /// <remarks>
        /// Fetch employee information from cache
        /// </remarks>
        [HttpGet]
        public async Task<ActionResult<ListResponse<UserSession>>> GetByFilterAsync([FromQuery] FilterBaseWithRoles filter, CancellationToken cancellationToken = default)
        {
            var result = await _bl.GetByFilterAsync(filter);
            Response.Headers.Add(GeneralConstants.Common.HEADER_DATA_IS_FROM_CACHE, result.IsCache.ToString());
            Response.Headers.Add(GeneralConstants.Common.HEADER_DATA_SOURCE_CACHE, result.SourceCache.ToString());
            return result.Data;
        }

        [HttpGet("userSession")]
        public UserSession GetUserSession()
        {
            return _bl.GetUserSession();
        }

        /// <summary>
        /// Fetch employee information filtering by role Admin, BusinessRep or both.
        /// </summary>
        /// <param name="filterow"></param>
        /// <returns>Employee list</returns>
        /// <remarks>
        /// Fetch employee information from cache filtering by role Admin, BusinessRep or both.
        /// </remarks>
        [HttpGet("GetEmployeesByRole")]
        public async Task<ActionResult<ListResponse<UserSession>>> GetEmployeesByRoleAsync([FromQuery] FilterBaseWithRoles filter, CancellationToken cancellationToken = default)
        {
            var result = await _bl.GetEmployeesByRoleAsync(filter, cancellationToken);
            Response.Headers.Add(GeneralConstants.Common.HEADER_DATA_IS_FROM_CACHE, result.IsCache.ToString());
            Response.Headers.Add(GeneralConstants.Common.HEADER_DATA_SOURCE_CACHE, result.SourceCache.ToString());
            return result.Data;
        }

    }
}
