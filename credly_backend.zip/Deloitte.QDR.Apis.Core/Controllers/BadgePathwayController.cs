﻿using Deloitte.QDR.Apis.Core.Controllers.Base;
using Deloitte.QDR.Contracts.BL;
using Deloitte.QDR.DTO;
using Deloitte.QDR.DTO.Common;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace Deloitte.QDR.Apis.Core.Controllers;

[Route("api/[controller]")]
[ApiController]
[Authorize]
public class BadgePathwayController : ControllerBase,
    IGetByIdAsync<Guid, BadgePathway>
{
    private readonly IBadgePathwayBL _bl;
    public BadgePathwayController(IBadgePathwayBL bl)
    {
        _bl = bl ?? throw new ArgumentNullException(nameof(bl));
    }

    #region Base Endpoints

    [HttpGet("{id}")]
    public async Task<ActionResult<BadgePathway>> GetByIdAsync(Guid id, CancellationToken cancellationToken = default)
    {
        return await _bl.GetByIdAsync(id, cancellationToken);
    }

    [HttpPost]
    public async Task<BadgePathway> CreateAsync(BadgePathway badgePathwayDTO, CancellationToken cancellationToken = default)
    {
        return await _bl.CreateAsync(badgePathwayDTO, cancellationToken);
    }

    [HttpPut]
    public async Task<BadgePathway> UpdateAsync(BadgePathway badgePathwayDTO, CancellationToken cancellationToken = default)
    {
        return await _bl.UpdateAsync(badgePathwayDTO, cancellationToken);
    }

    #endregion

    #region Custom Endpoints

    [HttpGet("GetSkillsFromBadgeTemplates")]
    public ActionResult<List<string>> GetSkillsFromBadgeTemplates([FromQuery] List<Guid> idBadgeTemplates)
    {
        return _bl.GetSkillsFromBadgeTemplates(idBadgeTemplates);
    }

    [HttpGet("query/BusinessRepAndAdmin")]
    public async Task<ActionResult<ListResponse<BadgePathway>>> GetBadgePathwaysBusinessRepAndAdminAsync([FromQuery] FilterBase filter, CancellationToken cancellationToken = default)
    {
        return await _bl.GetBadgePathwaysBusinessRepAndAdminAsync(filter, cancellationToken);
    }

    #endregion
}