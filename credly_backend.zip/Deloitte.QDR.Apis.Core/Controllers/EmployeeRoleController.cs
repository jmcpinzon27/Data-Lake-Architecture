﻿using Deloitte.QDR.Apis.Core.Controllers.Base;
using Deloitte.QDR.Contracts.BL;
using Deloitte.QDR.DTO;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Deloitte.QDR.Apis.Core.Controllers
{
    [Route("api/[controller]")]
    [Authorize]
    [ApiController]
    public class EmployeeRoleController : BaseCrudController<Guid, DTO.EmployeeRole, DTO.Filters.EmployeeRoleFilter>
    {
        public EmployeeRoleController(IEmployeeRoleBL bl) : base(bl)
        {
        }

        #region PublicMethods

        // DELETE api/<RolController>/5  => it could  return  boolean or id+role to try ti return operation result
        
        [HttpDelete]
        public ActionResult<Boolean> Delete([FromBody] DTO.EmployeeRole employeeRoleDTO)
        {
            return ((IEmployeeRoleBL)BL).Delete(employeeRoleDTO); //TODO create delete
        }

        /// <summary>
        /// Update employeer-role.
        /// </summary>
        /// <param name="EmployeeId">EmployeeId value</param>
        /// <param name="RoleId">RoleId value</param>
        /// <returns>DTO.EmployeeRole</returns>
        /// <remarks>
        /// Update current role by new assign.
        /// - Practicioner role cannot be removed.   
        /// </remarks>
        
        [HttpPatch()]
        [ProducesResponseType(typeof(DTO.EmployeeRole), 200)]
        public ActionResult<DTO.EmployeeRole> Patch([FromBody] DTO.EmployeeRoleBase employeeRoleBaseDTO)
        {
            var employeeRoleDTO = new DTO.EmployeeRole
            {
                EmployeeId = employeeRoleBaseDTO.EmployeeId,
                RoleId = employeeRoleBaseDTO.RoleId
            };
            return ((IEmployeeRoleBL)BL).Update(employeeRoleDTO);
        }

        #endregion PublicMethods

        //TODO: It can be moved to common library

        #region PrivateMethods

        private bool CheckErrorsOnInitialActionResult(bool mustCheckExistence, EmployeeRole employeeRoleDTO, out ActionResult actionResult)
        {
            if (!ModelState.IsValid)
            {
                actionResult = BadRequest(ModelState);
                return true;
            }

            var entityToApplyChanges = ((IEmployeeRoleBL)BL).GetByGuid(Guid.Parse(employeeRoleDTO.EmployeeId));

            if ((entityToApplyChanges == null || entityToApplyChanges.Count == 0) && mustCheckExistence) //TODO check condition
            {
                actionResult = NotFound();
                return true;
            }
            if ((entityToApplyChanges.Count > 0) && !mustCheckExistence) //TODO check condition
            {
                actionResult = BadRequest();
                return true;
            }

            actionResult = null;
            return false;
        }

        #endregion PrivateMethods
    }
}