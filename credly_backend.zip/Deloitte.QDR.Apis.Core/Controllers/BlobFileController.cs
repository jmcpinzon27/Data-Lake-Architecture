﻿using Deloitte.QDR.Contracts.BL;
using Deloitte.QDR.DTO.Common;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace Deloitte.QDR.Apis.Core.Controllers
{
    [Route("api/[controller]")]
    [Authorize]
    public class BlobFileController : Controller
    {
        private readonly IBlobFileBL _blobFileBL;

        public BlobFileController(IBlobFileBL blobFileBL)
        {
            _blobFileBL = blobFileBL;
        }

        
        [HttpPost("UploadFile")]
        public async Task<ActionResult> UploadBadgeFile([FromBody] Base64File file)
        {
            var result = await _blobFileBL.UploadBadgeFile(file);
            return Ok(result);
        }

        [HttpGet("DownloadFile")]
        public async Task<ActionResult> DownloadBadgeFile(string idBlobFile)
        {
            if (string.IsNullOrWhiteSpace(idBlobFile))
            {
                throw new ValidationException(new Result { Messages = new List<string>() { GeneralConstants.ErrorMessages.IDBLOB_IS_REQUIRED }, HasErrors = true });
            }
            var result = await _blobFileBL.DownloadBadgeFile(idBlobFile);
            return File(result.Content, result.ContentType, result.NameFile);
        }

        
        [HttpDelete("DeleteFile")]
        public async Task<ActionResult> DeleteBadgeFile(string idBlobFile)
        {
            await _blobFileBL.DeleteBadgeFile(idBlobFile);
            return Ok();
        }

        [HttpGet("GetListFile")]
        public async Task<ActionResult<List<BlobFileInfo>>> GetListBadgeFile(string prefix)
        {
            return Ok(await _blobFileBL.GetListBadgeFile(prefix));
        }
    }
}
