﻿using Deloitte.QDR.Contracts.BL;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace Deloitte.QDR.Apis.Core.Controllers;

[Route("api/[controller]")]
[Authorize]
[ApiController]
public class SystemController : ControllerBase
{
    private readonly ISystemBL _bl;

    public SystemController(ISystemBL bl)
    {
        _bl = bl ?? throw new ArgumentNullException(nameof(bl));
    }

    [HttpGet("getparameters")]
    public ActionResult<List<KeyValuePair<string, string>>> GetParameters()
    {
        return _bl.GetParameters();
    }
}