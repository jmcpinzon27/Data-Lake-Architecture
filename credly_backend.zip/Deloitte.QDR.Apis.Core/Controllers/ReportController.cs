﻿using Deloitte.QDR.Contracts.BL;
using Deloitte.QDR.DTO.Common;
using Deloitte.QDR.DTO.Reports;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace Deloitte.QDR.Apis.Core.Controllers
{
    [Route("api/[controller]")]
    [Authorize]
    public class ReportController : Controller
    {
        private readonly IReportBL _bl;

        public ReportController(IReportBL bl)
        {
            _bl = bl ?? throw new ArgumentNullException(nameof(bl));
        }

        [HttpGet("admin/summary")]
        [ProducesResponseType(200, Type = typeof(AdminSummaryReport))]
        public async Task<AdminSummaryReport> GetAdminSummaryReportAsync()
        {
            return await _bl.GetAdminSummaryReportAsync();
        }

        [HttpGet("admin/badgesByPeriod/{interval}")]
        [ProducesResponseType(200, Type = typeof(BadgesByPeriodReportItem))]
        public IList<BadgesByPeriodReportItem> GetBadgesByPeriodReport([Bind] Interval interval)
        {
            return _bl.GetBadgesByPeriodReport(interval);
        }

        [HttpGet("practitioner/summary")]
        [ProducesResponseType(200, Type = typeof(PractitionerSummaryReport))]
        public async Task<PractitionerSummaryReport> GetPractitionerSummaryReportAsync()
        {
            return await _bl.GetPractitionerSummaryReportAsync();
        }
    }
}