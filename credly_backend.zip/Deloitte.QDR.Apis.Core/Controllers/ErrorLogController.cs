﻿using Deloitte.QDR.Apis.Core.Controllers.Base;
using Deloitte.QDR.Contracts.BL;
using Deloitte.QDR.DTO;
using Deloitte.QDR.DTO.Common;
using Deloitte.QDR.DTO.Filters;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace Deloitte.QDR.Apis.Core.Controllers;

[Route("api/[controller]")]
[ApiController]
[Authorize]
public class ErrorLogController : ControllerBase,
    IGetByFilter<ErrorLog, ErrorLogFilter>
{
    private readonly IErrorLogBL _bl;
    public ErrorLogController(IErrorLogBL bl)
    {
        _bl = bl ?? throw new ArgumentNullException(nameof(bl));
    }

    [HttpGet]
    public ActionResult<ListResponse<ErrorLog>> GetByFilter([FromQuery] ErrorLogFilter filter)
    {
        return _bl.GetByFilter(filter);
    }

}