﻿using Deloitte.QDR.Contracts.BL;
using Deloitte.QDR.DTO;
using Deloitte.QDR.DTO.Common;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Threading;

namespace Deloitte.QDR.Apis.Core.Controllers
{

    [Route("api/[controller]")]
    [Authorize]
    [ApiController]
    [RequireHttps]
    public class AwardingProcessController : ControllerBase
    {
        private readonly IAwardingProcessBL _bl;

        public AwardingProcessController(IAwardingProcessBL bl)
        {
            _bl = bl ?? throw new ArgumentNullException(nameof(bl));
        }

        [HttpGet("businessrep/Get")]
        public ActionResult<ListResponse<DTO.AwardingProcess>> GetBulkAwardingProcessBusinessRep([FromQuery] DTO.Common.FilterBase filter)
        {
            return GetBulkAwardingProcess(filter);
        }

        
        [HttpGet("{id}")]
        public ActionResult<AwardingProcess> GetById(Guid id)
        {
            return _bl.GetById(id);
        }

        
        [HttpPost("businessrep/Create")]
        public ActionResult CreateAwardingProcessBusinessRep()
        {
            return CreateBulkAwardingProcess();
        }

        [HttpPut("businessrep/Update")]
        public async Task<ActionResult<AwardingProcess>> UpdateAwardingProcessBusinessRepAsync(AwardingProcess awardingProcess, CancellationToken cancellationToken = default)
        {
            return await UpdateBulkAwardingProcessAsync(awardingProcess, cancellationToken);
        }

        
        [HttpGet("admin/Get")]
        public ActionResult<ListResponse<DTO.AwardingProcess>> GetBulkAwardingProcessAdmin([FromQuery] DTO.Common.FilterBase filter)
        {
            return GetBulkAwardingProcess(filter);
        }

        [HttpPost("admin/Create")]
        public ActionResult CreateAwardingProcessAdmin()
        {
            return CreateBulkAwardingProcess();
        }

        [HttpPut("admin/Update")]
        public async Task<ActionResult<AwardingProcess>> UpdateAwardingProcessAdminAsync(AwardingProcess awardingProcess, CancellationToken cancellationToken = default)
        {
            return await UpdateBulkAwardingProcessAsync(awardingProcess, cancellationToken);
        }

        [HttpPut("admin/ChangeStatus")]
        public ActionResult ChangeStatusAwardingProcessAdmin(AwardingProcess awardingProcess)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            var result = _bl.ChangeStatus(awardingProcess);
            if (result == null)
            {
                return NotFound();
            }
            return Ok(result);
        }

        
        [HttpDelete("admin/Delete")]
        public ActionResult Delete(Guid Id)
        {
            _bl.Delete(Id);
            return Ok();
        }

        #region PrivateMethods
        private ActionResult<ListResponse<AwardingProcess>> GetBulkAwardingProcess(FilterBase filter)
        {
            var result = _bl.GetByFilter(filter);
            return result;
        }
        private ActionResult CreateBulkAwardingProcess()
        {
            var result = _bl.CreateAwardingProcess();
            return Ok(result);
        }
        private async Task<ActionResult<AwardingProcess>> UpdateBulkAwardingProcessAsync(AwardingProcess awardingProcess, CancellationToken cancellationToken)
        {
            var result = await _bl.UpdateAsync(awardingProcess, cancellationToken);

            return Ok(result);
        }

        #endregion
    }
}
