﻿using Deloitte.QDR.Apis.Core.Controllers.Base;
using Deloitte.QDR.Contracts.BL;
using Deloitte.QDR.DTO;
using Deloitte.QDR.DTO.Common;
using Deloitte.QDR.DTO.Filters;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace Deloitte.QDR.Apis.Core.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [Authorize]
    public class SkillController : ControllerBase,
        IGetByFilter<Skill, SkillFilter>
    {
        private readonly ISkillBL _bl;
        public SkillController(ISkillBL bl)
        {
            _bl = bl ?? throw new ArgumentNullException(nameof(bl));
        }

        [HttpGet]
        public ActionResult<ListResponse<Skill>> GetByFilter([FromQuery] SkillFilter filter)
        {
            return _bl.GetByFilter(filter);
        }

        [HttpGet("GetSkillsDistinctByName")]
        public ActionResult GetSkillsDistinctByName()
        {
            return Ok(_bl.GetSkillsDistinctByName());
        }

        [HttpGet("GetSkillsByBadgeTemplateStatus")]
        public ActionResult GetSkillsByBadgeTemplateStatus([FromQuery] SkillFilter filter)
        {
            return Ok(_bl.GetSkillsByBadgeTemplateStatus(filter));
        }
    }
}