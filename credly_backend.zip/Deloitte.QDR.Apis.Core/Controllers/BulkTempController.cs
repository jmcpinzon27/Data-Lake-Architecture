﻿using Deloitte.QDR.Contracts.BL;
using Deloitte.QDR.DTO.Common;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace Deloitte.QDR.Apis.Core.Controllers
{
    [Route("api/[controller]")]
    [Authorize]
    public class BulkTempController : Controller
    {
        private readonly IBulkTempBL _bl;

        public BulkTempController(IBulkTempBL bl)
        {
            _bl = bl ?? throw new ArgumentNullException(nameof(bl));
        }

        [HttpGet("load")]
        [ProducesResponseType(200, Type = typeof(System.Boolean))]
        public bool BulkEmployeeData([Bind] string email, [Bind] RoleType role)
        {
            return _bl.BulkEmployeeData(email, role, true);
        }

        [HttpGet("changerole")]
        [ProducesResponseType(200, Type = typeof(System.Boolean))]
        public bool ChangeRole([Bind] string email, [Bind] RoleType role)
        {
            return _bl.ChangeRole(email, role);
        }

        /// <summary>
        /// Refresh all data of employees in cache.
        /// </summary>
        /// <remarks>
        /// Refresh all data of employees in cache.
        /// </remarks>
        [HttpGet("RefreshEmployeesCache")]
        public async Task RefreshEmployeesCache()
        {
            await _bl.RefreshEmployeesCache();
        }

        
        [HttpPost("SendEmail")]
        public async Task<bool> SendEmail(NotificationEmailData maildata)
        {
            if (maildata.UseHtmlTemplate)
            {
                return await _bl.SendMailAsync(maildata);
            }
            else
            {
                return await _bl.SendMailTestAsync(maildata);
            }
        }
    }
}