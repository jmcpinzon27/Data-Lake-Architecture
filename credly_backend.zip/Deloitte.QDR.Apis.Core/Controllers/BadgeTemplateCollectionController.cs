﻿using Deloitte.QDR.Apis.Core.Controllers.Base;
using Deloitte.QDR.Contracts.BL;
using Deloitte.QDR.DTO.Filters;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace Deloitte.QDR.Apis.Core.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [Authorize]
    public class BadgeTemplateCollectionController : BaseCrudController<Guid, DTO.BadgeTemplateCollection, BadgeTemplateCollectionFilter>
    {
        public BadgeTemplateCollectionController(IBadgeTemplateCollectionBL bl)
            : base(bl) { }

    }
}
