﻿using Deloitte.QDR.Contracts.BL.Base;
using Deloitte.QDR.DTO.Common;
using Microsoft.AspNetCore.Mvc;
using System.Security.Cryptography;

namespace Deloitte.QDR.Apis.Core.Controllers.Base
{
    //TODO: this class will be removed because should use the crud interface
    public abstract class BaseCrudController<TID, TD, TF> : ControllerBase
        where TD : class
        where TF : FilterBase
    {
        public readonly ICrudBL<TID, TD, TF> BL;

        public BaseCrudController(ICrudBL<TID, TD, TF> bl)
        {
            BL = bl;
        }

        [HttpGet]
        public ActionResult<ListResponse<TD>> Get([FromQuery] TF filter)
        {
            return BL.GetByFilter(filter);
        }

        [HttpGet("{id}")]
        public ActionResult<TD> Get(TID id)
        {
            return BL.GetById(id);
        }

        [HttpPost]
        public TD Post([FromBody] TD dto)
        {
            return BL.Create(dto);
        }

        [HttpPut]
        public TD Put(TD dto)
        {
            return BL.Update(dto);
        }

        [HttpDelete("{id}")]
        public void Delete(TID id)
        {
            BL.Delete(id);
        }
    }

    public interface IGetById<TID, TD>
    {
        ActionResult<TD> GetById(TID id);
    }

    public interface IGetByIdAsync<TID, TD>
    {
        Task<ActionResult<TD>> GetByIdAsync(TID id, CancellationToken cancellationToken = default);
    }

    public interface IGetByFilter<TD, TF> where TF : FilterBase
    {
        ActionResult<ListResponse<TD>> GetByFilter([FromQuery] TF filter);
    }

    public interface IGetByFilterAsync<TD, TF> where TF : FilterBase
    {
        Task<ActionResult<ListResponse<TD>>> GetByFilterAsync([FromQuery] TF filter, CancellationToken cancellationToken = default);
    }

    public interface ICreate<TD>
    {
        TD Create(TD badgeDTO);
    }

    public interface ICreateAsync<TD>
    {
        Task<TD> CreateAsync(TD badgeDTO, CancellationToken cancellationToken = default);
    }

    public interface IUpdate<TD>
    {
        TD Update(TD badgeDTO);
    }

    public interface IUpdateAsync<TD>
    {
        Task<TD> UpdateAsync(TD badgeDTO, CancellationToken cancellationToken = default);
    }

    public interface IDelete<TID>
    {
        void Delete(TID id);
    }

    public interface IDeleteAsync<TID>
    {
        Task DeleteAsync(TID id, CancellationToken cancellationToken = default);
    }
}
