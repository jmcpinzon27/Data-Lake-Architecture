﻿using Deloitte.QDR.Apis.Core.Controllers.Base;
using Deloitte.QDR.Contracts.BL;
using Deloitte.QDR.DTO;
using Deloitte.QDR.DTO.Common;
using Deloitte.QDR.DTO.Filters;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace Deloitte.QDR.Apis.Core.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [Authorize]
    public class BadgeController : ControllerBase,
        IGetById<Guid, Badge>,
        IGetByFilter<Badge, BadgesFilter>,
        ICreate<Badge>,
        IUpdateAsync<Badge>,
        IDelete<Guid>
    {
        private readonly IBadgeBL _bl;
        public BadgeController(IBadgeBL bl)
        {
            _bl = bl ?? throw new ArgumentNullException(nameof(bl));
        }

        #region Base Endpoints

        [HttpGet("{id}")]
        public ActionResult<Badge> GetById(Guid id)
        {
            return _bl.GetById(id);
        }

        [HttpGet]
        public ActionResult<ListResponse<Badge>> GetByFilter([FromQuery] BadgesFilter filter)
        {
            return _bl.GetByFilter(filter);
        }


        [HttpPost]
        public Badge Create([FromBody] Badge dto)
        {
            return _bl.Create(dto);
        }


        [HttpPut]
        public async Task<Badge> UpdateAsync(Badge badgeDTO, CancellationToken cancellationToken = default)
        {
            return await _bl.UpdateAsync(badgeDTO, cancellationToken);
        }


        [HttpDelete("{id}")]
        public void Delete(Guid id)
        {
            _bl.Delete(id);
        }

        #endregion

        #region Custom Endpoints

        [HttpGet("query/practitioner")]
        public ActionResult<ListResponse<DTO.Queries.BadgeQuery>> GetBadgesPractitioner(
            [FromQuery] DTO.Filters.BadgesFilter filter
        )
        {
            return _bl.GetBadgesPractitioner(filter);
        }

        [HttpGet("query/businessrep")]
        public async Task<ActionResult<ListResponse<DTO.Queries.BadgeQuery>>> GetBadgesBusinessRepAsync(
            [FromQuery] DTO.Filters.BadgesFilter filter
        )
        {
            return await _bl.GetBadgesBusinessRepAsync(filter);
        }

        [HttpGet("query/admin")]
        public ActionResult<ListResponse<DTO.Queries.BadgeQuery>> GetBadgesAdmin(
            [FromQuery] DTO.Filters.BadgesFilter filter
        )
        {
            return _bl.GetBadgesAdmin(filter);
        }

        /// <summary>
        /// Validate badge status flow.
        /// </summary>
        /// <param name="badgeStatusFlow"></param>
        /// <returns>badgeStatusFlow</returns>
        /// <remarks>
        /// Update the status for a badge.
        /// - Valid values for status:   Initiated = 1, Awarded = 2, InProgress = 3, Withdrawn = 4, SubmittedForApproval = 5, AttentionRequired = 6, Approved = 7, Rejected = 8, Revoked = 9, Archived = 10, Expired = 11, Deleted = 12, ToBeArchived = 13, Discarded = 14
        /// - Returns a badgeStatusFlow with the new values.
        /// </remarks>


        [HttpPost("admin/status")]
        public async Task<ActionResult<BadgeStatusFlow>> StatusFlowAsync([FromBody] DTO.BadgeStatusFlow badgeStatusFlow)
        {
            return await _bl.StatusFlowAsync(badgeStatusFlow);
        }

        /// <summary>
        /// Re-initite a Badge
        /// </summary>
        /// <param name="id"></param>
        /// <returns>Badge</returns>
        /// /// <remarks>
        /// Re-Initiate a badge with status Rejected
        /// </remarks>
        [HttpPost("practitioner/reinitiate/{id}")]
        public async Task<ActionResult<Badge>> ReInitiatedBadgeAsync(Guid id, CancellationToken cancellationToken = default)
        {
            return await _bl.ReInitiatedBadgeAsync(id, cancellationToken);
        }

        #endregion



    }
}
