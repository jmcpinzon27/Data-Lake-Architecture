﻿using Azure.Identity;
using Deloitte.QDR.Apis.Core.Filters;
using Deloitte.QDR.BLL;
using Deloitte.QDR.Cache;
using Deloitte.QDR.Contracts;
using Deloitte.QDR.Contracts.BL;
using Deloitte.QDR.Contracts.Services;
using Deloitte.QDR.DAL;
using Deloitte.QDR.DTO.CredlyAPI.Common;
using Deloitte.QDR.Hubs;
using Deloitte.QDR.Infrastructure;
using Deloitte.QDR.Infrastructure.Config;
using Deloitte.QDR.Infrastructure.KeyVault;
using Deloitte.QDR.Infrastructure.ServiceBus;
using Deloitte.QDR.Services;
using Deloitte.QDR.Services.Config;
using Deloitte.QDR.Services.CustomValidaiton;
using Microsoft.AspNetCore.Http.Connections;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Azure;
using static Deloitte.QDR.DTO.Common.GeneralConstants;

namespace Deloitte.QDR.Apis.Core
{
    public static class Bootstrapper
    {
        public static void AddRepositories(this IServiceCollection services)
        {
           
            services.AddDbContext<AuditableDBContext>(
                options =>
                    options
                        .UseSqlServer(AppSettings.Settings.GetSecret(KeyVault.SECRET_SQLDBCONNECTIONSTRING))
                        //ONLY FOR TESTING 
                        .EnableSensitiveDataLogging(true)
            );

            services.AddScoped<IDBContext>(provider => provider.GetService<AuditableDBContext>());
            services.AddSingleton<IHttpContextAccessor, HttpContextAccessor>();
            services.AddSingleton<IDataCache, RedisDataCache>();
            services.AddSingleton<IKeyVaultManager, KeyVaultManager>();
        }

        public static void AddBLs(this IServiceCollection services)
        {
            services.AddScoped<IBadgeBL, BadgeBL>();
            services.AddScoped<IBadgeTemplateBL, BadgeTemplateBL>();
            services.AddScoped<IEmployeeBL, EmployeeBL>();
            services.AddScoped<INotificationBL, NotificationBL>();
            services.AddScoped<IReportBL, ReportBL>();
            services.AddScoped<IBlobFileBL, BlobFileBL>();
            services.AddScoped<ISkillBL, SkillBL>();
            services.AddScoped<IBulkTempBL, BulkTempBL>();
            services.AddScoped<IAwardingProcessBL, AwardingProcessBL>();
            services.AddScoped<ICollectionBL, CollectionBL>();
            services.AddScoped<IEmployeeRoleBL, EmployeeRoleBL>();
            services.AddScoped<IBadgeTemplateCollectionBL, BadgeTemplateCollectionBL>();
            services.AddScoped<IUserActivityBL, UserActivityBL>();
            services.AddScoped<IRoleBL, RoleBL>();
            services.AddScoped<IBadgePathwayBL, BadgePathwayBL>();
            services.AddScoped<ISystemBL, SystemBL>();
	    services.AddScoped<IErrorLogBL, ErrorLogBL>();
        }

        public static void AddServices(this IServiceCollection services)
        {
            AddKeyVaultService(services);
            services.AddHttpContextAccessor();
            services.AddScoped<ISessionService, SessionService>();
            services.AddScoped<IFaqBL, FaqBL>();
            services.AddSingleton<IBlobStorageService>(
                x =>
                    new BlobStorageService(
                        AppSettings.Settings.GetSecret(KeyVault.SECRET_BLOBSTORAGECONNECTIONSTRING),
                        AppSettings.Settings.BlobStorageUriBase,
                        AppSettings.Settings.BlobStorageContainer
                    )
            );
            services.AddSingleton(x => new CredlyHttpData
            {
                BadgeTemplate = new CredlyOrganizationData
                {
                    Organization = AppSettings.Settings.GetSecret(KeyVault.SECRET_CREDLYORGANIZATION_BADGETEMPLATE),
                    Authorization = AppSettings.Settings.GetSecret(KeyVault.SECRET_CREDLYAUTH_BADGETEMPLATE)
                },
                Badge = new CredlyOrganizationData
                {
                    Organization = AppSettings.Settings.GetSecret(KeyVault.SECRET_CREDLYORGANIZATION_BADGE),
                    Authorization = AppSettings.Settings.GetSecret(KeyVault.SECRET_CREDLYAUTH_BADGE)
                }
            });
            services.AddScoped<ICredlyAPIService, CredlyAPIService>();
            services.AddHttpClient<ICredlyAPIService, CredlyAPIService>(http =>
            {
                http.BaseAddress = new Uri($"{AppSettings.Settings.GetSecret(KeyVault.SECRET_CREDLYURLBASE)}");
            });
            services.AddScoped<IHubService, HubService>();
            services.AddScoped<BadgeStatusFlowService>();
            services.AddScoped<BadgeTemplateStatusFlowService>();
            services.AddScoped<INotificationService, NotificationService>();
            services.AddScoped<IEmailValidation, EmailValidation>();
            services.AddScoped<ILoginValidationService, LoginValidationService>();
            services.AddScoped<IFeedbackService, FeedbackService>();
            services.AddHostedService<RefresherService>();
            services.AddMemoryCache();
            services.AddScoped<ICacheService, CacheService>();
            services.AddScoped<IEmailService, EmailService>();
            services.AddScoped<ISMTPEmailHandler, SMTPEmailHandler>();
            services.AddScoped<ISABAService, SABAService>();
            services.AddHttpClient<ISABAService, SABAService>(http =>
            {
                http.BaseAddress = new Uri($"{AppSettings.Settings.SABAUrlBase}");
                //http.DefaultRequestHeaders.Add(
                //    "Authorization",
                //    AppSettings.Settings.GetSecret(KeyVault.SECRET_CREDLYAUTH)
                //);
            });
  	    services.AddScoped<IQueueService, AZQueue>();
            services.AddScoped<ApiKeyAuthorizationFilter>();

            //Enforce all requests over https
            services.AddHsts(opt =>
            {
                opt.IncludeSubDomains = true;
                opt.MaxAge = TimeSpan.FromDays(1);
            });
        }

        public static void MapHubs(this IEndpointRouteBuilder app)
        {
            app.MapHub<NotificationHub>("/notification", hubOptions =>
            {
                hubOptions.Transports = HttpTransportType.LongPolling;
                hubOptions.ApplicationMaxBufferSize = 1000000; // 1 Megabyte
                hubOptions.TransportMaxBufferSize = 1000000; // 1 Megabyte
                hubOptions.CloseOnAuthenticationExpiration = true;
            });
        }

        private static void AddKeyVaultService(this IServiceCollection services)
        {
            services.AddAzureClients(azureClient =>
            {
                azureClient.AddSecretClient(new Uri(AppSettings.Settings.VaultUri));

                var credential = new ClientSecretCredential(
                    AppSettings.Settings.GetSecret(KeyVault.SECRET_TENANTID),
                    AppSettings.Settings.GetSecret(KeyVault.SECRET_CLIENTID),
                    AppSettings.Settings.GetSecret(KeyVault.SECRET_CLIENTSECRET));

                azureClient.UseCredential(credential);
            });
        }
    }
}
