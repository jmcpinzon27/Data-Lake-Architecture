﻿namespace Deloitte.QDR.Credly.Functions.Infrastructure.KeyVault
{
    public interface IKeyVaultManager
    {
        Task<string> GetSecretAsync(string secretName, string version = default, CancellationToken cancellationToken = default);

        string GetSecret(string secretName);
    }
}