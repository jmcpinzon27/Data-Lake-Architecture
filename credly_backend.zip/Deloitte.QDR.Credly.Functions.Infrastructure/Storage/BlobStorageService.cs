﻿using Azure.Storage.Blobs;
using Azure.Storage.Blobs.Models;
using Deloitte.QDR.DTO.Common;

namespace Deloitte.QDR.Credly.Functions.Infrastructure.Storage
{
    public class BlobStorageService : IBlobStorageService
    {
        private readonly string _blobStorageConnectionString;
        private readonly string _blobStorageUriBase;
        private readonly string _container;

        public BlobStorageService(
            string blobStorageConnectionString,
            string blobStorageUriBase,
            string container
        )
        {
            _blobStorageConnectionString = blobStorageConnectionString;
            _blobStorageUriBase = blobStorageUriBase;
            _container = container;
        }

        public async Task<BlobFileInfo> UploadBlobFile(
            MemoryStream file,
            string idBlobFile,
            string ContentType
        )
        {
            file.Position = 0;
            var blobContainerClient = new BlobContainerClient(
                _blobStorageConnectionString,
                _container
            );
            BlobClient blob = blobContainerClient.GetBlobClient(idBlobFile);
            var response = await blob.UploadAsync(
                file,
                new BlobHttpHeaders { ContentType = ContentType }
            );
            return new BlobFileInfo
            {
                IdBlob = idBlobFile,
                NameFile = idBlobFile.Substring(idBlobFile.LastIndexOf("/") + 1),
                Uri = $"{_blobStorageUriBase}/{_container}/{idBlobFile}",
                ContentType = ContentType,
                ContentLength = response.Value.ContentHash.Length,
                LastModified = response.Value.LastModified,
                CreatedOn = response.Value.LastModified,
            };
        }
    }
}