﻿using Deloitte.QDR.DTO.Common;

namespace Deloitte.QDR.Credly.Functions.Infrastructure.Storage
{
    public interface IBlobStorageService
    {
        Task<BlobFileInfo> UploadBlobFile(MemoryStream file, string idBlobFile, string ContentType);
    }
}