﻿using Azure.Identity;
using Azure.Security.KeyVault.Secrets;

namespace Deloitte.QDR.Credly.Functions.Infrastructure.Config
{
    public class Settings
    {
        #region PUBLIC_PROPERTIES

        public bool IsLocalEnv { get; set; }
        public string VaultUri { get; set; }
        public string TenantId { get; set; }
        public string ClientId { get; set; }
        public string ClientSecret { get; set; }
        public string QDRAPIUrlBase { get; set; }
        public string ArchiveBadgeCapacityToProcess { get; set; }
        public string ImageProcessingQueue { get; set; }
        public string ServiceBusConnection { get; set; }
        public string BlobStorageUriBase { get; set; }
        public string BlobStorageContainer { get; set; }
        public string CredlyVersion { get; set; }

        #endregion PUBLIC_PROPERTIES

        public void ReadIsLocalEnv(string isLocalEnv)
        {
            bool result = false;
            bool.TryParse(isLocalEnv, out result);
            IsLocalEnv = result;
            if (result)
            {
                ServiceBusConnection = Environment.GetEnvironmentVariable(nameof(Settings.ServiceBusConnection));
            }
        }

        public string GetSecret(string secretName)
        {
            if (IsLocalEnv)
            {
                return GetLocalSecret(secretName);
            }
            else
            {
                return GetReleaseSecret(secretName);
            }
        }

        private string GetReleaseSecret(string secretName)
        {
            string result = string.Empty;
            try
            {
                var keyVaultUri = new Uri(AppSettings.Settings.VaultUri);

                var credential = new DefaultAzureCredential(new DefaultAzureCredentialOptions { ExcludeEnvironmentCredential= true });

                var keyVaultClient = new SecretClient(keyVaultUri, credential);

                var secret = keyVaultClient.GetSecret(secretName);

                result = secret.Value.Value;
            }
            catch (Exception ex)
            {
                //TODO: REPORT TO LOG
                throw ex;
            }
            return result;
        }

        private string GetLocalSecret(string secretName)
        {
            string result = string.Empty;
            try
            {
                var credential = new ClientSecretCredential(AppSettings.Settings.TenantId, AppSettings.Settings.ClientId, AppSettings.Settings.ClientSecret);
                var keyVaultClient = new SecretClient(new Uri(AppSettings.Settings.VaultUri), credential);
                var secret = keyVaultClient.GetSecret(secretName);
                result = secret.Value.Value;
            }
            catch (Exception ex)
            {
                //TODO: REPORT TO LOG
                throw ex;
            }
            return result;
        }
    }
}