﻿namespace Deloitte.QDR.Credly.Functions.Infrastructure.Config
{
    public class AppSettings
    {
        public static Settings Settings { get; set; }

        public static void BindSettings()
        {
            Settings = new Settings
            {
                ClientId = Environment.GetEnvironmentVariable(nameof(Settings.ClientId)),
                ClientSecret = Environment.GetEnvironmentVariable(nameof(Settings.ClientSecret)),
                TenantId = Environment.GetEnvironmentVariable(nameof(Settings.TenantId)),
                VaultUri = Environment.GetEnvironmentVariable(nameof(Settings.VaultUri)),
                QDRAPIUrlBase = Environment.GetEnvironmentVariable(nameof(Settings.QDRAPIUrlBase)),
                ImageProcessingQueue = Environment.GetEnvironmentVariable(nameof(Settings.ImageProcessingQueue)),
                BlobStorageContainer = Environment.GetEnvironmentVariable(nameof(Settings.BlobStorageContainer)),
                BlobStorageUriBase = Environment.GetEnvironmentVariable(nameof(Settings.BlobStorageUriBase)),
                CredlyVersion = Environment.GetEnvironmentVariable(nameof(Settings.CredlyVersion)),
                ArchiveBadgeCapacityToProcess = Environment.GetEnvironmentVariable(nameof(Settings.ArchiveBadgeCapacityToProcess))
            };
            Settings.ReadIsLocalEnv(Environment.GetEnvironmentVariable(nameof(Settings.IsLocalEnv)));
        }
    }
}