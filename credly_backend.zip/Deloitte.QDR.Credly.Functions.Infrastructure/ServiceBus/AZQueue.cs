﻿using Deloitte.QDR.Credly.Functions.Infrastructure.Config;
using Deloitte.QDR.Credly.Functions.Infrastructure.KeyVault;
using Deloitte.QDR.DTO.Common;
using Microsoft.Azure.ServiceBus;
using Microsoft.Extensions.Configuration;
using System.Text;

namespace Deloitte.QDR.Credly.Functions.Infrastructure.ServiceBus
{
    public class AZQueue : IQueueService
    {
        private IQueueClient _queueClient;
        private readonly IKeyVaultManager _keyVaultManager;

        public AZQueue(IKeyVaultManager keyVaultManager, IConfiguration conf)
        {
            _keyVaultManager = keyVaultManager ?? throw new ArgumentNullException(nameof(keyVaultManager));

            var serviceBusConnection = string.Empty;
            var queueName = string.Empty;

            if (AppSettings.Settings.IsLocalEnv)
            {
                serviceBusConnection = AppSettings.Settings.ServiceBusConnection;
                queueName = AppSettings.Settings.ImageProcessingQueue;
            }
            else
            {
                serviceBusConnection = _keyVaultManager.GetSecret(GeneralConstants.KeyVault.SECRET_SERVICEBUSCONNECTIONSTRING);
                queueName = _keyVaultManager.GetSecret(GeneralConstants.KeyVault.SECRET_SERVICEBUSQUEUENAME);
            }

            _queueClient = new QueueClient(serviceBusConnection, queueName);
        }

        public async Task SendAsync(string payload)
        {
            var payloadMessage = new Message(Encoding.UTF8.GetBytes(payload));
            await _queueClient.SendAsync(payloadMessage);
        }
    }
}