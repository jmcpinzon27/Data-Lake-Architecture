﻿namespace Deloitte.QDR.Credly.Functions.Infrastructure.ServiceBus
{
    public interface IQueueService
    {
        Task SendAsync(string payload);
    }
}